the sequence that works even though not all steps might be needed is

1) configure JDK to 1.7 if needed in Tomcat v.7.0 server configuration.
2) ensure Tomcat v.7.0 launch configuration points to the right directories 
for Tomcat and external-config files of the project
3) execute "gradle eclipse" in core-services and group-schedule projects
4) refresh the workspace or above 2 projects only
5) start Tomcat and go to http://localhost:8080/group-schedule/main.html
6) if something does not work it might be that mySQL is down, or data is
   missing, or prior to "gradle eclipse" or after it developer must execute 
   "gradle war" to ensure pre-processing classes are generated and they 
   together with source classes are all compiled and made available to 
   Tomcat.
   
known issues:
LogInterceptor class not found (the sequence above must address the issue)   

todos:
1) UI component "schedulines" calls directly executeDeleteEvent, which 
couples it tightly to specific function. Would be cleaner if there is 
model injected in the UI, which upon update is internally synchronized 
with the services.

http://www.appelsiini.net/2009/10/html5-drag-and-drop-multiple-file-upload


1) $('td[data-coordinates=""]', '#scheduXXX') does not work. must be addressed
	$('td').click(function() { //'#schedulines'  
		alert('SORT'); //[data-coordinates="[1,1,1]"]
		GS.sortUsers(true);
		initSchedulines();
	});

	
		$('td').click(function() { //#schedutable  
		//alert('SORT'); //[data-coordinates="[1,1,1]"]
		GS.sortUsers(true);
		initSchedutable();
	});
	
2) sorting by position in weekly view has some problems with Mary Gas
3) contentable.js
// temporary {
			var coordinates = $(this).closest('td.contentcell').attr('data-coordinates');
			coordinates = JSON.parse(coordinates);
			if (coordinates[0] == 1 && coordinates[1] == 1 && coordinates[2] == 1) {
				return true;
			} // } temporary
4) problem to think about
this solution might not work in schedulines view when user has 2 or more positions
	//, but the first found position does not have an event on that same day; however, another
	// position (may be the second in line) does have an event on that same day.
	
5) initSchedulines(loadedEvents) and initSchedutable(loadedEvents)	
can be used to speed up sorting. the events will be read prior to sorting and stored in loadedEvents
and when sorting is completed loadedEvents will be passed to initScheduXXX functions to minimize the 
network traffic.

btw, these loadedEvents could be used to address 4)