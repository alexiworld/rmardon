package com.coloredshapes.groupschedule.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Stamp.class)
public abstract class Stamp_ {

	public static volatile SingularAttribute<Stamp, String> invocationContext;
	public static volatile SingularAttribute<Stamp, String> updateUser;
	public static volatile SingularAttribute<Stamp, String> createUser;
	public static volatile SingularAttribute<Stamp, DateTime> updateDateTime;
	public static volatile SingularAttribute<Stamp, DateTime> createDateTime;

}

