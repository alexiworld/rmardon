var GS = initGS();

function initGS() {
	var t = this;
	
	// exports
	t.logout           = logout;
	t.getContext       = getContext;
	
	t.setWeekStartTime = setWeekStartTime;
	t.getWeekStartTime = getWeekStartTime;
	t.getWeekEndTime   = getWeekEndTime;
	
	t.setDayStartTime  = setDayStartTime;
	t.getDayStartTime  = getDayStartTime;
    t.getDayEndTime    = getDayEndTime;
    
    t.prevWeek         = prevWeek;
    t.nextWeek         = nextWeek;
    t.prevDay          = prevDay;
    t.nextDay          = nextDay;

	t.groupsScript     = null; // search for groupsScript in this same file
	t.initSchedutable  = null; // search for initSchedutable in schedutable.jsp
	t.initSchedulines  = null; // search for initSchedulines in schedulines.jsp

	t.asc              =  1; // not used yet
	t.desc             = -1; // not used yet
	t.orderOf          = []; // not used yet
	t.sortUsers        = sortUsers;
	t.getStatisticsByDays  = getStatisticsByDays;
	t.setStatisticsByDays  = setStatisticsByDays;
	t.getStatisticsByUsers = getStatisticsByUsers;
	t.setStatisticsByUsers = setStatisticsByUsers;

	t.loadImage         = loadImage;
	t.addImageToCache   = addImageToCache; 
	t.clearImageCache   = clearImageCache; 

	t.putIntoGlobalCache    = putIntoGlobalCache; 
	t.getFromGlobalCache    = getFromGlobalCache; 
	t.removeFromGlobalCache = removeFromGlobalCache; 
	t.clearGlobalCache      = clearGlobalCache; 

	// locals
	var loggingOut       = false;
	var weekStartTime, weekEndTime;
	var dayStartTime, dayEndTime;
	var statisticsByDays;
	var imageCache = {};
	var globalCache = {};

	function logout() {
		loggingOut = true;
		document.location.href='logout.html';
	}

	function getContext() {
		var protocol = $(location).attr('protocol');
	    var host     = $(location).attr('host');
		var URL  = protocol + '//' + host + '/group-schedule';
		return URL;
	}
	
	function setWeekStartTime(wst) {
    	weekStartTime = getMonday(wst.clone());  
    	weekEndTime   = weekStartTime.clone().addDays(7); 
    	weekEndTime.setMilliseconds(-1);
    	
    	if (!dayStartTime) {
    		dayStartTime = weekStartTime.clone();
        	dayEndTime   = dayStartTime.clone().addDays(1); 
        	dayEndTime.setMilliseconds(-1);
    	} else if (!dayStartTime.between(weekStartTime, weekEndTime)) {
    		var day = dayStartTime.getDay();
    		dayStartTime = weekStartTime.clone().addDays(day);
        	dayEndTime   = dayStartTime.clone().addDays(1); 
        	dayEndTime.setMilliseconds(-1);
    	}
	} 
	
	function getWeekStartTime() {
    	return weekStartTime;
	}

	function getWeekEndTime() {
    	return weekEndTime;
	}

	function setDayStartTime(dst) {
    	dayStartTime = dst.clone();  
    	dayEndTime   = dayStartTime.clone().addDays(1); 
    	dayEndTime.setMilliseconds(-1);
    	
    	// NOTE: In case day start time moves to another week
    	// we need to readjust the week start and end times.
    	if (!dayStartTime.between(weekStartTime, weekEndTime)) {
    		setWeekStartTime(dayStartTime);
    	}
	}

	function getDayStartTime() {
    	return dayStartTime;
	}

	function getDayEndTime() {
    	return dayEndTime;
	}
	
	function prevWeek() {
		weekStartTime.addDays(-7);
		weekEndTime.addDays(-7);
		
		dayStartTime.addDays(-7);
		dayEndTime.addDays(-7);
	}
	
	function nextWeek() {
		weekStartTime.addDays(+7);
		weekEndTime.addDays(+7);
		
		dayStartTime.addDays(+7);
		dayEndTime.addDays(+7);
	}
	
	function prevDay() {
		dayStartTime.addDays(-1);
		dayEndTime.addDays(-1);
		setWeekStartTime(dayStartTime);
	}
	
	function nextDay() {
		dayStartTime.addDays(+1);
		dayEndTime.addDays(+1);
		setWeekStartTime(dayStartTime);
	}
	
	function getStatisticsByDays() {
		return statisticsByDays;
	}

	function setStatisticsByDays(stat) {
		statisticsByDays = stat;
	}
    
	function getStatisticsByUsers() {
		return statisticsByUsers;
	}

	function setStatisticsByUsers(stat) {
		statisticsByUsers = stat;
	}

	function sortUsers(incrementSortBy) {
		if (!GS.sortBy) GS.sortBy = 0;

    	switch (GS.sortBy % 4) {
			case 0: { // users asc
				sortByUsers(+1);
				break;
			}
			case 1: { // users desc
				sortByUsers(-1);
				break;
			}
			case 2: { // position,user asc
				sortByUserPositions(+1);
				break;
			}
			case 3: { // position,user desc
				sortByUserPositions(-1);
				break;
			}
		}

    	var selectedGroup = GS.groupsScript.getSelectedGroup();
		$.each(selectedGroup.users, function(index, user) {
			user.sequence = index + 1;
		}); 

		/* debug, please remove when done { 
		$.each(selectedGroup.users, function(index, user) {
			console.log(user.name + '->' + user.sequence);
		});
		} debug, please remove when done */

		if (incrementSortBy) {
			GS.sortBy++;
		}
	}
	
	function sortByUsers(factor) {
		//console.log('<-u' + factor + '------------------------------------->');
		var selectedGroup = GS.groupsScript.getSelectedGroup();
		selectedGroup.users = selectedGroup.users.sort(function(user1, user2) {
			return factor*strcmp(user1.name, user2.name);
		});
	}
	
	function sortByUserPositions(factor) {
		//console.log('<-up' + factor + '------------------------------------->');
		var selectedGroup = GS.groupsScript.getSelectedGroup();
		selectedGroup.users = selectedGroup.users.sort(function(user1, user2){
			var position1 = getUserFirstPosition(user1);
			var position2 = getUserFirstPosition(user2);
			
			var diff = strcmp(position1, position2);
			if (diff == 0) {
				diff = strcmp(user1.name, user2.name);
			}
			
			var res = factor*(diff == 0 ? 0 : (diff > 0 ? 1: -1));
			//console.log('>>' + user1.name + '-' + position1 + '-' + user2.name + '-' + position2 + '<<');
			return res;
		});
	}

	//TODO: this solution might not work in schedulines view when user has 2 or more positions
	//, but the first found position does not have an event on that same day; however, another
	// position (may be the second in line) does have an event on that same day.
	// eventually selection could be based on priority e.g. position with highest pay rate
	function getUserFirstPosition(user) { // if one is available, if not the first enlisted
		var positionName;
		
		var selectedGroup = GS.groupsScript.getSelectedGroup();
		if (user.details && user.details.assignments) {
			$.each(user.details.assignments, function(index, assignment) {
				if (assignment && assignment.status == 'ACTIVE') {
					if (assignment.role) {
						$.each(selectedGroup.positionIds, function(index, positionId) {
							if (assignment.role.id == positionId) {
								positionName = assignment.role.name;
								return false; // break out the loop
							}
						});
					} else if (assignment.roleId) {
						$.each(selectedGroup.positions, function(index, position) {
							if (assignment.roleId == position.id) {
								if (position.groupId == selectedGroup.id) {
									positionName = position.name;
									return false; // break out the loop
								}
							}
						});
					}
					if (positionName) return false; // break out the loop
				}
			});
		}
		
		if (!positionName) {
			positionName = '';
		}
		
		return positionName;
	}
	
	function loadImage(imageURL, callback) { 
		var image = getImageFromCache(imageURL);
		if (image) {
			callback(image.clone());
		} else {
			$('<img>').load(function(){
				image = $(this);
				addImageToCache(imageURL, image);
				callback(image.clone());
			})
			.error(function(){
			})
			.attr('src', imageURL);
		}
	}

	function getImageFromCache(key) {
		return imageCache[key];
	}

	function addImageToCache(key, value) {
		imageCache[key] = value;
	}
	
	function clearImageCache() {
		imageCache = {}
	}
	
	function putIntoGlobalCache(key, value) {
		globalCache[key] = value;
	}
	
	function getFromGlobalCache(key) {
		return globalCache[key];
	}
	
	function removeFromGlobalCache(key) {
		var value = globalCache[key];
		globalCache[key] = undefined;
		return value;
	} 
	
	function clearGlobalCache() {
		var oldGlobalCache = globalCache;
		globalCache = {}
		delete oldGlobalCache;
	} 

	function init() {
    	var wst = Date.parse("monday"); // Date.parse('3/4/2013');  
    	setWeekStartTime(wst);          // Date.parse('3/10/2013');
	}
	
	init();
	
	return t;
}

(function($) { 
	/* function body here */ 
    $(document).ready(function() {
        GS.hideAllViews        = hideAllViews;
        GS.showHomeView        = showHomeView;
        GS.showGroupsView      = showGroupsView;
        GS.showSchedutableView = showSchedutableView;
        GS.showSchedulinesView = showSchedulinesView;
        GS.showReportsView     = showReportsView;
        GS.showContactusView   = showContactusView;
    	
    	initAllViews();
    	showHomeView(); updateBreadcrumb(['Home']);
    	//showGroupsView(); updateBreadcrumb(['Groups']);
    	
    	$(document).bind('keydown', 'alt+ctrl+s', function() {
            alert('This could redirect the user to:' + '\r\r' + '    My Own Schedule' + '\r');
        });
        $(document).bind('keydown', 'alt+ctrl+f', function() {
            alert('This could redirect the user to:' + '\r\r' + '    My Own Favorites' + '\r');
        });
        $(document).bind('keydown', 'alt+ctrl+m', function() {
            alert('This could launch the Messages modal popup' + '\r\r');
        });
        $(document).bind('keydown', 'alt+ctrl+p', function() {
            alert('This could redirect the user to:' + '\r\r' + '    User Preferences' + '\r');
        });
        $('#logout').click(logout);

        function initAllViews() {
        	// TODO: Lazy init views
        	var siteContent = $('.site-content');
        	siteContent.empty();
        	$('#home-view').appendTo(siteContent).hide();
        	$('#groups-view').appendTo(siteContent).hide();
        	$('#schedutable-view').appendTo(siteContent).hide();
        	$('#schedulines-view').appendTo(siteContent).hide();
        	$('#reports-view').appendTo(siteContent).hide();
        	$('#contactus-view').appendTo(siteContent).hide();
        	//setTimeout(function() {
        	//	$('#schedulines-view').hide();
        	//}, 10);
        	adjustSiteContent();
            adjustHomeImage();
        }
        
        function adjustSiteContent() {
        	var toolbar = $('.toolbar-body-wrapper-row');
        	var siteFooter = $('.site-footer'); 
        	var marginTop    = toolbar.position().top + toolbar.innerHeight() + 4; 
        	var marginBottom = siteFooter.outerHeight();
        	var siteContentHeight = $(window).height() - marginTop - marginBottom - 10;
        	$('.site-content').height(siteContentHeight);
        }
        
        function adjustHomeImage() {
        	// Take into consideration the space consumed by the header (logo and toolbar)
    		var toolbar = $('.toolbar-body-wrapper-row');
    		var footer  = $('footer');
    		var marginTop    = toolbar.position().top + toolbar.innerHeight() + 4; 
    		var marginBottom = footer.outerHeight();
    		var homeImageHeight = $(window).height() - marginTop - marginBottom - 30;

        	$('#homeImage').height(homeImageHeight);
        }
        
        function hideAllViews() {
        	$('#home-view').hide();
        	$('#groups-view').hide();
        	$('#schedutable-view').hide();
        	$('#schedulines-view').hide();
        	$('#reports-view').hide();
        	$('#contactus-view').hide();
        }
        
        function showHomeView() {
        	hideAllViews();
        	$('#home-view').show();
        }
        
        function showGroupsView() {
        	hideAllViews();
        	initGroupsView();
        	$('#groups-view').show();
        }
        
        function initGroupsView() {
        	var groupsView = $('#groups-view');
        	if (groupsView.children().size() == 0) {
        		groupsView.load('groups', function(responseText, textStatus, jqXHR) {
        			if (jqXHR.status === 401) {
        				//logout
        			}
        			// textStatus == 'success' or
        			if (jqXHR.status === 200) { // export
        				GS.groupsScript = initGroupsScript();
        			}
        		});
        	}
        }

        function showSchedutableView() {
        	var schedutableView = $('#schedutable-view');
        	if (schedutableView.children().size() == 0) {
        		schedutableView.load('schedutable');
        	}
        	hideAllViews();
        	schedutableView.show();
        	
        	$('#SchedutableStartingDate', ".schedutableRightToolbar").val(GS.getWeekStartTime().toString('MM/dd/yyyy'));
        	if (GS.initSchedutable) { GS.initSchedutable(); }
        }
    
        function showSchedulinesView() {
        	var schedulinesView = $('#schedulines-view');
        	if (schedulinesView.children().size() == 0) {
        		schedulinesView.load('schedulines');
        	}
        	hideAllViews();
        	schedulinesView.show();
        	
        	$('#SchedulinesStartingDate', ".schedulinesRightToolbar").val(GS.getDayStartTime().toString('MM/dd/yyyy'));
        	if (GS.initSchedulines) { GS.initSchedulines(); }
        }
    
        function showReportsView(reportType) {
        	var reportsView = $('#reports-view');
        	reportsView.empty();
        	//if (reportsView.children().size() == 0) {
        		var selectedGroup = GS.groupsScript.getSelectedGroup();
        		reportsView.load('reports/' + reportType + '?groupId=' + selectedGroup.id, function() { // 'reports', 'reports/user_pays'
            		//var toolbar       = $('.toolbar-body-wrapper-row');
            		//var marginTop     = toolbar.position().top + toolbar.innerHeight() + 4; // 30;
            		var reportparams  = $('#reportparams-container');
            		var marginTop     = reportparams.position().top + reportparams.innerHeight() + 4; // 30;
            		var marginBottom  = $('.site-footer').innerHeight() + 10;
            		var windowHeight  = $(window).height();
            		var reportsHeight = windowHeight - marginTop - marginBottom;
            		$('#reports-container').height(reportsHeight);
        		});
        	//}
    		hideAllViews();
    		reportsView.show();
        }
    
        function showContactusView() {
        	var contactusView = $('#contactus-view');
        	if (contactusView.children().size() == 0) {
        		/*
	        		$.getScript("scripts/contacts/contacts.js")
        			.done(function(script, textStatus) {
	        			console.log("Loaded contacts.js script");
	        			$("#OnTheMap").show();
	        		})
	        		.fail(function(jqxhr, settings, exception) {
	        			console.log(exception);
	        			console.log("Failed to load contacts.js script.");
	        		});
		        */

        		contactusView.load('contacts');
        	}

    		hideAllViews();
        	contactusView.show();
        }
        
        function closeDropDownHavingALink(link) {
        	link.closest('.drop-down-menu').parent().children('.has-drop-down').trigger('click');
        }
        
        function updateBreadcrumb(path) {
        	var breadcrumb = '<span class="breadcrumb-ancestors">';
        	for (var i = 0; i < path.length -1; i++) {
        		breadcrumb += path[i];
        		breadcrumb += ' &gt; ';
        	}
        	breadcrumb += '</span>';
        	breadcrumb += path[path.length - 1];
        	$('.breadcrumb').html(breadcrumb);
        }

        $('#homeMenu').click(function() {
        	showHomeView();
        	updateBreadcrumb(['Home']);
        })
        
        $('#groupsMenu').click(function() {
        	showGroupsView();
        	updateBreadcrumb(['Groups']);
        	return false;
        })
        
        $('#menupos31').click(function() {
        	// NOTE: The following was not needed if the element is assigned class="user-link"
        	// closeDropDownHavingALink($(this));
        	showSchedutableView();
        	updateBreadcrumb(['Schedule', 'Weekly schedule']);
        	return false;
        })
        
        $('#menupos32').click(function() {
        	// NOTE: The following was not needed if the element is assigned class="user-link"
        	// closeDropDownHavingALink($(this));
        	showSchedulinesView();
        	updateBreadcrumb(['Schedule', 'Daily schedule']);
        	return false;
        })
        
        $('.reportLink').click(function() {
        	// NOTE: The following was not needed if the element is assigned class="user-link"
        	// closeDropDownHavingALink($(this));
        	var reportType = $(this).attr('data-type');
        	showReportsView(reportType);
        	
        	var subSubmenuText = $(this).text();
        	var closestLev3    = $(this).closest('div.lev3');
        	var submenuId      = closestLev3.attr('id').split('menulev3-')[1];
        	var submenuText    = $('#menupos' + submenuId).text();
        	var menuText       = closestLev3.closest('li').children('a').text();
        	updateBreadcrumb([menuText, submenuText, subSubmenuText]);
        	
        	return false;
        })
        
        $('#contactUsMenu').click(function() {
        	showContactusView();
        	updateBreadcrumb(['Contact Us']);
        	return false;
        })
    });
})(jQuery);
