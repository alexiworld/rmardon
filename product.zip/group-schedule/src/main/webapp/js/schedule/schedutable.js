(function($, undefined) {

stripes = new Array('', ' horizontal stripes', ' angled-135 stripes', ' vertical stripes', ' angled stripes');
//var counter = 2000000;

var st = $.schedutable = { version: "1.0.0" };
var stViews = st.views = {};

st.sourceNormalizers = [];
st.sourceFetchers = [];

var defaults = {
}

var ajaxDefaults = {
	dataType: 'json',
	cache: false
};

$.fn.schedutable = function(options) {
	// method calling
	if (typeof options == 'string') {
		var args = Array.prototype.slice.call(arguments, 1);
		var res;
		this.each(function() {
			var schedutable = $.data(this, 'schedutable');
			if (schedutable && $.isFunction(schedutable[options])) {
				var r = schedutable[options].apply(schedutable, args);
				if (res === undefined) {
					res = r;
				}
				if (options == 'destroy') {
					$.removeData(this, 'schedutable');
				}
			}
		});
		if (res !== undefined) {
			return res;
		}
		return this;
	}
	
	// would like to have this logic in ContentManager, but needs to happen before options are recursively extended
	var eventSources = options.eventSources || [];
	//delete options.eventSources; // commented because options might be shared with other components
	if (options.events) {
		eventSources.push(options.events);
		//delete options.events;   // commented because options might be shared with other components
	}

	options = $.extend(true, {},
		defaults,
		options
	);
	
	this.each(function(i, _element) {
		var element = $(_element);
		var schedutable = new Schedutable(element, options, eventSources);
		element.data('schedutable', schedutable); 
	});
	
	return this;
};

function Schedutable(element, options, eventSources) {
	var t = this;

	// exports
	t.options = options;
	t.addEventSource = addEventSource;
	t.removeEventSource = removeEventSource;
	t.addEvent     = addEvent;
	t.addEvents    = addEvents;
	t.updateEvent  = updateEvent;
	t.updateEvents = updateEvents;
	t.removeEvents = removeEvents;
	t.getEventSources = getEventSources;
	t.getEvents       = getEvents;
	t.isChanged       = isChanged;
	t.calculateStatistics = calculateStatistics;
	t.updateStatistics    = updateStatistics;
	
	// imports
	
	// locals
	var startTime = options.startTime, endTime = options.endTime;
	if (startTime > endTime) throw "Start time must be prior the end time.";
	
	function getContentable() {
		return 	element.data('contentable'); 
	}
	
	function isChanged() {
		getContentable().isChanged();
	}
	
	var datesContentSource = [];
	datesContentSource.push({ content: 'Users', type: 0, coordinates: [1, 1, 1]}); // Employee replaced by Users
	var date = new Date(startTime), i = 2;
	while (date.getTime() <= endTime.getTime()) {
		datesContentSource.push({ date: date, content: date.toString("ddd dd/MM/yy"), type: 0, coordinates: [1, 1, i++]});
		date = date.addDays(1);
	}

	i = 2;
	var usersContentSource = $.map(options.users(), function(user, index) {
		/*
		var imageFile;
		switch (index%7) { 
			case 0: imageFile = 'Jamie';     break; 
			case 1: imageFile = 'Frederico'; break;
			case 2: imageFile = 'Jamie';     break;
			case 3: imageFile = 'Rajib';     break;
			case 4: imageFile = 'Yuping';    break;
			case 5: imageFile = 'Biljana';   break;
			case 6: imageFile = 'Elaine';    break;
		}
		var imageTag = '<img width="" src="images/photos/' + imageFile + '.png" style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
		*/
		
		/*
		var imageURL = GS.getContext() + '/proxy/read/user[' + user.id + ']';
		var imageTag = '<img class="userPhoto" src="' + imageURL + '" style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
		*/
		
		var imageTag = '<img class="userPhoto" data-id="' + user.id + '"' 
			         + 'src="css/groups/images/person32x32.png" ' 
			         + 'style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
		var nameTag  = '<div style="float: left;">' + user.name + '</div>';
		var statTag  = '<div style="float: right;" class="userstat" data-id="' + user.id + '"></div>';
		var content  = imageTag + nameTag + statTag; 

		return { user: user, content: content, type: 0, coordinates: [1, i++, 1]};
	});

	var statContentSource = [];
	for (j = 1; j < 9; j++) {
		//statContentSource.push({content: '<span class="stat" data-id="' + j + '" onclick="alert(' + j + '); return true;">STAT</span>', type: 0, coordinates: [1, i, j]});
		var content = '<span class="stat' + (j == 1 ? '' : ' identifier') + '" data-id="' + j + '"></span>';
		statContentSource.push({content: content, type: 0, coordinates: [1, i, j]});
	}
	
	var eventsContentSource = $.map(eventSources, function(eventSource, index) {
		return toContentSource(eventSource);
	});
	
	var contentSources = eventsContentSource.concat([datesContentSource]).concat([usersContentSource]).concat([statContentSource]);
	
	element.contentable({
		contentSources: contentSources,
		start: startTime,
		end: endTime,
		className: function(content) {
			if (!content) { content = this; }
			
			if (content.type > 0) {
				if (content.type%2 === 0) { return horizontalStripes; }
				if (content.type%2 === 1) { return verticalStripes;   }
			} else {
				if (content.event && !content.event.position) {
					return diagonalStripes;
				}
			}
		
			return '';
		},
		style: function(content) {
			if (!content) { content = this; }
			
			if (content.event && content.event.position && content.event.position.color) {
				return 'background-color: #' + content.event.position.color;
			}
		
			return '';
		},
		renderContent: function(content) {
			if (!content) { content = this; }
			
			var coordinates = content.coordinates;
			if (coordinates[0] === 1 && coordinates[1] === 1) {        // leading row
				if (coordinates[2] == 1) { // 'Users' content needs class 'sortswitcher'
					return '<span class="header sortswitcher">' + this.content + '</span>';
				} else {
					return '<span class="header">' + this.content + '</span>';
				}
			} else if (coordinates[0] === 1 && coordinates[2] === 1) { // leading column
				return '<span class="identifier">' + this.content + '</span>';
			} else {
				if (content.type >= 0){ // all positive types are visible
					return this.content;
				} else {                // all negative types are invisible
					return ''; 
				}
			}
		},
		addContent: function(coordinates, event) {
			//return { id: ++counter, content: '8:00-16:00 New', type: 2, coordinates: coordinates};
			var date = new Date(startTime).addDays(coordinates[2] - 2); // -1 to exclude the leading column
			clearTime(date);
			
			$.each(options.users(), function(index, user) {
				// User identifiers do not appear in sequential order,
				// which would require the use of index for the list.
				// if (user.id == coordinates[1] - 1) {
				if (index + 1 == coordinates[1] - 1) {
					options.addEvent(user, date, function(event) {
						if (event) { addEvent(event); updateStatistics(false); } 
					}); 					
					return false; // break
				}
			});
		},
		editContent: function(content, event) {
			/*
			alert(JSON.stringify(content, function replacer(key, value) {
				// http://www.json.org/js.html
				// http://stackoverflow.com/questions/13861254/json-stringify-deep-objects
				if (key === 'source') {
					return '';
				}
				return value;
			}));
			*/
			
			var coordinates = content.coordinates;
			if (coordinates[0] == 1 && coordinates[1] == 1) {
				if (coordinates[2] > 1) {
					//switch to daily view
					var dayStartTime = GS.getWeekStartTime().clone().addDays(coordinates[2] - (1+1)); // 1 to exclude Employee column, 1 to take into consideration Monday is 0, etc.
					GS.setDayStartTime(dayStartTime);
					GS.showSchedulinesView();
				}
				return null;
			}
			
			var originalEvent = event = toEvent(content);
			if (!event) return; // no event for editing
			
			options.editEvent(event.user, event, function(event) {
				if (event) {
					// NOTE: The event returned might be a different object or with a changed id.
					// Updating an event in core services at the present time is implemented as 
					// two consecutive operations - delete and add. Why? Releasing alpha earlier.
					// Therefore, updateEvent would not work properly in this case and require a
					// temporary fix until implementation in core services change. Alternatively,
					// a second id could be used in contentable.js' renderContent to locate the
					// content on the screen, but must be carefully considered to prevent issues.
					// updateEvent(event); 
					removeEvents(originalEvent.id);
					if (!originalEvent.deleted) {
						addEvent(event);
					}

					// TODO: Calculations could be speed up by manipulating
					// existing statistics object - GS.getStatisticsByDays().
					// and calling updateStatistics.
					// It voids the need of calling getCalculatedStatistics()
					calculateStatistics();
					updateStatistics(false);
				} 
			});

			/*
			if (content) {
				if (content.className ===  verticalStripes) {
					content.className = horizontalStripes;
				} else if (content.className ===  horizontalStripes) {
					content.className = diagonalStripes;
				} else if (content.className ===  diagonalStripes) {
					content.className = verticalStripes;
				}
			}
			
			return content;
			*/
		},
		dropContent: function(coordinates, content, uiEvent, callbackDropConent) {
			var dayDiff = coordinates[2] - content.coordinates[2];
			$.each(options.users(), function(index, user) {
				// User identifiers do not appear in sequential order,
				// which would require the use of index for the list.
				// if (user.id == coordinates[1] - 1) {
				if (index + 1 == coordinates[1] - 1) {
					var userEvent = toEvent(content);		
					
					// calculate the new dates and times
					var newStartTime = new Date(userEvent.startTime).addDays(dayDiff).getTime(); 
					var newEndTime   = new Date(userEvent.endTime).addDays(dayDiff).getTime();
					
					var eventToSave = $.extend(false, 
						{},
						userEvent,
						{ 
							user:      user,
							startTime: newStartTime, 
							endTime:   newEndTime,
						}
					); 
					
					var callbackSaveEvent = function() {
						userEvent.id        = eventToSave.id;
						userEvent.user      = eventToSave.user;
						userEvent.startTime = eventToSave.startTime;
						userEvent.endTime   = eventToSave.endTime;
						callbackDropConent(); // reflect the change on the screen
					}

					saveEvent(eventToSave, callbackSaveEvent);

					// TODO: Calculations could be speed up by manipulating
					// existing statistics object - GS.getStatisticsByDays().
					// and calling updateStatistics.
					// It voids the need of calling getCalculatedStatistics()
					calculateStatistics();
					updateStatistics(false);
					
					return false; // break
				}
			});
		},
		clickable: function(coordinates) {
			return true;
		},
		draggable: function(coordinates, content, event) {
			if (coordinates[0] === 1 && (coordinates[1] === 1 || coordinates[2] === 1)) {
				return false;
			}
			
			var event = toEvent(content);
			if (!event) {
				return false;
			}
			
			return true;
		},
		droppable: function(coordinates, content, event) {
			if (coordinates[0] === 1 && (coordinates[1] === 1 || coordinates[2] === 1)) {
				return false;
			}
			
			// Check for conflicting types e.g. user receiving the event already
			// has assigned a different event having the same position type and
			// on the exact same day.
			
			var conflictingTypes = false;
			var contents = getContentable().getContents();
			$.each(contents, function(i, c) {
				if (c != content && c.id != content.id) {
					if (matchingCoordinates(coordinates, c.coordinates)) {
						if (c.type == content.type) {
							conflictingTypes = true;
							return false;
						}
					}
				}
			});
			
			if (conflictingTypes) {
				return false;
			}
			
			// Check if the user taking over the dropped event has been assigned
			// the event position. If not, the operation is not permitted.

			var userEvent = toEvent(content);
			
			var assignment;
			$.each(options.users(), function(index, user) {
				// User identifiers do not appear in sequential order,
				// which would require the use of index for the list.
				// if (user.id == coordinates[1] - 1) {
				if (index + 1 == coordinates[1] - 1) {
					assignment = getUserAssignment(user, userEvent.position);
					return false; // to break out of the loop
				}
			});
			
			if (!assignment) return false;
			
			return true;
		},
		renderCompleted: function() {
			calculateStatistics();
			updateStatistics(false);
			
			// Clicking on total or daily stats results in switching the type
			var statTotalUI = $(".stat", element); // $(".stat[data-id='1']");
			statTotalUI.click(function() {
				updateStatistics(true);
			});
			var statUserUI = $(".userstat", element); 
			statUserUI.click(function() {
				updateStatistics(true);
			});
				
			loadPhotos();
		}
	});
	
	function updateStatistics(switchType) {
		var statTotalUI = $(".stat[data-id='1']", element);
		
		var type = statTotalUI.data('type');
		if (type == undefined) { 
			type = 0; 
		} else if (switchType) {
			type++;
		}
		
		renderCalculatedStatistics(type % 4);
		statTotalUI.data('type', type);
	}
	
	function renderCalculatedStatistics(type) {
		// Render statistics by day
		var statisticsByDays = GS.getStatisticsByDays();
		var total = 0;
		if (!statisticsByDays) {
			$('.stat', element).each(function(idx, stat) { $(this).html(""); });
		} else if (statisticsByDays.length == 0) {
			$('.stat', element).each(function(idx, stat) { $(this).html(renderByDayByType(0, type)) });
		} else {
			$.each(statisticsByDays, function(index, statisticsByDay) {
				if (!statisticsByDay) return true;
				var number = extractByDayByType(statisticsByDay, type);
				total = totalByType(total, number, type);
				$('.stat[data-id="' + index + '"]', element).html(renderByDayByType(number, type));
			});
		}
		$('.stat[data-id="1"]', element).html('Total: ' + renderByDayByType(total, type));

		// Render statistics by user
		var statisticsByUsers = GS.getStatisticsByUsers();
		if (!statisticsByUsers) {
			$('.userstat', element).each(function(idx, stat) { $(this).html(""); });
		} else if (statisticsByUsers.length == 0) {
			$('.userstat', element).each(function(idx, stat) { $(this).html(renderByUserByType(0, type)) });
		} else {
			/*
			$.each(statisticsByUsers, function(index, statisticsByUser) {
				if (!statisticsByUser) return true;
				var number = extractByUserByType(statisticsByUser, type);
				$('.userstat[data-id="' + index + '"]', element).html(renderByUserByType(number, type));
			});
			*/
			for (var index in statisticsByUsers) {
				var statisticsByUser = statisticsByUsers[index]; 
				if (!statisticsByUser) continue;
				if ($.isFunction(statisticsByUser)) break; // for-in could returns a function e.g. Array.prototype.first
				var number = extractByUserByType(statisticsByUser, type);
				$('.userstat[data-id="' + index + '"]', element).html(renderByUserByType(number, type));
			}
		}
	}

	function totalByType(total, number, type) {
		switch(type) {
			case 0: return total + number;
			case 1: return total + number;
			case 2: return Math.max(total, number);
			case 3: return Math.max(total, number);
			default: return total + number;
		}
	}

	function renderByDayByType(value, type) {
		switch(type) {
			case 0: return '$' + value;
			case 1: return value + ' hrs';
			case 2: return value + (value == 1 ? ' person' : ' people');
			case 3: return value + ' position' + (value == 1 ?  '' : 's');
			default: return '$' + value;
		}
	}

	function extractByDayByType(statisticsByDay, type) {
		switch(type) {
			case 0: return statisticsByDay.totalCost;
			case 1: return statisticsByDay.totalHours;
			case 2: return statisticsByDay.users.length;
			case 3: return statisticsByDay.positions.length;
			default: return statisticsByDay.totalCost;
		}
	}
	
	function renderByUserByType(value, type) {
		switch(type) {
			//case 0: return '$' + value;
			//case 1: return value + ' hrs';
			case 0: return (value > 0 ? '$' + value    : '');
			case 1: return (value > 0 ? value + ' hrs' : '');
			case 2: return '';
			case 3: return (value > 1 ? value + ' pos' : '');
			default: return '$' + value;
		}
	}

	function extractByUserByType(statisticsByUser, type) {
		switch(type) {
			case 0: return statisticsByUser.totalCost;
			case 1: return statisticsByUser.totalHours;
			case 2: return 1;
			case 3: return statisticsByUser.positions.length;
			default: return statisticsByUser.totalCost;
		}
	}
	
	function calculateStatistics() {
		calculateDayStatistics();
		calculateUserStatistics();
	}
	
	function calculateDayStatistics() {
		var statisticsByDays  = [];
		var contents = getContentable().getContents();
		$.each(contents, function(index, content) {
			var event = toEvent(content);
			if (event && event.position) {
				// Calculate statistics by day
				var day = content.coordinates[2];
				var statisticsByDay = statisticsByDays[day]; 
				if (!statisticsByDay) {
					statisticsByDay = {
						contents: [],
						users: [],
						positions: [],
						totalHours: 0,
						totalCost: 0
					}
					statisticsByDays[day] = statisticsByDay;
				} 
				statisticsByDay.contents.push(content);

				var eventHours = (event.endTime - event.startTime) / 3600000; // 60 min/h * 60 sec/min * 1000 ms/sec
				var eventCost  = eventHours * event.position.assignedRate;

				statisticsByDay.totalHours += eventHours;
				statisticsByDay.totalCost  += eventCost;

				if ($.inArray(event.user.id, statisticsByDay.users) < 0) {
					statisticsByDay.users.push(event.user.id);
				}
				if ($.inArray(event.position.id, statisticsByDay.positions) < 0) {
					statisticsByDay.positions.push(event.position.id);
				}
			}
		});
		GS.setStatisticsByDays(statisticsByDays);
	}
	
	function calculateUserStatistics() {
		var statisticsByUsers = [];
		var contents = getContentable().getContents();
		$.each(contents, function(index, content) {
			var event = toEvent(content);
			if (event && event.position) {
				// Calculate statistics user by user
				var user = event.user;
				var statisticsByUser = statisticsByUsers[user.id];
				if (!statisticsByUser) {
					statisticsByUser = {
						contents: [],
						positions: [],
						totalHours: 0,
						totalCost: 0
					}
					statisticsByUsers[user.id] = statisticsByUser;
				}
				statisticsByUser.contents.push(content);
				
				var eventHours = (event.endTime - event.startTime) / 3600000; // 60 min/h * 60 sec/min * 1000 ms/sec
				var eventCost  = eventHours * event.position.assignedRate;

				statisticsByUser.totalHours += eventHours;
				statisticsByUser.totalCost  += eventCost;

				if ($.inArray(event.position.id, statisticsByUser.positions) < 0) {
					statisticsByUser.positions.push(event.position.id);
				}
			}
		});
		
		GS.setStatisticsByUsers(statisticsByUsers);
	}

	function loadPhotos() {
		$('.userPhoto', t.ui).each(function(index, userPhoto) {
			userPhoto = $(userPhoto);
			var userId = userPhoto.attr('data-id');
			var imageURL = GS.getContext() + '/proxy/read/user[' + userId + ']';
			var css = { width: '30px', height: '30px', float: 'left', 'margin-right': '5px' };
			GS.loadImage(imageURL, function(image) {
				userPhoto.replaceWith(image.css(css));
			});
		});
	}
	
    function render() {
		return this.content;
	}
	function renderLeadingRow() {
		return '<span class="header">' + this.content + '</span>';
	}
	function renderLeadingColumn() {
		return '<span class="identifier">' + this.content + '</span>';
	}
	function verticalStripes() {
		return stripes[3];
	}
	function horizontalStripes() {
		return stripes[1];
	}
	function diagonalStripes() {
		return stripes[4]; //stripes[2];
	}
	
	/* Transformation functions
	-----------------------------------------------------------------------------*/
	
	function toEventSources(contentSources) {
		return contentSources.eventSource;
	}
	
	function toEvent(content) {
		// A content presently is created from event thus allowing the 
		// use of the original source. 
		// In other circumstances (e.g. content created from something 
		// else than event) an appropriate conversion would be necessary
		return content.event;
	}

	function toEvents(contents) {
		return $.map(contents, function(content, index) {
			return content.event;
		});
	}

	function toContentSource(source) {
		if ($.isFunction(source) || $.isArray(source)) {
			source = { events: source };
		}
		else if (typeof source == 'string') {
			source = { url: source };
		}
		
		var contentSource = {
			contents: function(rangeStart, rangeEnd, callback) {
				var events = source.events;
				if (events) {
					if ($.isFunction(events)) {
						events(rangeStart, rangeEnd, function(events) {
							var contents = toContents(events);
							callback(contents);
						});
					}
					else if ($.isArray(events)) {
						var contents = toContents(events);
						callback(contents);
					}
					else {
						callback();
					}
				}else{
					var url = source.url;
					if (url) {
						var success = source.success;
						var error = source.error;
						var complete = source.complete;
						var data = $.extend({}, source.data || {});
						var startParam = firstDefined(source.startParam, options.startParam);
						var endParam = firstDefined(source.endParam, options.endParam);
						if (startParam) {
							data[startParam] = rangeStart;
						}
						if (endParam) {
							data[endParam] = rangeEnd;
						}
						$.ajax($.extend({}, ajaxDefaults, source, {
							data: data,
							success: function(events) {
								events = events || [];
								var res = applyAll(success, this, arguments);
								if ($.isArray(res)) {
									events = res;
								}
								var contents = toContents(events);
								callback(contents);
							},
							error: function() {
								applyAll(error, this, arguments);
								callback();
							},
							complete: function() {
								applyAll(complete, this, arguments);
							}
						}));
					}else{
						callback();
					}
				}
			} 
		}
		
		contentSource.eventSource = source;
		return contentSource;
	}
	
	function toContent(event) {
		var eventStartTime = new Date(event.startTime);
		var eventEndTime   = new Date(event.endTime);
		var eventStartDay  = (eventStartTime.getDay() == 0 ? 7 : eventStartTime.getDay()); 
		
		var coordX = 1; // parseInt(event.group.id); Later, if needed to display multiple groups in the same table. It would require changes in contentable.js>renderContents(contents)>var contents = matrix3D[i][j][k]; 
		var coordY = parseInt(event.user.sequence) + 1; // add 1 to compensate for the presence of the leading row; user sequence replaced user id because the latter might even be > number of users to be displayed 
		var coordZ = eventStartDay - startTime.getDay() + 2;  // add 1 to compensate for the presence of the leading column
		
		var content = { 
			event: event, 
			id: event.id, 
			coordinates: [coordX, coordY, coordZ]
		}
		
		if (event.position) {
			content.content  = eventStartTime.toString("HH:mm") + '-' + eventEndTime.toString("HH:mm") + ' ' + event.position.description; 
			content.type     = event.position.id;
		} else {
			content.decorate = 0x0F;
			content.content  = eventStartTime.toString("HH:mm") + '-' + eventEndTime.toString("HH:mm") + ' Not Available'; 
			content.type     = 0;
		}
		
		if (event.source) {
			var contentSourceOfTheEvent;
			var contentSources = getContentable().getContentSources();
			$.each(contentSources, function(index, contentSource) {
				if (contentSource.eventSource == event.source) {
					contentSourceOfTheEvent = contentSource;
				}
			});

			if (!contentSourceOfTheEvent) {
				contentSourceOfTheEvent = toContentSource(event.source);
			}
			content.source = contentSourceOfTheEvent;
		}
		
		return content;
	}
	
	function toContents(events) {
		var contents = [];
		$.each(events, function(index, event) {
			contents.push(toContent(event));
		});
		return contents;
	}
	
	/* Retrieving event sources and events
	-----------------------------------------------------------------------------*/
	
	function getEventSources() {
		return toEventSources(getContentable().getContentSources());
	}
	
	function getEvents() {
		return toEvents(getContentable().getContents());
	};
	
	/* Event Sources
	-----------------------------------------------------------------------------*/

	function addEventSource(source) {
		getContentable().addContentSource(toContentSource(source));
	}
	
	function removeEventSource(source) {
		var contentSources = getContentable().getContentSources();
		sources = $.each(contentSources, function(index, contentSource) {
			if (contentSource.eventSource == source) {
				getContentable().removeContentSource(contentSource);
			}
		});
	}

	/* Events Manipulation
	-----------------------------------------------------------------------------*/

	function addEvent(event) { 
		getContentable().addContent(toContent(event));
	}

	function addEvents(events) { 
		if ($.isArray(events)) {
			for (var i = 0; i < events.length; i++) {
				addEvent(events[i]);
			}
		} else {
			var event = events;
			addEvent(event);
		}
	}	
	
	function updateEvent(event) { 
	    getContentable().updateContent(toContent(event));
	}
	
	function updateEvents(events) { 
		if ($.isArray(events)) {
			for (var i = 0; i < events.length; i++) {
				updateEvent(events[i]);
			}
		} else {
			var event = events;
			updateEvent(event);
		}
	}	
	
	function removeEvents(filter) {
		getContentable().removeContents(filter);
	}
	
}	

/* Utils
------------------------------------------------------------------------------*/

function matchingCoordinates(coordinates1, coordinates2) {
	if ($.isArray(coordinates1) && $.isArray(coordinates2)) {
		if (coordinates1.length == coordinates2.length) {
			for (var i = 0; i < coordinates1.length; i++) {
				if (coordinates1[i] != coordinates2[i]) return false;
			}
			return true;
		}
	}
	return false;
}

function clearTime(d) {
	d.setHours(0);
	d.setMinutes(0);
	d.setSeconds(0); 
	d.setMilliseconds(0);
	return d;
}

})(jQuery);
