(function($, undefined) {

var ct = $.contentable = { version: "1.0.0" };
var ctViews = ct.views = {};

ct.sourceNormalizers = [];
ct.sourceFetchers = [];

var defaults = {
	coordinates: [0, 0, 0],
	className: function(content) { return ''; },
	style:     function(content) { return ''; },
	renderContent: function(content) {
		return (content.content ? content.content : '')
	},
	addContent:  function(coordinates, event) { return null; },
	editContent: function(content, event)     { return content; },
	dropContent: function(coordinates, content, event, callback) { callback(); },
	clickable: function(coordinates) { return true; },
	draggable: function(coordinates, content, event) { return true; },
	droppable: function(coordinates, content, event) { return true; },
	renderCompleted: function() {}
}

var ajaxDefaults = {
	dataType: 'json',
	cache: false
};

$.fn.contentable = function(options) {
	// method calling
	if (typeof options == 'string') {
		var args = Array.prototype.slice.call(arguments, 1);
		var res;
		this.each(function() {
			var contentable = $.data(this, 'contentable');
			if (contentable && $.isFunction(contentable[options])) {
				var r = contentable[options].apply(contentable, args);
				if (res === undefined) {
					res = r;
				}
				if (options == 'destroy') {
					$.removeData(this, 'contentable');
				}
			}
		});
		if (res !== undefined) {
			return res;
		}
		return this;
	}
	
	// would like to have this logic in ContentManager, but needs to happen before options are recursively extended
	var contentSources = options.contentSources || [];
	delete options.contentSources;
	if (options.contents) {
		contentSources.push(options.contents);
		delete options.contents;
	}

	options = $.extend(true, {},
		defaults,
		options
	);
	
	this.each(function(i, _element) {
		var element = $(_element);
		var contentable = new Contentable(element, options, contentSources);
		element.data('contentable', contentable); // TODO: look into memory leak implications
		contentable.render();
	});
	
	return this;
};

function Contentable(element, options, contentSources) {
	var t = this;

	// exports
	t.options = options;
	t.trigger = trigger;
	t.invoke  = invoke;
	t.render  = render;
	t.ui      = element[0];
	t.isChanged = false;
	
	// imports
	ContentRenderer.call(t);
	ContentManager.call(t, options, contentSources);
	
	// locals
	// var currentView;
	// var viewInstances = {};

	/* Main Functions
	-----------------------------------------------------------------------------*/

	function trigger(name, thisObj) {
		if (options[name]) {
			return options[name].apply(
				thisObj || _element,
				Array.prototype.slice.call(arguments, 2)
			);
		}
	}
	
	function resolve(object, property) {
	    var resolved = object[property];
		if (!resolved) {
			resolved = options[property];
		}
		return resolved;
	}
	
	function invoke(object, property) {
		var resolved = resolve(object, property);
		if (resolved) {
			if ($.isFunction(resolved)) {
				return resolved.apply(object, Array.prototype.slice.call(arguments, 2));
			} else {
				return resolved;
			}
		}
	}
	
	/*
	Testing the framework ...
	var testObject = {
		testStringProperty: 'Hi, I\'m a string property',
		testNumberProperty: 100,
		testFunctionProperty: function(arg1, arg2) {
			alert(arg1 + ' ' + arg2);
		}
	}
	
	var arg1 = invoke(testObject, 'testStringProperty');
	var arg2 = invoke(testObject, 'testNumberProperty');
	invoke(testObject, 'testFunctionProperty', arg1, arg2);
	*/

	/* Main Rendering
	-----------------------------------------------------------------------------*/
	
	function render() {
		var start = options.start; // 0;    could be a number, or date, or any value
		var end   = options.end;   // 100;  that can be specified in a range
		t.fetchContents(start, end);
		isChanged = false;
	}
	
}

function ContentRenderer() {
	var t = this;
	
	// exports
	t.renderContent  = renderContent;
	t.renderContents = renderContents;
	t.foregoContents = foregoContents;
	
	// imports
	
	// locals
	
	function makeContentClickable(content) {
		content.click(function(event) {
			//alert("content: " + event);

			// temporary {
			var coordinates = $(this).closest('td.contentcell').attr('data-coordinates');
			coordinates = JSON.parse(coordinates);
			if (coordinates[0] == 1 && coordinates[1] == 1 && coordinates[2] == 1) {
				return true;
			} // } temporary
			
			event.stopImmediatePropagation();

			/*
			var coordinates = $(this).closest('td.contentcell').attr('data-coordinates');
			coordinates = JSON.parse(coordinates);
			var content = t.findContentsByCoordinates(coordinates)[0]; 
			*/

			var contentId = $(this).attr('id');
			
			var content;
			if (contentId && contentId != 'undefined') {
				content = t.findContentById(contentId);
			} else {
				var coordinates = $(this).closest('td.contentcell').attr('data-coordinates');
				coordinates = JSON.parse(coordinates);
				content = t.findContentsByCoordinates(coordinates)[0]; 
			}
			
			content = t.options.editContent(content, event);
			if (content) {
				alert("Update contantable: " + JSON.stringify(content, function replacer(key, value) {
					// http://www.json.org/js.html
					// http://stackoverflow.com/questions/13861254/json-stringify-deep-objects
					if (key === 'source') {
						return '';
					}
					return value;
				}));
				renderContent(content);
			}
		});
	}
	
	function makeContentDraggable(content) {
		content.draggable({
			opacity: 0.5, 
			scope: "contentcell", 
			zIndex : 100,
			cursor: "pointer",
			grid: [5, 5],
			//containment: "#contentable",
			appendTo: "body",
			helper: 'clone',
			start: function(event, ui) {
				var coordinates = $(this).closest('td.contentcell').attr('data-coordinates');
				coordinates = JSON.parse(coordinates);

				var content;
				var contentId = $(this).attr('id');
				if (contentId && contentId != 'undefined') {
					content = t.findContentById(contentId);
				} else {
					content = t.findContentsByCoordinates(coordinates)[0]; 
				}

				if (!t.options.draggable(coordinates, content, event)) return false;
				
				//$(ui.helper).addClass('external-event');
				//$(ui.helper).css('font-weight', 'bold');
				//$(ui.helper).removeClass('content pos1');			
				$(ui.helper).css('position', 'absolute'); 
				$(ui.helper).css('left', '200');
				$(ui.helper).width($(this).width());
				$(ui.helper).height($(this).height());
				$(this).hide();             
			},
			stop: function(){
				$(this).show()
			}
		}); // end of draggable()
	}
	
	function makeContentCellClickable(contentCell) {
		contentCell.click(function(event) {
			//alert("contentcell: " + event);
			var coordinates = $(this).attr('data-coordinates');
			coordinates = JSON.parse(coordinates);
			
			var content = t.options.addContent(coordinates, event);
			if (content) {
				//alert("Add to contantable: " + JSON.stringify(content));
				t.addContent(content);
			}
		});
	}
	
	function makeContentCellDroppable(contentCell) {
		contentCell.droppable({
			hoverClass: "acceptable-content", 
			scope: "contentcell", 
			//accept: function() {return true;},
			//dropover: function(event,info){
			//    $(this).addClass('acceptable-content');
			//},
			drop: function(event, info){
				//info.draggable.fadeOut();
				var newContentCell = $(this);
				var newCoordinates = JSON.parse(newContentCell.attr('data-coordinates'));
				
				var oldContentCell = info.draggable.parent(); // grab the grand parent in case of wrapper
				if (oldContentCell.hasClass('contentwrap')) { oldContentCell = oldContentCell.parent() }
				var oldCoordinates = JSON.parse(oldContentCell.attr('data-coordinates'));
				if (matchingCoordinates(oldCoordinates, newCoordinates)) return;

				var contentId = $(info.draggable).attr('id');
				var content = t.findContentById(contentId);

				if (!t.options.droppable(newCoordinates, content, event)) return;
				isChanged = true;
				
				var callback = function() {
					if (newContentCell.has('div.contentwrap').size() > 0) {
						newContentCell.children('div.contentwrap').append(info.draggable.css({ top: 0, left: 0}));
					} else {
						newContentCell.append(info.draggable.css({ top: 0, left: 0}));
					}
		
					if (content) { content.coordinates = newCoordinates; }

					setTimeout(function() {
						 updateContentWrapsHeight(newContentCell);
						 updateContentWrapsHeight(oldContentCell);
					}, 100);
					//info.draggable.fadeIn();
				}
				
				t.options.dropContent(newCoordinates, content, event, callback);
			}
		}); // end of droppable()
	}

	function renderContent(content) {
		if (!content) return;
		
		var td = $('td[data-coordinates="' + JSON.stringify(content.coordinates) + '"]' , t.ui);
		
		var contentUI = $('.content[id="' + content.id + '"]', td);
		var contentClassName = denormalizeClassName(t.invoke(content, 'className') /*content.className*/);
		var contentStyle = t.invoke(content, 'style');
		
		if (contentUI.size() == 0) {
			var contentHTML = '<div id="' 
						    + content.id 
						    + '" class="content contentype' 
						    + content.type 
						    + ' ' 
						    + contentClassName
							+ '" ' 
							+ 'style="' 
							+ contentStyle 
							+ '"'
							+'>';
			contentHTML += t.invoke(content, 'renderContent'); //content.render();
			contentHTML += '</div>';

			$(contentHTML).appendTo(td).end().css({ top: 0, left: 0}); // end() does not work because of what is appended
			contentUI = $('.content', td); 
			makeContentClickable(contentUI);
			makeContentDraggable(contentUI);
		} else {
			var className = 'content contentype' + content.type + ' ' + contentClassName;
			contentUI.removeClass();
			contentUI.addClass(className);
			contentUI.css(normalizeStyle(contentStyle));
			contentUI.html(t.invoke(content, 'renderContent'));
		}
	}
	
	function renderContents(contents) {
		if (!contents) return;
		
		var matrix3D = [], maxI = 0, maxJ = 0, maxK = 0;
		$.each(contents, function(index, content) {
			if (content.coordinates) {
				var i = content.coordinates[0] - 1;
				var j = content.coordinates[1] - 1;
				var k = content.coordinates[2] - 1;
				
				if (!matrix3D[i]) {
					matrix3D[i] = [];
				}
				if (!matrix3D[i][j]) {
					matrix3D[i][j] = [];
				}
				if (!matrix3D[i][j][k]) {
					matrix3D[i][j][k] = [];
				}
				
				matrix3D[i][j][k].push(content);	
				
				if (maxI < ++i) maxI = i;
				if (maxJ < ++j) maxJ = j;
				if (maxK < ++k) maxK = k;
			}
		});

		var tableHTML = '<table class="contentable" style="width: 100%;">';
		for (var i = 0; i < maxI; i++) {
			for (var j = 0; j < maxJ; j++) {
				tableHTML += '<tr>';
				for (var k = 0; k < maxK; k++) {
					var contents = matrix3D[i][j][k];
					var contentHTML = '';
					var dataCoordinatesAttribute = 'data-coordinates="' + JSON.stringify([i+1, j+1, k+1]) + '"';
					if (contents) {
						//if (contents.length == 1 && contents[0] && contents[0].type == 0) {
						//	var content = contents[0];
						//	contentHTML = '<td class="contentcell '  + content.className.join(' ')  + '" ' + dataCoordinatesAttribute + '>' + content.render() + '</td>';
						//} else {
							var decorateTopLeft;
							var decorateTopRight;
							var decorateBottomLeft;
							var decorateBottomRight;
							
							$.each(contents, function(index, content) {
								decorateTopLeft     = (content.decorate & 0x08) > 0;
								decorateTopRight    = (content.decorate & 0x04) > 0;
								decorateBottomLeft  = (content.decorate & 0x02) > 0;
								decorateBottomRight = (content.decorate & 0x01) > 0;
							});
							
							var decorate = decorateTopLeft || decorateTopRight || decorateBottomLeft || decorateBottomRight;
							
							contentHTML = '<td class="contentcell" ' + dataCoordinatesAttribute + '>';
							if (decorate) {
								contentHTML += '<div class="contentwrap" style="position: relative;">'; 
								if (decorateTopLeft    ) { contentHTML += '<div class="corner top-left-corner"></div>';     }
								if (decorateTopRight   ) { contentHTML += '<div class="corner top-right-corner"></div>';    }
								if (decorateBottomLeft ) { contentHTML += '<div class="corner bottom-left-corner"></div>';  }
								if (decorateBottomRight) { contentHTML += '<div class="corner bottom-right-corner"></div>'; }
							}
							
							$.each(contents, function(index, content) {
								if (!content.content) return true;

								var contentClassName = denormalizeClassName(t.invoke(content, 'className') /*content.className*/);
								var contentStyle = t.invoke(content, 'style');
								contentHTML += '<div id="' 
								            + content.id 
											+ '" class="content contentype' 
											+ content.type 
											+ ' ' 
											+ contentClassName 
											+ '" ' 
											+ 'style="' 
											+ contentStyle 
											+ '"'
											+'>';
								contentHTML += t.invoke(content, 'renderContent'); //content.render();
								contentHTML += '</div>';
							});
							
							if (decorate) {
								contentHTML += '</div>';
							} 
						//}
					} else {
						contentHTML = '<td class="contentcell" ' + dataCoordinatesAttribute + '></td>';
					}
					tableHTML += contentHTML;
				}	 	
				tableHTML += '</tr>';
			}
		}
	
		
		tableHTML += '</table>';
		$(t.ui).html(tableHTML); 
		
		/*
		$('.userPhoto', t.ui).error(function(){
			$(this).attr('src', 'css/groups/images/people.png');
		});
		*/
		
		/*
		Checking the complete flag earlier somehow leads to not successful 
		loading of photos.
		$('.userPhoto', t.ui).each(function(index, userPhoto) {
			if (!userPhoto.complete) {
				$(userPhoto).attr('src', 'css/groups/images/person32x32.png');
			}
		});
		*/
		
		makeContentClickable($('.content', t.ui));
		makeContentDraggable($('.content', t.ui));
		makeContentCellClickable($('.contentcell', t.ui));
		makeContentCellDroppable($('.contentcell', t.ui));
	}

	function foregoContents(contents) {
		$.each(contents, function(index, content) {
			$('*[id="' + content.id + '"]', t.ui).remove();
		});
	}

	function updateContentWrapsHeight(contentCell) {
		var tdMaxHeight = $('table.contentable td', t.ui).height();
		contentCell.parent().children('td').each(function(index, td) {
			var tdHeight = 0;
			
			var children;
			if ($(td).has('div.contentwrap').size() > 0) {
				children = $(td).children('div.contentwrap').children();
			} else {
				children = $(td).children();
			}

			children.each(function(subindex, child) {
				if ($(child).hasClass('content')) {
					tdHeight += $(child).height();
				}
			});
			tdMaxHeight = (tdMaxHeight > tdHeight) ? tdMaxHeight : tdHeight;
		});
		contentCell.parent().children('td').children('div.contentwrap').height(tdMaxHeight);
	}
}

/* ContentManager is to manage sources and fetch data
-----------------------------------------------------------------------------*/
	
function ContentManager(options, _sources) {
	var t = this;
	
	// exports
	t.isFetchNeeded = isFetchNeeded;
	t.fetchContents  = fetchContents;
	t.addContentSource = addContentSource;
	t.removeContentSource = removeContentSource;
	t.addContent     = addContent;
	t.addContents    = addContents;
	t.updateContent  = updateContent;
	t.updateContents = updateContents;
	t.removeContents = removeContents;
	t.getContentSources = getContentSources;
	t.getContents       = getContents;
	t.findContentById   = findContentById;
	t.findContentsByCoordinates = findContentsByCoordinates;
	
	// imports
	var trigger = t.trigger;
	var renderContent  = t.renderContent;
	var renderContents = t.renderContents;
	
	// locals
	var unidentifiedSource = { contents: [] };
	var sources = [ unidentifiedSource ];
	var rangeStart, rangeEnd;
	var currentFetchID = 0;
	var pendingSourceCnt = 0;
	var loadingLevel = 0;
	var cache = [];

	for (var i=0; i<_sources.length; i++) {
		_addContentSource(_sources[i]);
	}
	
	/* Retrieving content sources and contents
	-----------------------------------------------------------------------------*/
	
	function getContentSources() {
		// Shallow copy
		// var b = jQuery.extend({}, a);

		// Deep copy
		// var b = jQuery.extend(true, {}, a);

		// Switched to shallow copy because deep copy was causing infinite loop 
		// with recursive objects (e.g. child node pointing to parent node)
		// return jQuery.extend(true, [], sources);
		return jQuery.extend(false, [], sources);
	}
	
	function getContents() {
		return cache;
	};
	
	function findContentsByCoordinates(coordinates) {
		var contents = [];
		for (var i = 0; i < cache.length; i++) {
			if (matchingCoordinates(cache[i].coordinates, coordinates)) { 
				contents.push(cache[i]);
			}
		}
		return contents;
	};
	
	function findContentById(id) {
		var content;
		for (var i = 0; i < cache.length; i++) {
			if (cache[i].id == id) { 
				content = cache[i];
				break;
			}
		}
		return content;
	};
	
	/* Fetching
	-----------------------------------------------------------------------------*/
	
	function isFetchNeeded(start, end) {
		return !rangeStart || start < rangeStart || end > rangeEnd;
	}
	
	function fetchContents(start, end) {
		rangeStart = start;
		rangeEnd = end;
		cache = [];
		var fetchID = ++currentFetchID;
		var len = sources.length;
		pendingSourceCnt = len;
		for (var i=0; i<len; i++) {
			fetchContentSource(sources[i], fetchID);
		}
	}
	
	function fetchContentSource(source, fetchID) {
		_fetchContentSource(source, function(contents) {
			if (fetchID == currentFetchID) {
				if (contents) {
					for (var i=0; i<contents.length; i++) {
						contents[i].source = source;
						normalizeContent(contents[i]);
					}
					cache = cache.concat(contents);
				}
				pendingSourceCnt--;
				if (!pendingSourceCnt) {
					renderContents(cache);
					options.renderCompleted();
				}
			}
		});
	}
	
	function _fetchContentSource(source, callback) {
		var i;
		var fetchers = ct.sourceFetchers;
		var res;
		for (i=0; i<fetchers.length; i++) {
			res = fetchers[i](source, rangeStart, rangeEnd, callback);
			if (res === true) {
				// the fetcher is in charge. made its own async request
				return;
			}
			else if (typeof res == 'object') {
				// the fetcher returned a new source. process it
				_fetchContentSource(res, callback);
				return;
			}
		}
		var contents = source.contents;
		if (contents) {
			if ($.isFunction(contents)) {
				pushLoading();
				contents(rangeStart, rangeEnd, function(contents) {
					callback(contents);
					popLoading();
				});
			}
			else if ($.isArray(contents)) {
				callback(contents);
			}
			else {
				callback();
			}
		}else{
			var url = source.url;
			if (url) {
				var success = source.success;
				var error = source.error;
				var complete = source.complete;
				var data = $.extend({}, source.data || {});
				var startParam = firstDefined(source.startParam, options.startParam);
				var endParam = firstDefined(source.endParam, options.endParam);
				if (startParam) {
					data[startParam] = rangeStart;
				}
				if (endParam) {
					data[endParam] = rangeEnd;
				}
				pushLoading();
				$.ajax($.extend({}, ajaxDefaults, source, {
					data: data,
					success: function(contents) {
						contents = contents || [];
						var res = applyAll(success, this, arguments);
						if ($.isArray(res)) {
							contents = res;
						}
						callback(contents);
					},
					error: function() {
						applyAll(error, this, arguments);
						callback();
					},
					complete: function() {
						applyAll(complete, this, arguments);
						popLoading();
					}
				}));
			}else{
				callback();
			}
		}
	}
	
	/* Sources
	-----------------------------------------------------------------------------*/

	function addContentSource(source) {
		source = _addContentSource(source);
		if (source) {
			pendingSourceCnt++;
			fetchContentSource(source, currentFetchID); // will eventually call reportContents
		}
		isChanged = true;
	}
	
	function _addContentSource(source) {
		if ($.isFunction(source) || $.isArray(source)) {
			source = { contents: source };
		}
		else if (typeof source == 'string') {
			source = { url: source };
		}
		if (typeof source == 'object') {
			normalizeSource(source);
			sources.push(source);
			return source;
		}
	}
	
	function removeContentSource(source) {
		var removedContents = [];
		sources = $.grep(sources, function(src) {
			return !isSourcesEqual(src, source);
		});
		// remove all client contents from that source
		cache = $.grep(cache, function(e) {
			var eq = isSourcesEqual(e.source, source);
			if (eq) { removedContents.push(e); }
			return !eq;
		});
		// foregoEvents is better than renderEvents because it takes the source events out 
		// the screen, while the other rerenders the screen and animation might be annoying  
		// renderContents(cache);
		foregoContents(removedContents);
		isChanged = true;
	}

	/* Content Manipulation
	-----------------------------------------------------------------------------*/

	function addContent(content) { 
		if (!content.source) {
			unidentifiedSource.contents.push(content);
			content.source = unidentifiedSource;
		}
	    normalizeContent(content);
		cache.push(content);
		renderContent(content);
		isChanged = true;
	}

	function addContents(contents) { 
		if ($.isArray(contents)) {
			for (var i = 0; i < contents.length; i++) {
				addContent(contents[i]);
			}
		} else {
			var content = contents;
			addContent(content);
		}
	}	
	
	function updateContent(content) { 
	    normalizeContent(content);
		renderContent(content);
		isChanged = true;
	}
	
	function updateContents(contents) { 
		if ($.isArray(contents)) {
			for (var i = 0; i < contents.length; i++) {
				updateContent(contents[i]);
			}
		} else {
			var content = contents;
			updateContent(content);
		}
	}	
	
	function removeContents(filter) {
		if (!filter) { // remove all
			cache = [];
			// clear all array sources
			for (var i=0; i<sources.length; i++) {
				if ($.isArray(sources[i].contents)) {
					sources[i].contents = [];
				}
			}
			renderContents(cache);
		} else {
			if (!$.isFunction(filter)) { // an content ID
				var id = filter + '';
				filter = function(c) {
					return c._id == id;
				};
			}

			var removedContents = $.grep(cache, filter, false);
			t.foregoContents(removedContents);
			
			cache = $.grep(cache, filter, true);
			// remove contents from array sources
			for (var i=0; i<sources.length; i++) {
				if ($.isArray(sources[i].contents)) {
					sources[i].contents = $.grep(sources[i].contents, filter, true);
				}
			}
		}
		isChanged = true;
	}
	
	/* Loading State
	-----------------------------------------------------------------------------*/
	
	function pushLoading() {
		if (!loadingLevel++) {
			trigger('loading', null, true);
		}
	}
	
	function popLoading() {
		if (!--loadingLevel) {
			trigger('loading', null, false);
		}
	}
	
	/* Content Normalization
	-----------------------------------------------------------------------------*/
	
	function normalizeContent(content) {
		content._id = content._id || (content.id === undefined ? '_ct' + generateGUID() : content.id + '');
		if (!content.coordinates) {
			var source = content.source || {}; // default coordinates can be specified on source and options level
			content.coordinates = firstDefined(source.coordinates, options.coordinates);
		} 
		// content.className = normalizeClassName(content.className);
		// TODO: if there is no start, return false to indicate an invalid content
	}

	function normalizeSource(source) {
		source.className = normalizeClassName(source.className);
		var normalizers = ct.sourceNormalizers;
		for (var i=0; i<normalizers.length; i++) {
			normalizers[i](source);
		}
	}
	
	function isSourcesEqual(source1, source2) {
		return source1 && source2 && getSourcePrimitive(source1) == getSourcePrimitive(source2);
	}
	
	function getSourcePrimitive(source) {
		return ((typeof source == 'object') ? (source.contents || source.url) : '') || source;
	}
	
}	

/* Utils
------------------------------------------------------------------------------*/

var GUID = 1;
	
function generateGUID() {
	return (GUID++);
}

function normalizeStyle(style) {
	// e.g. normalizeStyle('background-color: #000000; color: #FFFFFF');
	var normalizedStyle = {}; 
	var styleProperties = style.split(";");
	$.each(styleProperties, function(index, styleProperty) {
		var normalizedStyleProperty = styleProperty.split(/:\s+/);
		normalizedStyle[normalizedStyleProperty[0]] = normalizedStyleProperty[1];
	});
	alert(JSON.stringify(normalizedStyle));
}

function denormalizeClassName(className) {
	if (className) {
		if ($.isFunction(className)) {
			return denormalizeClassName(className());
		}
		if ($.isArray(className)) {
			return className.join(' ');
		}
		if (typeof className == 'string') {
			return className;
		}
	}
	return '';
}

function normalizeClassName(className) {
	if (className) {
		// TODO: repeat code, same code for content classNames
		if (typeof className == 'string') {
			className = className.split(/\s+/);
		}
	}else{
		className = [];
	}
	return className;
}

function applyAll(functions, thisObj, args) {
	if ($.isFunction(functions)) {
		functions = [ functions ];
	}
	if (functions) {
		var i;
		var ret;
		for (i=0; i<functions.length; i++) {
			ret = functions[i].apply(thisObj, args) || ret;
		}
		return ret;
	}
}


function firstDefined() {
	for (var i=0; i<arguments.length; i++) {
		if (arguments[i] !== undefined) {
			return arguments[i];
		}
	}
}

function matchingCoordinates(coordinates1, coordinates2) {
	if ($.isArray(coordinates1) && $.isArray(coordinates2)) {
		if (coordinates1.length == coordinates2.length) {
			for (var i = 0; i < coordinates1.length; i++) {
				if (coordinates1[i] != coordinates2[i]) return false;
			}
			return true;
		}
	}
	return false;
}

})(jQuery);