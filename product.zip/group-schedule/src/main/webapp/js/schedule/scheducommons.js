(function($, undefined) {

/* Utils
------------------------------------------------------------------------------*/

var GUID = 1;
	
function generateGUID() {
	return (GUID++);
}

function zeroPad(n) {
	return (n < 10 ? '0' : '') + n;
}

function denormalizeClassName(className) {
	if (className) {
		if ($.isFunction(className)) {
			return denormalizeClassName(className());
		}
		if ($.isArray(className)) {
			return className.join(' ');
		}
		if (typeof className == 'string') {
			return className;
		}
	}
	return '';
}

function normalizeClassName(className) {
	if (className) {
		// TODO: repeat code, same code for content classNames
		if (typeof className == 'string') {
			className = className.split(/\s+/);
		}
	}else{
		className = [];
	}
	return className;
}

function applyAll(functions, thisObj, args) {
	if ($.isFunction(functions)) {
		functions = [ functions ];
	}
	if (functions) {
		var i;
		var ret;
		for (i=0; i<functions.length; i++) {
			ret = functions[i].apply(thisObj, args) || ret;
		}
		return ret;
	}
}


function firstDefined() {
	for (var i=0; i<arguments.length; i++) {
		if (arguments[i] !== undefined) {
			return arguments[i];
		}
	}
}

function matchingCoordinates(coordinates1, coordinates2) {
	if ($.isArray(coordinates1) && $.isArray(coordinates2)) {
		if (coordinates1.length == coordinates2.length) {
			for (var i = 0; i < coordinates1.length; i++) {
				if (coordinates1[i] != coordinates2[i]) return false;
			}
			return true;
		}
	}
	return false;
}


})(jQuery);

//
// Functions common for both schedutable and schedulines components.
// Includes: loading, creation of new and update of existing events
//

function eventDialog(user, userDate, userEvent, callback) {
	var group = GS.groupsScript.getSelectedGroup(); 
	
	var uiDialogContainter = $("#DialogContainer");
	uiDialogContainter.empty().append($("#EventTemplate").tmpl({
		edit: userEvent ? true : false,
		user: user.name, 
		startTime: (userEvent ? new Date(userEvent.startTime).toString('HH:mm') : ''), 
		endTime:   (userEvent ? new Date(userEvent.endTime).toString('HH:mm') : '')
	}));
	
	if (!userEvent) {
		$('#EventDelete', uiDialogContainter).remove();
	}
	
	var uiEventPosition = $('#EventPosition', uiDialogContainter);
	
	// TODO: (Suggestion for a better user experience) In case of users with no assignments
	// all group positions can be listed. Upon creating the event, selected event position
	// can be automatically assigned to the user and after that event can be created.
	
	if (user.details && user.details.assignments) {
		$.each(user.details.assignments, function(outerIndex, assignment) {
			// Do not enlist positions other than ACTIVE
			if (assignment.status != 'ACTIVE') return true;
			
			var position;
			if (assignment.role) {
				// Do not enlist positions from other groups
				$.each(group.positions, function(index, pos) {
					if (assignment.role.id == pos.id) {
						position = assignment.role;
						return false;
					}
				});
			} else if (assignment.roleId) {
				$.each(group.positions, function(index, pos) {
					if (assignment.roleId == pos.id) {
						position = pos;
						return false;
					}
				});
			}

			var assignedRate = assignment.rate ? assignment.rate  : position.rate;
			var defaultRate  = position.rate;
			
			if (!assignedRate) assignedRate = 0; 
			if (!defaultRate ) defaultRate  = 0;

			//console.log('position: ' + position);
			if (position && position.name != 'Admin') {
				uiEventPosition.append(
			        $('<option></option>').val(position.id)
			        .html(position.name)
			        .data('color', position.color)
			        .data('assignedRate', assignedRate)
			        .data('defaultRate', defaultRate)
				);    
			}
		});
	}
	
	if (userEvent) {
		if (!userEvent.position) return; // non-editable event, ignore user action
		uiEventPosition.val(userEvent.position.id);
	}
	
	var uiEventPanel = $('#EventPanel'); // uiEventPanel.outerHTML()
	$('#EventDelete', uiEventPanel).click(function(event) {
		modal.close();
		deleteEvent(userEvent, callback);
	});
	$('#EventSave', uiEventPanel).click(function(event) {
		var datePrefix = userDate.toString('MM/dd/yyyy') + ' ';
		
		var startTime  = datePrefix + $('#EventStartTime').val();
		startTime = Date.parse(startTime);
		
		var endTime    = datePrefix + $('#EventEndTime').val();
		endTime   = Date.parse(endTime);
		
		var selectedOptionUI = $('#EventPosition option:selected');
		var position = {
			id: $('#EventPosition').val(),
			description:  selectedOptionUI.text(),
			color:        selectedOptionUI.data('color'),
			assignedRate: selectedOptionUI.data('assignedRate'),
			defaultRate:  selectedOptionUI.data('defaultRate')
		};

		modal.close();
	
		var callbackEvent = $.extend(false, 
			{},
			userEvent,
			{ 
				position:  position,
				startTime: startTime.getTime(), 
				endTime:   endTime.getTime()
			}
		); 
		
		if (!userEvent) { 
			callbackEvent.user  = user;
			callbackEvent.group = group;
		}
		
		saveEvent(callbackEvent, callback);
	});

	var onClose = function() {}
	modal.open({ content: uiEventPanel, onClose: onClose });
}

function deleteEvent(userEvent, callback) {
	var group = GS.groupsScript.getSelectedGroup();

	var method = 'PUT'; 
	var url = '/group-schedule/proxy/events/byDate/synchPatch';

	var dateEventsPatchDto = {
		groupId: group.id,
		startTime: userEvent.startTime,
		endTime:   userEvent.endTime,
		deletedEvents  : [ userEvent.id ]
	}
	
	var failureMessage = 'Deleting the event failed';

	var callbackPatch = function(result) {
		// result is expected to be DateEventPatchDto object: 
		// 
		// String refNum
		// Long groupId
		// String note
		// DateTime startTime
		// DateTime endTime
		// Long[] userIds
		// Long[] deletedEvents
		// Long[] successfullyDeletedEvents
		// List<DateEventsDto> addedEvents
		// List<DateEventsDto> successfullyAddedEvents
		//
		// , where DateEventsDto object structure is:
		//
		// Long userId
		// Long groupId
		// List<DateEventDto> dateEvents
		//
		// and DateEventDto object structure is:
		//	
		// Long     id
		// DateTime startTime (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// DateTime endTime   (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// Long     userId
		// Long     groupId
		// Long     assignmentId
		// String   note
		
		if (result && result.successfullyDeletedEvents && 
			result.successfullyDeletedEvents.length > 0) {
			userEvent.deleted = true;
			callback(userEvent);
		} else {
			alert(failureMessage);
		}
	}
	
	sendData(
			url,
			method,
			dateEventsPatchDto,
			failureMessage, 
			callbackPatch, false);
}

function saveEvent(userEvent, callback) {
	var group = GS.groupsScript.getSelectedGroup();

	var method = 'PUT'; 
	var url = '/group-schedule/proxy/events/byDate/synchPatch';

	var assignment = getUserAssignment(userEvent.user, userEvent.position);

	var dateEventsPatchDto = {
		groupId: group.id,
		startTime: GS.getWeekStartTime().getTime(),
		endTime:   GS.getWeekEndTime().getTime(),
		addedEvents  : [{
			userId: userEvent.user.id, 
			events: [{
				startTime: userEvent.startTime, 
				endTime:   userEvent.endTime,
				userId:  userEvent.user.id,
				groupId: userEvent.group.id,
				assignmentId: assignment.id,
				note: ''
			}]
		}]
	}
	
	if (userEvent.id) {
		dateEventsPatchDto.deletedEvents = [ userEvent.id ];
	}
		
	var failureMessage = 'Saving the event failed';

	var callbackPatch = function(result) {
		// result is expected to be DateEventPatchDto object: 
		// 
		// String refNum
		// Long groupId
		// String note
		// DateTime startTime
		// DateTime endTime
		// Long[] userIds
		// Long[] deletedEvents
		// Long[] successfullyDeletedEvents
		// List<DateEventsDto> addedEvents
		// List<DateEventsDto> successfullyAddedEvents
		//
		// , where DateEventsDto object structure is:
		//
		// Long userId
		// Long groupId
		// List<DateEventDto> dateEvents
		//
		// and DateEventDto object structure is:
		//	
		// Long     id
		// DateTime startTime (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// DateTime endTime   (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// Long     userId
		// Long     groupId
		// Long     assignmentId
		// String   note
		
		if (result && result.successfullyAddedEvents && 
			result.successfullyAddedEvents.length > 0 && 
			result.successfullyAddedEvents[0].events.length > 0) {
			userEvent.id = result.successfullyAddedEvents[0].events[0].eventId;
			callback(userEvent);
		} else {
			alert(failureMessage);
		}
	}
	
	sendData(
			url,
			method,
			dateEventsPatchDto,
			failureMessage, 
			callbackPatch, false);
}

function patchEvents(addedEvents, deletedEvents, callback) {
	var group = GS.groupsScript.getSelectedGroup();

	var method = 'PUT'; 
	var url = '/group-schedule/proxy/events/byDate/synchPatch';

	var addedEventsForDto = [];
	var usersEvents = {};
	if (addedEvents) {
		$.each(addedEvents, function(index, addedEvent) {
			var assignment = getUserAssignment(addedEvent.user, addedEvent.position);
			
			var userEvents = usersEvents[addedEvent.user.id];
			if (!userEvents) {
				userEvents = { 
					userId: addedEvent.user.id, 
					events: []
				};
				usersEvents[addedEvent.user.id] = userEvents;
				addedEventsForDto.push(userEvents);
			}
			
			userEvents.events.push({
				startTime: addedEvent.startTime, 
				endTime:   addedEvent.endTime,
				userId:  addedEvent.user.id,
				groupId: addedEvent.group.id,
				assignmentId: assignment.id,
				note: ''
			});
		});
	}
	
	var deletedEventsForDto = [];
	if (deletedEvents) {
		$.each(deletedEvents, function(index, deletedEvent) {
			deletedEventsForDto.push(deletedEvent.id);
		});
	}
	
	var dateEventsPatchDto = {
		groupId: group.id,
		startTime: GS.getWeekStartTime().getTime(),
		endTime:   GS.getWeekEndTime().getTime(),
		addedEvents:   addedEventsForDto,
		deletedEvents: deletedEventsForDto
	}
	
	var failureMessage = 'Saving changes failed';

	var callbackPatch = function(result) {
		callback(result);
	}
	
	sendData(
			url,
			method,
			dateEventsPatchDto,
			failureMessage, 
			callbackPatch, false);
}

function loadEvents(start, end, callback) {
	var group = GS.groupsScript.getSelectedGroup();
	var userIds = group.details ? group.details.userIds : [];
	
	var callbackRetrieve = function(usersEvents) {
		/*
		// result is expected to be list of DateEventsDto objects. The type:
		//	
		// Long userId
		// Long groupId
		// List<DateEventDto> dateEvents (serialized under "events" name)
		//
		//, where DateEventDto type is represented as follows:
		//	
		// Long     id
		// DateTime startTime (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// DateTime endTime   (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
		// Long     userId
		// Long     groupId
		// Long     assignmentId
		// String   note

		var events = [];
		if (usersEvents) {
			$.each(usersEvents, function(index, userEvents) {
				$.each(userEvents.events, function(index, userEvent) {
					var user;
					$.each(group.users, function(index, groupUser) {
						if (groupUser.id == userEvent.userId) {
							user = groupUser;
							return false;
						}
					});
					
					if (userEvent.assignmentId) { // group scheduled event
						if (user && user.details && user.details.assignments) {
							$.each(user.details.assignments, function(index, assignment) {
								if (assignment.id == userEvent.assignmentId) {
									var position;
									if (assignment.role) {
										position = assignment.role;
									} else if (assignment.roleId) {
										$(group.positions, function(index, groupPosition) {
											if (assignment.roleId == groupPosition.id) {
												position = groupPosition;
												return false;
											}
										});
									}
									
									var assignedRate = assignment.rate ? assignment.rate  : position.rate;
									var defaultRate  = position.rate;
									
									if (!assignedRate) assignedRate = 0; 
									if (!defaultRate ) defaultRate  = 0;
									
									//console.log('position: ' + position);
									if (position && position.name != 'Admin') {
										events.push(
								  			{ 
								  				id:        userEvent.eventId, 
								  				group:     group,
								  				user: 	   user,
								  				position:  { 
								  					id: position.id, 
								  					description: position.name, 
								  					color: position.color,
								  					assignedRate: assignedRate,
								  					defaultRate: defaultRate
								  				},
								  				startTime: userEvent.startTime, 
								  				endTime:   userEvent.endTime
								  			}
							  			);
									}
								}
							});
						}
					} else { // user own event
						// TODO: handle user own events
						events.push(
				  			{ 
				  				id:        userEvent.eventId ? userEvent.eventId : -1, 
				  				user: 	   user,
				  				startTime: userEvent.startTime, 
				  				endTime:   userEvent.endTime
				  			}
				  		);
					}
				}); // end loop userEvents
			}); // end loop usersEvents
		}
		*/
		var events = upgradeEvents(usersEvents);

		callback(events);
	}

	var params = {
		groupId: group.id, 
		startTime: start.getTime(), 
		endTime:   end.getTime(),  
		userIds: userIds.join(',')
	};
	
	queryData(
		'/group-schedule/proxy/events', 
		params, 
		'Loading events for group ' + group.name + ' in the period ' + params.startTime + '-' + params.endTime + ' failed.', 
		callbackRetrieve);

	/*
	var events = [
		{ 
			id:        1000000, 
			group:     { id: 1 },
			user: { id: 1 },
			position:  { id: 1, description: 'Dish' },
			startTime: Date.parse('3/6/2013 8AM').getTime(), 
			endTime:   Date.parse('3/6/2004 4PM').getTime()
		}
	]
	callback(events);
	*/
}

function getUserAssignment(user, position) {
	var assignment;
	if (user.details && user.details.assignments) {
		$.each(user.details.assignments, function(index, userAssignment) {
			if (userAssignment.role) {
				if (userAssignment.role.id == position.id) {
					assignment = userAssignment;
					return false;
				};
			} else if (userAssignment.roleId) {
				$(group.positions, function(index, groupPosition) {
					if (groupPosition.id == position.id) {
						assignment = userAssignment;
						return false;
					}
				});
				if (assignment) return false;
			}
		});
	}
	return assignment;
}

function upgradeEvents(usersEvents) {
	var group = GS.groupsScript.getSelectedGroup();
	
	var events = [];
	if (usersEvents) {
		$.each(usersEvents, function(index, userEvents) {
			$.each(userEvents.events, function(index, userEvent) {
				var user;
				$.each(group.users, function(index, groupUser) {
					if (groupUser.id == userEvent.userId) {
						user = groupUser;
						return false;
					}
				});
				
				if (userEvent.assignmentId) { // group scheduled event
					if (user && user.details && user.details.assignments) {
						$.each(user.details.assignments, function(index, assignment) {
							if (assignment.id == userEvent.assignmentId) {
								var position;
								if (assignment.role) {
									position = assignment.role;
								} else if (assignment.roleId) {
									$(group.positions, function(index, groupPosition) {
										if (assignment.roleId == groupPosition.id) {
											position = groupPosition;
											return false;
										}
									});
								}
								
								var assignedRate = assignment.rate ? assignment.rate  : position.rate;
								var defaultRate  = position.rate;
								
								if (!assignedRate) assignedRate = 0; 
								if (!defaultRate ) defaultRate  = 0;
								
								//console.log('position: ' + position);
								if (position && position.name != 'Admin') {
									events.push(
							  			{ 
							  				id:        userEvent.eventId, 
							  				group:     group,
							  				user: 	   user,
							  				position:  { 
							  					id: position.id, 
							  					description: position.name, 
							  					color: position.color,
							  					assignedRate: assignedRate,
							  					defaultRate: defaultRate
							  				},
							  				startTime: userEvent.startTime, 
							  				endTime:   userEvent.endTime
							  			}
						  			);
								}
							}
						});
					}
				} else { // user own event
					// TODO: handle user own events
					events.push(
			  			{ 
			  				id:        userEvent.eventId ? userEvent.eventId : -1, 
			  				user: 	   user,
			  				startTime: userEvent.startTime, 
			  				endTime:   userEvent.endTime
			  			}
			  		);
				}
			}); // end loop userEvents
		}); // end loop usersEvents
	}
	
	return events;
}

function clearTime(d) {
	d.setHours(0);
	d.setMinutes(0);
	d.setSeconds(0); 
	d.setMilliseconds(0);
	return d;
}

////////////////////////////////////////////////////////////////////////
//

/*
var initiateCreate = function() {
	var method = 'POST'; 
	var url = '/group-schedule/proxy/events/byDate/users/' + user.id;

	var dateEventDtos = [{
		startTime: startTime.getTime(), 
		endTime:   endTime.getTime(),
		userId:  user.id,
		groupId: group.id,
		assignmentId: assignment.id,
		note: ''
	}];

	sendData(
			url,
			method,
			dateEventDtos,
			'Creating the event failed', 
			callbackCreate, false);
}

var callbackCreate = function(result) {
	// result is expected to be DateEventDto object: 
	// Long     id
	// DateTime startTime (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
	// DateTime endTime   (serialized as Long or 'yyyy/MM/dd HH:mm:ss')
	// Long     userId
	// Long     groupId
	// Long     assignmentId
	// String   note
	callbackEvent.id = result.id;
	callback(callbackEvent);
}

var initiateUpdate = function() {
	var method = 'DELETE'; 
	var url = '/group-schedule/proxy/events/byDate/users/' + user.id;

	var eventIds = [ userEvent.id ];

	sendData(
			url,
			method,
			eventIds,
			'Deleting ' + eventIds.join(', ') + ' failed', 
			callbackDelete, false);
}

var callbackUpdate = function(result) {
	// result is expected to be an array of strings
	initiateCreate();
}
	
if (userEvent) { 
	// updates existing event by deleting and recreating it
	initiateUpdate(); // calls internally initiateCreate();
} else {
	// creates a new event
	initiateCreate();
}
*/

                                                                      //
////////////////////////////////////////////////////////////////////////
