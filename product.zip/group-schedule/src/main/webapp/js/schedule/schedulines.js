(function($, undefined) {

var sl = $.schedulines = { version: "1.0.0" };
var slViews = sl.views = {};

sl.sourceNormalizers = [];
sl.sourceFetchers = [];

var defaults = {
}

var ajaxDefaults = {
	dataType: 'json',
	cache: false
};

$.fn.schedulines = function(options) {
	// method calling
	if (typeof options == 'string') {
		var args = Array.prototype.slice.call(arguments, 1);
		var res;
		this.each(function() {
			var schedulines = $.data(this, 'schedulines');
			if (schedulines && $.isFunction(schedulines[options])) {
				var r = schedulines[options].apply(schedulines, args);
				if (res === undefined) {
					res = r;
				}
				if (options == 'destroy') {
					$.removeData(this, 'schedulines');
				}
			}
		});
		if (res !== undefined) {
			return res;
		}
		return this;
	}
	
	// would like to have this logic in EventManager, but needs to happen before options are recursively extended
	var eventSources = options.eventSources || [];
	//delete options.eventSources; // commented because options might be shared with other components
	if (options.events) {
		eventSources.push(options.events);
		//delete options.events;   // commented because options might be shared with other components
	}

	options = $.extend(true, {},
		defaults,
		options
	);
	
	this.each(function(i, _element) {
		var element = $(_element);
		var schedulines = new Schedulines(element, options, eventSources);
		element.data('schedulines', schedulines); // TODO: look into memory leak implications
		schedulines.render();
	});
	
	return this;
};

function Schedulines(element, options, eventSources) {
	var t = this;

	// exports
	t.options = options;
	t.trigger = trigger;
	t.invoke  = invoke;
	t.render  = render;
	t.ui      = element[0];
	t.isChanged = false;
	
	// imports
	EventRenderer.call(t);
	EventManager.call(t, options, eventSources);
	var fetchEvents = t.fetchEvents;
	
	// locals
	// var currentView;
	// var viewInstances = {};

	/* Main Functions
	-----------------------------------------------------------------------------*/

	function trigger(name, thisObj) {
		if (options[name]) {
			return options[name].apply(
				thisObj || _element,
				Array.prototype.slice.call(arguments, 2)
			);
		}
	}
	
	function resolve(object, property) {
	    var resolved = object[property];
		if (!resolved) {
			resolved = options[property];
		}
		return resolved;
	}
	
	function invoke(object, property) {
		var resolved = resolve(object, property);
		if (resolved) {
			if ($.isFunction(resolved)) {
				return resolved.apply(object, Array.prototype.slice.call(arguments, 2));
			} else {
				return resolved;
			}
		}
	}

	/* Main Rendering
	-----------------------------------------------------------------------------*/
	
	function render() {
		var start = options.startTime; // 0;    could be a number, or date, or any value
		var end   = options.endTime;   // 100;  that can be specified in a range
		fetchEvents(start, end);
		isChanged = false;
	}
	
}

function EventRenderer() {
	var t = this;
	
	// exports
	t.renderEvent  = renderEvent;
	t.renderEvents = renderEvents;
	t.foregoEvents = foregoEvents;
	// The better place for calculateStatistics might be in EventManager, 
	// BUT to stay close to updateStatistics was placed in EventRenderer. 
	t.calculateStatistics = calculateStatistics;
	t.updateStatistics    = updateStatistics;
	
	// imports
	
	// locals

	// Resizing the browser window should result in repositioning of
	// the schedubars (a.k.a. events), but to prevent false window
	// resize events caused by event bubling from resizing schedubars
	// the schedulines component will consume all resize events thus
	// preventing them reaching the window and reported as false ones.
	$(t.ui).resize(function(ev) {
		ev.stopImmediatePropagation();
	});
	
	$(window).resize(function() {
		resizeSchedugrids();
		positionSchedubars();
	});
	
	function makeSchedubarsClickable(schedubars) {
		schedubars.dblclick(function(ev) {
			//alert("event: " + ev);
			ev.stopImmediatePropagation();

			var eventId = $(this).attr('id');
			var event = t.findEventById(eventId);

			// schedubar parent is scheduline and contains the user id.
			// => the parent() should be the same as parents('scheduline')
			// the later is more safe, but omitted for easy and quick result
			var userId = $(this).parent().attr('data-user');
			var users = t.options.users();
			$.each(users, function(index, user) {
				if (user.id == userId) {
					var originalEvent = event;
					t.options.editEvent(user, event, function(event) {
						if (event) {
							/*
							alert("Update schedubar: " + JSON.stringify(event, function replacer(key, value) {
								// http://www.json.org/js.html
								// http://stackoverflow.com/questions/13861254/json-stringify-deep-objects
								if (key === 'source') {
									return '';
								}
								return value;
							}));
							*/

							// NOTE: The event returned might be a different object or with a changed id.
							// Updating an event in core services at the present time is implemented as 
							// two consecutive operations - delete and add. Why? Releasing alpha earlier.
							// Therefore, updateEvent would not work properly in this case and require a
							// temporary fix until implementation in core services change. Alternatively,
							// a second id could be used in contentable.js' renderContent to locate the
							// content on the screen, but must be carefully considered to prevent issues.
							// renderEvent(event);
							t.removeEvents(originalEvent.id);
							if (!originalEvent.deleted) {
								t.addEvent(event);
							}

							// TODO: Calculations could be speed up by manipulating
							// existing statistics object - GS.getStatisticsByDays().
							// and calling updateStatistics.
							// It voids the need of calling getCalculatedStatistics()
							calculateStatistics();
							updateStatistics(false);
						} 
						
					});
					return false;
				}
			});
		});
	}
	
	function makeSchedubarsDraggableAndResizable(schedubars) {
		schedubars.resizable({
			//grid: 5,
			containment: ".scheduline",
			handles: "e",
			minWidth: 60,
			minHeight: 20,
			maxHeigth: 20,	
			stop: function(event, ui){
				updateSchedubarTail($(this));
				var schedubar  = $(this);
				var scheduline = $(this).parent();
				var left = schedubar.position().left - scheduline.position().left;
				$(this).css({ position: 'relative', top: 0, left: left });
			}
		}).draggable({
			opacity: 0.5, 
			axis: 'x',
			zIndex : 100,
			cursor: "pointer",
			grid: [1, 0],
			containment: ".scheduline",
			stop: function(event, ui){
				updateSchedubarHead($(this), ui);
			}
		});
	}
	
	// Thanks to kitchin for providing sample code on how to pass event to or find the underlying component
	// http://stackoverflow.com/questions/3015422/forwarding-mouse-events-through-layers-divs
	function mouse_event_over_element(evt, elem) {
		var o= elem.offset();
		var w= elem.width();
		var h= elem.height();
		return evt.pageX >= o.left && evt.pageX <= o.left + w && evt.pageY >= o.top && evt.pageY <= o.top + h;
	}

	function makeSchedulinesClickable(schedulines) {
		/*
		// Obscured by schedugrid and thus prevented from receiving the events. 
		schedulines.click(function(event) {
			//alert("event: " + event);
			
			var date = Date.parse('3/4/2013');
					
			var userId = $(this).attr('data-user');
			var users = t.options.users();
			$.each(users, function(index, user) {
				if (user.id == userId) {
					t.options.addEvent(user, date, function(event) {
						if (event) {
							//alert("Add to contantable: " + JSON.stringify(event));
							t.addEvent(event);
						}
					});
					return false;
				}
			});
		});
		*/
		
		$('.schedugrid').click(function(ev) {
			// One way to dispatch the event to the underlying element is by using the following library
			// http://e-infotainment.com/projects/interface-query/demos/behaviours/forward-mouse-events/
			// There was no clear indication on the code license; therefore, a more simple solution was
			// provided.
			schedulines.each(function() {
				if (mouse_event_over_element(ev, $(this))) {
					//var date = Date.parse('3/4/2013');
					var date = GS.getDayStartTime();
							
					var userId = $(this).attr('data-user');
					var users = t.options.users();
					$.each(users, function(index, user) {
						if (user.id == userId) {
							t.options.addEvent(user, date, function(event) {
								if (event) {
									//alert("Add to contantable: " + JSON.stringify(event));
									t.addEvent(event);

									// TODO: Calculations could be speed up by manipulating
									// existing statistics object - GS.getStatisticsByDays().
									// and calling updateStatistics.
									// It voids the need of calling getCalculatedStatistics()
									calculateStatistics();
									updateStatistics(false);
								}
							});
							return false;
						}
					});
				}
			});
		});
	}

	function renderEvent(event) {
		if (!event) return;
		
		var schedubar = $('.schedubar[id="' + event.id + '"]' , t.ui);
		if (schedubar.size() == 0) {
			var scheduline = $('.scheduline[data-user="' + event.user.id + '"]' , t.ui);
			if (scheduline.children().size() == 0) {
				// Place the schedubar into the existing scheduline.
				var schedubarHTML = '<div id="' + event.id + '" class="schedubar">' 
				                  + event.toHTML() 
								  + (event.position ? getDeleteSchedubarHTML() : '')
								  + '</div>';
				$(schedubarHTML).appendTo(scheduline); 

				// Make the schedubar draggable, resizable, and clickable.
				schedubar = $('.schedubar[id="' + event.id + '"]' , t.ui);

				// Paint the background of the event to match the position color
				var backgroundColor = (event.position && event.position.color) ? ('#' + event.position.color) : ('#D3D3D3');
				schedubar.css({backgroundColor: backgroundColor});

				prepareDeleteSchedubar(schedubar);
				makeSchedubarsClickable(schedubar);
				makeSchedubarsDraggableAndResizable(schedubar);
			} else {
				var schedulineHTML = '<tr>';
				schedulineHTML += '<td data-user="' + event.user.id + '" class="scheduline">';
				schedulineHTML += '<div id="' + event.id + '" class="schedubar">';
				schedulineHTML += event.toHTML();
				schedulineHTML += (event.position ? getDeleteSchedubarHTML() : '');
				schedulineHTML += '</div>';
				schedulineHTML += '</td>';
				schedulineHTML += '</tr>';

				var schedulineParent = scheduline.eq(0).parent();
				var scheduface = $('.scheduface', schedulineParent);
				
				// Increase the rowspan of selected scheduface by 1 and append a new scheduline row to the end.
				var numberOfRows = scheduface.attr("rowspan");
				scheduface.attr("rowspan", ++numberOfRows);
				
				while (--numberOfRows > 1 && schedulineParent) { 
					schedulineParent = schedulineParent.next(); 
				} 
				
				$(schedulineHTML).insertAfter(schedulineParent); 

				// Set the height
				schedubar = $('.schedubar[id="' + event.id + '"]' , t.ui);
				schedubar.parent().css({height: schedubar.outerHeight()});
				scheduface.height(schedubar.outerHeight()*numberOfRows);

				// Paint the background of the event to match the position color
				var backgroundColor = (event.position && event.position.color) ? ('#' + event.position.color) : ('#D3D3D3');
				schedubar.css({backgroundColor: backgroundColor});
				
				// Make the schedubar draggable, resizable, and clickable.
				prepareDeleteSchedubar(schedubar);
				makeSchedubarsClickable(schedubar);
				makeSchedubarsDraggableAndResizable(schedubar);
				makeSchedulinesClickable(schedubar.parent());

				resizeSchedugrids();
			}
		} else {
			// Update the schedubar information
			schedubar.contents(':eq(0)').wrap('<span></span>').parent().text(schedubarHTML);
		}
		
		positionSchedubars([event]);
	}
	
	function renderEvents(events) {
		if (!events) return;

		var usersEvents = new Array();
		$.each(events, function(index, event) {
			var userId = event.user.id;
			var userEvents = usersEvents[userId];
			if (!userEvents) {
				userEvents = [];
				usersEvents[userId] = userEvents;
			}
			userEvents.push(event);
		});
		
		var tableHTML = '<table class="schedulines" style="width: 100%; position: relative;">';
		tableHTML += '<tr>'
		tableHTML += '	<td style="width: 12.5%; border: 0px;"></td>';
		tableHTML += '	<td style="border: 0px;">';
		
		// Chrome browser has problems with matching schedule grid and sub grid. Therefore, the
		// sub grid is not rendered on it.
		// var chrome = /chrom(e|ium)/.test(navigator.userAgent.toLowerCase()); 
		var chrome = (typeof window.chrome === "object");
		var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
		var firefox = ( navigator.userAgent.match(/Firefox/g) ? true : false );

		if (!chrome && !iOS) {
			tableHTML += '  	<div>';
			tableHTML += '    		<table class="schedusubgrid" style="position: absolute; width: 87.5%; height: 0px; top: 2px;">'; //was top: 2px;
			tableHTML += '      		<tr style="height: 25px;">';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			tableHTML += '      		</tr>';
			tableHTML += '    		</table>';
			tableHTML += '  	</div>';
		}
		
		tableHTML += '		<div>';
		tableHTML += '    		<table class="schedugrid" style="position: absolute; width: 87.5%; height: 0px; top: 2px;">'; // did not have top: 0px;
		tableHTML += '      		<tr style="height: 25px;">';
		tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
		tableHTML += '        			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
		tableHTML += '      		</tr>';
		tableHTML += '    		</table>';
		tableHTML += '  	</div>';
		tableHTML += '	</td>';
		tableHTML += '</tr>';

		tableHTML += '<tr><td class="scheduface sortswitcher" style="text-align: center;">Users</td><td class="scheduheader" style="height: 35px;"></td></tr>'; // Employee replaced by Users
		
		var users = t.options.users();
		$.each(users, function(outerIndex, user) {
			/*
			var imageFile;
			switch (outerIndex%7) { 
				case 0: imageFile = 'Jamie';     break; 
				case 1: imageFile = 'Frederico'; break;
				case 2: imageFile = 'Jamie';     break;
				case 3: imageFile = 'Rajib';     break;
				case 4: imageFile = 'Yuping';    break;
				case 5: imageFile = 'Biljana';   break;
				case 6: imageFile = 'Elaine';    break;
			}
			var imageTag = '<img width="" src="images/photos/' + imageFile + '.png" style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
			*/
			/*
			var imageURL = GS.getContext() + '/proxy/read/user[' + user.id + ']';
			var imageTag = '<img class="userPhoto" src="' + imageURL + '" style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
			*/
			
			var imageTag = '<img class="userPhoto" data-id="' + user.id + '"' 
				         + 'src="css/groups/images/person32x32.png" ' 
				         + 'style="width: 30px; height: 30px; float: left; margin-right: 5px;">';
			var nameTag  = '<div style="float: left;">' + user.name + '</div>';
			var statTag  = '<div style="float: right;" class="userstat" data-id="' + user.id + '"></div>';
			var schedufaceContent  = imageTag + nameTag + statTag; 
			
			var userEvents  = usersEvents[user.id];
			if (userEvents) {
				var firstEvent = true;
				$.each(userEvents, function(key, event) {
					var eventStartTime = new Date(event.startTime);
					var eventEndTime   = new Date(event.endTime);

					tableHTML += '<tr>';
					
					if (firstEvent) {
						tableHTML += '<td class="scheduface" rowspan="' + userEvents.length + '">' + schedufaceContent + '</td>';
						firstEvent = false;
					}
					
					// Paint the background of the event to match its position color
					var schedubarStyle = ' style="background-color: #';
					if (event.position && event.position.color) {
						schedubarStyle += event.position.color + ';"';
					} else {
						schedubarStyle += 'D3D3D3;"';
					}

					tableHTML += '<td data-user="' + user.id + '" class="scheduline">';
					tableHTML += '<div id="' + event.id + '" class="schedubar"' + schedubarStyle + '>';
					tableHTML += event.toHTML();
					tableHTML += (event.position ? getDeleteSchedubarHTML() : '');
					tableHTML += '</div>';
					tableHTML += '</td>';
					tableHTML += '</tr>';
				});
			} else {
				tableHTML += '<tr>';
				tableHTML += '<td class="scheduface" rowspan="1">' + schedufaceContent + '</td>';
				tableHTML += '<td data-user="' + user.id + '" class="scheduline"></td>';
				tableHTML += '</tr>';
			}
			
		});

		tableHTML += '<tr>' 
			      +  '  <td class="scheduface" style="text-align: center;"><span data-id="1" class="stat"></span></td>' 
			      +  '  <td class="schedufooter" style="height: 35px;">' 
			      //+  '    <div style="background-color: rgb(127, 255, 0); opacity: 1;  position: relative;width: 345px;">X</div>'
			      +  '  </td>'
			      +  '</tr>'; 

		tableHTML += '</table>';
		$(t.ui).html(tableHTML); 

		calculateStatistics();
		updateStatistics(false);
		
		// Clicking on total or daily stats results in switching the type
		var statTotalUI = $(".stat", t.ui);   // $(".stat[data-id='1']");
		statTotalUI.click(function() {
			updateStatistics(true);
		});
		// Clicking on user stats results in switching the type
		var statUserUI = $(".userstat", t.ui);   
		statUserUI.click(function() {
			updateStatistics(true);
		});

		$('.userPhoto', t.ui).each(function(index, userPhoto) {
			userPhoto = $(userPhoto);
			var userId = userPhoto.attr('data-id');
			var imageURL = GS.getContext() + '/proxy/read/user[' + userId + ']';
			var css = { width: '30px', height: '30px', float: 'left', 'margin-right': '5px' };
			GS.loadImage(imageURL, function(image) {
				var dataId = userPhoto.attr('data-id');
				image.attr('data-id', dataId).addClass('userPhoto');
				userPhoto.replaceWith(image.css(css));
			});
		});
		
		/*
		$('.userPhoto', t.ui).each(function(index, userPhoto) {
			userPhoto = $(userPhoto);
			var userId = userPhoto.attr('data-id');
			var imageURL = GS.getContext() + '/proxy/read/user[' + userId + ']';
			userPhoto.load(function(){
			})
			.error(function(){
				userPhoto.attr('src', 'css/groups/images/person32x32.png');
			})
			.attr('src', imageURL);
		});
		*/
		
		/*
		$('.userPhoto', t.ui).error(function(){
			$(this).attr('src', 'css/groups/images/person32x32.png');
		});
		*/

		// Resize the grids and position schedubars by animating them
		resizeSchedugrids();
		positionSchedubars();

		/*
		$('.userPhoto', t.ui).each(function(index, userPhoto) {
			if (!userPhoto.complete) {
				$(userPhoto).attr('src', 'css/groups/images/person32x32.png');
			}
		});
		*/

		var schedubars  = $('.schedubar', t.ui);
		var schedulines = $('.scheduline', t.ui);
		prepareDeleteSchedubar(schedubars);
		makeSchedubarsClickable(schedubars);
		makeSchedubarsDraggableAndResizable(schedubars);
		makeSchedulinesClickable(schedulines);
	}

	function foregoEvents(events) {
		$.each(events, function(index, event) {
			var schedubar = $('*[id="' + event.id + '"]', t.ui);
			var scheduline = schedubar.parent();
			var userId = scheduline.attr('data-user');
			var trs = $('tr:has(td.scheduline[data-user="' + userId + '"])', t.ui);
			var scheduface = $('.scheduface', trs);
			
			var numberOfRows = scheduface.attr("rowspan");
			if (numberOfRows > 1) {
				scheduface.attr("rowspan", --numberOfRows);
				var schedulineParent = scheduline.parent();
				var schedufaceParent = scheduface.parent();
				if (schedulineParent[0] == schedufaceParent[0]) {
					scheduface.prependTo(schedufaceParent.next());
					schedufaceParent.remove();
				} else {
					schedulineParent.remove();
				}
			} else {
				schedubar.remove();
			}
		});
		resizeSchedugrids();
	}
	
	function getDeleteSchedubarHTML() {
		return '<div class="delete-schedubar"></div>';
	}

	function prepareDeleteSchedubar(schedubars) {
		var deleteSchedubars = $('.delete-schedubar', schedubars);
		deleteSchedubars.text('x').css({
			position: 'absolute',
			right: 5, 
			top: 4, 
			border: '1px solid black',
			height: 12,
			padding: '0px 3px 0px 2px',
			cursor: 'pointer',
			lineHeight: '8px'  
		});
		deleteSchedubars.click(function(ev) {
			var schedubar = $(this).parent();
			var eventId = schedubar.attr('id');

			// The next line was replaced by a few more to provide a real event deletion
			//t.removeEvents(eventId);
			
			var userEvent = t.findEventById(eventId);

			var userId = schedubar.parent().attr('data-user');
			var users = t.options.users();
			$.each(users, function(index, user) {
				if (user.id == userId) {
					deleteEvent(userEvent, function(retEvent) { // located in scheducommons.js
						if (userEvent.deleted) {
							t.removeEvents(eventId);
						} 
					});
					return false;
				}
			});
		});
	}
	
	function resizeSchedugrids() {
		var chrome = (typeof window.chrome === "object");
		var iOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );

		// Animate schedule sub and main grids to take the necessary height, and diagonally display the hours in the header
		var height = $('.schedulines', t.ui).height() - 2;
		var speed = 0; //coeff * height;
		if (!chrome && !iOS) {
			$('.schedusubgrid', t.ui).animate({
					height: height 
				}, speed, 'linear', function() {
				// Animation complete.
			});
		}
		$('.schedugrid', t.ui).animate({
				height: height
			}, speed, 'linear', function() {
				// Animation complete.
				$('.schedugrid tr td', t.ui).each(function(index, td) {
					var hour = zeroPad(index) + ':00';
					$('<div><div class="rotate">' + hour + '</div></div>').css({position: 'relative', top: 11}).appendTo(td);
					$('div > div', td).css({ position: 'absolute', left: -3, top: -height/2 });
				});
		});
	}
	
	function positionSchedubars(events) {
		if (!events) {
			events = t.getEvents();
		}
		
		// Position events by animating them
		$.each(events, function(index, event) {
			var schedubar = $('div.schedubar[id="' + event.id + '"]', t.ui);
			
			// TODO: The same problem with position style being changed to absolute
			// after resizing the schedubar appear at this place. Additional logic
			// needs to be added to handle the case. (see updateSchedubarHead func)

			var scheduline = schedubar.parent();
			var schedulineWidth = scheduline.width();
			var eventPosition = getEventPosition(event, schedulineWidth);

			// The absolute position style was addressed by changing the style back to relative
			// once the schedubar resizing is over. This approach addresses hells of problems.
			//if (schedubar.css('position') == 'absolute') { 
			//	eventPosition.left += scheduline.offset().left - scheduline.parent().offset().left;
			//}
			
			schedubar.animate({
					opacity: 1,
					left: eventPosition.left,
					width: eventPosition.width,
					zIndex: 'auto'
				}, 500, 'linear', function() {
				// Animation complete.
			});
		});
	}
	
	function getPosition(time, length) {
		var h = new Date(time).getHours();
		var m = new Date(time).getMinutes();
		h += 0.25 * Math.round(m/15);
		var pos = Math.floor((length * h)/24);
		return pos;
	}
	
	function getEventPosition(event, length) {
		var left  = getPosition(event.startTime, length);
		var width = getPosition(event.endTime, length) - left; 
		return {
			left : left,
			width: width
		};
	}
	
	function updateSchedubarTail(schedubar) {
		var id = schedubar.attr('id');
		
		var parent = schedubar.parent();
		var thisPosLeft  = schedubar.position().left;
		var thisWidth = schedubar.width();
		var parentPosLeft = parent.position().left;
		var parentWidth = parent.width();
		
		var x = ((thisPosLeft - parentPosLeft) + thisWidth) / parentWidth;
		var h = Math.floor(x * 24);
		var m = Math.round((x * 96) - (4 * h));
		if (m == 4) { h++; m=0; }

		var adjustedWidth = ((h + m * 0.25) * parentWidth) / 24 - (thisPosLeft - parentPosLeft);
		schedubar.width(adjustedWidth);
		
		//$(':first-child', this).html(id + " # " + zeroPad(h) + ":" + zeroPad(m*15));
		//schedubar.contents()[0].data = id + " # " + zeroPad(h) + ":" + zeroPad(m*15);
		//schedubar.contents(':eq(0)').wrap('<span></span>').parent().text(id + " # <= " + zeroPad(h) + ":" + zeroPad(m*15));
		
		// Update the event object end time
		var event = t.findEventById(id);
		
		var newEndTime = new Date(event.endTime);
		clearTime(newEndTime);
		newEndTime.setHours(h);
		newEndTime.setMinutes(m*15);
		newEndTime = newEndTime.getTime();

		/*
		var callbackEvent = {
			id : event.id,
			group: event.group,
			user: event.user,
			position: event.position,
			startTime: event.startTime, 
			endTime:   newEndTime,
			_id : event._id,
			coordinates: event.coordinates,
			source: event.source,
			toHTML: event.toHTML
		}
		*/

		var callbackEvent = $.extend(false, 
			{},
			event,
			{ 
				endTime: newEndTime
			}
		); 

		var callback = function(callbackEvent) {
			event.id = callbackEvent.id;
			event.startTime = callbackEvent.startTime;
			event.endTime   = callbackEvent.endTime;
			schedubar.attr('id', event.id).contents(':eq(0)').wrap('<span></span>').parent().text(event.toHTML());

			// TODO: Calculations could be speed up by manipulating
			// existing statistics object - GS.getStatisticsByDays().
			// and calling updateStatistics.
			// It voids the need of calling getcalculateStatistics()
			calculatedStatistics();
			updateStatistics(false);
		}
		
		saveEvent(callbackEvent, callback);
	}
	
	function updateSchedubarHead(schedubar, ui) {
		var id = schedubar.attr('id');
		var h, m;
		
		// schedubar is placed in the second td of each row. when the position style of schedubar is relative position.left
		// value is relative to the second td (parent of schedubar). however, when the position style is changed to absolute 
		// (result of resizing it) position.left value is relative to the row or first td.

		if (schedubar.css('position') == 'relative') { // if this schedubar has not been resized yet the position is relative to its parent (td)
			var x = ui.position.left / schedubar.parent().width();
			h = Math.floor(x * 24);
			m = Math.round((x * 96) - (4 * h));
			if (m == 4) { h++; m=0; }
			
			var adjustedLeft = ((h + m * 0.25) * schedubar.parent().width()) / 24;
			schedubar.css({left: adjustedLeft});
		} else { // if this schedubar has been previously resized the position is absolute and the width of the first td is included in calc
			var parent = schedubar.parent();
			var thisPosLeft  = schedubar.position().left;
			var thisWidth = schedubar.width();
			var parentPosLeft = parent.position().left;
			var parentWidth = parent.width();
			
			var x = (thisPosLeft - parentPosLeft) / parentWidth;
			h = Math.floor(x * 24);
			m = Math.round((x * 96) - (4 * h));
			if (m == 4) { h++; m=0; }

			var adjustedLeft = ((h + m * 0.25) * parentWidth) / 24 + parentPosLeft;
			schedubar.css({left: adjustedLeft});
		}
		
		//schedubar.contents(':eq(0)').wrap('<span></span>').parent().text(id + " # >= " + zeroPad(h) + ":" + zeroPad(m*15));
		
		// Update the event object start time
		var event = t.findEventById(id);
		var timeDiff = event.endTime - event.startTime;
		var newStartTime = new Date(event.startTime);
		clearTime(newStartTime);
		newStartTime.setHours(h);
		newStartTime.setMinutes(m*15);
		newStartTime = newStartTime.getTime();
		var newEndTime = newStartTime + timeDiff; 
		
		/*
		var callbackEvent = {
			id : event.id,
			group: event.group,
			user: event.user,
			position: event.position,
			startTime: newStartTime, 
			endTime:   newEndTime,
			_id : event._id,
			coordinates: event.coordinates,
			source: event.source,
			toHTML: event.toHTML
		}
		*/
		
		var callbackEvent = $.extend(false, 
			{},
			event,
			{ 
				startTime: newStartTime, 
				endTime:   newEndTime
			}
		);

		var callback = function(callbackEvent) {
			event.id = callbackEvent.id;
			event.startTime = callbackEvent.startTime;
			event.endTime   = callbackEvent.endTime;
			schedubar.attr('id', event.id).contents(':eq(0)').wrap('<span></span>').parent().text(event.toHTML());
		}
		
		saveEvent(callbackEvent, callback);
	}

	function updateStatistics(switchType) {
		var statTotalUI = $(".stat[data-id='1']", t.ui);
		
		var type = statTotalUI.data('type');
		if (type == undefined) { 
			type = 0; 
		} else if (switchType) {
			type++;
		}
		
		renderCalculatedStatistics(type % 4);
		statTotalUI.data('type', type);
	}
	
	function renderCalculatedStatistics(type) {
		// Render statistics by day
		var statisticsByDays = GS.getStatisticsByDays();
		
		var statisticsByDay = statisticsByDays[0];
		if (!statisticsByDay) return true;

		var total = 0;
		var number = extractByDayByType(statisticsByDay, type);
		
		total = totalByType(total, number, type);
		$('.stat[data-id="1"]', t.ui).html('Total: ' + renderByDayByType(total, type));
		
		// Render statistics by user
		var statisticsByUsers = GS.getStatisticsByUsers();
		if (!statisticsByUsers) {
			$('.userstat', t.ui).each(function(idx, stat) { $(this).html(""); });
		} else if (statisticsByUsers.length == 0) {
			$('.userstat', t.ui).each(function(idx, stat) { $(this).html(renderByUserByType(0, type)) });
		} else {
			// TODO: Quick hack to display $0 to users not having events scheduled. Can be done better way.
			//$('.userstat', t.ui).each(function(idx, stat) { $(this).html(renderByUserByType(0, type)) });
			
			/*
			$.each(statisticsByUsers, function(index, statisticsByUser) {
				if (!statisticsByUser) return true;
				var number = extractByUserByType(statisticsByUser, type);
				$('.userstat[data-id="' + index + '"]', t.ui).html(renderByUserByType(number, type));
			});
			*/
			for (var index in statisticsByUsers) {
				var statisticsByUser = statisticsByUsers[index]; 
				if (!statisticsByUser) continue;
				if ($.isFunction(statisticsByUser)) break; // for-in could returns a function e.g. Array.prototype.first
				var number = extractByUserByType(statisticsByUser, type);
				$('.userstat[data-id="' + index + '"]', t.ui).html(renderByUserByType(number, type));
			}
		}
	}

	function totalByType(total, number, type) {
		switch(type) {
			case 0: return total + number;
			case 1: return total + number;
			case 2: return Math.max(total, number);
			case 3: return Math.max(total, number);
			default: return total + number;
		}
	}

	function renderByDayByType(value, type) {
		switch(type) {
			case 0: return '$' + value;
			case 1: return value + ' hrs';
			case 2: return value + (value == 1 ? ' person' : ' people');
			case 3: return value + ' position' + (value == 1 ?  '' : 's');
			default: return '$' + value;
		}
	}

	function extractByDayByType(statisticsByDay, type) {
		switch(type) {
			case 0: return statisticsByDay.totalCost;
			case 1: return statisticsByDay.totalHours;
			case 2: return statisticsByDay.users.length;
			case 3: return statisticsByDay.positions.length;
			default: return statisticsByDay.totalCost;
		}
	}
	
	function renderByUserByType(value, type) {
		switch(type) {
			//case 0: return '$' + value;
			//case 1: return value + ' hrs';
			case 0: return (value > 0 ? '$' + value    : '');
			case 1: return (value > 0 ? value + ' hrs' : '');
			case 2: return '';
			case 3: return (value > 1 ? value + ' pos' : '');
			default: return '$' + value;
		}
	}

	function extractByUserByType(statisticsByUser, type) {
		switch(type) {
			case 0: return statisticsByUser.totalCost;
			case 1: return statisticsByUser.totalHours;
			case 2: return 1;
			case 3: return statisticsByUser.positions.length;
			default: return statisticsByUser.totalCost;
		}
	}
	
	function calculateStatistics() {
		calculateDayStatistics();
		calculateUserStatistics();
	}
	
	function calculateDayStatistics() {
		var statisticsByDays = [];

		statisticsByDay = {
			events: [],
			users:  [],
			positions: [],
			totalHours: 0,
			totalCost: 0
		}
		
		statisticsByDays[0] = statisticsByDay;

		var events = t.getEvents();
		$.each(events, function(index, event) {
			if (event && event.position) {
				statisticsByDay.events.push(event);
				
				var eventHours = (event.endTime - event.startTime) / 3600000; // 60 min/h * 60 sec/min * 1000 ms/sec
				var eventCost  = eventHours * event.position.assignedRate;

				statisticsByDay.totalHours += eventHours;
				statisticsByDay.totalCost  += eventCost;

				if ($.inArray(event.user.id, statisticsByDay.users) < 0) {
					statisticsByDay.users.push(event.user.id);
				}
				if ($.inArray(event.position.id, statisticsByDay.positions) < 0) {
					statisticsByDay.positions.push(event.position.id);
				}
			}
		});
		
		GS.setStatisticsByDays(statisticsByDays);
	}
	
	function calculateUserStatistics() {
		var statisticsByUsers = [];
		var events = t.getEvents();
		$.each(events, function(index, event) {
			if (event && event.position) {
				var user = event.user;
				var statisticsByUser = statisticsByUsers[user.id];
				if (!statisticsByUser) {
					statisticsByUser = {
						events: [],
						positions: [],
						totalHours: 0,
						totalCost: 0
					}
					statisticsByUsers[user.id] = statisticsByUser;
				}
				statisticsByUser.events.push(event);
				
				var eventHours = (event.endTime - event.startTime) / 3600000; // 60 min/h * 60 sec/min * 1000 ms/sec
				var eventCost  = eventHours * event.position.assignedRate;

				statisticsByUser.totalHours += eventHours;
				statisticsByUser.totalCost  += eventCost;

				if ($.inArray(event.position.id, statisticsByUser.positions) < 0) {
					statisticsByUser.positions.push(event.position.id);
				}
			}
		});
		
		GS.setStatisticsByUsers(statisticsByUsers);
	}	
}

/* EventManager is to manage sources and fetch data
-----------------------------------------------------------------------------*/
	
function EventManager(options, _sources) {
	var t = this;
	
	// exports
	t.isFetchNeeded = isFetchNeeded;
	t.fetchEvents = fetchEvents;
	t.addEventSource = addEventSource;
	t.removeEventSource = removeEventSource;
	t.addEvent        = addEvent;
	t.addEvents       = addEvents;
	t.updateEvent     = updateEvent;
	t.updateEvents    = updateEvents;
	t.removeEvents    = removeEvents;
	t.getEventSources = getEventSources;
	t.getEvents       = getEvents;
	t.findEventById   = findEventById;
	
	// imports
	var trigger = t.trigger;
	var renderEvent  = t.renderEvent;
	var renderEvents = t.renderEvents;
	var foregoEvents = t.foregoEvents;
	
	// locals
	var unidentifiedSource = { events: [] };
	var sources = [ unidentifiedSource ];
	var rangeStart, rangeEnd;
	var currentFetchID = 0;
	var pendingSourceCnt = 0;
	var loadingLevel = 0;
	var cache = [];

	for (var i=0; i<_sources.length; i++) {
		_addEventSource(_sources[i]);
	}
	
	/* Retrieving event sources and events
	-----------------------------------------------------------------------------*/
	
	function getEventSources() {
		// Shallow copy
		// var b = jQuery.extend({}, a);

		// Deep copy
		// var b = jQuery.extend(true, {}, a);
  
		return jQuery.extend(true, [], sources);
	}
	
	function getEvents() {
		return cache;
	};
	
	function findEventById(id) {
		var event;
		for (var i = 0; i < cache.length; i++) {
			if (cache[i].id == id) { 
				event = cache[i];
				break;
			}
		}
		return event;
	};
	
	/* Fetching
	-----------------------------------------------------------------------------*/
	
	function isFetchNeeded(start, end) {
		return !rangeStart || start < rangeStart || end > rangeEnd;
	}
	
	function fetchEvents(start, end) {
		rangeStart = start;
		rangeEnd = end;
		cache = [];
		var fetchID = ++currentFetchID;
		var len = sources.length;
		pendingSourceCnt = len;
		for (var i=0; i<len; i++) {
			fetchEventSource(sources[i], fetchID);
		}
	}
	
	function fetchEventSource(source, fetchID) {
		_fetchEventSource(source, function(events) {
			if (fetchID == currentFetchID) {
				if (events) {
					for (var i=0; i<events.length; i++) {
						events[i].source = source;
						normalizeEvent(events[i]);
					}
					cache = cache.concat(events);
				}
				pendingSourceCnt--;
				if (!pendingSourceCnt) {
					renderEvents(cache);
				}
			}
		});
	}
	
	function _fetchEventSource(source, callback) {
		var i;
		var fetchers = sl.sourceFetchers;
		var res;
		for (i=0; i<fetchers.length; i++) {
			res = fetchers[i](source, rangeStart, rangeEnd, callback);
			if (res === true) {
				// the fetcher is in charge. made its own async request
				return;
			}
			else if (typeof res == 'object') {
				// the fetcher returned a new source. process it
				_fetchEventSource(res, callback);
				return;
			}
		}
		var events = source.events;
		if (events) {
			if ($.isFunction(events)) {
				pushLoading();
				events(rangeStart, rangeEnd, function(events) {
					callback(events);
					popLoading();
				});
			}
			else if ($.isArray(events)) {
				callback(events);
			}
			else {
				callback();
			}
		}else{
			var url = source.url;
			if (url) {
				var success = source.success;
				var error = source.error;
				var complete = source.complete;
				var data = $.extend({}, source.data || {});
				var startParam = firstDefined(source.startParam, options.startParam);
				var endParam = firstDefined(source.endParam, options.endParam);
				if (startParam) {
					data[startParam] = rangeStart;
				}
				if (endParam) {
					data[endParam] = rangeEnd;
				}
				pushLoading();
				$.ajax($.extend({}, ajaxDefaults, source, {
					data: data,
					success: function(events) {
						events = events || [];
						var res = applyAll(success, this, arguments);
						if ($.isArray(res)) {
							events = res;
						}
						callback(events);
					},
					error: function() {
						applyAll(error, this, arguments);
						callback();
					},
					complete: function() {
						applyAll(complete, this, arguments);
						popLoading();
					}
				}));
			}else{
				callback();
			}
		}
	}
	
	/* Sources
	-----------------------------------------------------------------------------*/

	function addEventSource(source) {
		source = _addEventSource(source);
		if (source) {
			pendingSourceCnt++;
			fetchEventSource(source, currentFetchID); // will eventually call reportEvents
		}
		isChanged = true;
	}
	
	function _addEventSource(source) {
		if ($.isFunction(source) || $.isArray(source)) {
			source = { events: source };
		}
		else if (typeof source == 'string') {
			source = { url: source };
		}
		if (typeof source == 'object') {
			normalizeSource(source);
			sources.push(source);
			return source;
		}
	}
	
	function removeEventSource(source) {
		var removedEvents = [];
		sources = $.grep(sources, function(src) {
			return !isSourcesEqual(src, source);
		});
		// remove all client events from that source
		cache = $.grep(cache, function(e) {
			var eq = isSourcesEqual(e.source, source);
			if (eq) { removedEvents.push(e); }
			return !eq;
		});
		// foregoEvents is better than renderEvents because it takes the source events out 
		// the screen, while the other rerenders the screen and animation might be annoying  
		//renderEvents(cache);
		foregoEvents(removedEvents);
		isChanged = true;
	}

	/* Event Manipulation
	-----------------------------------------------------------------------------*/

	function addEvent(event) { 
		if (!event.source) {
			unidentifiedSource.events.push(event);
			event.source = unidentifiedSource;
		}
	    normalizeEvent(event);
		cache.push(event);
		renderEvent(event);
		isChanged = true;
	}

	function addEvents(events) { 
		if ($.isArray(events)) {
			for (var i = 0; i < events.length; i++) {
				addEvent(events[i]);
			}
		} else {
			var event = events;
			addEvent(event);
		}
	}	
	
	function updateEvent(event) { 
	    normalizeEvent(event);
		renderEvent(event);
		isChanged = true;
	}
	
	function updateEvents(events) { 
		if ($.isArray(events)) {
			for (var i = 0; i < events.length; i++) {
				updateEvent(events[i]);
			}
		} else {
			var event = events;
			updateEvent(event);
		}
	}	
	
	function removeEvents(filter) {
		if (!filter) { // remove all
			cache = [];
			// clear all array sources
			for (var i=0; i<sources.length; i++) {
				if ($.isArray(sources[i].events)) {
					sources[i].events = [];
				}
			}
			renderEvents(cache);
		} else {
			if (!$.isFunction(filter)) { // an event ID
				var id = filter + '';
				filter = function(c) {
					return c._id == id;
				};
			}

			var removedEvents = $.grep(cache, filter, false);
			foregoEvents(removedEvents);
			
			cache = $.grep(cache, filter, true);
			// remove events from array sources
			for (var i=0; i<sources.length; i++) {
				if ($.isArray(sources[i].events)) {
					sources[i].events = $.grep(sources[i].events, filter, true);
				}
			}
			//renderEvents(cache);
		}
		isChanged = true;
	}
	
	/* Loading State
	-----------------------------------------------------------------------------*/
	
	function pushLoading() {
		if (!loadingLevel++) {
			trigger('loading', null, true);
		}
	}
	
	function popLoading() {
		if (!--loadingLevel) {
			trigger('loading', null, false);
		}
	}
	
	/* Event Normalization
	-----------------------------------------------------------------------------*/
	
	function normalizeEvent(event) {
		event._id = event._id || (event.id === undefined ? '_ct' + eventGUID() : event.id + '');
		if (!event.coordinates) {
			var source = event.source || {}; // default coordinates can be specified on source and options level
			event.coordinates = firstDefined(source.coordinates, options.coordinates);
		} 
		// event.className = normalizeClassName(event.className);
		// TODO: if there is no start, return false to indicate an invalid event
		event.toHTML = function () {
			var eventStartTime = new Date(this.startTime);
			var eventEndTime   = new Date(this.endTime);
			var schedubarHTML  = eventStartTime.toString("HH:mm") + '-' + eventEndTime.toString("HH:mm") 
			                   + ' ' 
			                   + (this.position ? this.position.description : 'Not Available');
			return schedubarHTML;
		}
	}

	function normalizeSource(source) {
		source.className = normalizeClassName(source.className);
		var normalizers = sl.sourceNormalizers;
		for (var i=0; i<normalizers.length; i++) {
			normalizers[i](source);
		}
	}
	
	function isSourcesEqual(source1, source2) {
		return source1 && source2 && getSourcePrimitive(source1) == getSourcePrimitive(source2);
	}
	
	function getSourcePrimitive(source) {
		return ((typeof source == 'object') ? (source.events || source.url) : '') || source;
	}
	
}	

/* Utils
------------------------------------------------------------------------------*/

var GUID = 1;
	
function generateGUID() {
	return (GUID++);
}

function zeroPad(n) {
	return (n < 10 ? '0' : '') + n;
}

function clearTime(d) {
	d.setHours(0);
	d.setMinutes(0);
	d.setSeconds(0); 
	d.setMilliseconds(0);
	return d;
}

function denormalizeClassName(className) {
	if (className) {
		if ($.isFunction(className)) {
			return denormalizeClassName(className());
		}
		if ($.isArray(className)) {
			return className.join(' ');
		}
		if (typeof className == 'string') {
			return className;
		}
	}
	return '';
}

function normalizeClassName(className) {
	if (className) {
		// TODO: repeat code, same code for event classNames
		if (typeof className == 'string') {
			className = className.split(/\s+/);
		}
	}else{
		className = [];
	}
	return className;
}

function applyAll(functions, thisObj, args) {
	if ($.isFunction(functions)) {
		functions = [ functions ];
	}
	if (functions) {
		var i;
		var ret;
		for (i=0; i<functions.length; i++) {
			ret = functions[i].apply(thisObj, args) || ret;
		}
		return ret;
	}
}


function firstDefined() {
	for (var i=0; i<arguments.length; i++) {
		if (arguments[i] !== undefined) {
			return arguments[i];
		}
	}
}

function matchingCoordinates(coordinates1, coordinates2) {
	if ($.isArray(coordinates1) && $.isArray(coordinates2)) {
		if (coordinates1.length == coordinates2.length) {
			for (var i = 0; i < coordinates1.length; i++) {
				if (coordinates1[i] != coordinates2[i]) return false;
			}
			return true;
		}
	}
	return false;
}

})(jQuery);