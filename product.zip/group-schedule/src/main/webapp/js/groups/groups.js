// proxy/**
// proxyvoidresp/**

var COUNTRY_ID_US = 40;
var COUNTRY_ID_CA = 235;

//$(document).ready(function() {
function initGroupsScript() {
	var t = this;
	
	// exports
	t.getSelectedGroup = getSelectedGroup;
	
	$( document ).tooltip({
		position: {
			my: "center bottom-20",
			at: "center top",
			using: function( position, feedback ) {
				$( this ).css( position );
				$( "<div>" )
				.addClass( "arrow" )
				.addClass( feedback.vertical )
				.addClass( feedback.horizontal )
				.appendTo( this );
			}
		},
		show: { delay: 800 }
	});

	var GUID      = 1;
	var groupGUID = 1;
	var userGUID  = 1;
	var positionGUID  = 1;
	
	var layout = new Object();
	var model = null;
	var selectedGroup = null;
	
	initView();
	initCommands();
	initEdits();
	
	function initView() {
		retrieveModel();
	}
	
	function updateView() {
		prepareModel();
		
		if (selectedGroup == null ) {
			selectedGroup = model.groups[0];
			$('.users, .positions').hide();
		}

		redrawShapes();
		
		registerEndPointEventHandlers();
		registerShapeEventHandlers();
		initDialogs();
	}

	function retrieveUserGroups(callback) {
		var params = {
			contentLimit: 'BASIC', 
			contentStatus: 'ACTIVE'
		}
		
		queryData(
			'/group-schedule/proxy/users/' + loggedInUserId + '/frontgroups', 
			params, 
			'Loading user groups failed.', 
			callback);
	}

	function retrieveGroup(selectedGroupId, callback) {
		var params = {
			contentLimit: 'COMPLETE', 
			contentStatus: 'ACTIVE'
		}
		
		queryData(
			'/group-schedule/proxy/groups/' + selectedGroupId, 
			params, 
			'Loading group#' + selectedGroupId + ' failed.', 
			callback);
	}

	function retrieveUsers(groupId, userIds, callback) {
		var params = {
			users : userIds,
			contentLimit: 'COMPLETE', 
			contentStatus: 'ACTIVE',
			groupId: groupId
		}

		queryData(
			'/group-schedule/proxy/users', 
			params, 
			'Loading users failed.', 
			callback);
	}
	
	function retrieveMemberships(selectedGroupId, callback) {
		var params = {
		}

		queryData(
			'/group-schedule/proxy/groups/' + selectedGroupId + '/memberships', 
			params, 
			'Loading memberships failed.', 
			callback);
	}
	
	function retrieveModel() {
		if (selectedGroup == null || selectedGroup.id == null) {
			retrieveUserGroups(function(userGroups) {
				var groups = [];

				groups.push(
		  			{
		  				parentId: null,
		  				id: null, 
		  				name: 'ROOT',
		  				members: [],
		  				managers: [],
		  				positionIds: []
		  			}
			  	);
				
				$.each(userGroups, function(index, userGroup) {
					var group =	{
		  				parentId: null,
		  				id: userGroup.id, 
		  				name: userGroup.shortName,
		  				members: [],
		  				managers: [],
		  				positionIds: []
		  			}
					groups.push(group);
				});
				
				var newModel = {
					groups: groups,
					users: [],
					positions: []
				}   

				model = newModel; // TODO: use setter function
				updateView();
			});
		} else {
			retrieveGroup(selectedGroup.id, function(groupDto) {
				var groups = [];
				groups.push(selectedGroup.parentGroup);
				groups.push(selectedGroup);

				var positionIds = [];
				if (groupDto.roles) {
					$.each(groupDto.roles, function(index, role) {
						positionIds.push(role.id);
					});
				}
				selectedGroup.positionIds = positionIds;
				selectedGroup.members = groupDto.userIds;
				
				selectedGroup.details = groupDto;

				$.each(groupDto.subGroups, function(index, subGroup) {
					var group =	{
		  				parentId: selectedGroup.id,
		  				id: subGroup.id, 
		  				name: subGroup.shortName,
		  				members: [],
		  				managers: [],
		  				positionIds: []
		  			}
					groups.push(group);
				});
				
				var newModel = {
					groups: groups,
					users: [],
					positions: []
				}   

				var userIds = groupDto.userIds.join(',');
				retrieveUsers(selectedGroup.id, userIds, function(userDtos) {
					$.each(userDtos, function(index, userDto) {
						var positions = [];
						var color = defaultColor = 'CACACA';
						var rate  = 0;
						$.each(groupDto.assignments, function(index, assignment) {
							if (userDto.id == assignment.userId) {
								positions.push(assignment.roleId);
								if (assignment.rate) {
									if (assignment.rate > rate) {
										rate = assignment.rate;
										if (assignment.color) {
											color = assignment.color;
										} else {
											$.each(groupDto.roles, function(index, role) {
												if (assignment.roleId == role.id) {
													color = role.color ? role.color : defaultColor; 
													return false; // break out the loop
												}
											});
										}
									}
								} else {
									$.each(groupDto.roles, function(index, role) {
										if (assignment.roleId == role.id) {
											if (role.name == 'Admin') {
												rate = Number.MAX_VALUE;
												color = role.color ? role.color : defaultColor;
											} else if (role.rate && role.rate > rate) {
												rate = role.rate;
												color = role.color ? role.color : defaultColor; 
											}
											return false; // break out the loop
										}
									});
								}
							}
						});
						
						var user = {
							id        : userDto.id,
							name      : userDto.shortName,
							positions : positions,
							details   : userDto,
							color     : '#' + color
						}
						
						newModel.users.push(user);
					});
					
					//newModel.users = users;
					newModel.positions = groupDto.roles

					model = newModel; // TODO: use setter function
					updateView();
				});
			});
			
		}
		
		/*
		var positions = [
			{
				id: 1,
				description: 'WAITER',
				rate: 12.50
			},
			{
				id: 2,
				description: 'COOK',
				rate: 20.00
			},
			{
				id: 3,
				description: 'MANAGER',
				rate: 15.00
			}
		]

		var users = [
				{ 
					id: 1, 
					name: 'Employee #1',
					positions: [ 1 ]
				},
				{ 
					id: 2, 
					name: 'Employee #2',
					positions: [ 2 ]
				},
				{ 
					id: 3, 
					name: 'Employee #3',
					positions: [ 3 ]
				}
		]

		var organizationId  = generateGroupGUID();
		var selectedGroupId = generateGroupGUID();
		
		var groups = [
			{
				parentId: null,
				id: organizationId, 
				name: 'The Organization',
				members: [3],
				managers: [3],
				positionIds: [3]
			},
			{
				parentId: organizationId,
				id: selectedGroupId, 
				name: 'Development',
				members: [3],
				managers: [3],
				positionIds: [3]
			}
		]

		for (var i = 3; i < 25; i++) {
			var id = generateGroupGUID();
			groups.push(
				{
					parentId: selectedGroupId,
					id: id+1, 
					name: 'Group ' + id,
					members: [1, 2],
					managers: [3],
					positionIds: [1, 2, 3]
				}
			);
		}

		var model = {
			groups: groups,
			users: users,
			positions: positions
		}   
	
		return model;
		*/
	}
	
	function prepareModel() {
		var groups = model.groups;
		
		$.each(groups, function(index, group) {
			group.subGroups = [];
			
			var users = [];
			$.each(group.managers, function(outerIndex, manager) {
				$.each(model.users, function(innerIndex, user) {
					if (manager == user.id) {
						userClone = jQuery.extend(true, {manager: true}, user);
						users.push(userClone);
						return false;
					}
				});
			});
			$.each(group.members, function(outerIndex, member) {
				// continue by skipping a member who appears also to be a manager
				if ($.inArray(member, group.managers) >= 0) return true; 
				
				$.each(model.users, function(innerIndex, user) {
					if (member == user.id) {
						userClone = jQuery.extend(true, {manager: false}, user);
						users.push(userClone);
						return false;
					}
				});
			});

			group.users = users;

			// The user sequence is needed to determine what events coordinates to be in schedutable.js
			if (selectedGroup) {
				GS.sortUsers();
			}
			//$.each(group.users, function(index, user) {
			//	user.sequence = index + 1;
			//});
			
			var positions = []
			$.each(group.positionIds, function(outerIndex, positionId) {
				$.each(model.positions, function(innerIndex, position) {
					if (positionId == position.id) {
						//positionClone = jQuery.extend(true, {}, position);
						//positions.push(positionClone);
						positions.push(position);
						return false;
					}
				});
			});
			
			group.positions = positions;
		});
		
		$.each(groups, function(index1, group1) {
			$.each(groups, function(index2, group2) {
				if (index1 != index2) {
					if (group1.id == group2.parentId) {
						if (!group2.parentGroup) {
							group1.subGroups.push(group2);
							group2.parentGroup = group1;
						}
					} else if (group2.id == group1.parentId) {
						if (!group1.parentGroup) {
							group2.subGroups.push(group1);
							group1.parentGroup = group2;
						}
					}
				}
			});
		});
	}
	
	function inGroupsMode() {
		var groupsMode = $('.groups').hasClass('grayscale');
		return groupsMode;
	}
	
	function inUsersMode() {
		var usersMode = $('.users').hasClass('grayscale');
		return usersMode;
	}
	
	function inPositionsMode() {
		var positionsMode = $('.positions').hasClass('grayscale');
		return positionsMode;
	}
	
	function setSelectedGroup(group) {
		if (selectedGroup == null || group == null || selectedGroup.id != group.id) {
			selectedGroup = group;
			initView();
		}
	}
	
	function getSelectedGroup() {
		return selectedGroup;
	}
	
	function addAll(source, target) {
		$.each(target, function(index, element) {
			source.push(element);
		});
	}

	function positionShapes() {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();

		var selectedGroup = getSelectedGroup();
		
		var descendants;
		if (groupsMode) {
			descendants = selectedGroup.subGroups;
		} else if (usersMode) {
			descendants = selectedGroup.users;
		} else {
			descendants = selectedGroup.positions;
		}

		// Take into consideration the space consumed by the header (logo and toolbar)
		var toolbar = $('.toolbar-body-wrapper-row');
		
		var windowWidth  = $(window).width();
		var windowHeight = $(window).height();
		//console.log("windowWidth, windowHeight: " + [windowWidth, windowHeight].join(', '));
		var marginLeft   = 30;
		var marginRight  = 200;
		var marginTop    = toolbar.position().top + toolbar.innerHeight() + 4; // 30;
		var marginBottom = 30;
		var diameter     = 120; // shape diameter
		var distanceX    = 20;  // minimum horizontal distance between peripheries of two closest shapes 
		var distanceY    = 10;  // minimum vertical   distance between peripheries of two closest shapes 
		var wx = diameter + distanceX; 
		var hy = diameter + distanceY; 

		var innerWidth  = (windowWidth  - marginLeft - marginRight );
		var innerHeight = (windowHeight - marginTop  - marginBottom);
		
		var nx = Math.floor((innerWidth               + distanceX) / wx);
		var ny = Math.floor((innerHeight - 2*diameter + distanceY) / hy);
		var n = 2*(nx + ny);
		
		var m = (selectedGroup.parentGroup ? 1 : 0) + descendants.length;
		// IDEA: If (m > n - 2) the top left subgroup and bottom right shapes 
		// could be replaced by PREV and NEXT shapes to scroll forth and back. 
		m = Math.min(m + 2, n);
		var mx = Math.floor(m*(nx/n));
		var my = Math.floor(m*(ny/n));

		//console.log("n, nx, ny, m, mx, my: " + [n, nx, ny, m, mx, my].join(', '));
		
		var diff = m - 2*(mx + my);
		var diffx = nx - mx;
		var diffy = ny - my;
		var diffyMin = Math.min(diffy, diff);
		//console.log("diff, diffx, diffy, diffyMin: " + [diff, diffx, diffy, diffyMin].join(', '));
		my   += Math.round(diffyMin/2);
		diff -= diffyMin;
		var diffxMin = Math.min(diffx, diff);
		mx   += Math.round(diffxMin/2);
		diff -= diffxMin;
		//console.log("diff, diffx, diffy, diffxMin: " + [diff, diffx, diffy, diffxMin].join(', '));
		
		var wxUpdated = (innerWidth  + distanceX) / mx;
		var hyUpdated = (innerHeight + distanceY) / (my + 2);
		
		// Ensure the wxUpdated and hyUpdated do not exceed the workable area
		wxUpdated = Math.min(wxUpdated, innerWidth  - wx);
		hyUpdated = Math.min(hyUpdated, innerHeight - hy);

		//console.log("mx, my, wxUpdated, hyUpdated: " + [mx, my, wxUpdated, hyUpdated].join(', '));
		
		if (selectedGroup.parentGroup) {
			selectedGroup.parentGroup.uiPosition = { top: marginTop, left: marginLeft }
		}
		
		var index = 0;

		var top  = marginTop;
		var left = marginLeft + wxUpdated;
		for (var i = 0; i < mx - 2; i++) { // -2 because of the parent group shape and
			left += wxUpdated;             // empty space next to it on the first row.
			if (!descendants[index]) break;
			descendants[index++].uiPosition = { top: top, left: left }
		}
		
		var leftOf2ndColum = left;
		
		top  = marginTop + hyUpdated;
		left = marginLeft;
		for (var i = 0; i < my - 1; i++) {
			top  += hyUpdated;
			if (!descendants[index]) break;
			descendants[index++].uiPosition = { top: top, left: left }
		}
		
		var topOf2ndRow = top;
		
		top  = marginTop;
		left = leftOf2ndColum; 
		for (var i = 0; i < my; i++) {
			top  += hyUpdated;
			if (!descendants[index]) break;
			descendants[index++].uiPosition = { top: top, left: left }
		}
		
		top  = topOf2ndRow + hyUpdated;
		left = marginLeft;
		for (var i = 0; i < mx; i++) {
			if (!descendants[index]) break;
			descendants[index++].uiPosition = { top: top, left: left }
			left += wxUpdated;
		}
		
		//topOfSelectedGroup  = (windowHeight - diameter) / 2;
		//leftOfSelectedGroup = (windowWidth  - diameter) / 2;
		topOfSelectedGroup  = ((top  + diameter - marginTop) - diameter) / 2 + marginTop;
		leftOfSelectedGroup = ((leftOf2ndColum + diameter -  marginLeft) - diameter) / 2;
		selectedGroup.uiPosition = { top: topOfSelectedGroup, left: leftOfSelectedGroup }
	}

	function clearShapes() {
		$('#shapes').empty();
    }
	
	function drawShapes() {
		var selectedGroup = getSelectedGroup();
		addGroup(selectedGroup);

		if (selectedGroup.parentGroup) {
			addGroup(selectedGroup.parentGroup);
			connectShapes(selectedGroup.parentGroup, selectedGroup);
		}
	
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		if (groupsMode) {
			$.each(selectedGroup.subGroups, function(index, subGroup) {
				addGroup(subGroup);
			});

			$.each(selectedGroup.subGroups, function(index, subGroup) {
				connectShapes(selectedGroup, subGroup);
			});
		} else if (usersMode) {
			$.each(selectedGroup.users, function(index, user) {
				addUser(user);
			});

			$.each(selectedGroup.users, function(index, user) {
				connectShapes(selectedGroup, user);
			});
		} else {
			$.each(selectedGroup.positions, function(index, position) {
				addPosition(position);
			});

			$.each(selectedGroup.positions, function(index, position) {
				connectShapes(selectedGroup, position);
			});
		}

		loadGroupLogos();
		loadUserPhotos();
	}
	
	function loadGroupLogos(groupLogos) {
		if (!groupLogos) {
			groupLogos = $('.icon-group,.icon-office');
		}
		groupLogos.each(function(index, groupLogo) {
			var shape = $(groupLogo).parent();
			var group  = shape.data('group');
			var imageURL = GS.getContext() + '/proxy/read/group[' + group.id + ']';
			var css = { width: '32px', height: '32px'};
			GS.loadImage(imageURL, function(image) {
				image.css(css).appendTo(groupLogo);
			});
		});
	}
	
	function loadUserPhotos(userPhotos) {
		if (!userPhotos) {
			userPhotos = $('.icon-user');
		}
		userPhotos.each(function(index, userPhoto) {
			var shape = $(userPhoto).parent();
			var user  = shape.data('user');
			var imageURL = GS.getContext() + '/proxy/read/user[' + user.id + ']';
			var css = { width: '32px', height: '32px'};
			GS.loadImage(imageURL, function(image) {
				image.css(css).appendTo(userPhoto);
			});
		});
	}
	
	function redrawShapes() {
		clearShapes();
		positionShapes();
		drawShapes();
	}

	function initCommands() {
		$('.add').click(function(event) {
			$('#dialog').dialog('close');
			addGroupOrUserOrPosition();
		});

		$('.groups').click(function(event) {
			$('#dialog').dialog('close');
			$('.groups').addClass('grayscale');
			$('.users').removeClass('grayscale');
			$('.positions').removeClass('grayscale');
			redrawShapes();
		});

		$('.users').click(function(event) {
			$('#dialog').dialog('close');
			$('.users').addClass('grayscale');
			$('.groups').removeClass('grayscale');
			$('.positions').removeClass('grayscale');
			redrawShapes();
		});
		
		$('.positions').click(function(event) {
			$('#dialog').dialog('close');
			$('.positions').addClass('grayscale');
			$('.groups').removeClass('grayscale');
			$('.users').removeClass('grayscale');
			redrawShapes();
		});
		
		$('.trash').droppable({
			//scope: "shape",
			drop: function( event, ui ) {
				var source = ui.draggable;
				
				// TODO: Change this code - ROOT and top groups should not be removed
				if (source.attr("id") == 'group1') {
					return; // cannot remove the organization or the selected group, i.e. the group
					// the user stepped into. to remove the selected group the user must step out/up.
				}
				
				removeGroupOrUserOrPosition(source);
				/*
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					if (connection) {
						if (connection.source[0] == source[0] || connection.target[0] == source[0]) {
							$(connectionPath).parent().remove();
						} 
					}
				});
				source.remove();
				*/
			}
		});
	}
	
	function addGroup(group) {
		var groupShape = $(groupHTML(group)).appendTo('#shapes');
		//var groupShape = $('#group' + group.id); // slower vs proven
		
		/*
		NOTE: Replaced css class based circles by SVG
		if (group.id == selectedGroup.id) {
			groupShape.addClass('selected-shape');
		} else if (group.id == selectedGroup.parentId) {
			groupShape.addClass('parent-shape');
		}
		*/
		
		groupShape.data('group', group);
		registerShapeEventHandlers(groupShape);
		registerEndPointEventHandlers($('.ep',groupShape));
	}
	
	function groupHTML(group) {
		if (!group.uiPosition) { // temp hack for not
			return '';           // rendered groups 
		}

		/*
		// NOTE: The below code and its comment have been invalidated after applying width and height to SVG.
		//
		// To prevent vertical and horizontal bars appearance when displaying a temporary shape for new group 
		// to be created the code uses the initial variant of shapes i.e. div with background of grey circle
		// All other cases are backed up by SVG variant of shapes.
		if (group.id < 0) {
			var groupHTML = '<div id="group' + group.id + '" class="shape group" data-shape="circle" data-image="circle" style="left:' 
						  + group.uiPosition.left + 'px; top: ' + group.uiPosition.top + 'px;"><div class="ep"></div>'  
						  + '<div class="' + (group.details && group.details.business ? 'icon-office' : 'icon-group') + '"></div>' + group.name + '</div>';
			return groupHTML;
		}
		*/
		
		var styleClass = '';
		var fill = '#CACACA';
		if (group.id == selectedGroup.id) {
			fill = '#FCF344'; 
			styleClass = ' selected-shape';
		} else if (group.id == selectedGroup.parentId) {
			fill = '#76F068';
		}
		
		// prior to setting SVG's width and height the following code used to be
		// uncommented to align the shape text depending on the browser name. 
		// var firefox = ( navigator.userAgent.match(/Firefox/g) ? true : false );
		// var top = firefox ? -90 : -60; 
		var top = -60; 
		
		var groupHTML = '<div id="group' + group.id + '" class="shape group ' + styleClass  
					  + '" style="left:' + group.uiPosition.left + 'px; top: ' + group.uiPosition.top + 'px; width: 122px; height: 122px;">'
					  + '<svg xmlns="http://www.w3.org/2000/svg" width="122" height="122" version="1.1">'
					  + '<circle cx="61" cy="61" r="60" stroke="#959595" stroke-width="2" fill="' + fill + '" />'
					  + '</svg>' 
					  + '<div class="ep"></div>'  
					  + '<div style="position: relative; top: ' + top + 'px; left: 0px;">' + group.name + '</div>'
					  + '<div class="' + (group.details && group.details.business ? 'icon-office' : 'icon-group') + '"></div></div>';
		
		return groupHTML;
	}
	
	function addUser(user) {
		var userShape = $(userHTML(user)).appendTo('#shapes');
		//var userShape = $('#user' + user.id); // slower vs proven
		userShape.data('user', user);
		registerShapeEventHandlers(userShape); 
		registerEndPointEventHandlers($('.ep','#user' + user.id));
	}
	
	function userHTML(user) {
		/*
		// NOTE: The below code and its comment have been invalidated after applying width and height to SVG.
		//
		// To prevent vertical and horizontal bars appearance when displaying a temporary shape for new user 
		// to be created the code uses the initial variant of shapes i.e. div with background of grey circle
		// All other cases are backed up by SVG variant of shapes.
		if (user.id < 0) {
			var userHTML = '<div id="user' + user.id + '" class="shape ' 
			              + (user.manager?'manager':'member') + '" data-shape="circle" data-image="circle" style="left:' 
						  + user.uiPosition.left + 'px; top: ' + user.uiPosition.top + 'px;"><div class="ep"></div>'  
						  + '<div class="icon-user"></div>' + user.name + '</div>';
			return userHTML;
		}
		*/
		
		var fill = user.color ? user.color : '#CACACA';

		// prior to setting SVG's width and height the following code used to be
		// uncommented to align the shape text depending on the browser name. 
		var firefox = ( navigator.userAgent.match(/Firefox/g) ? true : false );
		var top = firefox ? -90 : -60; 
		//var top = -60; 
		
		var userHTML = '<div id="user' + user.id + '" class="shape ' + (user.manager?'manager':'member') 
				 	 + '" style="left:' + user.uiPosition.left + 'px; top: ' + user.uiPosition.top + 'px; width: 122px; height: 122px;">'
					 + '<svg xmlns="http://www.w3.org/2000/svg" version="1.1">'
					 + '<circle cx="61" cy="61" r="60" stroke="#959595" stroke-width="2" fill="' + fill + '" />'
					 + '</svg>' 
					 + '<div class="ep"></div>'  
					 + '<div style="position: relative; top: ' + top + 'px; left: 0px;">' + user.name + '</div>'
					 + '<div class="icon-user"></div></div>';

		return userHTML;
	}
	
	function addPosition(position) {
		var positionShape = $(positionHTML(position)).appendTo('#shapes');
		//var positionShape = $('#position' + position.id); // slower vs proven
		positionShape.data('position', position);
		registerShapeEventHandlers(positionShape); 
		registerEndPointEventHandlers($('.ep','#position' + position.id));
	}
	
	function positionHTML(position) {
		var positionHTML;

		/*
		// NOTE: The below code and its comment have been invalidated after applying width and height to SVG.
		//
		// To prevent vertical and horizontal bars appearance when displaying a temporary shape for new position 
		// to be created the code uses the initial variant of shapes i.e. div having a background of grey circle
		// All other cases are backed up by SVG variant of shapes.
		if (position.id < 0) {
			var positionHTML = '<div id="position' + position.id + '" class="shape position" data-shape="circle" data-image="circle" style="left:' 
						  + position.uiPosition.left + 'px; top: ' + position.uiPosition.top + 'px;"><div class="ep"></div>'  
						  + '<div class="icon-position"></div>' + position.name + '</div>';
			return positionHTML;
		}
		*/

		var fill = position.color ? position.color : 'CACACA';
		var firefox = ( navigator.userAgent.match(/Firefox/g) ? true : false );
		var top = firefox ? -105 : -80; 
		
		positionHTML = '<div id="position' + position.id + '" class="shape position' // TODO: prevent hardcoded values for coordinates/sizes
					 + '" style="left:' + position.uiPosition.left + 'px; top: ' + position.uiPosition.top + 'px; width: 122px; height: 122px;">'
					 + '<svg xmlns="http://www.w3.org/2000/svg" version="1.1">'
					 + '<circle cx="61" cy="61" r="60" stroke="#959595" stroke-width="2" fill="#' + fill + '" />'
					 + '</svg>' 
					 + '<div class="ep"></div>'  
					 + '<div style="position: relative; top: ' + top + 'px; left: 0px;">' + position.name + '</div>'
					 + '<div class="icon-position"></div></div>';

		return positionHTML;
	}
	
	function addGroupOrUserOrPosition() {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		var shape = $('.shape');
		var top = $(window).height() - shape.height() - 60;
		var left = $(window).width() - shape.width()  - 40;
		
		var selectedGroupId = selectedGroup.id;
		if (groupsMode) {
			var id = generateGroupGUID();
			addGroup({
				parentId: selectedGroupId,
				id: -id, 
				name: 'Group ' + id,
				members: [1, 2],
				managers: [3],
				uiPosition: { top: top, left: left }
			});
		} else if (usersMode) {
			var id = generateUserGUID();
			addUser({
				parentId: selectedGroupId,
				id: -id, 
				name: 'User ' + id,
				uiPosition: { top: top, left: left }
			});
		} else if (positionsMode) {
			var id = generatePositionGUID();
			addPosition({
				parentId: selectedGroupId,
				id: -id, 
				name: 'Position ' + id,
				uiPosition: { top: top, left: left }
			});
		}
	}

	// NOTE: Prerequisite to use the function is to save
	// model object (group, user, position) in the shape, 
	// which id must be updated.
	function updateGroupOrUserOrPositionID(newId, oldId) {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		var uiID;
		if (groupsMode) {
			uiID = "group";
		} else if (usersMode) {
			uiID = "user";
		} else {
			uiID = "position";	
		}
		uiID += oldId;
		
		// Retrieve the position of the old shape
		var oldShape = $('#' + uiID);        
		//-60/140 position adjustment causes problems/offset when updating existing shapes
		//the problem adjustment aimed to address was resolved by setting width and height
		//to SVGs.
		var top  = oldShape.position().top;  //-  60; // move the updated shape a bit to 
		var left = oldShape.position().left; //- 140; // the left and up due to SVG issue
		var uiPosition = { top: top, left: left }; // causing scrollbars to appear.
		
		// If id remains the same, the shape appearence only needs an update. 
		// Otherwise, a new shape will be created and positioned over the 
		// old shape. The new shape will be connected to currently selected 
		// group, and the old shape and its connections taken off the screen.

		if (groupsMode) {
			var newGroup = oldShape.data('group');

			if (newId == oldId) {
				$.each(oldShape.contents(), function(idx, content) { if (idx > 0) { $(content).remove(); } });
				var innerHTML = '<div class="' 
					          + (newGroup.details && newGroup.details.business ? 'icon-office' : 'icon-group') 
					          + '"></div>' + newGroup.name;
				oldShape.append(innerHTML);
			} else {
				// Remove the old shape and its connections from the screen
				removeConnectionToOrFrom(oldShape);
				oldShape.remove(); 

				// Create the new shape and connect it to the selected group
				newGroup.uiPosition = uiPosition;
				addGroup(newGroup);
				connectShapes(selectedGroup, newGroup);
			}
			
			loadGroupLogos($('#group' + newId).children('.icon-group,.icon-office')); // use find to get to 2nd, etc. levels
		} else if (usersMode) {
			var newUser = oldShape.data('user');
			
			// Remove the old shape and its connections from the screen
			removeConnectionToOrFrom(oldShape);
			oldShape.remove(); 

			// Create the new shape and connect it to the selected group
			newUser.uiPosition = uiPosition;
			addUser(newUser); 
			connectShapes(selectedGroup, newUser);
			
			loadUserPhotos($('#user' + newId).children('.icon-user')); // use find to get to 2nd, etc. levels
		} else {
			var newPosition = oldShape.data('position');
			
			// Remove the old shape and its connections from the screen
			removeConnectionToOrFrom(oldShape);
			oldShape.remove(); 
			
			// Create the new shape and connect it to the selected group
			newPosition.uiPosition = uiPosition;
			addPosition(newPosition); 
			connectShapes(selectedGroup, newPosition);
		}
	}

	function removeGroupOrUserOrPositionByID(id) {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		var uiID;
		if (groupsMode) {
			uiID = "group";
		} else if (usersMode) {
			uiID = "user";
		} else {
			uiID = "position";	
		}
		uiID += id;
		
		// Remove shape and all its connections
		var shape = $('#' + uiID);
		removeGroupOrUserOrPosition(shape);
	}

	function removeGroupOrUserOrPosition(shape) {
		shape = $(shape);

		var isGroup    = shape.hasClass('group');
		var isUser     = (!isGroup) && (shape.hasClass('manager') || shape.hasClass('member'));
		var isPosition = (!isGroup) && (!isUser) && shape.hasClass('position');
		
		if (isGroup) {
			removeGroup(shape);
		} else if (isUser) {
			removeUser(shape);
		} else {
			removePosition(shape);	
		}
	}

	function registerEndPointEventHandlers(ep) {
		if (!ep) {
			ep = $('.ep');
		}
		ep.draggable({
			addClasses: "ui-draggable-dragging",
			opacity: 0.5, 
			scope: "shape", 
			zIndex : 100,
			cursor: "pointer",
			grid: [1, 1],
			appendTo: "body",
			helper: 'clone',
			start: function(e, ui) {
				//$(ui.helper).addClass('external-event');
				//$(ui.helper).css('font-weight', 'bold');
				//$(ui.helper).removeClass('content pos1');
				//$(ui.helper).addClass('content contentype1  horizontal stripes ui-draggable');//$(this).attr('class'));				
				//$(ui.helper).width($(this).width());
				//$(ui.helper).height($(this).height());
				// increase the size of the clone comparing to the one of the original thus capturing user attention

				$(this).addClass("ui-draggable-dragging");

				var xm  = e.pageX;
				var ym  = e.pageY;
				var halfw = $(this).width()/2;
				var halfh = $(this).height()/2;
				
				var dragExistingConnection = false;
				var shape = $(this).parent();
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					var sameAsConnectionSource = (connection.source[0] == shape[0]);
					var sameAsConnectionTarget = (connection.target[0] == shape[0]);
					if (sameAsConnectionSource || sameAsConnectionTarget) {
						var x1 = (sameAsConnectionSource ? connection.x1 : connection.x2);
						var y1 = (sameAsConnectionSource ? connection.y1 : connection.y2);
						var x2 = x1 + halfw; x1 -= halfw;
						var y2 = y1 + halfh; y1 -= halfh;
						console.log(">>> xm, ym, x1, y1, x2, y2:" + [xm, ym, x1, y1, x2, y2].join(', ') + ", in: " + isPointInside(xm, ym, x1, y1, x2, y2));
						
						if (isPointInside(xm, ym, x1, y1, x2, y2)) {
							dragExistingConnection = true;
							draggedPath = $(connectionPath);
							draggedConn = draggedPath.parent();
							draggedPath.attr("id", "dragged-path");
							draggedConn.attr("id", "dragged-connection");
							//draggedPath.removeData("connection");
						}
					}
				});
					
				if (!dragExistingConnection) {
					//var x = $(this).position().left;
					var x = $(this).offset().left;
					var y = $(this).offset().top;
					
					//var conn = '<svg style="position:absolute;left:0px;top:0px" width="1024" height="800" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="dragged-connection"><path d="M ' + x + ' ' + y + ' ' + x + ' ' + y + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="dragged-path"/>'
					
					//<path pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" d="M632.0161661646432,236.23104297875918 L606.4605650244299,219.02897187199045 L603.9735149964521,225.57225714456837 L601.4864649684743,232.11554241714634 L632.0161661646432,236.23104297875918" class="" stroke="rgba(153, 153, 153, 1.0)" fill="rgba(153, 153, 153, 1.0)"/></svg>
					
					var width  = $(window).width();
					var height = $(window).height();
					var conn = '<svg style="position:absolute;left:0px;top:0px" width="' + width + '" height="' + height + '" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="dragged-connection"><path d="M ' + x + ' ' + y + ' ' + x + ' ' + y + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="dragged-path"/>'
					materializeConnection(conn);
					
					$(window).resize(function(ev) { // does not work well
						var connections = $('svg');
						var width  = $(window).width();
						var height = $(window).height();
						connections.attr("width", width);
						connections.attr("height", height);
					});
					
				}
			},
			drag: function( event, ui ) {
				// redraw the line b/n the source object and its clone representing the moving end of the connection

				var draggedPath = $("#dragged-path");
				var connection = draggedPath.data("connection");
				if (connection) {
					var source = connection.source;
					var target = connection.target;

					var shape = $(this).parent();
					if (source[0] == shape[0]) {
						source = ui.helper;
					} else {
						target = ui.helper;
					} 
					
					var x1 = $(source).offset().left;
					var y1 = $(source).offset().top;
					x1 += $(source).width()/2;
					y1 += $(source).height()/2;
					var radius1 = $(source).width()/2;
					var circle1 = { x: x1, y: y1, radius: radius1 }
					
					var x2 = $(target).offset().left;
					var y2 = $(target).offset().top;
					x2 += $(target).width()/2;
					y2 += $(target).height()/2;
					var radius2 = $(target).width()/2;
					var circle2 = { x: x2, y: y2, radius: radius2 }

					var cps = findConnectingPointsOnTheCircles(circle1, circle2);
					//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
					$("#dragged-path").attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
					$(this).hide();
				} else {
					var x1 = $(this).offset().left;
					var y1 = $(this).offset().top;
					var x2 = ui.offset.left;
					var y2 = ui.offset.top;
					
					draggedPath.attr("d", "M " + x1 + " " + y1 + " " + x2 + " " + y2);
				}
			},
			stop: function( event, ui ) {
				$(this).removeClass("ui-draggable-dragging");
				$(this).hide();
				
				var draggedPath = $("#dragged-path");
				var draggedConn = $("#dragged-connection");
				if (draggedPath.data("connection")) {
					var guid = generateGUID();
					draggedConn.attr("id", "connection" + guid);
					draggedPath.attr("id", "path" + guid);
					//draggedPath.addClass("connection-path");
					draggedPath.attr("class", "connection-path");
				} else {
					draggedConn.remove();
				}
			}
		});
	}
	
	function switchToGroup(shape) {
		var shapeId = shape.attr("id");
		if (/^group/i.test(shapeId)) {
			$('.groups').addClass('grayscale');
			$('.users').removeClass('grayscale');
			$('.positions').removeClass('grayscale');
			
			GS.clearImageCache();
			
			var id = shapeId.substr('group'.length);
			if (id == 'null') {
				setSelectedGroup(null);
				//Disable buttons on the right for switching to users or positions because at
				//root level these operations are not permitted, there is no sense of having them.
				$('.users, .positions').hide();
			} else if (getSelectedGroup().id != id) {
				$('.users, .positions').show();
				$.each(model.groups, function(index, group) {
					if (group.id == id) {
						setSelectedGroup(group);
						//redrawShapes(); // setSelectedGroup will call initView() function
						return false;
					}
				});
			}
		}
	}
	
	function registerShapeEventHandlers(shape) {
		if (!shape) {
			shape = $(".shape");
		}
		
		shape.dblclick(function(event) {
			switchToGroup($(this));
		});

		shape.bind('tap', function(event) {
			switchToGroup($(this));
		});
		
		shape.droppable({
			scope: "shape",
			over: function( event, ui ) { 
				// animate the shape e.g. different color, increased size, pulsating
			},
			out: function( event, ui ) {
				// rollback the shape to its initial state (size, color, etc.)
			},
			drop: function( event, ui ) {
				// rollback the shape to its initial state (size, color, etc.)
				var source = ui.draggable.parent();
				var target = $(this);
				
				var draggedPath = $("#dragged-path");
				var connection = draggedPath.data("connection");
				if (connection) {
					if (connection.source[0] == source[0]) {
						source = $(this);
						target = connection.target;
					} else {
						source = connection.source;
						target = $(this);
					} 
				}
				
				if (source[0] == target[0]) {
					var draggedPath = $("#dragged-path");
					draggedPath.removeData("connection");
					return;
				}
				
				var radius = $(this).width()/2;

				var x1 = source.offset().left;
				var y1 = source.offset().top;
				x1 += source.width()/2;
				y1 += source.height()/2;
				var circle1 = { x: x1, y: y1, radius: radius }
				
				var x2 = target.offset().left;
				var y2 = target.offset().top;
				x2 += target.width()/2;
				y2 += target.height()/2;
				var circle2 = { x: x2, y: y2, radius: radius }

				var cps = findConnectingPointsOnTheCircles(circle1, circle2);
				console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
				$("#dragged-path").attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
				ui.draggable.hide();
				
				$("#dragged-path").data("connection", { source: source, target: target, x1: cps.x1, y1: cps.y1, x2: cps.x2, y2: cps.y2 });
			}
		});
		
		shape.mouseleave(function(event) {
			var ep = $('.ep', this);
			if (!ep.hasClass("ui-draggable-dragging")) {
				ep.hide();
			}
		});
		
		shape.mousemove(function(event) {
			var ep = $('.ep', this);
			var x  = event.pageX - $(this).offset().left;
			var y  = event.pageY - $(this).offset().top;
			var w  = $(this).width();
			var h  = $(this).height();
			var cx = w/2;
			var cy = h/2;
			var distance   = Math.sqrt((cx-x)*(cx-x) + (cy-y)*(cy-y));
			var radius     = cx;
			var threshold  = 5;
			
			/*
			console.log("left=" + x);
			console.log("top=" + y);
			console.log("width=" + w);
			console.log("height=" + h);
			*/
			
			//console.log("distance=" + distance);
			
			if ((radius - threshold) <= distance && distance <= (radius + threshold)) {
				var circle = {
					x: cx,
					y: cy,
					radius: radius - 2
				}
				var point = {
					x: x,
					y: y
				}
				var closestPointOnTheCircle = findClosestPointOnTheCircle(point, circle);
				x = closestPointOnTheCircle.x;
				y = closestPointOnTheCircle.y;
				
				ep.css({
					position: 'absolute',
					left: x - ep.width()/2, 
					top: y - ep.height()/2
				}).show();
			} else {
				if (!ep.hasClass("ui-draggable-dragging")) {
					ep.hide();
				}
			}
		});
		
		shape.draggable({
			cursor: "pointer",
			start: function(e, ui) {
				$(this).addClass("ui-draggable-dragging");
				$('.ep', this).hide(); // hide the endpoint in case it is visible when dragging the shape
			},
			drag: function( event, ui ) {
				var draggedShape = $(this);
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					if (connection.source[0] == draggedShape[0] || connection.target[0] == draggedShape[0]) {
						var radius = draggedShape.width()/2;

						var source = $(connection.source);
						var x1 = source.offset().left;
						var y1 = source.offset().top;
						x1 += source.width()/2;
						y1 += source.height()/2;
						var circle1 = { x: x1, y: y1, radius: radius }
						
						var target = $(connection.target);
						var x2 = target.offset().left;
						var y2 = target.offset().top;
						x2 += target.width()/2;
						y2 += target.height()/2;
						var circle2 = { x: x2, y: y2, radius: radius }

						var cps = findConnectingPointsOnTheCircles(circle1, circle2);
						//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
						$(connectionPath).attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
					}
				});
			},
			stop: function( event, ui ) {
				$(this).removeClass("ui-draggable-dragging");
			}
		});
	}
	
	function connectShapes(source, target) {
		/*
		// Solved the issue with the width and height of a position with custom color by specifying the
		// width and height at the time of HTML creation for that position shape. Therefore the code with
		// useSourceChild and useTargetChild below is no longer needed. It will be kept until next check
		// in the source repository.
		var useSourceChild;
		var useTargetChild;

		if (!source.members && !source.positions) { // then it is a position
			//if ($(source).children(':eq(0)')[0].tagName == 'svg') { ... }
			if (source.details && source.details.color) {
				useSourceChild = true;
			}
		}

		if (!target.members && !target.positions) { // then it is a position
			//if ($(target).children(':eq(0)')[0].tagName == 'svg') { ... }
			if (target.details && target.details.color) {
				useTargetChild = true;
			}
		}
		*/
		
		var source = $((source.members ? '#group' : (source.positions ? '#user' : '#position')) + source.id);
		var target = $((target.members ? '#group' : (target.positions ? '#user' : '#position')) + target.id);

		if (target.size() == 0) {
			// the subgroup or user is not rendered; therefore, 
			// no connection is to be established.
			return; 
		}

		/*
		if (useSourceChild) { // position
			source = $(source).children(':eq(0)'); // use svg coordinates and sizes
		}
		
		if (useTargetChild) { // position
			target = $(target).children(':eq(0)'); // use svg coordinates and sizes
		}
		*/
		
		var x1 = $(source).offset().left;
		var y1 = $(source).offset().top;
		x1 += $(source).width()/2;
		y1 += $(source).height()/2;
		var radius1 = $(source).width()/2;
		var circle1 = { x: x1, y: y1, radius: radius1 }
		
		var x2 = $(target).offset().left;
		var y2 = $(target).offset().top;
		x2 += $(target).width()/2;
		y2 += $(target).height()/2;
		var radius2 = $(target).width()/2;
		var circle2 = { x: x2, y: y2, radius: radius2 }

		var cps = findConnectingPointsOnTheCircles(circle1, circle2);
		//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
		var width  = $(window).width()  - 20; // to prevents scroller bars, needs investigation
		var height = $(window).height() - 20; // to prevents scroller bars, needs investigation
		var guid = generateGUID();
		
		var conn = '<svg style="position:absolute;left:0px;top:0px" width="' + width + '" height="' + height + '" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="connection' + guid + '"><path d="M ' + cps.x1 + ' ' + cps.y1 + ' ' + cps.x2 + ' ' + cps.y2 + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="path' + guid + '"/>'
		materializeConnection(conn);

		var createdPath = $("#path" + guid);
		createdPath.data("connection", { source: source, target: target, x1: cps.x1, y1: cps.y1, x2: cps.x2, y2: cps.y2 });
		createdPath.attr("class", "connection-path");
	}
	
	function materializeConnection(conn) {
		// '#shapes' is used instead of 'body' to make clear shapes easy to implement
		$(conn).appendTo('#shapes').dblclick(function(event) {
			$(this).remove();
		}).bind('tap', function(event) {
			$(this).remove();
		});
	}
	
	function removeConnectionToOrFrom(shape) {
		shape = $(shape);
		// Remove all connections to the old shape from the screen
		$(".connection-path").each(function(index, connectionPath) {
			var connection = $(connectionPath).data("connection");
			if (connection.source[0] == shape[0] || connection.target[0] == shape[0]) {
				$(connectionPath).remove();
			}
		});		
	}
	
	/* Dialogs 
	------------------------------------------------------------------------------*/
	
	function moveShapesToFront() {
		/* workaround to ensure shapes are properly repaint */
		$('.shape').css({zIndex: 2});
	}

	function moveShapesToBack() {
		/* workaround to ensure shapes are properly repaint */
		$('.shape').css({zIndex: 0});
	}
	
	function initDialogs() {
		var closefn = function() {
			moveShapesToFront();
		}

		// To avoid initializing the dialog (esp. save button more than once)
		var initialized = $( '#dialog' ).data('initialized');
		if (!initialized) {
			$( '#dialog' ).data('initialized', true);

			$( '#dialog' ).dialog({ autoOpen: false, height: 560, width: 560, close: closefn });
			$('button#save').button().click(function(event) {
				event.preventDefault();

				var form = $('#dataForm');
				var shape = form.data('shape'); 

				var isValid;
				if (shape.hasClass('member')) {
					isValid = validateUser(form);
				} else if (shape.hasClass('manager')) {
					isValid = validateUser(form);
				} else if (shape.hasClass('group')) {
					isValid = validateGroup(form);
				} else if (shape.hasClass('position')) {
					isValid = validatePosition(form);
				}
				
				if (!isValid) return;

				$( '#dialog' ).dialog('close');
				
				moveShapesToBack(); 
				
				if (shape.hasClass('member')) {
					updateUser(form);
				} else if (shape.hasClass('manager')) {
					updateUser(form);
				} else if (shape.hasClass('group')) {
					updateGroup(form);
				} else if (shape.hasClass('position')) {
					updatePosition(form);
				}

				moveShapesToFront(); 
			});
		}
		
		/*
		// Listeners for double click on shapes needs to be registered just once and 
		// will be invoked no matter the number of times shapes are created, deleted 
		// and recreated.  
		$( document ).on('dblclick', 'div.shape.member',  { member  : true }, editUser);
		$( document ).on('dblclick', 'div.shape.manager', { manager : true }, editUser);
		$( document ).on('dblclick', 'div.shape.group',    editGroup   );
		$( document ).on('dblclick', 'div.shape.position', editPosition);
		*/
		//initColors();
	}

	function initEdits() {
		$( document ).on('dblclick tap', 'div.shape.member',  { member  : true }, editUser);
		$( document ).on('dblclick tap', 'div.shape.manager', { manager : true }, editUser);
		$( document ).on('dblclick tap', 'div.shape.group',    editGroup   );
		$( document ).on('dblclick tap', 'div.shape.position', editPosition);
	}
	
	function loadAddress(form, dto) {
		if (dto) {
			var country = dto.country;
			var countryId = $('#countryId option', form).filter(function () { return $(this).html() == country; }).val();
			$('#countryId', form).val(countryId);

			$('#countryId', form).change(function(event) {
				var countryId = $(this).val();
				if (countryId == COUNTRY_ID_US || countryId == COUNTRY_ID_CA) {
					$('#region',   form).hide();
					$('#regionId', form).show();
				} else {
					$('#region',   form).show();
					$('#regionId', form).hide();
				}
			});

			// Select the region when country is US or CA; otherwise, set the region name in the text field
			var region = dto.region;
			if (countryId == COUNTRY_ID_US || countryId == COUNTRY_ID_CA) {
				$('#region',   form).hide();
				$('#regionId', form).show();
	
				var regionId = $('#regionId option', form).filter(function () { return $(this).html() == region; }).val();
				$('#regionId', form).val(regionId);
			} else {
				$('#region',   form).show();
				$('#regionId', form).hide();
				
				$('#region', form).val(region);
			}
			
			$('#city',       form).val(dto.city);
			$('#address',    form).val(dto.address);
			$('#postalCode', form).val(dto.postalCode);
		} else {
			$('#region',   form).hide();
			$('#regionId', form).show();
		}
	}
	
	function updateAddress(form, dto) {
		var country = $('#countryId option:selected', form).text();
		dto.country = country;
		
		if ($('#regionId', form).is(':visible')) { // :reallyvisible
			// TODO: selected text might be internationalized and therefore be in a local
			// format. One option is to store ids along with free form text for region, 
			// which is possible with two separate fields in the user entity. The other
			// option is the values of select options to be latin representation of the 
			// region. The problem can be addressed at later time. 
			//var regionId = $('#regionId', form).val(), // it is ID, not text
			var region = $('#regionId option:selected', form).text(); 
			dto.region = region;
		} else {
			var region = $('#region', form).val(); // free form text
			dto.region = region;
		}
	}
	
	function editUser(event) {
		//event.data.member ? alert('Edit User') : alert('Edit Manager');
		//event.data.member ? console.log('Edit User') : console.log('Edit Manager'); 
		
		var templData = {};
		$('#dialog-content').empty().append($('#user-template').tmpl(templData)); 
		$('#address-container').append($('#address-template').tmpl(templData));
		// NOTE: Not aware of the reason for having it before, but prior commenting
		// it out it was causing visible disturbing scrollers to appear in the dialog
		//$('#dialog-content').height($('#dataForm').height());
		$('#dialog').dialog('option', 'height', 600);
		$('#dialog').dialog('option', 'title', 'Edit User');
		$('#dialog').dialog('open');

		var form = $('#dataForm');
		form.accordion({heightStyle: 'auto'});
		
		var shape = $(this);
		form.data('shape', shape); // used later when closing dialog
		
		var user = shape.data('user');
		form.data('user', user);
		
		loadUser(form);
		installUserAutocomplete(form);
		installMenu();
		initColors();
	}

	function loadUser(form) {
		// Initialize user section
		loadUserIdentity(form);
		// Initialize positions section
		loadUserPositions(form);
		// Initialize address section
		loadUserAddress(form);
	}
	
	function loadUserIdentity(form) {
		var user = form.data('user');
		var userDto = user.details;
		
		if (userDto) {
			// Editing  
			$('#searchForm', form).hide();

			$('#email',     form).val(userDto.email);
			$('#firstName', form).val(userDto.firstName);
			$('#lastName',   form).val(userDto.lastName);
			$('#shortName', form).val(userDto.shortName);
			$('#phone',     form).val(userDto.phone);
			$('#mobile',    form).val(userDto.mobile);
			
			// Note: See updateUser for detailed reason on why these two fields
			// have been taken out the equation.
			//$('#status',    form).val(userDto.status);
			//$('#reason',    form).val(userDto.reason);
			
			// Details of existing users are e
			var userFormFields = $('#email, #firstName, #lastName, #shortName, #phone, #mobile', form);
			userFormFields.prop("readonly", true).css({color: '#A0A0A0'});
		} else {
			var userFormFields = $('#email, #firstName, #lastName, #shortName, #phone, #mobile', form);
			$('#useUser', form).click(function() {
				userFormFields.prop("readonly", true).css({color: '#A0A0A0'});
				$('#user', form).prop("readonly", false).css({color: '#000000'});
			}).prop('checked', true);
			
			$('#newUser', form).click(function() {
				userFormFields.prop("readonly", false).css({color: '#000000'});
				$('#user', form).prop("readonly", true).css({color: '#A0A0A0'});
			});
		}
	}
	
	function loadUserPositions(form) {
		var positionList = $('div.position > ul');
		positionList.empty();
		prepareListOfPositions(form);
		var listOfPositions = form.data('listOfPositions');
		$.each(listOfPositions, function(index, position) {
			var groupPositionHTML = 
				'<li data-position="' + position.role.id + '">' + 
				'<input type="checkbox" style="margin: 7px 10px 0px 3px; float: left;"' + 
				(position.assignment.id ? ' checked="true"' : '') +  
				'>' + 
				'<a href="#">' + position.role.name + '</a>' + 
				'</li>';
			console.log(groupPositionHTML);
			positionList.append(groupPositionHTML);
		});
		
		$('li', positionList).click(function(event) {
			event.stopPropagation();
		});
		$('a', positionList).click(function() {
			var selectedPositionId = $(this).parent().attr('data-position');
			if (selectedPositionId == 'undefined') { selectedPositionId = undefined; }
			$.each(listOfPositions, function(index, position) {
				if (position.role.id == selectedPositionId) {
					switchSelectedPosition(form, position);
					return false;					
				}
			});
		});
		
		var selectedPosition = form.data('selectedPosition');
		if (selectedPosition) {
			var userPositionId = selectedPosition.role.id;
			positionList.attr('data-selected-position', userPositionId);
			$('li[data-position="' + userPositionId + '"] > a', positionList).trigger('click');
		}
	}
	
	function prepareListOfPositions(form) {
		var user = form.data('user');
		
		var listOfPositions = [];
		form.data('listOfPositions', listOfPositions);
		
		var newSelectedPosition;
		$.each(model.positions, function(index, position) {
			var positionAssignment;

			if (user.positions) { // When editing details of user to be created
				$.each(user.positions, function(index, userPositionId) {
					if (position.id == userPositionId) {
						// There is an assignment, go find and use it
						$.each(selectedGroup.details.assignments, function(index, assignment) {
							if (assignment.userId == user.id && assignment.roleId == position.id) {
								positionAssignment = assignment;
								return false;
							}
						});
						// Move to the next model position by breaking out the user positions loop
						return false;
					}
				});
			}

			var currentPosition = {
				assignment: { },
				role: jQuery.extend(true, {}, position)
			}
			
			if (positionAssignment) {
				currentPosition.assignment = positionAssignment; 
				
				if (!newSelectedPosition) { // autoselect the first user position
					newSelectedPosition = currentPosition;
				}
			}
			
			if (!currentPosition.assignment.hours) {
				currentPosition.assignment.hours = {}
			}
			
			if (!currentPosition.role.hours) {
				currentPosition.role.hours = {}
			}
			
			listOfPositions.push(currentPosition);
		});

		{
			var newPosition = {
				assignment: { 
					// "roleId" and assignment "id" not known yet, "status" is not set because the new position might 
					// never be selected 
					userId: user.id,
					hours: {},
				},
				role: {
					// NOTE: role properties will be filled in by the admin (or group manager) if a new position for 
					// the user subject to update needs to be created.
					// e.g. {"name":"New Position","shortName":"NewPos","status":"ACTIVE","color":"FF0000","id":"33"}
					name: "New Position",
					hours : {}
				}
			}
			
			listOfPositions.push(newPosition);
		}

		if (!newSelectedPosition) {
			newSelectedPosition = listOfPositions[0];
		}
			
		if (newSelectedPosition) {
			form.data('selectedPosition', newSelectedPosition);
		}
	}
	
	function switchSelectedPosition(form, newSelectedPosition) {
		saveSelectedPosition(form);
		form.data('selectedPosition', newSelectedPosition);
		loadSelectedPosition(form);
		
		var positionFormFields = $('#positionName, #positionShortName, #positionColor, #positionDescription', form);
		if (newSelectedPosition.role.id) {
			positionFormFields.prop("readonly", true).css({color: '#A0A0A0'});
		} else {
			positionFormFields.prop("readonly", false).css({color: '#000000'});
		}
	}
	
	function saveSelectedPosition(form) {
		var selectedPosition = form.data('selectedPosition');
		if (!selectedPosition) return;
		
		var roleId = selectedPosition.role.id;
		if (roleId) {
			selectedPosition.assignment.roleId = roleId;
			var rate    = $('#positionRate', form).val();
			var perDay  = $('#positionHoursPerDay',  form).val();
			var perWeek = $('#positionHoursPerWeek', form).val();

			var assignmentRate  = selectedPosition.assignment.rate;
			var roleRate        = selectedPosition.role.rate;
			var assignmentHours = selectedPosition.assignment.hours;
			var roleHours       = selectedPosition.role.hours;
			
			if (assignmentRate || roleRate != rate) {
				assignmentRate = rate;
			}
			
			if (assignmentHours.perDay || roleHours.perDay != perDay) {
				assignmentHours.perDay = perDay;
			}
			
			if (assignmentHours.perWeek || roleHours.perWeek != perWeek) {
				assignmentHours.perWeek = perWeek;
			}
		} else {
			selectedPosition.role = {
				groupId   : selectedGroup.id,
				name      : $('#positionName',        form).val(),
				shortName : $('#positionShortName',   form).val(),
				description : $('#positionShortName', form).val(),
				color     : $('#positionColor', form).val(),
				rate      : $('#positionRate',  form).val(),
				hours: {
					perDay   : $('#positionHoursPerDay',  form).val(),
					perWeek  : $('#positionHoursPerWeek', form).val()
				},
				description  : $('#positionDescription', form).val()
			}
		}
	}

	function loadSelectedPosition(form) {
		var selectedPosition = form.data('selectedPosition');
		if (!selectedPosition) return;

		$('#positionName',      form).val(selectedPosition.role.name);
		$('#positionShortName', form).val(selectedPosition.role.shortName);
		$('#positionColor',     form).val(selectedPosition.role.color);
		
		if (selectedPosition.assignment.rate) {
			$('#positionRate', form).val(selectedPosition.assignment.rate);
		} else {
			$('#positionRate', form).val(selectedPosition.role.rate);
		}
		
		var assignmentHours = selectedPosition.assignment.hours;
		var roleHours       = selectedPosition.role.hours;
		
		if (assignmentHours.perDay) {
			$('#positionHoursPerDay',  form).val(assignmentHours.perDay);
		} else if (roleHours.perDay) {
			$('#positionHoursPerDay',  form).val(roleHours.perDay);
		}
		
		if (assignmentHours.perWeek) {
			$('#positionHoursPerWeek',  form).val(assignmentHours.perWeek);
		} else if (roleHours.perWeek) {
			$('#positionHoursPerWeek',  form).val(roleHours.perWeek);
		}
		
		$('#positionDescription', form).val(selectedPosition.role.description);
	}
	
	function loadUserAddress(form) {
		var user = form.data('user');
		var userDto = user.details;
		loadAddress(form, userDto);
	}
	
	function validateUser(form) {
		return true;
	}
	
	function updateUser(form) {
		//NOTE: The id is important to be retrieved from details field of user
		//object because when searching for an existing user the id is stored in
		//details. The user object id contains the id that identifies the shape.
		//This permits replacing the user shape with a new one!!!
		var user = form.data('user');
		var id = user.details ? user.details.id : null; 
		
		var userDto = {
			id        : id,
			email     : $('#email',  form).val(),
			firstName : $('#firstName', form).val(),
			lastName  : $('#lastName',  form).val(),
			shortName : $('#shortName', form).val(),
			phone     : $('#phone',  form).val(),
			mobile    : $('#mobile', form).val(),
			
			// NOTE: The group administrator cannot change the status of user.
			// It is possible is to remove the user from the group by dragging
			// him/her off to the recycle bin. Existing assignments to group
			// roles as result will be removed (presently only one is supported)
			// If there is membership established b/n the group (possible case
			// with top groups) the status will be changed to inactive or the
			// membership will be completely removed. The advantage of changing
			// only the status is that later group will not need user to approve
			// the membership request again.
			//status    : $('#status', form).val(),
			//reason    : $('#reason', form).val(),
			
			city       : $('#city',       form).val(),
			address    : $('#address',    form).val(),
			postalCode : $('#postalCode', form).val(),
		
			containsAllAssignments: true,
			assignments: []
		}
		
		updateAddress(form, userDto);

		//
		// Prepare user assignments to be sent
		//
		
		var assignments = userDto.assignments;
		
		// Save the latest form data
		saveSelectedPosition(form);

		var listOfPositions = form.data('listOfPositions');
		var positionCheckboxes = $('div.position > ul > li > input[type="checkbox"]');
		positionCheckboxes.filter(function(index) {
			return ($(this).is(':checked'));
		}).each(function(index, positionCheckbox) { // each is a better way
			var positionId = $(this).parent().attr('data-position');
			
			if (positionId == 'undefined') {
				var newPosition = listOfPositions[listOfPositions.length-1];
				newPosition.assignment.role = newPosition.role; 
				assignments.push(newPosition.assignment);
			} else {
				var position;
				$.each(listOfPositions, function(index, position) {
					if (position.role.id == positionId) {
						position.assignment.userId = user.id;
						position.assignment.roleId = positionId;
						position.assignment.role   = null; // NOTE: No need of passing information that exists on the other side of the wire (e.g. role)
						assignments.push(position.assignment);
						return false;
					}
				});
			}
		});

		var url, method;
		if (id) {
			method = 'PUT';
			url = '/group-schedule/proxy/groups/' + selectedGroup.id + '/userassignments/' + id;
		} else {
			method = 'POST';
			url = '/group-schedule/proxy/groups/' + selectedGroup.id + '/userassignments';
		}
		
		var callback = function(result) {
			//user.id = 1000; // simulate the returned result from saving op
			
			if (result) {
				// Apply new delta to the model to avoid complete refresh
				// of the seleced group (includes updating ids, adding new
				// roles, etc).

				var tempUserId = user.id;
				user.id = userDto.id = result.userId;
				
				// Add the user if it has not been previously added to the selected
				// group. Note that membership with the top group does not equal 
				// being added to the group. The membership is about user granting 
				// permission to the top group and its subgroups to see his or her 
				// profile, add to groups, and schedule events involving the user.

				var itIsGroupUser = false;
				$.each(selectedGroup.users, function(index, selectedGroupUser){
					if (selectedGroupUser.id == user.id) {
						itIsGroupUser = true;
						return true; // break out the loop
					}
				});
				
				if (!itIsGroupUser) {
					selectedGroup.members.push(user.id);
					selectedGroup.users.push(user);
					model.users.push(user);
				}

				// Update user assignment and role ids from the result assuming that
				// ids are coming back in the same order they are sent to the service.
				// If a new role has been created and assigned to the user, that role
				// will be registered in the model positions and the selected group 
				// position ids. 
				
				if (result.assignments) {
					// result is returned in the form of a map, which is the reason
					// for assignments to appear as a string after stringifying and
					// parsing of the result. As result, further parsing is needed.
					result.assignments = JSON.parse(result.assignments);
					
					var positions = [];
					$.each(result.assignments, function(index, resultAssignment) {
						var userDtoAssignment = userDto.assignments[index];
						if (!userDtoAssignment.id) {
							userDtoAssignment.id = resultAssignment.id;
						}
						var resultAssignmentRoleId = resultAssignment.roleId;
						if (!userDtoAssignment.roleId) {
							userDtoAssignment.roleId = resultAssignmentRoleId;
						}
						if (userDtoAssignment.role) { // Newly created role
							userDtoAssignment.role.id = resultAssignmentRoleId;
							// The new role will be added to the model and selected group
							// A check for prior existence is no needed cause it is a new.
							selectedGroup.positionIds.push(resultAssignmentRoleId);
							selectedGroup.positions.push(userDtoAssignment.role);
							model.positions.push(userDtoAssignment.role);
						} else {
							$.each(model.positions, function(index, position) {
								if (position.id == resultAssignmentRoleId) {
									userDtoAssignment.role = position;
									return true;
								}
							});
						}
						positions.push(resultAssignmentRoleId);
					});
					user.positions = positions;
				}
				
				// Update selected group assignments by removing all assignments of the
				// user and adding just updated assignments of userDto object.
				
				var selectedGroupAssignments = selectedGroup.details.assignments;
				var selectedGroupLatestAssignments = [];
				if (selectedGroupAssignments) {
					$.each(selectedGroupAssignments, function(index, selectedGroupAssignment) {
						if (selectedGroupAssignment.userId != userDto.id) {
							selectedGroupLatestAssignments.push(selectedGroupAssignment);
						}
					});
				}
				$.each(userDto.assignments, function(index, assignment) {
					selectedGroupLatestAssignments.push(assignment);
				});
				selectedGroup.details.assignments = selectedGroupLatestAssignments; 
			}

			// Update user name and details after userDto is successfully saved
			user.name = userDto.shortName;
			user.details = userDto;   

			// Replace the old shape with a new shape. The reason not to update, but
			// to replace is because it is easier and less error prone. Performance
			// remains in the acceptable range.
			
			var shape = form.data('shape'); // store details in the user shape
			shape.data('user', user); // used by updateGroupOrUserOrPositionID 
			updateGroupOrUserOrPositionID(user.id, tempUserId);

			alert('User ' + userDto.shortName + ' successfully saved!');
		}
		
		/* testing 
		var data = '{"id":"4","email":"pavelworld@gmail.com","firstName":"Pavel","lastName":"Jordanov","shortName":"Pavel","phone":"7787133305","mobile":"","city":"NEW WESTMINSTER","address":"338 Hospital Street","postalCode":"V3L 3L4","containsAllAssignments":true,"assignments":[{"hours":{"perDay":"5.0","perWeek":"25"},"roleId":"4","rate":"13","userId":"4","role":null},{"userId":"4","role":{"name":"TS","shortName":"TS","description":"TS","color":"007f7f","rate":"15","hours":{"perDay":"4","perWeek":"20"},"description":"TS Description","groupId":"2"}}],"country":"CANADA","region":""}';
		var userDto = JSON.parse(data);	
		
		data = {"userId":"4","assignments":"[{ \"id\": 29, \"roleId\": 4}, { \"id\": 30, \"roleId\": 24}]"};
		var result = JSON.parse(JSON.stringify(data));
		callback(result);
		*/
		
		sendData(
			url,
			method,
			userDto,
			'Saving ' + userDto.shortName + ' failed', 
			callback, false);
	}
	
	// TODO: UI and save to/load from services are good to be separated.
	// Moreover, forms and shapes should be placed in different js files.
	function removeUser(shape) {
		var user = shape.data('user');

		var callback = function() {
			//Update the model and selected group not to contain
			//the removed user and its assignments
			
			for (var i = 0; i < model.users.length; i++) {
				if (model.users[i].id == user.id) {
					model.users.splice(i, 1);
					break;
				}
			}

			if (selectedGroup.users) {
				for (var i = 0; i < selectedGroup.users.length; i++) {
					if (selectedGroup.users[i].id == user.id) {
						selectedGroup.users.splice(i, 1);
						break;
					}
				}
			}
			
			if (selectedGroup.members) {
				for (var i = 0; i < selectedGroup.members.length; i++) {
					if (selectedGroup.members[i] == user.id) {
						selectedGroup.members.splice(i, 1);
						break;
					}
				}
			}
			
			if (selectedGroup.managers) {
				for (var i = 0; i < selectedGroup.managers.length; i++) {
					if (selectedGroup.managers[i] == user.id) {
						selectedGroup.managers.splice(i, 1);
						break;
					}
				}
			}
			
			if (selectedGroup.details) {
				if (selectedGroup.details.userIds) {
					for (var i = 0; i < selectedGroup.details.userIds.length; i++) {
						if (selectedGroup.details.userIds[i] == user.id) {
							selectedGroup.details.userIds.splice(i, 1);
							break;
						}
					}
				}
				
				if (selectedGroup.details.assignments) {
					for (var i = 0; i < selectedGroup.details.assignments.length; i++) {
						if (selectedGroup.details.assignments[i].userId == user.id) {
							selectedGroup.details.assignments.splice(i, 1);
							break;
						}
					}
				}
			}
			
			// Remove all connections to the shape from the screen
			removeConnectionToOrFrom(shape);
			
			// Remove the shape from the screen
			shape.remove();
	
			alert('User ' + user.name + ' successfully removed!');
		}
	
		if (user.id >= 0) {
			method = 'DELETE'; 
			url = '/group-schedule/proxyvoidresp/groups/' + selectedGroup.id + '/users/' + user.id;
			sendData(
					url,
					method,
					{},
					'Removing ' + user.name + ' failed', 
					callback, false);
		} else {
			callback(); // removing non-existing (a.k.a. detached) group is visually only
		}
	}

	function editGroup(event) {
		//alert('Edit Group');
		//console.log('Edit Group');
		
		// NOTE: Only selected non-root group or a new detached group
		// is permitted to be edited.
		var shape = $(this);

		var isRootGroup = (shape.attr('id') == 'groupnull');
		if (isRootGroup) return true;
		
		var group = shape.data('group');
		var groupDto = group.details;
		
		var selectedGroup = shape.hasClass('selected-shape');
		var detachedGroup = (group.id < 0);
		var editableGroup = selectedGroup || detachedGroup;
		if (!editableGroup) return true;

		var settings = {
			template : '#group-template',
			title: 'Edit Group',
			height: 520,
			panelHeight: 200
		}
		
		var templData = {};
		$('#dialog-content').empty().append($(settings.template).tmpl(templData)); 
		$('#address-container').append($('#address-template').tmpl(templData));
		$('#dialog').dialog('option', 'height', settings.height);
		$('#dialog').dialog('option', 'title', settings.title);
		$('#dialog').dialog('open');

		var form = $('#dataForm');
		form.accordion({heightStyle: 'auto'});
		$('#dataForm > div', '#dialog').height(settings.panelHeight);
		$('#business', form).click(function(event) { 
			event.stopPropagation();
			
			var businessFields = $('#businessName, #businessNumber, #incorporatedName, #taxNumber, #industryId', form);

			if ($('#business', form).prop('checked')) { // or .is(':checked')
				businessFields.prop("readonly", false).css({color: '#000000'});	
			} else {
				businessFields.prop("readonly", true).css({color: '#A0A0A0'});
			}
		});
		
		form.data('shape', shape); // used later when closing dialog
		form.data('group', group);

		loadGroup(form, shape);
		initLogo();
	}
	
	function loadGroup(form) {
		var group = form.data('group');
		var groupDto = group.details;
		if (!groupDto) return;

		$('#groupName',    form).val(groupDto.name);
		$('#shortName',    form).val(groupDto.shortName);
		//$('#logo',         form).val(groupDto.logo);
		$('#description',  form).val(groupDto.description);
		$('#status',       form).val(groupDto.status);

		if (groupDto.business) {
			$('#business',         form).prop('checked', true);
			$('#businessName',     form).val(groupDto.business.businessName);
			$('#businessNumber',   form).val(groupDto.business.businessNumber);
			$('#incorporatedName', form).val(groupDto.business.incorporatedName);
			$('#taxNumber',        form).val(groupDto.business.taxNumber);
			$('#industryId',       form).val(groupDto.business.industry); // number
		}

		$('#phoneNumber', form).val(groupDto.phoneNumber);
		$('#mobileNumber', form).val(groupDto.mobileNumber);
		$('#email',       form).val(groupDto.email);

		//$('#officePhone1', form).val(groupDto.officePhone1);
		//$('#officePhone2', form).val(groupDto.officePhone2);
		//$('#email',        form).val(groupDto.email);
		//$('#altEmail',     form).val(groupDto.altEmail);

		loadAddress(form, groupDto);
	}
	
	function validateGroup(form) {
		if ($('#business', form).prop('checked')) { // or .is(':checked')
			var business = {
				businessName     : $('#businessName',     form).val(),
				businessNumber   : $('#businessNumber',   form).val(),
				incorporatedName : $('#incorporatedName', form).val(),
				taxNumber        : $('#taxNumber',        form).val(),
				industry         : $('#industryId',       form).val() // number
			}

			if (!(business.businessName && business.businessNumber)) { 
				alert('Please complete the business information, \nor uncheck the business section.'); 
				return false; 
			} 
		}

		return true;
	}
	
	function updateGroup(form) {
		var group = form.data('group');
		var id = group.details ? group.details.id : null;
		var parentId = id ? group.details.parentId : selectedGroup.id;

		var groupDto = {
			id           : id,
			parentId     : parentId, 
			name         : $('#groupName',    form).val(),
			shortName    : $('#shortName',    form).val(),
			status       : $('#status',       form).val(),
			phoneNumber  : $('#phoneNumber',  form).val(),
			mobileNumber : $('#mobileNumber', form).val(),
			email        : $('#email',        form).val(),
			//officePhone1 : $('#officePhone1', form).val(),
			//officePhone2 : $('#officePhone2', form).val(),
			//email        : $('#email',        form).val(),
			//altEmail     : $('#altEmail',     form).val(),
			//logo         : $('#logo',         form).val(),
			description  : $('#description',  form).val(),
			address      : $('#address',      form).val(),
			city         : $('#city',         form).val(),
			postalCode   : $('#postalCode',   form).val()
		}

		updateAddress(form, groupDto);

		if ($('#business', form).prop('checked')) { // or .is(':checked')
			groupDto.business = {
				businessName     : $('#businessName',     form).val(),
				businessNumber   : $('#businessNumber',   form).val(),
				incorporatedName : $('#incorporatedName', form).val(),
				taxNumber        : $('#taxNumber',        form).val(),
				industry         : $('#industryId',       form).val() // number
			}
		}
				
		var url, method;
		if (id) {
			method = 'PUT'; 
			url = '/group-schedule/proxyvoidresp/groups/' + selectedGroup.id;
		} else {
			method = 'POST';
			url = '/group-schedule/proxy/groups';
		}
		
		var callback = function(result) {
			var tempGroupId = group.id;
			
			if (!id) { // the position has just been created
				group.id = groupDto.id = result.id;
			}
			
			// Update group name and details after groupDto is successfully saved
			group.name = groupDto.shortName;
			group.details = groupDto;
			//alert(JSON.stringify(groupDto));

			// Update shape on the screen
			var uploadCallback = function() {
				updateGroupOrUserOrPositionID(group.id, tempGroupId);
			} 
			
			var logo = $('#logo');
			var file = logo[0].files[0];
			file.imageRef = group.id;
			uploadFile(file, uploadCallback, uploadCallback);
			
			alert('Group ' + groupDto.shortName + ' successfully saved!');
		}
		
		/* callback({id : group.id}); */
		/* callback({id : 1000});     */
		
		sendData(
			url,
			method,
			groupDto,
			'Saving ' + groupDto.shortName + ' failed', 
			callback, false);
	}

	// TODO: UI and save to/load from services are good to be separated.
	// Moreover, forms and shapes should be placed in different js files.
	function removeGroup(shape) {
		var group = shape.data('group');

		var callback = function() {
			if (group.id == selectedGroup.id) {
				setSelectedGroup(selectedGroup.parent);
			} else {
				// The group must be removed from the model and its parent
				// group. The other solution is to refresh the whole level,
				// which is some cases is lot more easier and cleaner, but 
				// eventually might impact the performance.
				for (var i = 0; i < model.groups.length; i++) {
					if (model.groups[i].id == group.id) {
						model.groups.splice(i, 1);
						break;
					}
				}
				
				var parentGroup = group.parentGroup;
				if (parentGroup) {
					// Subgroups are present as direct property and as details property.
					// The direct property is used when rendering shapes on the screen,
					// while details (a.k.a. dto) property is coming back from services.
					
					if (parentGroup.subGroups) { 
						for (var i = 0; i < parentGroup.subGroups.length; i++) {
							if (parentGroup.subGroups[i].id == group.id) {
								parentGroup.subGroups.splice(i, 1);
							}
						}
					}
					
					if (parentGroup.details && parentGroup.details.subGroups) {
						for (var i = 0; i < parentGroup.details.subGroups.length; i++) {
							if (parentGroup.details.subGroups[i].id == group.id) {
								parentGroup.details.subGroups.splice(i, 1);
							}
						}
					}
				}
				
				// Remove all connections to the shape from the screen
				removeConnectionToOrFrom(shape);
				// Remove the shape from the screen
				shape.remove();
			}

			alert('Group ' + group.name + ' successfully removed!');
		}

		if (group.id >= 0) {
			method = 'DELETE'; 
			url = '/group-schedule/proxyvoidresp/groups/' + group.id;
			sendData(
					url,
					method,
					{},
					'Removing ' + group.name + ' failed', 
					callback, false);
		} else {
			callback(); // removing non-existing (a.k.a. detached) group is visually only
		}
	}
	
	function editPosition(event) {
		//alert('Edit Position');
		//console.log('Edit Position');
		
		var templData = {};
		$('#dialog-content').empty().append($('#position-template').tmpl(templData)); 
		$('#dialog-content').height($('#dataForm').height());
		$('#dialog').dialog('option', 'height', 380);
		$('#dialog').dialog('option', 'title', 'Edit Position');
		$('#dialog').dialog('open');
		
		var form  = $('#dataForm');
		var shape = $(this);
		form.data('shape', shape); // used later when closing dialog
		
		var position = shape.data('position');
		form.data('position', position);
		
		loadPosition(form);
		initLogo();
		initColors();
	}

	function loadPosition(form) {
		var position = form.data('position');
		if (!position.id || position.id < 0) return;

		$('#positionName',      form).val(position.name);
		$('#positionShortName', form).val(position.shortName);
		$('#positionColor',     form).val(position.color);
		$('#positionRate',      form).val(position.rate);
		if (position.hours) {
			$('#positionHoursPerDay',  form).val(position.hours.perDay);
			$('#positionHoursPerWeek', form).val(position.hours.perWeek);
		}
		$('#positionDescription', form).val(position.description);
	}
	
	function validatePosition(form) {
		return true;
	}
	
	function updatePosition(form) {
		var position = form.data('position');
		var id = (position.id >= 0 ? position.id : null); 
		
		var updatedPosition = {
			//frequency was omitted
			id        : id,
			groupId   : selectedGroup.id,
			name      : $('#positionName',      form).val(),
			shortName : $('#positionShortName', form).val(),
			color     : $('#positionColor',     form).val(),
			rate      : $('#positionRate',      form).val(),
			hours: {
				perDay   : $('#positionHoursPerDay',  form).val(),
				perWeek  : $('#positionHoursPerWeek', form).val()
			},
			description  : $('#positionDescription', form).val()
		}

		var url, method;
		if (id) {
			method = 'PUT';
			url = '/group-schedule/proxyvoidresp/groups/' + selectedGroup.id + '/roles/' + id;
		} else {
			method = 'POST';
			url = '/group-schedule/proxy/groups/' + selectedGroup.id + '/roles';
		}
		
		var callback = function(result) {
			var tempPositionId = position.id;
			
			if (!id) { // the position has just been created
				updatedPosition.id = result.id;
			}
			
			position.id      = updatedPosition.id;
			position.groupId = updatedPosition.groupId;
			position.name    = updatedPosition.name;
			position.shortName   = updatedPosition.shortName;
			position.color       = updatedPosition.color;
			position.rate        = updatedPosition.rate;
			position.hours       = updatedPosition.hours;
			position.description = updatedPosition.description;
			
			//TODO: Update shape on the screen
			updateGroupOrUserOrPositionID(position.id, tempPositionId);
			
			if (!id) {
				model.positions.push(updatedPosition);
				model.users.positions.push(updatedPosition.id);
				selectedGroup.positions.push(updatedPosition);
				selectedGroup.positionIds.push(updatedPosition.id);
			}
			
			alert('Position ' + updatedPosition.description + ' successfully saved!');
		}

		sendData(
				url,
				method,
				updatedPosition,
				'Saving ' + updatedPosition.description + ' failed', 
				callback, false);
	}
	
	// TODO: UI and save to/load from services are good to be separated.
	// Moreover, forms and shapes should be placed in different js files.
	function removePosition(shape) {
		var position = shape.data('position');

		var callback = function() {
			if (position.id >= 0) {
				// The position must be removed from the model, its group and
				// users.
				// An alternative solution is to update the model by refresh 
				// -ing the selected group, which in some cases is a lot more 
				// easier and cleaner, but eventually impacts the performance.
				// Furthermore, it would be noticeable on the screen due to
				// repositioning some shapes just recently added to the group.
				for (var i = 0; i < model.positions.length; i++) {
					if (model.positions[i].id == position.id) {
						model.positions.splice(i, 1);
						break;
					}
				}

				if (model.users.positions) {
					$(model.users, function(index, user) {
						for (var i = 0; i < user.positions.length; i++) {
							if (user.positions[i] == position.id) {
								user.positions.splice(i, 1);
								
								if (user.details) {
									if (user.details.roles) {
										for (var j = 0; j < user.details.roles.length; j++) {
											if (user.details.roles[j].id == position.id) {
												user.details.roles.splice(j, 1);
												break;
											}
										}
									}

									if (user.details.assignments) {
										for (var j = 0; j < user.details.assignments.length; j++) {
											if (user.details.assignments[j].roleId == position.id) {
												user.details.assignments.splice(j, 1);
												break;
											}
										}
									}
								}
								
								break;
							}
						}
					});
				}

				if (selectedGroup.positions) {
					for (var i = 0; i < selectedGroup.positions.length; i++) {
						if (selectedGroup.positions[i].id == position.id) {
							selectedGroup.positions.splice(i, 1);
							break;
						}
					}
				}

				if (selectedGroup.positionIds) {
					for (var i = 0; i < selectedGroup.positionIds.length; i++) {
						if (selectedGroup.positionIds[i] == position.id) {
							selectedGroup.positionIds.splice(i, 1);
							break;
						}
					}
				}

				if (selectedGroup.details && selectedGroup.details.assignments) {
					for (var i = 0; i < selectedGroup.details.assignments.length; i++) {
						if (selectedGroup.details.assignments[i].role.id == position.id) {
							selectedGroup.details.assignments.splice(i, 1);
							break;
						}
					}
				}
			}
				
			// Remove all connections to the shape from the screen
			removeConnectionToOrFrom(shape);
			// Remove the shape from the screen
			shape.remove();
	
			alert('Position ' + position.name + ' successfully removed!');
		}
	
		if (position.id >= 0) {
			method = 'DELETE'; 
			url = '/group-schedule/proxyvoidresp/groups/' + selectedGroup.id + '/roles/' + position.id;
			sendData(
					url,
					method,
					{},
					'Removing ' + position.name + ' failed', 
					callback, false);
		} else {
			callback(); // removing non-existing (a.k.a. detached) group is visually only
		}
	}

	
	function initLogo() {
		$('#logo').bind('change', function() {
			if (this.files[0].size > 81920) {
				alert('The file size of logo cannot be greater than 80k');
			};
			
			updateLogo(this.files[0]);
		});
	}
	
	function initColors() {
		$('#positionColor').jPicker({
			window: { 
				expandable: true,
				position: {
					x: 'screenCenter', 
					y: 'bottom'
				}
			}
		});
		//$(document.body).children('div.jPicker.Container').css({zIndex:110});
		//$('div.jPicker.Container').css({zIndex:120});
		$('#positionColor').hide();
	};
	
	function prepareAutocompleteUsers(form) {
		var users = []; 
		form.data('autocomplete-users', users);

		retrieveMemberships(selectedGroup.id, function(membershipDtos) {
			var userIds = [];
			$.each(membershipDtos, function(index, membershipDto) {
				// membershipDto.membershipStatus = PENDING, ACTIVE, SUSPENDED, INACTIVE
				// NOTE: Only users with a memberships, but not connected to this group
				// are to be used for autocompletion. There is no need group users info
				// to be transferred over the network.
				var userAlreadyInGroup = false;
				$.each(model.users, function(index, user) {
					if (user.id == membershipDto.userId) {
						userAlreadyInGroup = true;
					}
				});
				if (!userAlreadyInGroup) {
					userIds.push(membershipDto.userId);
				}
			});
			
			userIds = userIds.join(',');
			
			retrieveUsers(selectedGroup.id, userIds, function(userDtos) {
				$.each(userDtos, function(index, userDto) {
					users.push(
						{
							value: userDto.id,
							label: userDto.firstName + " " + userDto.lastName,
							description: "Positions to be enlisted",
							image: "images/photos/Jamie.png",
							details: userDto
						}
					);
				});
			});
		});
	}
	
	function installUserAutocomplete(form) {
		// http://codeblogging.net/blogs/1/15/
		// https://github.com/twitter/typeahead.js
		// http://forum.jquery.com/topic/alternating-style-on-autocomplete
		// http://ajaxdump.com/?cL8V22l5

		prepareAutocompleteUsers(form);
		var userInSearchForm = $("#user", "#searchForm");
		userInSearchForm.autocomplete({
			source: function( request, response ) {
				var matcher = new RegExp( $.ui.autocomplete.escapeRegex( request.term ), "i" );
				/*
				var users = [
				    {
						value: "Tom Hanks",
						label: "Tom Hanks",
						description: "Actor",
						image: "images/photos/Jamie.png"
					},
					{
						value: "Termionator 2",
						label: "Termionator 2",
						description: "Movie",
						image: "images/photos/Jamie.png"
					},
					{
						value: "Invitation",
						label: "Send invitation",
						description: "Please enter a valid email address",
						image: "images/photos/Jamie.png"
					}
				];
				
				// TODO: There is no point in enlisting users from currently selected group. The code below 
				// needs to search for users with established membership to the top group of selected group.
				//$.each(model.users, function(index, user) {
				//	users.push(
				//		{
				//			value: user.id,
				//			label: user.details.firstName + " " + user.details.lastName,
				//			description: "Positions to be enlisted",
				//			image: "images/photos/Jamie.png"
				//		}
				//	);
				//});
				*/
				
				var users = form.data('autocomplete-users');
				
				var inv = form.data('autocomplete-invitation');
				if (!inv) { // Send Invitation menu item will be added the first time 
					form.data('autocomplete-invitation', true);
					users.push(
						{
							value: "Invitation",
							label: "Send invitation",
							description: "Please enter a valid email address",
							image: "images/photos/Jamie.png"
						}
					);
				}
				
				response(
					$.grep( users, function( value ) {
						value = value.label || value.value || value;
						// TODO: if you find the exact match, Invitation should not be rendered.
						return matcher.test( value ) || value == 'Send invitation'; 
					}) 
				);
			},
			open: function( event, ui ) {
				// http://stackoverflow.com/questions/4428642/suggest-a-good-pattern-for-validating-email-with-javascript
				// http://stackoverflow.com/questions/940577/javascript-regular-expression-email-validation
				if (/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test($(this).val())) {
					$('.description', '.invitation').html('Response time depends on invitee.');
				} else {
					$('.description', '.invitation').html('Please enter a valid email address');
				}
			},
			select: function( event, ui ) { 
				event.preventDefault(); 
				
				// TODO:  Populate the user section with the details of presently found and selected user. 
				// For a better user experience switching to 'create a new user' must restore the previous
				// data manually entered in the user section. Instead model users use users with membership
				// to the top group.
				//var userId = ui.item.value;
				//$.each(model.users, function(index, user) {
				//	if (user.id == userId) {
				//		var form = $('#dataForm');
				//		var userDto = user.details;
				//		$('#email',     form).val(userDto.email);
				//		$('#firstName', form).val(userDto.firstName);
				//		$('#lastName',  form).val(userDto.lastName);
				//		$('#shortName', form).val(userDto.shortName);
				//		$('#phone',     form).val(userDto.phone);
				//		$('#mobile',    form).val(userDto.mobile);
				//		return false;
				//	} 
				//});

				var userDto = ui.item.details;
				if (userDto) {
					var form = $('#dataForm');
					userInSearchForm.val(ui.item.label);
					$('#email',     form).val(userDto.email);
					$('#firstName', form).val(userDto.firstName);
					$('#lastName',  form).val(userDto.lastName);
					$('#shortName', form).val(userDto.shortName);
					$('#phone',     form).val(userDto.phone);
					$('#mobile',    form).val(userDto.mobile);

					// NOTE: Saves the selected user in the form. Note that it is not yet saved in the shape 
					// because the logged in user might decide to cancel the changes by closing the dialog. 
					// Only when the logged in user saves successfully the changes the user will be updated 
					// back in the shape object and added to the model.users object.
					var positions = [];
					
					// NOTE: This comment is to avoid the confusion regarding the shape user id and selected user id. 
					// The shape user id is needed to locate the shape on the screen and must be preserved in order 
					// later to replace detached user shapes (shapes created as result of clicking 'Add user' button
					// located on the screen right side, second from top to bottom) with attached shapes (referring 
					// to existing users). Preserving is performed by storing the id in the user object. 
					// The selected user id is used to add selected user to the group and create attached user shape 
					// replacing the detached user shape.
					var shapeUserId = form.data('user').id;
					
					var user = {
						id        : shapeUserId, //userDto.id, 
						name      : userDto.shortName,
						positions : positions,
						details   : userDto
					}
					
					form.data('user', user);
					loadUserAddress(form);
				}
			},
			minLength: 1
		}).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
			var isInvitationItem = false;
			if (item.value == 'Invitation') {
				isInvitationItem = true;
			}

			var inner_html = '<a><div class="list_item_container ' + (isInvitationItem? 'invitation' : '')+ '"><div class="image"><img src="' 
						   + item.image 
						   + '"></div><div class="label">' 
						   + item.label 
						   + '</div><div class="description">' 
						   + item.description 
						   + '</div></div></a>';
			var res = $( "<li></li>" )
				.data( "item.autocomplete", item )
				.append(inner_html)
				.appendTo( ul );
			
			if (item.value == 'Invitation') {
				res.click(function(event) {
					if (/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(userInSearchForm.val())) {
						var url, method;
						
						method = 'POST';
						url = '/group-schedule/proxyvoidresp/memberships/invitation/';
						
						var membershipDto = {
							groupId : selectedGroup.id,
							userEmail : $('#user').val()
						}

						var callback = function() {
							alert('Invitation sent to ' + membershipDto.userEmail + '\n Response time depends on invitee.');
							$( '#dialog' ).dialog('close');
						}

						sendData(
							url,
							method,
							membershipDto,
							'Invitation sent to ' + membershipDto.userEmail + '\n Response time depends on invitee.', 
							callback, false);
					} else {
						alert('Please enter a valid email address');
					}

					event.stopImmediatePropagation();
				});
			}
			
			return res;
		};
	}
	
	function installMenu() {
		var menu = $('div.position > ul').menu();
		closeMenu(menu);
		menu.hover(
			function() { openMenu (menu) }, 
			function() { closeMenu(menu) }
		);

		var action = $('li > a', menu).click(function() {
			//document.location.href=$(this).attr('href');
			menu.attr('data-selected-position', $(this).parent().attr('data-position'));
			closeMenu(menu);
		});
	}
	
	function enableMenu() {
		var menu = $('div.position > ul').menu();
		menu.menu( "enable" );
	}
	
	function disableMenu() {
		var menu = $('div.position > ul').menu();
		menu.menu( "disable" );
	}
	
	function openMenu(menu) {
		menu.parent().css({'z-index': '100'});
		menu.children('li').show();
	}
	
	function closeMenu(menu) {
		menu.parent().css({'z-index': '0'});
		var selectedPosition = menu.attr('data-selected-position');
		menu.children('li').each(function(index, child) {
			child = $(child);
			if (selectedPosition == child.attr('data-position')) {
				child.show();
			} else {
				child.hide();
			}
		});
	}
	
	/* Utils
	------------------------------------------------------------------------------*/

	function sign(x) {
		return (x < 0 ? -1 : (x > 0 ? 1 : 0));
	}
	
	function isPointInside(x, y, x1, y1, x2, y2) {
		return (x1 <= x && x <= x2) && (y1 <= y && y <= y2);
	}
	
	function findClosestPointOnTheCircle(point, circle) {
		//console.log("point&circle: " + [point.x, point.y, circle.x, circle.y, circle.radius].join(','));
		var dyp = (point.y - circle.y);
		var dxp = (point.x - circle.x);
		var alpha = Math.atan(dyp/dxp);
		var dy = Math.abs(circle.radius*Math.sin(alpha));
		var dx = Math.sqrt(circle.radius*circle.radius - dy*dy);
		//console.log("calcs: " + [dxp, dyp, alpha, dx, dy].join(','));
		//console.log("result: " + [circle.x + dx * sign(dxp), circle.y + dy * sign(dyp)].join(','));
		return {
			x: circle.x + dx * sign(dxp), 
			y: circle.y + dy * sign(dyp)
		};
	}
	
	function findConnectingPointsOnTheCircles(circle1, circle2) {
		//console.log("circle1, circle2=" + [circle1.x, circle1.y, circle1.radius, circle2.x, circle2.y, circle2.radius].join(', '));
		var dyr = (circle2.y - circle1.y);
		var dxr = (circle2.x - circle1.x);
		var alpha = Math.atan(dyr/dxr);
		var dy1 = Math.abs(circle1.radius * Math.sin(alpha));
		var dx1 = circle1.radius * Math.cos(alpha);
		var q = (Math.sqrt(dyr*dyr + dxr*dxr) - circle2.radius); 
		var dy2 = Math.abs(q * Math.sin(alpha));
		var dx2 = q * Math.cos(alpha);
		//console.log("dxr, dyr, alpha, dx1, dy1, q, dx2, dy2=" + [dxr, dyr, alpha, dx1, dy1, q, dx2, dy2].join(', '));
		return {
			x1: circle1.x + dx1 * sign(dxr), 
			y1: circle1.y + dy1 * sign(dyr), 
			x2: circle1.x + dx2 * sign(dxr), 
			y2: circle1.y + dy2 * sign(dyr), 
		}
	}

	function generateGUID() {
		return (GUID++);
	}

	function generateGroupGUID() {
		return (groupGUID++);
	}

	function generateUserGUID() {
		return (userGUID++);
	}
	
	function generatePositionGUID() {
		return (positionGUID++);
	}
	
	function updateLogo(file) {
		var fileReader = new FileReader();
		fileReader.onload = function(e) { 
			$('#logo').attr("src", e.target.result); 
		};
		/*
		var imageElem=document.createElement("img");
		fileReader.onload = (function(img) { return function(e) { img.src = e.target.result; }; })(imageElem);
		*/
		fileReader.readAsDataURL(file);
	}
	
	function uploadFile(file, successCallback, failureCallback) {
		try {
	
			var reader = new FileReader();  
			var xhr = new XMLHttpRequest();
			var formData = new FormData();
			// selectedGroup.id was replaced by file.imageRef (an additionally
			// added property to file object prior calling this function) due 
			// to the fact that in some cases the uploaded logo is not for the 
			// selected group, but rather for a newly created group. The change
			// addresses the problem with overriding the logo of the selected 
			// group that appears to be parent of the newly created group e.g.
			// creating top groups under ROOT previously led to storing the logo
			// as 'group[null]' and logo to appear on ROOT group shape instead
			// of the newly created group shape.
			formData.append('imageref', 'group[' + file.imageRef + ']');
			formData.append('files[0]', file);
			 
			function transferStart(evt) {
				// show progess bar and percentage elements if any
			}
			
			function transferProgress(evt) {
				if (evt.lengthComputable) {
					// update progess bar and percentage elements if any
					var percentage = Math.round((evt.loaded * 100) / evt.total);
					console.log("upload percentage: " + percentage);
				}
			}
				
			function transferComplete(evt) {
				//alert("The transfer is complete.");
				
				// Successful transfer processing was tightly coupled with updating the group background, 
				// but later lousely coupled and hence improved by invoking a callback function provided 
				// by the client.
				//// set progess bar and percentage elements to 100%
				//var backgroundImageURL = GS.getContext() + '/proxy/read/group[' + file.imageRef + ']';
				//$('.icon-group', '#group' + file.imageRef)
				//.css('background-image', 'url("' + backgroundImageURL + '")')
				//.css('background-size',  '32px 32px');
				
				successCallback();
			}
	
			function transferFailed(evt) {
				//alert("Failed to transfer the image.");
				failureCallback();
			}
	
			function transferCanceled(evt) {
				//alert("The transfer has been canceled by the user.");	
				failureCallback();
			}
	
			xhr.upload.addEventListener("progress",  transferProgress, false);
			xhr.upload.addEventListener("loadstart", transferStart,    false);
			xhr.upload.addEventListener("load",      transferComplete, false);
			xhr.upload.addEventListener("error",     transferFailed,   false);
			xhr.upload.addEventListener("abort",     transferCanceled, false);
			
			xhr.open('POST', GS.getContext() + '/multipartproxy/save.html');
			try { // the following override operation failed on Internet Explorer
				xhr.overrideMimeType('text/plain; charset=x-user-defined-binary');
			} catch (e) {}
			xhr.send(formData);

		} catch (e) { 
			//alert('ERR: ' + e);
			failureCallback();
		}
	}

	
	return this;
	
}//);
