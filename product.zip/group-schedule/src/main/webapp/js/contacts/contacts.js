			(function($) {
				$('.expandable .toggle', parent.document).click(function() {
					//alert($(this).parent().html());
					$(this).parent().children('.target').toggle();
				});
			})(jQuery);
			
			(function($) {
				try {
					var mapWidget = $("#map-widget").css({
						width : 640,
						height : 320
					}).get(0);
					
					var mapOptions = {
						center: new google.maps.LatLng(49.228528, -122.894568),
						zoom: 8,
						tilt : 0,
						mapTypeId: google.maps.MapTypeId.ROADMAP
					};
					
					var map = new google.maps.Map(mapWidget, mapOptions);
				} catch (e) {
					$('#OnTheMap', parent.document).hide();
					return;
				}
				
				var $addresses = $('address', parent.document);
				var lastInfoWindow = null;

				$addresses.each(function() {
					var $addressItem = $(this).addClass('clickable');
					var data = getAddressData($addressItem);

					$addressItem.click(function() {
						//window.location.hash = '#!/' + data.id;
						var $addressItem = $(this);
						if ($addressItem.attr('data-coordinates')) {
							var data = getAddressData($addressItem);
							selectContact($addressItem, data);
						}
					});

					var position = new google.maps.LatLng(data.coords.lat, data.coords.lng);
					
					var marker = new google.maps.Marker({
						position : position,
						map : map,
						title : data.label
					});
					
					var infowindow = new google.maps.InfoWindow({
						content : $addressItem.html(),
						position : position
					});
					
					google.maps.event.addListener(marker, 'click',
						function() {
							infowindow.open(map, marker);

							if (lastInfoWindow) {
								lastInfoWindow.close();
							}

							lastInfoWindow = infowindow;
						}
					);
				});

				function getAddressData($address) {
					var coords = $address.attr('data-coordinates').split(',');

					return {
						id : $address.attr('id'),
						label : $address.find('.title').html(),
						coords : {
							lat : parseFloat(coords[0]),
							lng : parseFloat(coords[1]),
							zoom : parseInt(coords[2])
						}
					};
				}

				function selectContact($address, data) {
					$address.addClass('selected').siblings().removeClass('selected');
					map.panTo(new google.maps.LatLng(data.coords.lat, data.coords.lng));
					map.setZoom(data.coords.zoom);
					map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
				}

				/*
				function hashChangeContact(hash) {
					var elementId = hash.replace(/#!(\/)?/, '#');
					var $addressItem = $(elementId);

					if ($addressItem.size() && $addressItem.attr('data-coordinates')) {
						var data = getAddressData($addressItem);
						selectContact($addressItem, data);
					}
				}

				$(window).on('hashchange', function() {
					hashChangeContact(window.location.hash);
				});
				hashChangeContact(window.location.hash);
				*/
			})(jQuery);
