(function($) { 
	/* function body here */ 
    $(document).ready(function() {
    });
})(jQuery);
