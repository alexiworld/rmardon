//
// IO operations - http://api.jquery.com/jQuery.getScript/
//

jQuery.cachedScript = function(url, options) {
	// allow user to set any option except for dataType, cache, and url
	options = $.extend(options || {}, {
		dataType : "script",
		cache : true,
		url : url
	});
	// Use $.ajax() since it is more flexible than $.getScript
	// Return the jqXHR object so we can chain callbacks
	return jQuery.ajax(options);
};

//
// UI operations
//

$.extend(
	$.expr[":"],
	{ reallyvisible: function (a) { return ($(a).is(":visible") && $(a).parents(":hidden").length == 0) } }
)

//
// Date/Time operations
//

function getDoubleFromTime(time,partOfDay,startOrEnd) //part of Day =1 if Am and 2 if PM and part Of Day=3; am but startTime was pm
{
	
	if(time.length == 0) {
		return 0.0;
	}
	
	var parts = null;
	var converted=0;
	if(time.indexOf(':')!=-1)
		parts = time.split(":");
	else if(time.indexOf('.')!=-1)
		parts = time.split(".");
	else if(time.indexOf(';')!=-1)
		parts = time.split(";");
	else if(time.indexOf(' ')!=-1)
		parts = time.split(" ");
	else if(time.indexOf(',')!=-1)
		parts = time.split(",");

	if(parts==null)
	{
		if((time.length == 1)||(time.length == 2))
		{
			var temp=time/1;
			converted=temp%12;
		}
	}
	else
	{
		if(parts.length == 1)
		{
			var temp2=parts[0]/1;
			converted=temp2%12;
		}
		else
		{
			var whole = 1;
			var fraction = -60.0;
		
			whole = parts[0]/1;
			fraction = parts[1]%60;
		
			converted= whole+(fraction/60.0);
		}
	}

	if(((converted==0)&&(partOfDay==1)&&(startOrEnd=="end"))||((partOfDay==3)&&(startOrEnd=="end")))
	{
		converted+=24;
	}
	if((partOfDay==2))
	{
		converted+=12;
	}
	return converted;
}

function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
  diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}

// The next date/time ops are under review

var HOUR_MS = 3600000;

function addMinutes(d, n) {
	d.setMinutes(d.getMinutes() + n);
	return d;
}

function addDays(d, n, keepTime) { // deals with daylight savings
	if (+d) {
		var dd = d.getDate() + n,
			check = cloneDate(d);
		check.setHours(9); // set to middle of day
		check.setDate(dd);
		d.setDate(dd);
		if (!keepTime) {
			clearTime(d);
		}
		fixDate(d, check);
	}
	return d;
}


function fixDate(d, check) { // force d to be on check's YMD, for daylight savings purposes
	if (+d) { // prevent infinite looping on invalid dates
		while (d.getDate() != check.getDate()) {
			d.setTime(+d + (d < check ? 1 : -1) * HOUR_MS);
		}
	}
}

function cloneDate(d, dontKeepTime) {
	if (dontKeepTime) {
		return clearTime(new Date(+d));
	}
	return new Date(+d);
}

function clearTime(d) {
	d.setHours(0);
	d.setMinutes(0);
	d.setSeconds(0);
	d.setMilliseconds(0);
}

// Collections, Objects operations

// A quick way to get the first element in array.
// No iteration from 0 to N is needed to obtain
// the first element e.g.
// var arr = []; arr[N] = 1; arr.first() returns 1
Array.prototype.first = function () {
    //return this[0];
	for (var i in this) return this[i];
};

function insertAt(array, index) {
    var arrayToInsert = Array.prototype.splice.apply(arguments, [2]);
    return insertArrayAt(array, index, arrayToInsert);
}

function insertArrayAt(array, index, arrayToInsert) {
    Array.prototype.splice.apply(array, [index, 0].concat(arrayToInsert));
    return array;
}

// Usage:
//
// if you want to insert specific values whether constants or variables:
// insertAt(arr, 1, "x", "y", "z");
//
// OR if you have an array:
// var arrToInsert = ["x", "y", "z"];
// insertArrayAt(arr, 1, arrToInsert);

function sendData(url, method, data, retryMsg, callback, processData) {
	if (processData == undefined) processData = true;
	$.support.cors = true;
	$.ajax({
		global: false,
		cache: false,
		url  : url,
		type : method, 
		async: true,
		data : JSON.stringify( data ), 
		processData: processData,
		contentType : "application/json",
		dataType : 'json',
		error : function(jqXHR, textStatus, errorThrown) {
			if (jqXHR.status === 401) {
				GS.logout();
			} else if (jqXHR.status === 200) {
				callback(); // takes it here when calling proxyvoidresp service operations
			} else {
				if (confirm(retryMsg + '\nWould you like to retry?')) {
					sendData(url, method, data, retryMsg, callback, processData);
				} else {
					//TODO: Uncomment when done with the development
					//GS.logout();
				}
			}
			return;
	    },
		statusCode: {
			401: function() { 
				GS.logout();  // if session has expired do logout.
		    }
		},
		success : function(data, textStatus, xhr){
			var result = JSON.parse(JSON.stringify(data));
			callback(result);
		}
	});
}

function queryData(url, params, retryMsg, callback) {
	$.ajax({
		type : "GET", 
		url  : url, // + "?",
		data : params, 
		contentType : "application/json",
		dataType : 'json',
		error : function(jqXHR, textStatus, errorThrown) {
			if (jqXHR.status === 401) {
				GS.logout();
			} else {
				if (confirm(retryMsg + '\nWould you like to retry?')) {
					queryData(url, params, retryMsg, callback);
				} else {
					GS.logout();
				}
			}
			return;
	    },
		statusCode: {
			401: function() { 
				GS.logout();  // if session has expired do logout.
		    }
		},
		success : function(data, textStatus, xhr){
			var result = JSON.parse(JSON.stringify(data));
			callback(result);
		}
	});
}

function strcmp(a, b) {   
    return (a<b?-1:(a>b?1:0));  
}
