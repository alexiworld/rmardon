/*
    Group Schedule flyout menu
*/
$(document).ready(function() {
    // animation delay for opening and closing the menu
    var animDelay = 60,
        currFlyOut = null,
        currLink = null,
        userLink = null,
        // all drop-down menus
        dropDowns = $('.drop-down-menu');

    // hide the flyout menu if user clicks elsewhere on the page
    $('html').click(function() {
        if (currLink !== null && currFlyOut !== null) {
            /* TODO: refactor into a close function */
            currFlyOut.slideUp(animDelay);
            utilityDropDown.slideUp(animDelay);
            currLink.removeClass('current');
            currLink.data('open', 'false');
        }
    });
    // but keep the flyout open if the user clicks inside it
    dropDowns.click(function(event) {
        event.stopPropagation();
    });

    // click handler for 1st level links
    $('.lev1 > li > a, .user-link').click(function(event) {
        event.stopPropagation();
        currLink = $(this);

        // close any open menus and reset selected class on 1st level links
        dropDowns.slideUp(animDelay);
        if (currLink.data('open') !== 'true') {
            $('.lev1 > li > a').removeClass('current').data('open', 'false');
        }
        if (userLink !== null) {
            /* TODO: refactor into a close function */
            utilityDropDown.slideUp(animDelay);
            setTimeout(function() {
                $('.shape').css({zIndex: 2}); /* workaround ensuring drop down menu appears on the top of shapes */
            }, 10);
            userLink.removeClass('current');
        }

        // check if there are sub categories to display
        if (currLink.hasClass('has-drop-down')) {
            // Remove the outline styling as some browsers
            // persist it when the fly-out is open.
            currLink.css('outline', 'none');

            // get fly-out menu
            currFlyOut = currLink.next();
            if (currLink.data('open') === 'true') {
                /* TODO: refactor into a close function */
                currFlyOut.slideUp(animDelay);
                currLink.removeClass('current');
                currLink.data('open', 'false');
                setTimeout(function() {
                    $('.shape').css({zIndex: 2}); /* workaround ensuring drop down menu appears on the top of shapes */
                }, 10);
            } else {
                currLink.data('open', 'true');
                currLink.addClass('current');
                currFlyOut.slideDown(animDelay);
                setTimeout(function() {
                    $('.shape').css({zIndex: 0}); /* workaround ensuring drop down menu appears on the top of shapes */
                }, 10);
            }

            /* workaround for drop down menus without sub drop down menus { */
            if (currLink.hasClass('has-sub-drop-down')) {
            	currFlyOut.css('background-position', '24.95% 0');
            } else {
            	currFlyOut.css('background-position', '0% 0');
            	currFlyOut.css('width', '267px');
            }
            /* } workaround for drop down menus without sub drop down menus */
        }
        return false; /* workaround to remove # appended to the URL */
    });

    function activateSubmenu(row) {
        var $row = $(row),
            submenuId = $(row).attr('id').split('menupos')[1],
            $submenu = $("#menulev3-" + submenuId);

        // Show the submenu
        $submenu.css("display", "block");

        // Keep the currently activated row's highlighted look
        $row.addClass("maintainHover");
    }

    function deactivateSubmenu(row) {
        var $row = $(row),
            submenuId = $(row).attr('id').split('menupos')[1],
            $submenu = $("#menulev3-" + submenuId);

        // Hide the submenu and remove the row's highlighted look
        $submenu.css("display", "none");
        $row.removeClass("maintainHover");
    }

    // // 2nd level links
    $('.lev2').menuAim({
        rowSelector: "li > a",
        submenuSelector: "*",
        activate: activateSubmenu,
        deactivate: deactivateSubmenu
    });

    /* User (utility) menu */
    var utilityDropDown = $('.utility-drop-down');
    
    $('html').click(function() {
         if (userLink !== null) {
            /* TODO: refactor into a close function */
            utilityDropDown.slideUp(animDelay);
            userLink.removeClass('current');
            userLink.data('open', 'false');
        }
    });
    
    $('.utility-menu .user-link').click(function(event) {
        event.stopPropagation();
        userLink = $(this);
        
        userLink.css('outline', 'none');

        // close any open menus and reset selected class on the user link
        dropDowns.slideUp(animDelay);
        if (userLink.data('open') !== 'true') {
            userLink.removeClass('current').data('open', 'false');
        }

        if (userLink.data('open') === 'true') {
            /* TODO: refactor into a close function */
            utilityDropDown.slideUp(animDelay);
            userLink.removeClass('current');
            userLink.data('open', 'false');
        } else {
            userLink.data('open', 'true');
            userLink.addClass('current');
            utilityDropDown.slideDown(animDelay);
        }
    });

});