$(document).ready(function() {
	$( document ).tooltip({
		position: {
			my: "center bottom-20",
			at: "center top",
			using: function( position, feedback ) {
				$( this ).css( position );
				$( "<div>" )
				.addClass( "arrow" )
				.addClass( feedback.vertical )
				.addClass( feedback.horizontal )
				.appendTo( this );
			}
		},
		show: { delay: 800 }
	});

	var GUID      = 1;
	var groupGUID = 1;
	var userGUID  = 1;
	var positionGUID  = 1;
	
	var layout = new Object();
		
	var model = loadModel();
	prepareModel();
	
	var selectedGroup = model.groups[1];
	redrawShapes();
	initCommands();
	
	registerEndPointEventHandlers();
	registerShapeEventHandlers();
	initDialogs();

	function loadModel() {
		var positions = [
			{
				id: 1,
				description: 'WAITER',
				rate: 12.50
			},
			{
				id: 2,
				description: 'COOK',
				rate: 20.00
			},
			{
				id: 3,
				description: 'MANAGER',
				rate: 15.00
			}
		]

		var users = [
				{ 
					id: 1, 
					name: 'Employee #1',
					positions: [ 1 ]
				},
				{ 
					id: 2, 
					name: 'Employee #2',
					positions: [ 2 ]
				},
				{ 
					id: 3, 
					name: 'Employee #3',
					positions: [ 3 ]
				}
		]

		var organizationId  = generateGroupGUID();
		var selectedGroupId = generateGroupGUID();
		
		var groups = [
			{
				parentId: null,
				id: organizationId, 
				name: 'The Organization',
				members: [3],
				managers: [3],
				positionIds: [3]
			},
			{
				parentId: organizationId,
				id: selectedGroupId, 
				name: 'Development',
				members: [3],
				managers: [3],
				positionIds: [3]
			}
		]

		for (var i = 3; i < 25; i++) {
			var id = generateGroupGUID();
			groups.push(
				{
					parentId: selectedGroupId,
					id: id+1, 
					name: 'Group ' + id,
					members: [1, 2],
					managers: [3],
					positionIds: [1, 2, 3]
				}
			);
		}

		var model = {
			groups: groups,
			users: users,
			positions: positions
		}   
	
		return model;
	}
	
	function prepareModel() {
		var groups = model.groups;
		
		$.each(groups, function(index, group) {
			group.subGroups = [];
			
			var users = [];
			$.each(group.managers, function(outerIndex, manager) {
				$.each(model.users, function(innerIndex, user) {
					if (manager == user.id) {
						userClone = jQuery.extend(true, {manager: true}, user);
						users.push(userClone);
						return false;
					}
				});
			});
			$.each(group.members, function(outerIndex, member) {
				// continue by skipping a member who appears also to be a manager
				if ($.inArray(member, group.managers) >= 0) return true; 
				
				$.each(model.users, function(innerIndex, user) {
					if (member == user.id) {
						userClone = jQuery.extend(true, {manager: false}, user);
						users.push(userClone);
						return false;
					}
				});
			});
			
			group.users = users;

			var positions = []
			$.each(group.positionIds, function(outerIndex, positionId) {
				$.each(model.positions, function(innerIndex, position) {
					if (positionId == position.id) {
						positionClone = jQuery.extend(true, {}, position);
						positions.push(positionClone);
						return false;
					}
				});
			});
			
			group.positions = positions;
		});
		
		$.each(groups, function(index1, group1) {
			$.each(groups, function(index2, group2) {
				if (index1 != index2) {
					if (group1.id == group2.parentId) {
						if (!group2.parentGroup) {
							group1.subGroups.push(group2);
							group2.parentGroup = group1;
						}
					} else if (group2.id == group1.parentId) {
						if (!group1.parentGroup) {
							group2.subGroups.push(group1);
							group1.parentGroup = group2;
						}
					}
				}
			});
		});
	}
	
	function inGroupsMode() {
		var groupsMode = $('.groups').hasClass('grayscale');
		return groupsMode;
	}
	
	function inUsersMode() {
		var usersMode = $('.users').hasClass('grayscale');
		return usersMode;
	}
	
	function inPositionsMode() {
		var positionsMode = $('.positions').hasClass('grayscale');
		return positionsMode;
	}
	
	function setSelectedGroup(group) {
		selectedGroup = group;
	}
	
	function getSelectedGroup() {
		return selectedGroup;
	}
	
	function addAll(source, target) {
		$.each(target, function(index, element) {
			source.push(element);
		});
	}

	function positionShapes() {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();

		var selectedGroup = getSelectedGroup();
		
		var descendants;
		if (groupsMode) {
			descendants = selectedGroup.subGroups;
		} else if (usersMode) {
			descendants = selectedGroup.users;
		} else {
			descendants = selectedGroup.positions;
		}
	
		var windowWidth  = $(window).width();
		var windowHeight = $(window).height();
		console.log("windowWidth, windowHeight: " + [windowWidth, windowHeight].join(', '));
		var marginLeft   = 30;
		var marginRight  = 200;
		var marginTop    = 30;
		var marginBottom = 30;
		var diameter     = 120; // shape diameter
		var distanceX    = 20;  // minimum horizontal distance between peripheries of two closest shapes 
		var distanceY    = 10;  // minimum vertical   distance between peripheries of two closest shapes 
		var wx = diameter + distanceX; 
		var hy = diameter + distanceY; 

		var innerWidth  = (windowWidth  - marginLeft - marginRight );
		var innerHeight = (windowHeight - marginTop  - marginBottom);
		
		var nx = Math.floor((innerWidth               + distanceX) / wx);
		var ny = Math.floor((innerHeight - 2*diameter + distanceY) / hy);
		var n = 2*(nx + ny);
		
		var m = (selectedGroup.parentGroup ? 1 : 0) + descendants.length;
		// IDEA: If (m > n - 2) the top left subgroup and bottom right shapes 
		// could be replaced by PREV and NEXT shapes to scroll forth and back. 
		m = Math.min(m + 2, n);
		var mx = Math.floor(m*(nx/n));
		var my = Math.floor(m*(ny/n));

		console.log("n, nx, ny, m, mx, my: " + [n, nx, ny, m, mx, my].join(', '));
		
		var diff = m - 2*(mx + my);
		var diffx = nx - mx;
		var diffy = ny - my;
		var diffyMin = Math.min(diffy, diff);
		console.log("diff, diffx, diffy, diffyMin: " + [diff, diffx, diffy, diffyMin].join(', '));
		my   += Math.round(diffyMin/2);
		diff -= diffyMin;
		var diffxMin = Math.min(diffx, diff);
		mx   += Math.round(diffxMin/2);
		diff -= diffxMin;
		console.log("diff, diffx, diffy, diffxMin: " + [diff, diffx, diffy, diffxMin].join(', '));
		
		var wxUpdated = (innerWidth  + distanceX) / mx;
		var hyUpdated = (innerHeight + distanceY) / (my + 2);
		
		// Ensure the wxUpdated and hyUpdated do not exceed the workable area
		wxUpdated = Math.min(wxUpdated, innerWidth  - wx);
		hyUpdated = Math.min(hyUpdated, innerHeight - hy);

		console.log("mx, my, wxUpdated, hyUpdated: " + [mx, my, wxUpdated, hyUpdated].join(', '));
		
		if (selectedGroup.parentGroup) {
			selectedGroup.parentGroup.position = { top: marginTop, left: marginLeft }
		}
		
		var index = 0;

		var top  = marginTop;
		var left = marginLeft + wxUpdated;
		for (var i = 0; i < mx - 2; i++) { // -2 because of the parent group shape and
			left += wxUpdated;             // empty space next to it on the first row.
			if (!descendants[index]) break;
			descendants[index++].position = { top: top, left: left }
		}
		
		var leftOf2ndColum = left;
		
		top  = marginTop + hyUpdated;
		left = marginLeft;
		for (var i = 0; i < my - 1; i++) {
			top  += hyUpdated;
			if (!descendants[index]) break;
			descendants[index++].position = { top: top, left: left }
		}
		
		var topOf2ndRow = top;
		
		top  = marginTop;
		left = leftOf2ndColum; 
		for (var i = 0; i < my; i++) {
			top  += hyUpdated;
			if (!descendants[index]) break;
			descendants[index++].position = { top: top, left: left }
		}
		
		top  = topOf2ndRow + hyUpdated;
		left = marginLeft;
		for (var i = 0; i < mx; i++) {
			if (!descendants[index]) break;
			descendants[index++].position = { top: top, left: left }
			left += wxUpdated;
		}
		
		//topOfSelectedGroup  = (windowHeight - diameter) / 2;
		//leftOfSelectedGroup = (windowWidth  - diameter) / 2;
		topOfSelectedGroup  = ((top  + diameter - marginTop) - diameter) / 2 + marginTop;
		leftOfSelectedGroup = ((leftOf2ndColum + diameter -  marginLeft) - diameter) / 2;
		selectedGroup.position = { top: topOfSelectedGroup, left: leftOfSelectedGroup }
	}

	function clearShapes() {
		$('#shapes').empty();
    }
	
	function drawShapes() {
		var selectedGroup = getSelectedGroup();
		addGroup(selectedGroup);

		if (selectedGroup.parentGroup) {
			addGroup(selectedGroup.parentGroup);
			connectShapes(selectedGroup.parentGroup, selectedGroup);
		}
	
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		if (groupsMode) {
			$.each(selectedGroup.subGroups, function(index, subGroup) {
				addGroup(subGroup);
			});

			$.each(selectedGroup.subGroups, function(index, subGroup) {
				connectShapes(selectedGroup, subGroup);
			});
		} else if (usersMode) {
			$.each(selectedGroup.users, function(index, user) {
				addUser(user);
			});

			$.each(selectedGroup.users, function(index, user) {
				connectShapes(selectedGroup, user);
			});
		} else {
			$.each(selectedGroup.positions, function(index, position) {
				addPosition(position);
			});

			$.each(selectedGroup.positions, function(index, position) {
				connectShapes(selectedGroup, position);
			});
		}
	}
	
	function redrawShapes() {
		clearShapes();
		positionShapes();
		drawShapes();
	}

	function initCommands() {
		$('.add').click(function(event) {
			$('#dialog').dialog('close');
			addGroupOrUserOrPosition();
		});

		$('.groups').click(function(event) {
			$('#dialog').dialog('close');
			$('.groups').addClass('grayscale');
			$('.users').removeClass('grayscale');
			$('.positions').removeClass('grayscale');
			redrawShapes();
		});

		$('.users').click(function(event) {
			$('#dialog').dialog('close');
			$('.users').addClass('grayscale');
			$('.groups').removeClass('grayscale');
			$('.positions').removeClass('grayscale');
			redrawShapes();
		});
		
		$('.positions').click(function(event) {
			$('#dialog').dialog('close');
			$('.positions').addClass('grayscale');
			$('.groups').removeClass('grayscale');
			$('.users').removeClass('grayscale');
			redrawShapes();
		});
		
		$('.trash').droppable({
			//scope: "shape",
			drop: function( event, ui ) {
				var source = ui.draggable;
				
				if (source.attr("id") == 'group1') {
					return; // cannot remove the organization or the selected group, i.e. the group
					// the user stepped into. to remove the selected group the user must step out/up.
				}
				
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					if (connection) {
						if (connection.source[0] == source[0] || connection.target[0] == source[0]) {
							$(connectionPath).parent().remove();
						} 
					}
				});
				source.remove();
			}
		});
	}
	
	function addGroup(group) {
		var groupShape = $(groupHTML(group)).appendTo('#shapes');
		//var groupShape = $('#group' + group.id); // slower vs proven
		
		if (group.id == selectedGroup.id) {
			groupShape.addClass('selected-shape');
		} else if (group.id == selectedGroup.parentId) {
			groupShape.addClass('parent-shape');
		}
		
		groupShape.data('group', group);
		registerShapeEventHandlers(groupShape);
		registerEndPointEventHandlers($('.ep',groupShape));
	}
	
	function groupHTML(group) {
		if (!group.position) { // temp hack for not
			return '';         // rendered groups 
		}
		
		var groupHTML = '<div id="group' + group.id + '" class="shape group" data-shape="circle" style="left:' 
					  + group.position.left + 'px; top: ' + group.position.top + 'px;"><div class="ep"></div>'  
					  + '<div class="' + (group.id==1?'office':'group')+ '"></div>' + group.name + '</div>'
		return groupHTML;
	}
	
	function addUser(user) {
		var userShape = $(userHTML(user)).appendTo('#shapes');
		//var userShape = $('#user' + user.id); // slower vs proven
		userShape.data('user', user);
		registerShapeEventHandlers(userShape); 
		registerEndPointEventHandlers($('.ep','#user' + user.id));
	}
	
	function userHTML(user) {
		var userHTML = '<div id="user' + user.id + '" class="shape ' 
		              + (user.manager?'manager':'member') + '" data-shape="circle" style="left:' 
					  + user.position.left + 'px; top: ' + user.position.top + 'px;"><div class="ep"></div>'  
					  + '<div class="user"></div>' + user.name + '</div>'
		return userHTML;
	}
	
	function addPosition(position) {
		var positionShape = $(positionHTML(position)).appendTo('#shapes');
		//var positionShape = $('#position' + position.id); // slower vs proven
		positionShape.data('position', position);
		registerShapeEventHandlers(positionShape); 
		registerEndPointEventHandlers($('.ep','#position' + position.id));
	}
	
	function positionHTML(position) {
		var positionHTML = '<div id="position' + position.id + '" class="shape position' 
		              + '" data-shape="circle" style="left:' 
					  + position.position.left + 'px; top: ' + position.position.top + 'px;"><div class="ep"></div>'  
					  + '<div class="position"></div>' + position.description + '</div>'
		return positionHTML;
	}
	
	function addGroupOrUserOrPosition() {
		var groupsMode    = inGroupsMode();
		var usersMode     = inUsersMode();
		var positionsMode = inPositionsMode();
		
		var shape = $('.shape');
		var top = $(window).height() - shape.height() - 50;
		var left = $(window).width() - shape.width()  - 50;
		
		if (groupsMode) {
			var id = generateGroupGUID();
			addGroup({
				parentId: 1,
				id: id+1, 
				name: 'Group ' + id,
				members: [1, 2],
				managers: [3],
				position: { top: top, left: left }
			});
		} else if (usersMode) {
			var id = generateUserGUID();
			addUser({
				parentId: 1,
				id: id+1, 
				name: 'User ' + id,
				position: { top: top, left: left }
			});
		} else if (positionsMode) {
			var id = generatePositionGUID();
			addPosition({
				parentId: 1,
				id: id+1, 
				name: 'Position ' + id,
				position: { top: top, left: left }
			});
		}
	}
	
	function registerEndPointEventHandlers(ep) {
		if (!ep) {
			ep = $('.ep');
		}
		ep.draggable({
			addClasses: "ui-draggable-dragging",
			opacity: 0.5, 
			scope: "shape", 
			zIndex : 100,
			cursor: "pointer",
			grid: [1, 1],
			appendTo: "body",
			helper: 'clone',
			start: function(e, ui) {
				//$(ui.helper).addClass('external-event');
				//$(ui.helper).css('font-weight', 'bold');
				//$(ui.helper).removeClass('content pos1');
				//$(ui.helper).addClass('content contentype1  horizontal stripes ui-draggable');//$(this).attr('class'));				
				//$(ui.helper).width($(this).width());
				//$(ui.helper).height($(this).height());
				// increase the size of the clone comparing to the one of the original thus capturing user attention

				$(this).addClass("ui-draggable-dragging");

				var xm  = e.pageX;
				var ym  = e.pageY;
				var halfw = $(this).width()/2;
				var halfh = $(this).height()/2;
				
				var dragExistingConnection = false;
				var shape = $(this).parent();
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					var sameAsConnectionSource = (connection.source[0] == shape[0]);
					var sameAsConnectionTarget = (connection.target[0] == shape[0]);
					if (sameAsConnectionSource || sameAsConnectionTarget) {
						var x1 = (sameAsConnectionSource ? connection.x1 : connection.x2);
						var y1 = (sameAsConnectionSource ? connection.y1 : connection.y2);
						var x2 = x1 + halfw; x1 -= halfw;
						var y2 = y1 + halfh; y1 -= halfh;
						console.log(">>> xm, ym, x1, y1, x2, y2:" + [xm, ym, x1, y1, x2, y2].join(', ') + ", in: " + isPointInside(xm, ym, x1, y1, x2, y2));
						
						if (isPointInside(xm, ym, x1, y1, x2, y2)) {
							dragExistingConnection = true;
							draggedPath = $(connectionPath);
							draggedConn = draggedPath.parent();
							draggedPath.attr("id", "dragged-path");
							draggedConn.attr("id", "dragged-connection");
							//draggedPath.removeData("connection");
						}
					}
				});
					
				if (!dragExistingConnection) {
					//var x = $(this).position().left;
					var x = $(this).offset().left;
					var y = $(this).offset().top;
					
					//var conn = '<svg style="position:absolute;left:0px;top:0px" width="1024" height="800" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="dragged-connection"><path d="M ' + x + ' ' + y + ' ' + x + ' ' + y + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="dragged-path"/>'
					
					//<path pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" d="M632.0161661646432,236.23104297875918 L606.4605650244299,219.02897187199045 L603.9735149964521,225.57225714456837 L601.4864649684743,232.11554241714634 L632.0161661646432,236.23104297875918" class="" stroke="rgba(153, 153, 153, 1.0)" fill="rgba(153, 153, 153, 1.0)"/></svg>
					
					var width  = $(window).width();
					var height = $(window).height();
					var conn = '<svg style="position:absolute;left:0px;top:0px" width="' + width + '" height="' + height + '" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="dragged-connection"><path d="M ' + x + ' ' + y + ' ' + x + ' ' + y + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="dragged-path"/>'
					materializeConnection(conn);
					
					$(window).resize(function(ev) { // does not work well
						var connections = $('svg');
						var width  = $(window).width();
						var height = $(window).height();
						connections.attr("width", width);
						connections.attr("height", height);
					});
					
				}
			},
			drag: function( event, ui ) {
				// redraw the line b/n the source object and its clone representing the moving end of the connection

				var draggedPath = $("#dragged-path");
				var connection = draggedPath.data("connection");
				if (connection) {
					var source = connection.source;
					var target = connection.target;

					var shape = $(this).parent();
					if (source[0] == shape[0]) {
						source = ui.helper;
					} else {
						target = ui.helper;
					} 
					
					var x1 = $(source).offset().left;
					var y1 = $(source).offset().top;
					x1 += $(source).width()/2;
					y1 += $(source).height()/2;
					var radius1 = $(source).width()/2;
					var circle1 = { x: x1, y: y1, radius: radius1 }
					
					var x2 = $(target).offset().left;
					var y2 = $(target).offset().top;
					x2 += $(target).width()/2;
					y2 += $(target).height()/2;
					var radius2 = $(target).width()/2;
					var circle2 = { x: x2, y: y2, radius: radius2 }

					var cps = findConnectingPointsOnTheCircles(circle1, circle2);
					//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
					$("#dragged-path").attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
					$(this).hide();
				} else {
					var x1 = $(this).offset().left;
					var y1 = $(this).offset().top;
					var x2 = ui.offset.left;
					var y2 = ui.offset.top;
					
					draggedPath.attr("d", "M " + x1 + " " + y1 + " " + x2 + " " + y2);
				}
			},
			stop: function( event, ui ) {
				$(this).removeClass("ui-draggable-dragging");
				$(this).hide();
				
				var draggedPath = $("#dragged-path");
				var draggedConn = $("#dragged-connection");
				if (draggedPath.data("connection")) {
					var guid = generateGUID();
					draggedConn.attr("id", "connection" + guid);
					draggedPath.attr("id", "path" + guid);
					//draggedPath.addClass("connection-path");
					draggedPath.attr("class", "connection-path");
				} else {
					draggedConn.remove();
				}
			}
		});
	}
	
	function switchToGroup(shape) {
		var shapeId = shape.attr("id");
		if (/^group/i.test(shapeId)) {
			var id = shapeId.substr('group'.length);
			if (getSelectedGroup().id != id) {
				$.each(model.groups, function(index, group) {
					if (group.id == id) {
						setSelectedGroup(group);
						redrawShapes();
						return false;
					}
				});
			}
		}
	}
	
	function registerShapeEventHandlers(shape) {
		if (!shape) {
			shape = $(".shape");
		}
		
		shape.dblclick(function(event) {
			switchToGroup($(this));
		});
		
		shape.droppable({
			scope: "shape",
			over: function( event, ui ) { 
				// animate the shape e.g. different color, increased size, pulsating
			},
			out: function( event, ui ) {
				// rollback the shape to its initial state (size, color, etc.)
			},
			drop: function( event, ui ) {
				// rollback the shape to its initial state (size, color, etc.)
				var source = ui.draggable.parent();
				var target = $(this);
				
				var draggedPath = $("#dragged-path");
				var connection = draggedPath.data("connection");
				if (connection) {
					if (connection.source[0] == source[0]) {
						source = $(this);
						target = connection.target;
					} else {
						source = connection.source;
						target = $(this);
					} 
				}
				
				if (source[0] == target[0]) {
					var draggedPath = $("#dragged-path");
					draggedPath.removeData("connection");
					return;
				}
				
				var radius = $(this).width()/2;

				var x1 = source.offset().left;
				var y1 = source.offset().top;
				x1 += source.width()/2;
				y1 += source.height()/2;
				var circle1 = { x: x1, y: y1, radius: radius }
				
				var x2 = target.offset().left;
				var y2 = target.offset().top;
				x2 += target.width()/2;
				y2 += target.height()/2;
				var circle2 = { x: x2, y: y2, radius: radius }

				var cps = findConnectingPointsOnTheCircles(circle1, circle2);
				console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
				$("#dragged-path").attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
				ui.draggable.hide();
				
				$("#dragged-path").data("connection", { source: source, target: target, x1: cps.x1, y1: cps.y1, x2: cps.x2, y2: cps.y2 });
			}
		});
		
		$(".shape").mouseleave(function(event) {
			var ep = $('.ep', this);
			if (!ep.hasClass("ui-draggable-dragging")) {
				ep.hide();
			}
		});
		
		$(".shape").mousemove(function(event) {
			var ep = $('.ep', this);
			var x  = event.pageX - $(this).offset().left;
			var y  = event.pageY - $(this).offset().top;
			var w  = $(this).width();
			var h  = $(this).height();
			var cx = w/2;
			var cy = h/2;
			var distance   = Math.sqrt((cx-x)*(cx-x) + (cy-y)*(cy-y));
			var radius     = cx;
			var threshold  = 5;
			
			/*
			console.log("left=" + x);
			console.log("top=" + y);
			console.log("width=" + w);
			console.log("height=" + h);
			*/
			
			//console.log("distance=" + distance);
			
			if ((radius - threshold) <= distance && distance <= (radius + threshold)) {
				var circle = {
					x: cx,
					y: cy,
					radius: radius - 2
				}
				var point = {
					x: x,
					y: y
				}
				var closestPointOnTheCircle = findClosestPointOnTheCircle(point, circle);
				x = closestPointOnTheCircle.x;
				y = closestPointOnTheCircle.y;
				
				ep.css({
					position: 'absolute',
					left: x - ep.width()/2, 
					top: y - ep.height()/2
				}).show();
			} else {
				if (!ep.hasClass("ui-draggable-dragging")) {
					ep.hide();
				}
			}
		});
		
		$(".shape").draggable({
			cursor: "pointer",
			start: function(e, ui) {
				$(this).addClass("ui-draggable-dragging");
				$('.ep', this).hide(); // hide the endpoint in case it is visible when dragging the shape
			},
			drag: function( event, ui ) {
				var draggedShape = $(this);
				$(".connection-path").each(function(index, connectionPath) {
					var connection = $(connectionPath).data("connection");
					if (connection.source[0] == draggedShape[0] || connection.target[0] == draggedShape[0]) {
						var radius = draggedShape.width()/2;

						var source = $(connection.source);
						var x1 = source.offset().left;
						var y1 = source.offset().top;
						x1 += source.width()/2;
						y1 += source.height()/2;
						var circle1 = { x: x1, y: y1, radius: radius }
						
						var target = $(connection.target);
						var x2 = target.offset().left;
						var y2 = target.offset().top;
						x2 += target.width()/2;
						y2 += target.height()/2;
						var circle2 = { x: x2, y: y2, radius: radius }

						var cps = findConnectingPointsOnTheCircles(circle1, circle2);
						//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
						$(connectionPath).attr("d", "M " + cps.x1 + " " + cps.y1 + " " + cps.x2 + " " + cps.y2);
					}
				});
			},
			stop: function( event, ui ) {
				$(this).removeClass("ui-draggable-dragging");
			}
		});
	}
	
	function connectShapes(source, target) {
		var source = $((source.members ? '#group' : (source.positions ? '#user' : '#position')) + source.id);
		var target = $((target.members ? '#group' : (target.positions ? '#user' : '#position')) + target.id);

		if (target.size() == 0) {
			// the subgroup or user is not rendered; therefore, 
			// no connection is to be established.
			return; 
		}
		
		var x1 = $(source).offset().left;
		var y1 = $(source).offset().top;
		x1 += $(source).width()/2;
		y1 += $(source).height()/2;
		var radius1 = $(source).width()/2;
		var circle1 = { x: x1, y: y1, radius: radius1 }

		var x2 = $(target).offset().left;
		var y2 = $(target).offset().top;
		x2 += $(target).width()/2;
		y2 += $(target).height()/2;
		var radius2 = $(target).width()/2;
		var circle2 = { x: x2, y: y2, radius: radius2 }

		var cps = findConnectingPointsOnTheCircles(circle1, circle2);
		//console.log("cps=" + [cps.x1, cps.y1, cps.x2, cps.y2].join(', '));
		var width  = $(window).width()  - 20; // to prevents scroller bars, needs investigation
		var height = $(window).height() - 20; // to prevents scroller bars, needs investigation
		var guid = generateGUID();
		
		var conn = '<svg style="position:absolute;left:0px;top:0px" width="' + width + '" height="' + height + '" pointer-events="none" position="absolute" version="1.1" xmlns="http://www.w3.org/1999/xhtml" id="connection' + guid + '"><path d="M ' + cps.x1 + ' ' + cps.y1 + ' ' + cps.x2 + ' ' + cps.y2 + '" pointer-events="all" version="1.1" xmlns="http://www.w3.org/1999/xhtml" style="" fill="none" stroke="#999999" stroke-width="7" stroke-dasharray="20 8 " id="path' + guid + '"/>'
		materializeConnection(conn);

		var createdPath = $("#path" + guid);
		createdPath.data("connection", { source: source, target: target, x1: cps.x1, y1: cps.y1, x2: cps.x2, y2: cps.y2 });
		createdPath.attr("class", "connection-path");
	}
	
	function materializeConnection(conn) {
		// '#shapes' is used instead of 'body' to make clear shapes easy to implement
		$(conn).appendTo('#shapes').dblclick(function(event) {
			$(this).remove();
		});
	}
	
	/* Dialogs 
	------------------------------------------------------------------------------*/
	function initDialogs() {
		$( '#dialog' ).dialog({ autoOpen: false, height: 600, width: 528 });
		$( document ).on('dblclick', 'div.shape.member',  { member  : true }, editUser);
		$( document ).on('dblclick', 'div.shape.manager', { manager : true }, editUser);
		$( document ).on('dblclick', 'div.shape.group',    editGroup   );
		$( document ).on('dblclick', 'div.shape.position', editPosition);
		//initColors();
		$('button#save').button().click(function(event) {
			event.preventDefault();
			$( '#dialog' ).dialog('close');

			var form = $('#dataForm');
			var shape = form.data('shape');
			if (shape.hasClass('member')) {
				updateUser(form, shape);
			} else if (shape.hasClass('manager')) {
				updateUser(form, shape);
			} else if (shape.hasClass('group')) {
				updateGroup(form, shape);
			} else if (shape.hasClass('position')) {
				updatePosition(form, shape);
			}
		});
	}
	
	function editUser(event) {
		//event.data.member ? alert('Edit User') : alert('Edit Manager');
		
		var templData = {};
		$('#dialog-content').empty().append($('#user-template').tmpl(templData)); 
		$('#address-container').append($('#address-template').tmpl(templData));
		$('#dialog-content').height($('#dataForm').height());
		$('#dialog').dialog('option', 'height', 650);
		$('#dialog').dialog('option', 'title', 'Edit User');
		$('#dialog').dialog('open');
		
		var form = $('#dataForm');
		form.accordion({heightStyle: 'auto'});
		
		var shape = $(this);
		form.data('shape', shape); // used later when closing dialog
		
		installUserAutocomplete();
		installMenu();
		initColors();
		
		loadUser(form, shape);
	}

	function loadUser(form, shape) {
		var user = shape.data('user');

		//var isManager = $('#manager', form).val();
		
		var userDetails = user.details;
		$('#email',     form).val(userDetails.email);
		$('#firstName', form).val(userDetails.firstName);
		$('#lastName',   form).val(userDetails.lastName);
		$('#shortName', form).val(userDetails.shortName);
		$('#phone',     form).val(userDetails.phone);
		$('#mobile',    form).val(userDetails.mobile);
		$('#status',    form).val(userDetails.status);
		$('#reason',    form).val(userDetails.reason);
		
		$('#positionName',      form).val(userDetails.position.name);
		$('#positionShortName', form).val(userDetails.position.shortName);
		$('#positionColor',     form).val(userDetails.position.color);
		$('#positionRate',      form).val(userDetails.position.rate);
		$('#positionHoursPerDay',  form).val(userDetails.position.hours.perDay);
		$('#positionHoursPerWeek', form).val(userDetails.position.hours.perWeek);
		$('#positionNotes',        form).val(userDetails.position.notes);
		
		$('#address',    form).val(userDetails.address.address);
		$('#address2',   form).val(userDetails.address.address2);
		$('#city',       form).val(userDetails.address.city);
		$('#stateId',    form).val(userDetails.address.stateId);
		$('#countryId',  form).val(userDetails.address.countryId);
		$('#postalCode', form).val(userDetails.address.postalCode);
	}
	
	function updateUser(form, shape) {
		var user = shape.data('user');
		
		var isManager = $('#manager', form).val();
		
		var userDetails = {
			email     : $('#email',  form).val(),
			firstName : $('#firstName', form).val(),
			lastName  : $('#lastName',  form).val(),
			shortName : $('#shortName', form).val(),
			phone     : $('#phone',  form).val(),
			mobile    : $('#mobile', form).val(),
			status    : $('#status', form).val(),
			reason    : $('#reason', form).val(),
			position :	{
				//frequency was omitted
				name      : $('#positionName',      form).val(),
				shortName : $('#positionShortName', form).val(),
				color     : $('#positionColor',     form).val(),
				rate      : $('#positionRate',      form).val(),
				hours: {
					perDay   : $('#positionHoursPerDay',  form).val(),
					perWeek  : $('#positionHoursPerWeek', form).val()
				},
				notes    : $('#positionNotes',      form).val(),
			},
			address  : {
				address    : $('#address',    form).val(),
				address2   : $('#address2',   form).val(),
				city       : $('#city',       form).val(),
				stateId    : $('#stateId',    form).val(), // number
				countryId  : $('#countryId',  form).val(), // number
				postalCode : $('#postalCode', form).val()
			}
		}

		user.details = userDetails;
		alert(JSON.stringify(userDetails));
	}

	function editGroup(event) {
		//alert('Edit Group');
		if (!$(this).hasClass('selected-shape')) return;

		var editOrganization = ($(this).attr('id') == 'group1');
		var settings = editOrganization 
					 ? {
						template : '#organization-template',
						title: 'Edit Organization',
						height: 500,
						panelHeight: 250
					 }
					 :  {
						template : '#group-template',
						title: 'Edit Group',
						height: 460,
						panelHeight: 200
					 }
		var templData = {};
		$('#dialog-content').empty().append($(settings.template).tmpl(templData)); 
		$('#address-container').append($('#address-template').tmpl(templData));
		$('#dialog').dialog('option', 'height', settings.height);
		$('#dialog').dialog('option', 'title', settings.title);
		$('#dialog').dialog('open');

		var form = $('#dataForm');
		form.accordion({heightStyle: 'auto'});
		$('#dataForm > div', '#dialog').height(settings.panelHeight);
		
		var shape = $(this);
		form.data('shape', shape); // used later when closing dialog

		loadGroup(form, shape);
	}
	
	function loadGroup(form, shape) {
		var group = shape.data('group');
		var groupDetails = group.details;

		var editOrganization = (shape.attr('id') == 'group1');
		if (editOrganization) {
			$('#businessName',     form).val(groupDetails.businessName);
			$('#businessNumber',   form).val(groupDetails.businessNumber);
			$('#officePhone1',     form).val(groupDetails.officePhone1);
			$('#officePhone2',     form).val(groupDetails.officePhone2);
			$('#email',            form).val(groupDetails.email);
			$('#altEmail',         form).val(groupDetails.altEmail);
			$('#status',           form).val(groupDetails.status);
			$('#incorporatedName', form).val(groupDetails.incorporatedName);
			$('#taxNumber',        form).val(groupDetails.taxNumber);
			$('#industryId',       form).val(groupDetails.industryId); // number
			$('#shortName',    form).val(groupDetails.shortName);
			$('#logo',         form).val(groupDetails.logo);
			$('#notes',        form).val(groupDetails.notes);
		} else {
			$('#groupName',    form).val(groupDetails.groupName);
			$('#shortName',    form).val(groupDetails.shortName);
			$('#logo',         form).val(groupDetails.logo);
			$('#notes',        form).val(groupDetails.notes);
			$('#officePhone1', form).val(groupDetails.officePhone1);
			$('#officePhone2', form).val(groupDetails.officePhone2);
			$('#email',        form).val(groupDetails.email);
			$('#altEmail',     form).val(groupDetails.altEmail);
		}		
		
		$('#address',    form).val(groupDetails.address.address);
		$('#address2',   form).val(groupDetails.address.address2);
		$('#city',       form).val(groupDetails.address.city);
		$('#stateId',    form).val(groupDetails.address.stateId);
		$('#countryId',  form).val(groupDetails.address.countryId);
		$('#postalCode', form).val(groupDetails.address.postalCode);
	}
	
	function updateGroup(form, shape) {
		var group = shape.data('group');

		var editOrganization = (shape.attr('id') == 'group1');
		if (editOrganization) {
			var groupDetails = {
				businessName     : $('#businessName',     form).val(),
				businessNumber   : $('#businessNumber',   form).val(),
				officePhone1     : $('#officePhone1',     form).val(),
				officePhone2     : $('#officePhone2',     form).val(),
				email            : $('#email',            form).val(),
				altEmail         : $('#altEmail',         form).val(),
				status           : $('#status',           form).val(),
				incorporatedName : $('#incorporatedName', form).val(),
				taxNumber        : $('#taxNumber',        form).val(),
				industryId       : $('#industryId',       form).val(), // number
				shortName        : $('#shortName',        form).val(),
				logo             : $('#logo',             form).val(),
				notes            : $('#notes',            form).val(),
				address  : {
					address    : $('#address',    form).val(),
					address2   : $('#address2',   form).val(),
					city       : $('#city',       form).val(),
					stateId    : $('#stateId',    form).val(), // number
					countryId  : $('#countryId',  form).val(), // number
					postalCode : $('#postalCode', form).val()
				}
			}

			group.details = groupDetails;
			//alert(JSON.stringify(groupDetails));
		} else {
			var groupDetails = {
				groupName    : $('#groupName',    form).val(),
				shortName    : $('#shortName',    form).val(),
				logo         : $('#logo',         form).val(),
				notes        : $('#notes',        form).val(),
				officePhone1 : $('#officePhone1', form).val(),
				officePhone2 : $('#officePhone2', form).val(),
				email        : $('#email',        form).val(),
				altEmail     : $('#altEmail',     form).val(),
				address  : {
					address    : $('#address',    form).val(),
					address2   : $('#address2',   form).val(),
					city       : $('#city',       form).val(),
					stateId    : $('#stateId',    form).val(), // number
					countryId  : $('#countryId',  form).val(), // number
					postalCode : $('#postalCode', form).val()
				}
			}

			group.details = groupDetails;
			//alert(JSON.stringify(groupDetails));
		}
	}

	function editPosition(event) {
		//alert('Edit Position');
		var templData = {};
		$('#dialog-content').empty().append($('#position-template').tmpl(templData)); 
		$('#dialog-content').height($('#dataForm').height());
		$('#dialog').dialog('option', 'height', 360);
		$('#dialog').dialog('option', 'title', 'Edit Position');
		$('#dialog').dialog('open');
		
		var form  = $('#dataForm');
		var shape = $(this);
		form.data('shape', shape); // used later when closing dialog
		loadPosition(form, shape);
		
		initColors();
	}

	function loadPosition(form, shape) {
		var position = shape.data('position');
		var positionDetails = position.details;

		$('#positionName',      form).val(positionDetails.name);
		$('#positionShortName', form).val(positionDetails.shortName);
		$('#positionColor',     form).val(positionDetails.color);
		$('#positionRate',      form).val(positionDetails.rate);
		$('#positionHoursPerDay',  form).val(positionDetails.hours.perDay);
		$('#positionHoursPerWeek', form).val(positionDetails.hours.perWeek);
		$('#positionNotes',        form).val(positionDetails.notes);
	}
	
	function updatePosition(form, shape) {
		var position = shape.data('position');
		
		var positionDetails = {
			//frequency was omitted
			name      : $('#positionName',      form).val(),
			shortName : $('#positionShortName', form).val(),
			color     : $('#positionColor',     form).val(),
			rate      : $('#positionRate',      form).val(),
			hours: {
				perDay   : $('#positionHoursPerDay',  form).val(),
				perWeek  : $('#positionHoursPerWeek', form).val()
			},
			notes    : $('#positionNotes',      form).val(),
		}

		position.details = positionDetails;
		alert(JSON.stringify(positionDetails));
	}
	
	function initColors() {
		$('#positionColor').jPicker({
			window: { 
				expandable: true,
				position: {
					x: 'screenCenter', 
					y: 'bottom'
				}
			}
		});
		//$(document.body).children('div.jPicker.Container').css({zIndex:110});
		//$('div.jPicker.Container').css({zIndex:120});
		$('#positionColor').hide();
	};
	
	function installUserAutocomplete() {
		// http://codeblogging.net/blogs/1/15/
		// https://github.com/twitter/typeahead.js
		// http://forum.jquery.com/topic/alternating-style-on-autocomplete
		// http://ajaxdump.com/?cL8V22l5

		$("#user", "#searchForm").autocomplete({
			source: function( request, response ) {
				var matcher = new RegExp( $.ui.autocomplete.escapeRegex( request.term ), "i" );
				var users = [
					{
						value: "Tom Hanks",
						label: "Tom Hanks",
						description: "Actor",
						image: "hanks.png"
					},
					{
						value: "Termionator 2",
						label: "Termionator 2",
						description: "Movie",
						image: "terminator.png"
					},
					{
						value: "Invitation",
						label: "Send invitation",
						description: "Please enter a valid email address",
						image: "terminator.png"
					}
				]
				response( 
					$.grep( users, function( value ) {
						value = value.label || value.value || value;
						// TODO: if you find the exact match, Invitation should not be rendered.
						return matcher.test( value ) || value == 'Send invitation'; 
					}) 
				);
			},
			open: function( event, ui ) {
				// http://stackoverflow.com/questions/4428642/suggest-a-good-pattern-for-validating-email-with-javascript
				// http://stackoverflow.com/questions/940577/javascript-regular-expression-email-validation
				if (/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test($(this).val())) {
					$('.description', '.invitation').html('Response time depends on invitee.');
				} else {
					$('.description', '.invitation').html('Please enter a valid email address');
				}
			},
			minLength: 1
		}).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
			var isInvitationItem = false;
			if (item.value == 'Invitation') {
				isInvitationItem = true;
			}

			var inner_html = '<a><div class="list_item_container ' + (isInvitationItem? 'invitation' : '')+ '"><div class="image"><img src="' 
						   + item.image 
						   + '"></div><div class="label">' 
						   + item.label 
						   + '</div><div class="description">' 
						   + item.description 
						   + '</div></div></a>';
			var res = $( "<li></li>" )
				.data( "item.autocomplete", item )
				.append(inner_html)
				.appendTo( ul );
			
			if (item.value == 'Invitation') {
				res.click(function(event) {
					alert('Invitation sent to ' + $('#user').val() + '\n Response time depends on invitee.');
					event.stopImmediatePropagation();
				});
			}
			
			return res;
		};
	}
	
	function installMenu() {
		var menu = $('div.position > ul').menu();
		closeMenu(menu);
		menu.hover(
			function() { openMenu (menu) }, 
			function() { closeMenu(menu) }
		);

		var action = $('li > a', menu).click(function() {
			//document.location.href=$(this).attr('href');
			menu.attr('data-selected-position', $(this).parent().attr('data-position'));
			closeMenu(menu);
		});
	}
	
	function openMenu(menu) {
		menu.parent().css({'z-index': '100'});
		menu.children('li').show();
	}
	
	function closeMenu(menu) {
		menu.parent().css({'z-index': '0'});
		var selectedPosition = menu.attr('data-selected-position');
		menu.children('li').each(function(index, child) {
			child = $(child);
			if (selectedPosition == child.attr('data-position')) {
				child.show();
			} else {
				child.hide();
			}
		});
	}
	
	/* Utils
	------------------------------------------------------------------------------*/

	function sign(x) {
		return (x < 0 ? -1 : (x > 0 ? 1 : 0));
	}
	
	function isPointInside(x, y, x1, y1, x2, y2) {
		return (x1 <= x && x <= x2) && (y1 <= y && y <= y2);
	}
	
	function findClosestPointOnTheCircle(point, circle) {
		//console.log("point&circle: " + [point.x, point.y, circle.x, circle.y, circle.radius].join(','));
		var dyp = (point.y - circle.y);
		var dxp = (point.x - circle.x);
		var alpha = Math.atan(dyp/dxp);
		var dy = Math.abs(circle.radius*Math.sin(alpha));
		var dx = Math.sqrt(circle.radius*circle.radius - dy*dy);
		//console.log("calcs: " + [dxp, dyp, alpha, dx, dy].join(','));
		//console.log("result: " + [circle.x + dx * sign(dxp), circle.y + dy * sign(dyp)].join(','));
		return {
			x: circle.x + dx * sign(dxp), 
			y: circle.y + dy * sign(dyp)
		};
	}
	
	function findConnectingPointsOnTheCircles(circle1, circle2) {
		//console.log("circle1, circle2=" + [circle1.x, circle1.y, circle1.radius, circle2.x, circle2.y, circle2.radius].join(', '));
		var dyr = (circle2.y - circle1.y);
		var dxr = (circle2.x - circle1.x);
		var alpha = Math.atan(dyr/dxr);
		var dy1 = Math.abs(circle1.radius * Math.sin(alpha));
		var dx1 = circle1.radius * Math.cos(alpha);
		var q = (Math.sqrt(dyr*dyr + dxr*dxr) - circle2.radius); 
		var dy2 = Math.abs(q * Math.sin(alpha));
		var dx2 = q * Math.cos(alpha);
		//console.log("dxr, dyr, alpha, dx1, dy1, q, dx2, dy2=" + [dxr, dyr, alpha, dx1, dy1, q, dx2, dy2].join(', '));
		return {
			x1: circle1.x + dx1 * sign(dxr), 
			y1: circle1.y + dy1 * sign(dyr), 
			x2: circle1.x + dx2 * sign(dxr), 
			y2: circle1.y + dy2 * sign(dyr), 
		}
	}

	function generateGUID() {
		return (GUID++);
	}

	function generateGroupGUID() {
		return (groupGUID++);
	}

	function generateUserGUID() {
		return (userGUID++);
	}
	
	function generatePositionGUID() {
		return (positionGUID++);
	}
	
});
