/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum RoleStatus {

	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED;

	public static RoleStatus fromString(String status) {
		if (status != null) {
			for (RoleStatus groupStatus : RoleStatus.values()) {
				if (status.equalsIgnoreCase(groupStatus.name())) {
					return groupStatus;
				}
			}
		}
		return null;
	}

}
