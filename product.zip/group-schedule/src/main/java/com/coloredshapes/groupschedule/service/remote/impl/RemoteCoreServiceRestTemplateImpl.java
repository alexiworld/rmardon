package com.coloredshapes.groupschedule.service.remote.impl;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.coloredshapes.groupschedule.Constants;
import com.coloredshapes.groupschedule.domain.dto.GroupBasicDto;
import com.coloredshapes.groupschedule.domain.dto.UserCompleteDto;
import com.coloredshapes.groupschedule.exception.InvalidUserException;
import com.coloredshapes.groupschedule.service.remote.RemoteCoreService;
import com.coloredshapes.groupschedule.web.util.Utilities;
@Service
public class RemoteCoreServiceRestTemplateImpl implements RemoteCoreService {
	@Resource(name = "schedulerProperties")
	private Properties sysProperties;
	
	//@Autowired
	//private RestOperations restOperations;

	@Override
	public UserCompleteDto authenticate(String email, String password) {
		RestTemplate restOperations = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		String requestorAuth = Utilities.getRequestorAuth(email, password);
		headers.set(Constants.REQUESTOR_AUTH, requestorAuth);
		
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		
		UserCompleteDto user = restOperations.postForObject(
				"http://localhost:8080/core-services/authentications", 
				httpEntity,
				UserCompleteDto.class);
		
		if (user == null) { // or try/catch exception around getForEntity
			throw new InvalidUserException(email);
		}
		
		return user;
	}

	@Override
	public Map<Long, String> getUserGroups(String auth, String user) {
		RestTemplate restOperations = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.set(Constants.REQUESTOR_AUTH, auth);
		HttpEntity<String> data = new HttpEntity<String>(headers);

		Map<String, String> vars = new HashMap<String, String>();
		vars.put("userId", user);
		
		ResponseEntity<GroupBasicDto[]> response = restOperations.exchange(
			"http://localhost:8080/core-services/users/{userId}/groups?contentLimit=BASIC&contentStatus=ACTIVE", 
			HttpMethod.GET, 
			data, 
			GroupBasicDto[].class,
			vars);
		GroupBasicDto[] groups = response.getBody();
		
		Arrays.sort(groups, new Comparator<GroupBasicDto>() {
			@Override
			public int compare(GroupBasicDto group1, GroupBasicDto group2) {
				return group1.getName().compareTo(group2.getName());
			}
		});
		
		Map<Long, String> userGroups = new LinkedHashMap<Long, String>();
		for (GroupBasicDto group : groups) {
			userGroups.put(group.getId(), group.getName());
		}
		
		return userGroups;
	}

}