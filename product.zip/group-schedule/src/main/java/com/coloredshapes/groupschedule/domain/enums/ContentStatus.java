/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum ContentStatus {

	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED;

	public static ContentStatus fromString(String status) {
		if (status != null) {
			for (ContentStatus contentStatus : ContentStatus.values()) {
				if (status.equalsIgnoreCase(contentStatus.name())) {
					return contentStatus;
				}
			}
		}
		return null;
	}

}
