/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidUserException extends CoreServicesException {
	
	/**
	 * The serial version UID for this class.
	 */
	private static final long serialVersionUID = 23543456461L;
	
	private static final String errCode = "0007";
	private String userEmail;
	private Long userId;

	public InvalidUserException(String userEmail) {
		this.userEmail = userEmail;
	}

	public InvalidUserException(Long userId) {
		this.userId = userId;
	}
	
	public String getUserEmail() {
		return userEmail;
	}

	public Long getUserId() {
		return userId;
	}

	@Override
	public String getMessage() {
		if (userId != null) {
			return "User#" + userId + " does not exist";
		} else {
			return "User with email " + userEmail + " does not exist";
		}
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
