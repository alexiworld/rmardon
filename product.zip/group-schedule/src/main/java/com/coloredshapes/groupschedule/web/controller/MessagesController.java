/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.groupschedule.Constants;
import com.coloredshapes.groupschedule.message.MessageBox;

/**
 * <code>TimeBlockController</code> handles date time block 
 * requests to REST services. The supported operations are 
 * blocking time, retrieving the time blocks, removing 
 * existing time blocks, etc.
 * 
 * User: developer
 * Date: Jun 11, 2012
 * Time: 08:36:57 AM
 */
@Controller
public class MessagesController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * Gets the message box for this session
	 * 
	 * @param session	the http session object
	 * @return	the message box
	 */
	private MessageBox getMessageBox(HttpSession session) {
		MessageBox msgBox = (MessageBox) session.getAttribute(Constants.MSG_BOX_KEY);
		if (msgBox == null) { // time to create one and place it in the session
			msgBox = new MessageBox();
			session.setAttribute(Constants.MSG_BOX_KEY, msgBox);
		}
		return msgBox;
		
	}
	
	/**
	 * Load messages.
	 * 
	 * @param session
	 *            the session
	 * @return the list of messages
	 */
	@RequestMapping(value = "/LoadMessages", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<String> LoadMessages(HttpSession session) {
		MessageBox msgBox = getMessageBox(session);
		List<String> messages = msgBox.readMessages();
		return messages;
	}

}