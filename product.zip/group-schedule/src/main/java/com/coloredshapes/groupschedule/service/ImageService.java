/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service;

/**
 * <code>ImageService</code> type is an interface to image service.
 */
public interface ImageService {
	
	/**
	 * Creates the logo image file as a static resource. The static
	 * resource can be serves over HTTP and be visible on the page.
	 * 
	 * @param storagePath
	 *            the storage path for logos
	 * @param logoId
	 *            the logo id
	 * @return the path to the logo.
	 */
	public String createLogoFile(String storagePath, String logoId);

}