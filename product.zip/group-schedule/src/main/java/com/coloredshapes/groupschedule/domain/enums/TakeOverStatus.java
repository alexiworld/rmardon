/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum TakeOverStatus {
        OPEN,
        CANCELLED,
        ACCEPTED,
        DECLINED
}
