/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class AuthenticationException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -6068936856614757057L;
	private static final String errCode = "0006";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
