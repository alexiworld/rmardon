/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum MembershipStatus {
	
	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED
	
}
