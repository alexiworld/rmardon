/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.controller;

import java.io.DataInputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestOperations;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.HandlerMapping;

import com.coloredshapes.groupschedule.Constants;

/**
 * <code>ServiceAdminController</code> provides information
 * for the present version, date of build, and mode of core
 * services application.
 */
@Controller
public class ProxyController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

//	@Value("${version:NA}")
//	private String version;
//
//	@Value("${datetime:NA}")
//	private String datetime;
//
//	@Value("${mode:NA}")
//	private String mode;
	
	//Autowiring would not work when there is not unique bean of type RestOperations
	//@Autowired
	//private RestOperations restOperations;
	@Resource(name="restDefaultTemplate")
	private RestOperations restOperations;

	//http://stackoverflow.com/questions/4542489/match-the-rest-of-the-url-using-spring-3-requestmapping-annotation
	//http://stackoverflow.com/questions/3686808/spring-3-requestmapping-get-path-value
	//http://stackoverflow.com/questions/5954793/using-springs-requestmapping-with-wildcards
	//http://www.dzone.com/tutorials/java/spring/spring-annotation-controller-1.html
	//http://stackoverflow.com/questions/2513031/multiple-spring-requestmapping-annotations
	//http://stackoverflow.com/questions/12173854/request-mapping-url-pattern-in-spring-mvc3
	//http://static.springsource.org/spring/docs/3.0.x/javadoc-api/org/springframework/web/bind/annotation/RequestMapping.html

	@RequestMapping("/multipartproxy/{path1:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestMultiPartProxy(@PathVariable String path1,
			                                   			MultipartHttpServletRequest multipartRequest,
						                                @RequestParam Map<String, String> params)
	throws Exception {
		return dispatchToTarget(path1, null, null, null, multipartRequest, params);
	}

	@RequestMapping("/multipartproxy/{path1}/{path2:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestMultiPartProxy(@PathVariable String path1,
														@PathVariable String path2,
														MultipartHttpServletRequest multipartRequest,
						                                @RequestParam Map<String, String> params)
	throws Exception {
		return dispatchToTarget(path1, path2, null, null, multipartRequest, params);
	}

	@RequestMapping("/multipartproxy/{path1}/{path2}/{path3:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestMultiPartProxy(@PathVariable String path1,
														@PathVariable String path2,
														@PathVariable String path3,
														MultipartHttpServletRequest multipartRequest,
						                                @RequestParam Map<String, String> params)
	throws Exception {
		return dispatchToTarget(path1, path2, path3, null, multipartRequest, params);
	}

	@RequestMapping("/multipartproxy/{path1}/{path2}/{path3}/{path4:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestMultiPartProxy(@PathVariable String path1,
														@PathVariable String path2,
														@PathVariable String path3,
														@PathVariable String path4,
														MultipartHttpServletRequest multipartRequest,
						                                @RequestParam Map<String, String> params)
	throws Exception {
		return dispatchToTarget(path1, path2, path3, path4, multipartRequest, params);
	}

	@RequestMapping("/proxy/{path1:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestProxy(@PathVariable String path1,
			                                   HttpEntity<byte[]> request,
			                                   WebRequest webRequest, HttpServletRequest httpRequest,
			                                   @RequestParam Map<String, String> params)
	throws Exception {
		return dispatchToTarget(path1, null, null, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxy/{path1}/{path2:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestProxy(@PathVariable String path1,
			                                   @PathVariable String path2, 
			                                   HttpEntity<byte[]> request, 
			                                   WebRequest webRequest, 
			                                   HttpServletRequest httpRequest,
			                                   @RequestParam Map<String, String> params) 
	throws Exception {
		return dispatchToTarget(path1, path2, null, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxy/{path1}/{path2}/{path3:.*}") // , method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestProxy(@PathVariable String path1,
			                                   @PathVariable String path2, 
			                                   @PathVariable String path3,
			                                   HttpEntity<byte[]> request,
			                                   WebRequest webRequest, 
			                                   HttpServletRequest httpRequest,
			                                   @RequestParam Map<String, String> params) 
	throws Exception {
		return dispatchToTarget(path1, path2, path3, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxy/{path1}/{path2}/{path3:.*}/{path4:.*}") // , method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestProxy(@PathVariable String path1, 
			                                   @PathVariable String path2, 
			                                   @PathVariable String path3, 
			                                   @PathVariable String path4, 
			                                   HttpEntity<byte[]> request, 
			                                   WebRequest webRequest, 
			                                   HttpServletRequest httpRequest, 
			                                   @RequestParam Map<String, String> params) 
	throws Exception {
		return dispatchToTarget(path1, path2, path3, path4, request, webRequest, httpRequest, params);
	}


	@RequestMapping("/proxyvoidresp/{path1:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void requestProxyVoidResponse(@PathVariable String path1,
			                             HttpEntity<byte[]> request,
			                             WebRequest webRequest, HttpServletRequest httpRequest,
			                             @RequestParam Map<String, String> params)
	throws Exception {
		dispatchToTarget(path1, null, null, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxyvoidresp/{path1}/{path2:.*}")//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void requestProxyVoidResponse(@PathVariable String path1,
			                                   @PathVariable String path2, 
			                                   HttpEntity<byte[]> request, 
			                                   WebRequest webRequest, 
			                                   HttpServletRequest httpRequest,
			                                   @RequestParam Map<String, String> params) 
	throws Exception {
		dispatchToTarget(path1, path2, null, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxyvoidresp/{path1}/{path2}/{path3:.*}") // , method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void requestProxyVoidResponse(@PathVariable String path1,
			                             @PathVariable String path2, 
			                             @PathVariable String path3,
			                             HttpEntity<byte[]> request,
			                             WebRequest webRequest, 
			                             HttpServletRequest httpRequest,
			                             @RequestParam Map<String, String> params) 
	throws Exception {
		dispatchToTarget(path1, path2, path3, null, request, webRequest, httpRequest, params);
	}

	@RequestMapping("/proxyvoidresp/{path1}/{path2}/{path3:.*}/{path4:.*}") // , method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void requestProxyVoidResponse(@PathVariable String path1, 
			                             @PathVariable String path2, 
			                             @PathVariable String path3, 
			                             @PathVariable String path4, 
			                             HttpEntity<byte[]> request, 
			                             WebRequest webRequest, 
			                             HttpServletRequest httpRequest, 
			                             @RequestParam Map<String, String> params) 
	throws Exception {
		dispatchToTarget(path1, path2, path3, path4, request, webRequest, httpRequest, params);
	}
	
	//@RequestMapping(value = { "/proxy/{path1:.*}", 
	//		                    "/proxy/{path1}/{path2:.*}", 
	//		                    "/proxy/{path1}/{path2}/{path3:.*}", 
	//		                    "/proxy/{path1}/{path2}/{path3:.*}/{path4:.*}"})//, method = RequestMethod.POST)
	//@ResponseStatus(value = HttpStatus.OK)
	//@ResponseBody
	public ResponseEntity<byte[]> dispatchToTarget(/*@PathVariable*/ String path1, 
			                                       /*@PathVariable*/ String path2,
			                                       /*@PathVariable*/ String path3,
			                                       /*@PathVariable*/ String path4,
			                                       HttpEntity<byte[]> request,
			                                       WebRequest webRequest,
			                                       HttpServletRequest httpRequest,
			                                       /*@PathVariable*/ Map<String, String> params) 
	throws Exception {
		HttpMethod method = HttpMethod.valueOf(httpRequest.getMethod());

		System.out.println("path1: " + path1);
		System.out.println("path2: " + path2);
		System.out.println("path3: " + path3);
		System.out.println("path4: " + path4);
		String text = new String(request.getBody());
		System.out.println("[PROXY>]" + text);
		System.out.println("[HEADERS>]" + request.getHeaders().toSingleValueMap());
		System.out.println("[PARAMS>]" + params);
		
		String path = (String) webRequest.getAttribute( HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST );
		System.out.println("[PROXY PATH]" + path);
		path = path.replace("/proxyvoidresp", "");
		path = path.replace("/proxy", "");
		path = "http://localhost:8080/core-services" + path;
		if (HttpMethod.GET.equals(method)) {
			if (!params.isEmpty()) path += '?';
			for (Map.Entry<String, String> paramValue : params.entrySet()) {
				path += '&' + paramValue.getKey() + '=' + paramValue.getValue();
			}
		}
		System.out.println("[TARGET PATH]" + path);
		

		String requestAuth = (String) httpRequest.getSession().getAttribute(Constants.REQUESTOR_AUTH);

		HttpHeaders headers = new HttpHeaders();
		headers.setAll(request.getHeaders().toSingleValueMap());
		headers.set(Constants.REQUESTOR_AUTH, requestAuth);

		//RestTemplate restOperations = new RestTemplate();
		HttpEntity<byte[]> data = new HttpEntity<byte[]>(request.getBody(), headers);
		// Because proxy solution is generic no information about specific place holders or params is present
		// , params is taken out exchange because its purpose is to replace place holders in path with params
		ResponseEntity<byte[]> response = restOperations.exchange(path, method, data, byte[].class);
		
		HttpHeaders responseHeaders = response.getHeaders();
		MediaType contentType = responseHeaders.getContentType();
		System.out.println("[PROXY<]" + responseHeaders.toSingleValueMap());

		byte[] content = ((response.getBody() != null) ? response.getBody() : new byte[0]); 
		if (contentType != null && !contentType.getType().equals("image")) {
			text = new String(content);
			System.out.println("[PROXY<]" + text);
		}
		
		headers = new HttpHeaders();
		headers.setAll(request.getHeaders().toSingleValueMap()); // Browser has problems when using response headers
		headers.setContentLength(content.length);
		if (contentType != null) {
			headers.setContentType(contentType);
		}
		
		ResponseEntity<byte[]> responsex = new ResponseEntity<byte[]>(content, headers, HttpStatus.OK);
		return responsex;
	}

	//@RequestMapping(value = { "/proxy/{path1:.*}", 
	//		                    "/proxy/{path1}/{path2:.*}", 
	//		                    "/proxy/{path1}/{path2}/{path3:.*}", 
	//		                    "/proxy/{path1}/{path2}/{path3:.*}/{path4:.*}"})//, method = RequestMethod.POST)
	//@ResponseStatus(value = HttpStatus.OK)
	//@ResponseBody
	public ResponseEntity<byte[]> dispatchToTarget(/*@PathVariable*/ String path1, 
			                                       /*@PathVariable*/ String path2,
			                                       /*@PathVariable*/ String path3,
			                                       /*@PathVariable*/ String path4,
			                                       MultipartHttpServletRequest multipartRequest,
			                                       /*@PathVariable*/ Map<String, String> params) 
	throws Exception {
		System.out.println("path1: " + path1);
		System.out.println("path2: " + path2);
		System.out.println("path3: " + path3);
		System.out.println("path4: " + path4);
		
		System.out.println("[PARAMS>]" + params);

	    MultipartEntity multipartEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
		//HttpEntity reqEntity = MultipartEntityBuilder.create()
		//        .addPart("bin", bin)
		//        .addPart("comment", comment)
		//        .build();

		StringBuilder sb = new StringBuilder();
		Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
		for (Map.Entry<String, MultipartFile> fileEntry : fileMap.entrySet()) {
			String fileName = fileEntry.getKey();
			MultipartFile multipartFile = fileEntry.getValue();
			multipartEntity.addPart(fileName,
				new ByteArrayBody(multipartFile.getBytes(),
					multipartFile.getContentType(),
                    multipartFile.getOriginalFilename()));

			sb.append(multipartFile.getOriginalFilename());
			sb.append(';');
		}
		
		String text = sb.toString();
		System.out.println("[PROXY>]" + text);
		
		List<Header> headers = new LinkedList<Header>();
		
		@SuppressWarnings("unchecked")
		Enumeration<String> headerNames = multipartRequest.getHeaderNames();
		if (headerNames != null) {
			// [host: localhost:8080, user-agent: Mozilla/5.0 (Windows NT 6.2; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0, accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8, accept-language: en-US,en;q=0.5, accept-encoding: gzip, deflate, referer: http://localhost:8080/group-schedule/upload.html, content-type: multipart/form-data; boundary=---------------------------140482504715124, cookie: JSESSIONID=DEA964A9C22480EA539DC9B98B3C3D48, connection: keep-alive, pragma: no-cache, cache-control: no-cache]
			while (headerNames.hasMoreElements()) {
				String name = headerNames.nextElement();
				// Setting Content-Length header causes an exception
				if ("content-length".equals(name)) continue;
				//if ("host".equals(name)) continue;
				//if ("user-agent".equals(name)) continue;
				//if ("accept".equals(name)) continue;
				//if ("accept-language".equals(name)) continue;
				//if ("accept-encoding".equals(name)) continue;
				//if ("referer".equals(name)) continue;
				// Setting Content-Type header fails the processing on target side
				if ("content-type".equals(name)) continue;
				//if ("cookie".equals(name)) continue;
				//if ("connection".equals(name)) continue;
				//if ("pragma".equals(name)) continue;
				//if ("cache-control".equals(name)) continue;
				String value = multipartRequest.getHeader(name);
				Header header = new BasicHeader(name, value);
				headers.add(header);
			}
		}

		System.out.println("[HEADERS>]" + headers);

		String requestAuth = (String) multipartRequest.getSession().getAttribute(Constants.REQUESTOR_AUTH);
		Header header = new BasicHeader(Constants.REQUESTOR_AUTH, requestAuth);
		headers.add(header);
		
		// NOTE: Passing parameters would not work by creating and setting HttpParams
		// The parameters must be passed as string parts having name as parameter name
		// and string body built out of parameter value.
		//HttpParams httpParams = new BasicHttpParams();
		//for (Entry<String, String> param : params.entrySet()) {
		//	httpParams.setParameter(param.getKey(), param.getValue());
		//}
		for (Entry<String, String> param : params.entrySet()) {
			multipartEntity.addPart(param.getKey(), new StringBody(param.getValue())); 
		}
	
		String path = (String) multipartRequest.getAttribute( HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE );
		System.out.println("[PROXY PATH]" + path);
		path = path.replace("/multipartproxy", "");
		path = "http://localhost:8080/core-services" + path;
		System.out.println("[TARGET PATH]" + path);
		
		HttpClient httpClient = new DefaultHttpClient();
        HttpPost postRequest = new HttpPost(path);
		postRequest.setHeaders(headers.toArray(new Header[headers.size()]));
		//postRequest.setParams(httpParams); // NOTE: Please find a few lines above for reasons for commenting it
		postRequest.setEntity(multipartEntity);
        HttpResponse response = httpClient.execute(postRequest);
        
        byte[] responseContent = new byte[0];
        if (response != null && response.getEntity() != null) {
            InputStream content = response.getEntity().getContent();
            if (content != null) {
            	DataInputStream dataInputStream = new DataInputStream(content);
            	int numberOfBytes = dataInputStream.available();
            	responseContent = new byte[numberOfBytes];
            	dataInputStream.readFully(responseContent);
            }
        }
		text = new String(responseContent);
		
		System.out.println("[PROXY<]" + text);
		
		// TODO: if needed get headers list and convert to responseHeaders
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentLength(responseContent.length);
		
		ResponseEntity<byte[]> responseEntity = new ResponseEntity<byte[]>(responseContent, responseHeaders, HttpStatus.OK);
		return responseEntity;
	}

}