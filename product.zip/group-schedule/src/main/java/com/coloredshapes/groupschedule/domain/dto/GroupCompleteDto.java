/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.utils.StandardUtils;

public class GroupCompleteDto extends GroupProfileDto {

	private List<GroupBasicDto> subGroups;
	private List<Long> userIds;
	private List<AssignmentDto> assignments;
	private List<RoleDto> roles;

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<GroupBasicDto> getSubGroups() {
		return subGroups;
	}

	public void setSubGroups(List<GroupBasicDto> subGroups) {
		this.subGroups = subGroups;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<Long> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<Long> userIds) {
		this.userIds = userIds;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<AssignmentDto> getAssignments() {
		return assignments;
	}

	public void setAssignments(List<AssignmentDto> assignmentDtos) {
		this.assignments = assignmentDtos;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<RoleDto> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleDto> roles) {
		this.roles = roles;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("subGroups", StandardUtils.toDtoString(subGroups)) 
            .append("userIds", userIds) 
            .append("assignments", StandardUtils.toDtoString(assignments)) 
            .append("roles", StandardUtils.toDtoString(roles)) 
            .toString();
    }

}