/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.utils;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;

import com.coloredshapes.groupschedule.domain.dto.AssignmentDto;
import com.coloredshapes.groupschedule.domain.dto.IdDto;
import com.coloredshapes.groupschedule.domain.dto.RoleDto;
import com.coloredshapes.groupschedule.domain.dto.UserCompleteDto;
import com.coloredshapes.groupschedule.domain.entity.Stamp;

/**
 * <code>StandardUtils</code> type is an utility class proving helper methods.
 */
public class StandardUtils {
	
	/**
	 * The logger for this class
	 */
	protected final static Log logger = LogFactory.getLog(StandardUtils.class);

	private final static ThreadLocal<String> threadLocalUser = new ThreadLocal<String>();
	private final static Base32Codec codec = new Base32Codec(true); 
	private static volatile boolean transferDateAsText = false;
	private static volatile boolean transferEncodedIds = false;
	
	public static void setUser(String user) {
		threadLocalUser.set(user);
	}

	public static String getUser() {
		return threadLocalUser.get();
	}
	
	public static String encodeLong(Long value) {
		if (value == null) return null;
		if (transferEncodedIds) {
			return codec.encodeLong(value);
		} else {
			return value.toString();
		}
	}

	public static Long decodeLong(String code) {
		if (code == null) return null;
		if (transferEncodedIds) {
			return codec.decodeLong(code);
		} else {
			return Long.valueOf(code);
		}
	}

	public static String[] encodeLongs(Long[] values) {
		if (values == null) return null;
		if (transferEncodedIds) {
			String[] codes = new String[values.length];
			for (int i = 0; i < values.length; i++) {
				codes[i] = (values[i] == null ? null : codec.encodeLong(values[i])); 
			}
			return codes;
		} else {
			String[] codes = new String[values.length];
			for (int i = 0; i < values.length; i++) {
				codes[i] = (values[i] == null ? null : values[i].toString()); 
			}
			return codes;
		}
	}

	public static Long[] decodeLongs(String[] codes) {
		if (codes == null) return null;
		if (transferEncodedIds) {
			Long[] values = new Long[codes.length];
			for (int i = 0; i < codes.length; i++) {
				values[i] = (codes[i] == null ? null : codec.decodeLong(codes[i])); 
			}
			return values;
		} else {
			Long[] values = new Long[codes.length];
			for (int i = 0; i < codes.length; i++) {
				values[i] = (codes[i] == null ? null : Long.valueOf(codes[i])); 
			}
			return values;
		}
	}

	public static void setTransferDateAsText(boolean dateAsText) {
		transferDateAsText = dateAsText;
	}

	public static boolean isTransferDateAsText() {
		return transferDateAsText;
	}

	public static void setTransferEncodedIds(boolean encodedIds) {
		transferEncodedIds = encodedIds;
	}

	public static boolean isTransferEncodedIds() {
		return transferEncodedIds;
	}

	/**
	 * Returns a new Collection containing a - b. The cardinality of each element 
	 * e in the returned Collection will be the cardinality of e in a minus the 
	 * cardinality of e in b, or zero, whichever is greater.
	 *  
	 * @param a	the collection A
	 * @param b	the collection B
	 * @return	the subtraction result 
	 */
	public static <T> T[] substract(T[] a, T[] b, Class<T> componentType) {
		List<T> aList = new LinkedList<T>();
		for (T t : a) {
			aList.add(t);
		}

		List<T> bList = new LinkedList<T>();
		for (T t : b) {
			bList.add(t);
		}
		
		@SuppressWarnings("unchecked")
		Collection<T> cList = CollectionUtils.subtract(aList, bList);
		@SuppressWarnings("unchecked")
		T[] array = (T[]) Array.newInstance(componentType, cList.size());
		return cList.toArray(array);
	}

	public static Long[] substract(Long[] a, Long[] b) {
		List<Long> aList = new LinkedList<Long>();
		for (Long e : a) {
			aList.add(e);
		}

		List<Long> bList = new LinkedList<Long>();
		for (Long e : b) {
			bList.add(e);
		}
		
		@SuppressWarnings("unchecked")
		Collection<Long> cList = CollectionUtils.subtract(aList, bList);
		return cList.toArray(new Long[0]);
	}

	/**
	 * Creates a stamp for a new record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @return the stamp
	 */
	public static Stamp getCreateStamp(String user) {
		Stamp stamp = new Stamp();
		stamp.setCreateUser(user);
		stamp.setCreateDateTime(DateTime.now());
		return stamp;
	}
	
	/**
	 * Creates a stamp for a new record.
	 * 
	 * @return the stamp
	 */
	public static Stamp getCreateStamp() {
		return getCreateStamp(getUser());
	}
	
	/**
	 * Create a stamp for an existing record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @param lastStamp
	 *            the previous stamp on this record.
	 * @return the stamp
	 */
	public static Stamp getUpdateStamp(String user, Stamp lastStamp) {
		Stamp stamp = new Stamp();
		if (lastStamp == null) { lastStamp = new Stamp(); }
		stamp.setCreateUser(lastStamp.getCreateUser());
		stamp.setCreateDateTime(lastStamp.getCreateDateTime());
		stamp.setUpdateUser(user);
		stamp.setUpdateDateTime(DateTime.now());
		return stamp;
	}

	/**
	 * Create a stamp for an existing record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @param lastStamp
	 *            the previous stamp on this record.
	 * @return the stamp
	 */
	public static Stamp getUpdateStamp(Stamp lastStamp) {
		return getUpdateStamp(getUser(), lastStamp);
	}

	/**
	 * Returns string representation of dto collection.
	 * 
	 * @param dtos	the dtos
	 * @return	the string representation
	 */
	public static <T extends IdDto> String toDtoString(List<T> dtos) {
		return toDtoString(dtos, null);
	}
	
	/**
	 * Returns string representation of entity collection. If DTO class is specified it will be
	 * prepended. Please note the class is not derived directly from the element cause collection 
	 * can be empty.
	 * 
	 * @param entities	the dtos
	 * @elementClass	the exact type of dtos 
	 * @return	the string representation
	 */
	public static <T extends IdDto> String toDtoString(List<T> dtos, Class<T> dtoClass) {
		StringBuilder sb = new StringBuilder();
		
		if (dtoClass != null) {
			sb.append(dtoClass.getSimpleName());
		}
		
		if (dtos == null) {
			sb.append("null");
		} else {
			sb.append('{');
			boolean first = true;
			for (T dto : dtos) {
				if (first) {
					first = false;
				} else {
					sb.append(", ");
				}
				sb.append(dto.getId());
			}
			sb.append('}');
		}
		
		return sb.toString();
	}

	public static Map<String, String> toMap(UserCompleteDto userDto) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		
		map.put("userId", encodeLong(userDto.getId()));

		StringBuilder sb = new StringBuilder();
		sb.append('[');
		List<AssignmentDto> assignmentDtos = userDto.getAssignments();
		for (Iterator<AssignmentDto> iterator = assignmentDtos.iterator(); iterator.hasNext();) {
			AssignmentDto assignmentDto = iterator.next();
			sb.append("{ \"id\": ");
			sb.append(encodeLong(assignmentDto.getId()));
			sb.append(", \"roleId\": ");
			sb.append(encodeLong(assignmentDto.getRoleId()));
			sb.append('}');
			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}
		sb.append(']');

		map.put("assignments", sb.toString());
		return map;
	}

	public static RoleDto getAdminRole() {
		RoleDto roleDto = new RoleDto();
		roleDto.setName("Admin");
		roleDto.setShortName("Admin");
		roleDto.setColor("FF0000");
		return roleDto;
	} 

}