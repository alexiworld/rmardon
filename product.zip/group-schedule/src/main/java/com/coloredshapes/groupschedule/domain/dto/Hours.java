/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@Embeddable
public class Hours implements Serializable {
	
	private static final long serialVersionUID = -5998703105936409833L;

	@Column(name = "per_day")
	private Double perDay;

	@Column(name = "per_week")
    private Double perWeek;

	@Column(name = "per_month")
    private Double perMonth;

	@Column(name = "per_year")
    private Double perYear;

    @JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getPerDay() {
		return perDay;
	}

	public void setPerDay(Double perDay) {
		this.perDay = perDay;
	}

    @JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getPerWeek() {
		return perWeek;
	}

	public void setPerWeek(Double perWeek) {
		this.perWeek = perWeek;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getPerMonth() {
		return perMonth;
	}

	public void setPerMonth(Double perMonth) {
		this.perMonth = perMonth;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getPerYear() {
		return perYear;
	}

	public void setPerYear(Double perYear) {
		this.perYear = perYear;
	}
	
}