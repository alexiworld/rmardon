/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.coloredshapes.groupschedule.utils.StandardUtils;

/**
 * <code>IdSerializer</code> is a class used to encode entity identifiers.
 */
public class IdSerializer extends JsonSerializer<Long> {

	@Override
	public void serialize(Long value, JsonGenerator jgen, SerializerProvider provider) 
	throws IOException, JsonProcessingException {
		if (value == null) {
			jgen.writeString((String) null);
		} else {
			String idStr;
			if (StandardUtils.isTransferEncodedIds()) {
				idStr = StandardUtils.encodeLong(value);
			} else {
				idStr = value.toString();
			}
			jgen.writeString(idStr);
		}
	}

}
