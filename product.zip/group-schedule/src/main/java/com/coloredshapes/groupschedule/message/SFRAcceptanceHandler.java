package com.coloredshapes.groupschedule.message;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coloredshapes.groupschedule.service.ScheduleService;
/**
 * <code>MessageHandler</code> serves to collect SFR
 * acceptance messages placed by the services in the 
 * queue. 
 * 
 * User: developer
 * Date: Oct 9, 2012
 * Time: 07:36:00 AM
 *
 */
@Service("sfrAcceptanceHandler")
public class SFRAcceptanceHandler implements MessageListener{
	/** The logger. */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private ScheduleService scheduleService;
	
   /**
    * Handles SFR acceptance message by delegating the processing to the schedule service.
    */
	@Override
	public void onMessage(Message message) {
		if (logger.isInfoEnabled()) {
			logger.info("start processing SFR acceptance message");
		}
		
		byte[] body = message.getBody();
		ObjectMapper mapper = new ObjectMapper();
		
//		SFRAcceptance sfrAcceptance;
//		try {
//			sfrAcceptance = mapper.readValue(body, 0, body.length, SFRAcceptance.class);
//			if (logger.isDebugEnabled()) {
//				logger.debug("SFR key: " + sfrAcceptance.getSfrKey());
//				logger.debug("SFR taken by: " + sfrAcceptance.getTakenByMember());
//			}
//
//			scheduleService.acceptSFR(sfrAcceptance);
//		} catch (Exception e){
//			logger.error(e.getMessage() , e);
//		}
	}

}