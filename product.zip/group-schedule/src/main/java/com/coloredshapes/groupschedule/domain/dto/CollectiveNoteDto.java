/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.joda.time.DateTime;

import com.coloredshapes.groupschedule.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.DateSerializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdArraySerializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdSerializer;
import com.coloredshapes.groupschedule.exception.InvalidEventException;

/**
 * <code>CollectiveNoteDto</code> is a class representing
 * assignments to be send out from an group to users for 
 * specific time period.
 */
public class CollectiveNoteDto implements Comparable<CollectiveNoteDto> {
	
	private Long groupId;
	private Long[] userIds;
	private DateTime startTime;
	private DateTime endTime;
	private Long[] invalidUserIds;

    /**
     * Creates a notify assignments instance.
     */
	public CollectiveNoteDto() {
	}
	
    /**
     * Creates an date event instance.
     * 
     * @param groupId		the group id
     * @param userIds	the user ids
     * @param startTime		the start time
     * @param endTime		the end time
     */
    public CollectiveNoteDto(Long groupId, Long[] userIds, DateTime startTime, DateTime endTime) {
        validateBeforeCreate(startTime,endTime);
        this.groupId = groupId;
        this.userIds = userIds;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    /**
     * Validates times before creating the period instance.
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     * @throws InvalidEventException is raised if the start time appears to be later than the end time.
     */
    private static void validateBeforeCreate(DateTime startTime, DateTime endTime) throws InvalidEventException {
        if(endTime.isBefore(startTime)){
            throw new InvalidEventException("End Time must be after Start Time");
        }
    }
    
	/**
	 * Sets the group id
	 * 
	 * @param groupId the group id to set
	 */
    @JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * Gets the group id
	 * 
	 * @return the group id
	 */
    @JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getGroupId() {
		return groupId;
	}
	
	/**
	 * Sets the user ids
	 * 
	 * @param userKey the user ids to set
	 */
	@JsonDeserialize(contentAs = IdDeserializer.class)
	public void setUserIds(Long[] userIds) {
		this.userIds = userIds;
	}

	/**
	 * Gets the user ids
	 * 
	 * @return the user ids
	 */
	@JsonSerialize(using = IdArraySerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long[] getUserIds() {
		return userIds;
	}

	/**
	 * Sets the invalid user ids. These are the ids for which
	 * users are not found, or their email is not available, etc.
	 * 
	 * @param invalidUserKey 	the invalid user ids to set
	 */
	@JsonDeserialize(contentAs = IdDeserializer.class)
	public void setInvalidUserIds(Long[] invalidUserIds) {
		this.invalidUserIds = invalidUserIds;
	}

	/**
	 * Gets the invalid user ids
	 * 
	 * @return the invalid user ids
	 */
	@JsonSerialize(using = IdArraySerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long[] getInvalidUserIds() {
		return invalidUserIds;
	}

	/**
     * Sets the start time.
     * 
	 * @param startTime the start time to set
	 */
    @JsonDeserialize(using=DateDeserializer.class)
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	/**
     * Gets the start time
     * 
     * @return	the start time
     */
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getStartTime(){
    	return startTime;
    }

	/**
	 * Sets the end time.
	 * 
	 * @param endTime the end time to set
	 */
    @JsonDeserialize(using=DateDeserializer.class)
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	/**
     * Gets the end time
     * 
     * @return	the end time
     */
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getEndTime(){
        return endTime;
    }

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("groupId", groupId) 
        	.append("userIds", userIds) 
        	.append("startTime", startTime) //.toString("dd.MM.yyyy HH:mm")
            .append("endTime", endTime)   //.toString("dd.MM.yyyy HH:mm")
            .toString();
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof CollectiveNoteDto)) return false;

        CollectiveNoteDto collectiveNote = (CollectiveNoteDto) that;

        return new EqualsBuilder()
	        .append(startTime, collectiveNote.startTime)
	        .append(endTime, collectiveNote.endTime)
	        .append(groupId, collectiveNote.groupId)
	        .append(userIds, collectiveNote.userIds)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user id is always present, while the group id not.
     * To improve the searching performance in a map the hash
     * code only takes the user id into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
	        .append(groupId)
	        .append(userIds)
	        .append(startTime)
	        .append(endTime)
	        .hashCode();
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(CollectiveNoteDto that) {
        if (this == that) return 0;

        return new CompareToBuilder()
	        .append(startTime, that.startTime)
	        .append(endTime, that.endTime)
	        .append(groupId, that.groupId)
	        .append(userIds, that.userIds)
	        .toComparison();
    }
   
}