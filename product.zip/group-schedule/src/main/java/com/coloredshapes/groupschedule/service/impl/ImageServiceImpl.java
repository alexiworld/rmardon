/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.groupschedule.service.ImageService;

/**
 * <code>ImageServiceImpl</code> type provide set of image operation 
 * as they are defined in <code>ImageService</code>.
 */
@Service
public class ImageServiceImpl implements ImageService {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * Creates the logo image file as a static resource. The static
	 * resource can be serves over HTTP and be visible on the page.
	 * 
	 * @param storagePath
	 *            the storage path for logos
	 * @param logoId
	 *            the logo id
	 * @return the path to the logo.
	 */
	@Override
	@Transactional(readOnly=true)
	public String createLogoFile(String storagePath, String logoId) {
		// Create storage path directory if it does not exist
		File storagePathDirectory = new File(storagePath);
		if (!storagePathDirectory.exists()) {
			if (logger.isDebugEnabled()) {
				logger.debug("Creating logos directory: " + storagePath);
			}
			if (storagePathDirectory.mkdirs()) {
				if (logger.isDebugEnabled()) {
					logger.debug("Success");
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("Failed");
				}
			}
		}

		byte[] logoBytes = null; // retrieve the image from the service, entity, etc.
		String logoFilename = "logo" + "#123";
		
		File logoFile = new File(storagePathDirectory, logoFilename);
		if (logger.isDebugEnabled()) {
			logger.debug("Creating organization logo file: " + logoFile);
		}
		
		boolean createLogo = true;
		//if (logoFile.exists()) {
		//	Stamp stamp = null; // retrieve the timestamp from the service, entity, etc.
		//	if (stamp != null) {
		//		DateTime time = stamp.getUpdateDateTime();
		//		if (time == null) {
		//			time = stamp.getCreateDateTime();
		//		}
		//		
		//		if (time != null && 
		//			time.getMillis() < logoFile.lastModified()) {
		//			createLogo = false;
		//		}
		//	}
		//}
		
		if (createLogo) {
			logoFile.delete();
			
			BufferedOutputStream outputStream;
			try {
				outputStream = new BufferedOutputStream(new FileOutputStream(logoFile));
				outputStream.write(logoBytes);
				outputStream.close();
			} catch (IOException e) {
				if (logger.isErrorEnabled()) {
					logger.error("Creating logo file failed due to " + e);
				}
			}
		}

		return logoFile.getAbsolutePath();
	}
	
}