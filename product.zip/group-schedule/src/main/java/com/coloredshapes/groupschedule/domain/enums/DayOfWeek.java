/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum DayOfWeek {
    MON("Monday"),
    TUE("Tuesday"),
    WED("Wednesday"),
    THU("Thursday"),
    FRI("Friday"),
    SAT("Saturday"),
    SUN("Sunday");
    
    private String label;

    DayOfWeek(String label){
        this.label = label;
    }
    
    public String toString(){
        return this.label;
    }
    
}
