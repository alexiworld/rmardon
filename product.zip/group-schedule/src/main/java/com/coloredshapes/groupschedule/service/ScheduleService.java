/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service;


/**
 * <code>ScheduleService</code> type is an interface to manage schedule.
 */
public interface ScheduleService {
	
	
}