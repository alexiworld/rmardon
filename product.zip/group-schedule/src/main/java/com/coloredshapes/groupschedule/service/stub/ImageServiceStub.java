/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service.stub;

import org.springframework.stereotype.Service;

import com.coloredshapes.groupschedule.service.ImageService;

/**
 * <code>ImageServiceStub</code> type is the stub implementation
 * of <code>ImageService</code> interface.
 */
@Service
public class ImageServiceStub implements ImageService {

	/**
	 * Creates the logo image file as a static resource. The static
	 * resource can be serves over HTTP and be visible on the page.
	 * 
	 * @param storagePath
	 *            the storage path for logos
	 * @param logoId
	 *            the logo id
	 * @return the path to the logo.
	 */
	public String createLogoFile(String storagePath, String logoId) {
		return null;
	}

}