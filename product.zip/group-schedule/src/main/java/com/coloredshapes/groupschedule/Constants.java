/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule;

/**
 * The Group Schedule Constants.
 */
public class Constants {

	/** The Constant SUCCESS. */
	public static final String SUCCESS = "Success";	
	
	/** The Constant FAILURE. */
	public static final String FAILURE = "Failure";	
	
	public final static String SEARCH_PHRASE = "\"refNum\":\"";

	/** The Constant for Message Box session key */
	public final static String MSG_BOX_KEY = "MSG_BOX_KEY"; 

	/** The Constant for MAIN. */
	public static final String MAIN = "main";
	
	/** The Constant for SCHEDULE. */
	public static final String SCHEDULE = "schedule";
	
	/** The Constant for TORS. */
	public static final String TORS = "tors";
	
	/** The Constant for LOGIN. */
	public static final String LOGIN = "login";

	/** The Constant for REQUESTOR_AUTH. */
	public static final String REQUESTOR_AUTH = "Requestor-Authentication";

	/** The Constant for USER. */
	public static final String USER = "user";
	
	/** The Constant for USER_ID. */
	public static final String USER_ID = "userId";

	/** The Constant for USER_EMAIL. */
	public static final String USER_EMAIL = "email";

	/** The Constant for PASSWORD. */
	public static final String PASSWORD = "password";

	/** The Constant for GROUP. */
	public static final String GROUP = "group";
	
	/** The Constant for GROUP_ID. */
	public static final String GROUP_ID = "groupId";

	/** The Constant for GROUPS. */
	public static final String GROUPS = "groups";

	/** The Constant for LOGO. */
	public static final String LOGO = "logo";
	
	/** The Constant for schedule context. */
	public static final String SCHEDULE_CONTEXT = "scheduleContext";
	
	/** The Constant for delimiting tokens. */
	public static final char DELIM = '|';
	
}