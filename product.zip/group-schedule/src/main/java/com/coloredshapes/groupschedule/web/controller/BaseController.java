package com.coloredshapes.groupschedule.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

public class BaseController {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public Exception handleException3(MethodArgumentNotValidException ex) {
		return ex;
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Exception handleException(Exception ex) {
		if (logger.isErrorEnabled()) {
			logger.error("Failed to handle request due to " + ex);
		}
		return ex;
	}

}
