/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.dao.stub;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.coloredshapes.groupschedule.dao.GenericDao;
import com.coloredshapes.groupschedule.domain.entity.BaseEntity;

/**
 * <code>GenericDaoStub</code> type as stub for <code>GenericDao</code> 
 * interface enables quick development until the real DAO becomes available. 
 * It should not be used as a base for code reviews. 
 */
@Repository
public class GenericDaoStub<T> implements GenericDao<T> {

	private Map<Object, T> store = new HashMap<Object, T>();

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#countAll(java.util.Map)
	 */
	@Override
	public long countAll(Map<String, Object> params) {
		return store.size();
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#create(java.lang.Object)
	 */
	@Override
	public T create(T t) {
		if (t instanceof BaseEntity) {
			store.put(((BaseEntity) t).getId(), t);
		} else {
			store.put("" + t, t);
		}
		return t;
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#delete(java.lang.Object)
	 */
	@Override
	public void delete(Object id) {
		store.remove(id);
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#find(java.lang.Object)
	 */
	@Override
	public T find(Object id) {
		return store.get(id);
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#findOneBy(java.lang.String, java.lang.Object)
	 */
	@Override
	public T findOneBy(String param, Object value) {
		throw new RuntimeException("Not implemented operation.");
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#findOneBy(java.util.Map)
	 */
	@Override
	public T findOneBy(Map<String, Object> params) {
		throw new RuntimeException("Not implemented operation.");
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#findManyBy(java.lang.String, java.lang.Object)
	 */
	@Override
	public List<T> findManyBy(String param, Object value) {
		throw new RuntimeException("Not implemented operation.");
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#findManyBy(jatva.util.Map)
	 */
	@Override
	public List<T> findManyBy(Map<String, Object> params) {
		throw new RuntimeException("Not implemented operation.");
	}

	/* (non-Javadoc)
	 * @see com.coloredshapes.groupschedule.dao.GenericDao#update(java.lang.Object)
	 */
	@Override
	public T update(T t) {
		if (t instanceof BaseEntity) {
			store.put(((BaseEntity) t).getId(), t);
		} else {
			store.put("" + t, t);
		}
		return t;
	}
	
}