/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class ExistingUserException extends CoreServicesException {

	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 645646451L;
	private static final String errCode = "0003";

	private String userEmail;
	private Long userId;

	public ExistingUserException(String userEmail) {
		this.userEmail = userEmail;
	}

	public ExistingUserException(Long userId) {
		this.userId = userId;
	}

	@Override
	public String getMessage() {
		if (userId != null) {
			return "User#" + userId + " already exists";
		} else {
			return "User with email " + userEmail + " already exists";
		}
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
