/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.controller;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;

/**
 * <code>ScheduleController</code> handles schedule related
 * requests to REST services. The supported operations are 
 * retrieving the group schedule for specific period, the
 * schedule constraints, save, and notify.
 * 
 * User: developer
 * Date: 15/07/12
 * Time: 12:30 AM
 */
@Controller
public class ScheduleController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

//	/**
//	 * The schedule service.
//	 */
//	@Autowired
//	private ScheduleService scheduleService;
//
//	/**
//	 * Prepares the data required to show the schedule page.
//	 * 
//	 * @param session
//	 *            the session
//	 * @return the model and view
//	 */
//	@RequestMapping(value = "/schedule.html", method = RequestMethod.GET)
//	public ModelAndView showSchedulePage(HttpSession session) { // @RequestParam(required=false,defaultValue="mavens") String unitKey
//		if (logger.isDebugEnabled()) {
//			logger.debug("/schedule.html controller reached.");
//		}
//		
//		String unitKey = (String) session.getAttribute(Constants.UNIT_KEY);
//		String schedulorKey = (String) session.getAttribute(Constants.USER_ID);
//		
//		// It is needed to retrieve groups to which the schedulor has access to
//		// Groups groups = scheduleService.getGroupKeys(unitKey);
//		Schedulor schedulor = new Schedulor(schedulorKey);
//		Groups groups = scheduleService.getGroupKeys(schedulor, unitKey);
//		Organization org = scheduleService.getOrganizationByUnitKey(unitKey);
//		ScheduleContext context = scheduleService.getScheduleContext(schedulor, unitKey);
//
//		Map<String, Object> model = new HashMap<String, Object>();
//		model.put(Constants.USER_ID, schedulorKey);
//		model.put(Constants.UNIT_KEY, unitKey);
//		model.put(Constants.GROUPS, groups);
//		model.put(Constants.ORGANIZATION, org);
//		model.put(Constants.SCHEDULE_CONTEXT, context);
//		
//		return new ModelAndView(Constants.SCHEDULE, model);
//	}
//
//	/**
//	 * Prepares the data required to show clean schedule page.
//	 * 
//	 * @return the model and view
//	 */
//	@RequestMapping(value = "/cleanschedule.html", method = RequestMethod.GET)
//	public ModelAndView showCleanSchedulePage(HttpSession session) { // @RequestParam(required=false,defaultValue="mavens") String unitKey
//		if (logger.isDebugEnabled()) {
//			logger.debug("/cleanschedule.html controller reached.");
//		}
//
////		if (scheduleService instanceof ScheduleServiceStub) {
////			((ScheduleServiceStub) scheduleService).resetCache();
////		}
//		
//		String unitKey = (String) session.getAttribute(Constants.UNIT_KEY);
//		String schedulorKey = (String) session.getAttribute(Constants.USER_ID);
//		
//		// It is needed to retrieve groups to which the schedulor has access to
//		// Groups groups = scheduleService.getGroupKeys(unitKey);
//		Schedulor schedulor = new Schedulor(schedulorKey);
//		Groups groups = scheduleService.getGroupKeys(schedulor, unitKey);
//		
//		Map<String, Object> model = new HashMap<String, Object>();
//		model.put(Constants.USER_ID, schedulorKey);
//		model.put(Constants.UNIT_KEY, unitKey);
//		model.put(Constants.GROUPS, groups);
//		
//		return new ModelAndView(Constants.SCHEDULE, model);
//	}
//	
//	/**
//	 * Retrieves the schedulor's schedule for specific time period.
//	 *  
//	 * @param schedulorKey	the schedulor requesting the schedule
//	 * @param groupKey		the group the schedule is for
//	 * @param startTime		the start time
//	 * @param endTime		the end time
//	 * @return	the schedule
//	 * @throws Exception	an exception can be raised in case something goes wrong
//	 */
//	@RequestMapping(value = "/schedule/{schedulorKey}/{unitKey}/{groupKey}", method = RequestMethod.GET)
//	@ResponseStatus(value = HttpStatus.OK)
//	@ResponseBody
//	public Schedule getSchedule(@PathVariable String schedulorKey, 
//			  					@PathVariable String unitKey,
//								@PathVariable String groupKey, 
//			                    @RequestParam Long startTime, 
//			                    @RequestParam Long endTime) throws Exception {
//		if (logger.isDebugEnabled()) {
//			logger.debug("<getSchedule> controller action reached.");
//			logger.debug("schedulor: " + schedulorKey);
//			logger.debug("unit: "      + unitKey     );
//			logger.debug("group: "     + groupKey    );
//			logger.debug("startTime: " + startTime   );
//			logger.debug("endTime: "   + endTime     );
//		}
//		
//		Schedulor schedulor = new Schedulor();
//		schedulor.setSchedulorKey(schedulorKey);
//		TimePeriod timePeriod = new TimePeriod(startTime, endTime);
//		
//		return scheduleService.getSchedule(schedulor, unitKey, groupKey, timePeriod);
//	}
//
//	/**
//	 * Retrieves the schedulee constraints i.e. time blocks during which the schedulees are not available,
//	 * schedulee positions and their availability, etc.
//	 * 
//	 * @param schedulor		the schedulor requesting the schedule
//	 * @param group			the group the schedule is for
//	 * @param startTime		the start time
//	 * @param endTime		the end time
//	 * @return	the schedule constraints
//	 * @throws Exception	an exception can be raised in case something goes wrong
//	 */
//	@RequestMapping(value = "/scheduleConstraints/{schedulorKey}/{unitKey}/{groupKey}", method = RequestMethod.GET)
//	@ResponseStatus(value = HttpStatus.OK)
//	@ResponseBody
//	public ScheduleConstraints getScheduleConstraints(HttpSession session, 
//													  @RequestParam("schedule") Long scheduleKey,
//													  @PathVariable String schedulorKey, 
//													  @PathVariable String unitKey,
//													  @PathVariable String groupKey,
//													  @RequestParam Long startTime, 
//										              @RequestParam Long endTime) throws Exception {
//		if (logger.isDebugEnabled()) {
//			logger.debug("<getScheduleConstraints> controller action reached.");
//			logger.debug("schedule:  " + scheduleKey );
//			logger.debug("schedulor: " + schedulorKey);
//			logger.debug("unit: "      + unitKey     );
//			logger.debug("group: "     + groupKey    );
//			logger.debug("startTime: " + startTime   );
//			logger.debug("endTime: "   + endTime     );
//		}
//		
//		Schedulor schedulor = new Schedulor();
//		schedulor.setSchedulorKey(schedulorKey);
//
//		Schedule schedule = new Schedule();
//		schedule.setScheduleKey(scheduleKey);
//		schedule.setUnitKey(unitKey);
//		schedule.setGroupKey(groupKey);
//		schedule.setStartTime(new DateTime(startTime));
//		schedule.setEndTime(new DateTime(endTime));
//
//		
//		ScheduleePositions scheduleePositions = scheduleService.getScheduleePositions(schedulor, unitKey, groupKey);
//		List<ScheduleeConstraint> scheduleeConstraints = scheduleService.getScheduleeConstraints(schedule, scheduleePositions);
//		
//		ScheduleConstraints scheduleConstraints = new ScheduleConstraints();
//		scheduleConstraints.setScheduleKey(scheduleKey);
//		scheduleConstraints.setScheduleePositions(scheduleePositions.getScheduleePositions());
//		scheduleConstraints.setScheduleeConstraints(scheduleeConstraints);
//
//		return scheduleConstraints;
//	}
//
//	/**
//	 * Saves the schedule.
//	 * 
//	 * The schedule will contain the schedule identifier, schedulee shifts, time
//	 * period, etc.
//	 * 
//	 * The save result returned will contained the success/failure information.
//	 * 
//	 * The schedule if previously did not exist is always created on page load;
//	 * therefore, the method for this operation is PUT.
//	 * 
//	 * @param schedulorKey
//	 *            the schedulor key
//	 * @param schedule
//	 *            the schedule to be saved
//	 * @return the save result
//	 */
//	@RequestMapping(value = "/schedule/{schedulorKey}", method = RequestMethod.PUT)
//	@ResponseStatus(value = HttpStatus.OK)
//	@ResponseBody
//	public SaveResult saveSchedule(@PathVariable String schedulorKey, @RequestBody Schedule schedule) throws Exception {
//		if (logger.isDebugEnabled()) {
//			logger.debug("<saveSchedule> controller action reached.");
//			logger.debug("schedule: " + schedule);
//		}
//
//		Schedulor schedulor = new Schedulor();
//		schedulor.setSchedulorKey(schedulorKey);
//
//		return scheduleService.saveSchedule(schedulor, schedule);
//	}
//	
//	/**
//	 * Copies the schedulee shifts from the source schedule to the target
//	 * schedule respectively from the first to the second schedule from the
//	 * schedules array.
//	 * 
//	 * The schedule will contain the schedule identifier, schedulee shifts, time
//	 * period, etc.
//	 * 
//	 * The copy result returned will contained the success/failure information,
//	 * as well the source and target schedule keys.
//	 * 
//	 * The schedule if previously did not exist is always created on page load;
//	 * therefore, the method for this operation is PUT.
//	 * 
//	 * @param schedulorKey
//	 *            the schedulor key
//	 * @param schedules
//	 *            the source and target schedules
//	 * @return the copy result
//	 */
//	@RequestMapping(value = "/copyschedule/{schedulorKey}/", method = RequestMethod.PUT)
//	@ResponseStatus(value = HttpStatus.OK)
//	@ResponseBody
//	public CopyResult copySchedule(@PathVariable String schedulorKey, @RequestBody Schedule[] schedules) throws Exception {
//		if (logger.isDebugEnabled()) {
//			logger.debug("<copySchedule> controller action reached.");
//			logger.debug("schedules: " + (schedules == null ? null : Arrays.toString(schedules)));
//		}
//
//		Schedulor schedulor = new Schedulor();
//		schedulor.setSchedulorKey(schedulorKey);
//		
//		if (schedules == null || schedules.length != 2) {
//			throw new IllegalArgumentException("Invalid number of schedules");
//		}
//
//		return scheduleService.copySchedule(schedulor, schedules[0], schedules[1], false);
//	}
//	
//	/**
//	 * Notifies the schedulees about their shifts.
//	 * 
//	 * The schedule will contain the schedule identifier, and if 
//	 * necessary schedulor, schedulee and their shifts, time period, 
//	 * etc.
//	 * 
//	 * The schedule returned will also contained the success/failure 
//	 * information, or we can create a separate type for this.
//	 * 
//	 * @param schedule	the schedule to be saved
//	 * @return	the schedule 
//	 */
//	@RequestMapping(value = "/scheduleesNotification/{schedulorKey}", method = RequestMethod.POST)
//	@ResponseStatus(value = HttpStatus.OK)
//	@ResponseBody
//	public NotifyResult notifySchedulees(@PathVariable String schedulorKey, @RequestBody Schedule schedule) throws Exception {
//		if (logger.isDebugEnabled()) {
//			logger.debug("<notifySchedulees> controller action reached.");
//			logger.debug("schedule: " + schedule);
//		}
//
//		Schedulor schedulor = new Schedulor();
//		schedulor.setSchedulorKey(schedulorKey);
//
//		return scheduleService.notifySchedulees(schedulor, schedule);
//	}

}