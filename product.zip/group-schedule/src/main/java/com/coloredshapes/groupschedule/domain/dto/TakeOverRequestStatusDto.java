/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdSerializer;

public class TakeOverRequestStatusDto {
	
	/**
	 * unique identifier of the TOR
	 */
	private Long torId;	
	private String status;

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getTorId() {
		return torId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setTorId(Long torId) {
		this.torId = torId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}