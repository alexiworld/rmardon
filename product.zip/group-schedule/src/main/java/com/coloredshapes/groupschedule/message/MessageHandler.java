/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.message;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;

import com.coloredshapes.groupschedule.web.util.Utilities;

//
//The immediate response:
//
//{
//    "refNum": "1441505914760509589"
//}
//
//The message placed in the queue:
//
//{
//    "deletedTimeBlocks":[],
//    "addedTimeBlocks":[],
//    "unitKey": "safeway",
//    "refNum": "1441505914760509589"
//}
//
//The mapping will be done 
//

/**
 * <code>MessageHandler</code> serves to collect messages
 * placed by the services in the queue. These messages are
 * then delivered to the corresponding message box using 
 * the reference number in the message.
 * 
 * User: developer
 * Date: 15/07/12
 * Time: 14:16 AM
 */
public class MessageHandler implements MessageListener {
	
	/** The logger. */
	protected final Log logger = LogFactory.getLog(getClass());
	
	Map<String, MessageBox> refNumberMessageBox = new HashMap<String, MessageBox>();
	Map<String, String>     refNumberMessages   = new HashMap<String, String>();
	
	/**
	 * Registers the message box for a message with the specified reference number
	 * 
	 * @param refNum	the reference number
	 * @param msgBox	the message box to collect the message
	 */
	public void registerMessageBox(String refNum, MessageBox msgBox) {
		if (logger.isDebugEnabled()) {
			logger.debug("register message box: " + refNum + "," + msgBox);
		}
		String msg = refNumberMessages.get(refNum);
		if (msg != null) {
			msgBox.addMessage(msg);
			if (logger.isDebugEnabled()) {
				logger.debug("The message" + msg 
					+ " arrived earlier and is placed in the message box" + msgBox);
			}
		} else {
			refNumberMessageBox.put(refNum, msgBox);
		}
	}

	/**
	 * Delivers the message.
	 * 
	 * @param refNum	the message reference number
	 * @param msg		the message 
	 */
	public void deliverMessage(String refNum, String msg) {
		MessageBox msgBox = refNumberMessageBox.get(refNum);
		if (logger.isDebugEnabled()) {
			logger.debug("Deliver" + msg + " to message box" + msgBox);
		}

		if (msgBox != null) {
			msgBox.addMessage(msg);
			if (logger.isDebugEnabled()) {
				logger.debug("Message delivered");
			}
		} else {
			refNumberMessages.put(refNum, msg);
			if (logger.isDebugEnabled()) {
				logger.debug("Message arrived earlier");
			}
		}
	}

	/**
	 * Handles a message.
	 * 
	 * @param message	the message to be processed
	 */
	@Override
	public void onMessage(Message message) {
		if (logger.isDebugEnabled()) {
			logger.debug("Received message: " + new String(message.getBody()));
			logger.debug("Received message properties: " + message.getMessageProperties());
		}
		
		if (message.getBody() == null) return;
		
		String msg = new String(message.getBody());
		String refNum = Utilities.getReferenceNumber(msg);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Message reference number: " + refNum);
		}

		if (!StringUtils.isEmpty(refNum)) {
			deliverMessage(refNum, msg);
		}
	}

}