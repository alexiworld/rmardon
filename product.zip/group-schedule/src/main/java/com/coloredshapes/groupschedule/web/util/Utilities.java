/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.util;

import static com.coloredshapes.groupschedule.Constants.SEARCH_PHRASE;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.coloredshapes.groupschedule.domain.entity.Stamp;

/**
 * The Utilities class.
 */
@Component
public class Utilities {
	
	private static ThreadLocal<String> threadLocalUser = new ThreadLocal<String>();
	private static ThreadLocal<String> threadLocalRequestorAuth = new ThreadLocal<String>();
	
	public static void setUser(String user) {
		threadLocalUser.set(user);
	}

	public static String getUser() {
		return threadLocalUser.get();
	}

	public static void setRequestorAuth(String user) {
		threadLocalRequestorAuth.set(user);
	}

	public static String getRequestorAuth() {
		return threadLocalRequestorAuth.get();
	}

	public static String getRequestorAuth(final String email, final String password) {
		String auth = email + '|' + password;
		return auth;
	}

	/**
	 * Gets the reference number from the message.
	 * 
	 * @param message	the message to be processed
	 * @return the reference number from the message
	 */
	public static String getReferenceNumber(String message) {
		String refNum = null;
		int idx = message.indexOf(SEARCH_PHRASE);
		if (idx >= 0) {
			int begin = idx + SEARCH_PHRASE.length();
			int end   = message.indexOf('"', begin);
			refNum = message.substring(begin, end);
		}
		return refNum;
	}


//	/**
//	 * Calculates the delta between two snapshots of the same schedule, or any
//	 * two schedules.
//	 * 
//	 * @param scheduleSnapshotNew
//	 *            the first snapshot of the schedule
//	 * @param scheduleSnapshotOld
//	 *            the second snapshot of the schedule
//	 * @return the delta
//	 */
//	public static Map<String, List<ScheduleeShift>> getDelta(Schedule scheduleSnapshotNew, Schedule scheduleSnapshotOld) {
//		Map<String, List<ScheduleeShift>> delta = new HashMap<String, List<ScheduleeShift>>();
//		
//		ScheduleeShift[] scheduleeShiftsFromSnapshot1 = scheduleSnapshotNew.getScheduleeShifts().toArray(new ScheduleeShift[0]);
//		ScheduleeShift[] scheduleeShiftsFromSnapshot2 = scheduleSnapshotOld.getScheduleeShifts().toArray(new ScheduleeShift[0]);
//		
//		for (int i = 0; i < scheduleeShiftsFromSnapshot1.length; i++) {
//			for (int j = 0; j < scheduleeShiftsFromSnapshot2.length; j++) {
//				if (scheduleeShiftsFromSnapshot1[i].equals(scheduleeShiftsFromSnapshot2[j])) {
//					scheduleeShiftsFromSnapshot1[i] = null;
//					scheduleeShiftsFromSnapshot2[j] = null;
//					break;
//				}
//			}
//		}
//
//		List<ScheduleeShift> addedAssignedScheduleeShifts     = new ArrayList<ScheduleeShift>(scheduleeShiftsFromSnapshot1.length);
//		List<ScheduleeShift> deletedAssignedScheduleeShifts   = new ArrayList<ScheduleeShift>(scheduleeShiftsFromSnapshot2.length);
//		List<ScheduleeShift> addedUnassignedScheduleeShifts   = new LinkedList<ScheduleeShift>(); // Assuming unassigned schedule
//		List<ScheduleeShift> deletedUnassignedScheduleeShifts = new LinkedList<ScheduleeShift>(); // shifts are rare cases
//		
//		delta.put(Constants.ADDED_ASSIGNED_SCHEDULEE_SHIFTS,     addedAssignedScheduleeShifts    );
//		delta.put(Constants.DELETED_ASSIGNED_SCHEDULEE_SHIFTS,   deletedAssignedScheduleeShifts  );
//		delta.put(Constants.ADDED_UNASSIGNED_SCHEDULEE_SHIFTS,   addedUnassignedScheduleeShifts  );
//		delta.put(Constants.DELETED_UNASSIGNED_SCHEDULEE_SHIFTS, deletedUnassignedScheduleeShifts);
//		
//		for (int i = 0; i < scheduleeShiftsFromSnapshot1.length; i++) {
//			if (scheduleeShiftsFromSnapshot1[i] != null) {
//				if (StringUtils.isEmpty(scheduleeShiftsFromSnapshot1[i].getScheduleeKey())) {
//					addedUnassignedScheduleeShifts.add(scheduleeShiftsFromSnapshot1[i]);
//				} else {
//					addedAssignedScheduleeShifts.add(scheduleeShiftsFromSnapshot1[i]);
//				}
//			}
//		}
//		
//		for (int j = 0; j < scheduleeShiftsFromSnapshot2.length; j++) {
//			if (scheduleeShiftsFromSnapshot2[j] != null) {
//				if (StringUtils.isEmpty(scheduleeShiftsFromSnapshot2[j].getScheduleeKey())) {
//					deletedUnassignedScheduleeShifts.add(scheduleeShiftsFromSnapshot2[j]);
//				} else {
//					deletedAssignedScheduleeShifts.add(scheduleeShiftsFromSnapshot2[j]);
//				}
//			}
//		}
//
//		return delta;
//	}
//	
//	/**
//	 * Gets schedulee shift date time for target schedule i.e. calculates and
//	 * returns the date and time of target schedulee shift having the same day
//	 * and time as the original schedulee shift from the source schedule, but in
//	 * the target schedule.
//	 * 
//	 * @param scheduleeShiftDateTime
//	 *            the schedulee shift date time
//	 * @param sourceScheduleDateTime
//	 *            the source schedule date time
//	 * @param targetScheduleDateTime
//	 *            the target schedule date time
//	 * 
//	 * @return the date and time of the target schedulee shift
//	 */
//	public static DateTime getScheduleeShiftDateTimeForTargetSchedule(
//									DateTime scheduleeShiftDateTime, 
//									DateTime sourceScheduleDateTime, 
//									DateTime targetScheduleDateTime) {
//		long scheduleeShiftDateTimeForTargetSchedule =  targetScheduleDateTime.getMillis() 
//				+ (scheduleeShiftDateTime.getMillis() - sourceScheduleDateTime.getMillis());
//		return new DateTime(scheduleeShiftDateTimeForTargetSchedule);
//	}
//
	/**
	 * Creates a stamp for a new record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @return the stamp
	 */
	public static Stamp getCreateStamp(String user) {
		Stamp stamp = new Stamp();
		stamp.setCreateUser(user);
		stamp.setCreateDateTime(DateTime.now());
		return stamp;
	}
	
	/**
	 * Creates a stamp for a new record.
	 * 
	 * @return the stamp
	 */
	public static Stamp getCreateStamp() {
		return getCreateStamp(getUser());
	}
	
	/**
	 * Create a stamp for an existing record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @param lastStamp
	 *            the previous stamp on this record.
	 * @return the stamp
	 */
	public static Stamp getUpdateStamp(String user, Stamp lastStamp) {
		Stamp stamp = new Stamp();
		stamp.setCreateUser(lastStamp.getCreateUser());
		stamp.setCreateDateTime(lastStamp.getCreateDateTime());
		stamp.setUpdateUser(user);
		stamp.setUpdateDateTime(DateTime.now());
		return stamp;
	}

	/**
	 * Create a stamp for an existing record.
	 * 
	 * @param user
	 *            the user performing the operation.
	 * @param lastStamp
	 *            the previous stamp on this record.
	 * @return the stamp
	 */
	public static Stamp getUpdateStamp(Stamp lastStamp) {
		return getUpdateStamp(getUser(), lastStamp);
	}

}