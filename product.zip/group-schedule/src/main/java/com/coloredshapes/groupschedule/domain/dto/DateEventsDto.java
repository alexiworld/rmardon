/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdSerializer;

/**
 * <code>DateEventsDto</code> is a class representing
 * collection of date events.
 * 
 * The class does not subclass <code>BaseTimeBlocks</code>
 * to enable JSON mapping from JSON to this same type.
 */
public class DateEventsDto {
	
	private Long userId;
	private Long groupId;
	private List<DateEventDto> dateEvents;

    /**
     * Creates a events instance.
     */
	public DateEventsDto() {
	}
	
	/**
	 * Sets events
	 * 
	 * @param dateEvents the events to set
	 */
	public void setDateEvents(List<DateEventDto> dateEvents) {
		this.dateEvents = dateEvents;
	}

	/**
	 * Gets the events
	 * 
	 * @return the events
	 */
	@JsonProperty("events")
	public List<DateEventDto> getDateEvents() {
		return dateEvents;
	}

	/**
	 * Sets the user id
	 * 
	 * @param userId the user id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user id
	 * 
	 * @return the user id
	 */
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}


	/**
	 * Sets the group id
	 * 
	 * @param groupId the group id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * Gets the group id
	 * 
	 * @return the group id
	 */
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getGroupId() {
		return groupId;
	}
	
	/**
	 * Checks if the events are owned by a user.
	 * 
	 * @return true if the events are owned by a user, false otherwise
	 */
	@JsonIgnore
	public boolean isUserOwned() {
		return (userId != null);
	}

	/**
	 * Checks if the events are owned by an group.
	 * 
	 * @return true if the events are owned by an group, false otherwise
	 */
	@JsonIgnore
	public boolean isGroupOwned() {
		return (groupId != null);
	}

	/**
	 * Checks if the events are owned by the specified user.
	 * 
	 * @return true if the events are owned by the specified user, false otherwise
	 */
	@JsonIgnore
	public boolean isOwnedByUser(Long userKey) {
		return (this.userId != null && this.userId.equals(userKey));
	}
	
	/**
	 * Checks if the events are owned by the specified group.
	 * 
	 * @return true if the events are owned by the specified group, false otherwise
	 */
	@JsonIgnore
	public boolean isOwnedByGroup(Long groupKey) {
		return (this.groupId != null && this.groupId.equals(groupKey));
	}
	
    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
    	return new ToStringBuilder(this)
	    	.append("userId", userId)
	    	.append("groupId", groupId)
	    	.append("dateEvents", dateEvents)
	    	.toString();
    }

	/** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof DateEventsDto)) return false;

        DateEventsDto dateEvents = (DateEventsDto) that;

        return new EqualsBuilder()
    		.append(userId, dateEvents.userId)
    		.append(groupId, dateEvents.groupId)
    		.append(dateEvents, dateEvents.dateEvents)
    		.isEquals();
    }
    
    /** 
     * Returns the hash code of this object.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
    	return new HashCodeBuilder(17, 37)
	    	.append(userId)
	    	.append(groupId)
	    	.append(dateEvents)
	    	.hashCode();
    }
	
}