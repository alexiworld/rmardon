/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.controller;


import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.coloredshapes.groupschedule.Constants;
import com.coloredshapes.groupschedule.service.remote.RemoteCoreService;

/**
 * <code>ReportController</code> handles login requests.
 */
@Controller
@SessionAttributes("userGroups")
public class ReportController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The remote core service.
	 */
	@Autowired
	private RemoteCoreService remoteCoreService;

	/**
	 * Prepares the data required to show the login page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/reports/userPays", method = RequestMethod.GET)
	public ModelAndView showUserPaysPage(@RequestParam String groupId, HttpSession session) {
		if (logger.isDebugEnabled()) {
			logger.debug("/userPays.html controller reached.");
		}
		
		String auth = (String) session.getAttribute(Constants.REQUESTOR_AUTH);
		String userId = (String) session.getAttribute(Constants.USER_ID);
		Map<Long, String> userGroups = remoteCoreService.getUserGroups(auth, userId);
		
		GroupBean group = new GroupBean();
		group.setGroupId(groupId);
		
		ModelAndView modelAndView = new ModelAndView("reports/userPays");
		ModelMap model = modelAndView.getModelMap();
		model.put("group", group);
		model.put("command", group);
		model.put("userGroups", userGroups);

		return modelAndView;
	}

	/**
	 * Prepares the data required to show the login page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/reports/positionPays", method = RequestMethod.GET)
	public ModelAndView showPositionPaysPage(@RequestParam String groupId, HttpSession session) {
		if (logger.isDebugEnabled()) {
			logger.debug("/positionPays.html controller reached.");
		}
		
		String auth = (String) session.getAttribute(Constants.REQUESTOR_AUTH);
		String userId = (String) session.getAttribute(Constants.USER_ID);
		Map<Long, String> userGroups = remoteCoreService.getUserGroups(auth, userId);
		
		GroupBean group = new GroupBean();
		group.setGroupId(groupId);
		
		ModelAndView modelAndView = new ModelAndView("reports/positionPays");
		ModelMap model = modelAndView.getModelMap();
		model.put("group", group);
		model.put("command", group);
		model.put("userGroups", userGroups);

		return modelAndView;
	}

	/**
	 * Prepares the data required to show reports html page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/reports", method = RequestMethod.GET)
	public String showReportPage() {
		if (logger.isDebugEnabled()) {
			logger.debug("/reports controller reached.");
		}
		
		return "reports";
	}

	/**
	 * Prepares the data required to show reports html page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/reports/{page}", method = RequestMethod.GET)
	public String showReportFormPage(@PathVariable String page) {
		if (logger.isDebugEnabled()) {
			logger.debug("/reports/{page} controller reached.");
		}
		
		return "reports/" + page;
	}
	
	public class GroupBean {
		private String groupId;

		public String getGroupId() {
			return groupId;
		}

		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}
	}

}