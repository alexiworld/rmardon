package com.coloredshapes.groupschedule.service.remote;

import java.util.Map;

import com.coloredshapes.groupschedule.domain.dto.UserCompleteDto;

public interface RemoteCoreService {
	
	public UserCompleteDto authenticate(String user, String password);
	
	public Map<Long, String> getUserGroups(String auth, String user);

}
