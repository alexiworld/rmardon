/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidMembershipStatusException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -1154156497518775569L;
	private static final String errCode = "0010";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
