package com.coloredshapes.groupschedule.web.controller;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
 
@Controller
public class FileUploadController {

	private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);

    private final static String saveDirectory = 
    	System.getProperty("user.home") + "/coloredshapes/group-schedule/photos/"; 
    
    static {
    	File f = new File(saveDirectory);
    	f.mkdir();
    }

    @RequestMapping(value = "/show", method = RequestMethod.GET)
    public String displayForm() {
        return "file_upload_form";
    }
     
    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public String upload(@ModelAttribute("uploadForm") FileUploadForm uploadForm, Model map) 
    throws IllegalStateException, IOException {
		if (logger.isDebugEnabled()) {
			logger.debug("upload form: " + ReflectionToStringBuilder.toString(uploadForm));
		}
         
        List<MultipartFile> files = uploadForm.getFiles();
        List<String> fileNames = new ArrayList<String>();
         
        if(null != files && files.size() > 0) {
            for (MultipartFile multipartFile : files) {
                String fileName = multipartFile.getOriginalFilename();
                if(!"".equalsIgnoreCase(fileName)){
                	fileNames.add(fileName);
                	File localFile = new File(saveDirectory + fileName);
                	multipartFile.transferTo(localFile);   //Here I Added
                }
            }
        }
         
        map.addAttribute("files", fileNames);
        return "file_upload_success";
    }

    public static class FileUploadForm {
    	 
        private List<MultipartFile> files;
        private String imageref;

    	/**
    	 * Gets the files.
    	 * 
    	 * @return the files
    	 */
    	public List<MultipartFile> getFiles() {
    		return files;
    	}

    	/**
    	 * Sets the files.
    	 * 
    	 * @param files 	the files to set
    	 */
    	public void setFiles(List<MultipartFile> files) {
    		this.files = files;
    	}

    	/**
    	 * Gets the image name.
    	 * 
    	 * @return the image name
    	 */
    	public String getImageref() {
    		return imageref;
    	}

    	/**
    	 * Set the image name.
    	 * 
    	 * @param imageref 	the image name to set
    	 */
    	public void setImageref(String imageref) {
    		this.imageref = imageref;
    	}
    	
    	@Override
    	public String toString() {
    		return new ToStringBuilder(this)
				.append("files", (files != null && files.size() > 0))
				.append("imageref", imageref)
				.build();
    	}
    	
    }

}