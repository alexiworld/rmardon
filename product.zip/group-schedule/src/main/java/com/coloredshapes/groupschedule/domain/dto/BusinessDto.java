/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class BusinessDto {

	@NotNull
	private String businessName;
	
	@NotNull
	private String businessNumber;
	
	@NotNull
	private String incorporatedName;
	
	@NotNull
	@Size(min = 0, max = 14)
	@Pattern(regexp="^([a-zA-Z0-9]*)$")
	private String taxNumber;
	
	@NotNull
	private String industry;

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getBusinessNumber() {
		return businessNumber;
	}

	public void setBusinessNumber(String businessNumber) {
		this.businessNumber = businessNumber;
	}

	public String getIncorporatedName() {
		return incorporatedName;
	}

	public void setIncorporatedName(String incorporatedName) {
		this.incorporatedName = incorporatedName;
	}

	public String getTaxNumber() {
		return taxNumber;
	}

	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
}