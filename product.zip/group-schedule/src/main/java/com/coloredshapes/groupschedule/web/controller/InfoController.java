package com.coloredshapes.groupschedule.web.controller;

import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
public class InfoController extends BaseController {

	@Resource(name="infoProperties")
	private Properties infoProperties;
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@RequestMapping(value = "/info", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Properties schedulerInfo() throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("<scheduler info> controller action reached.");
		}

		return infoProperties;
	}
	
}
