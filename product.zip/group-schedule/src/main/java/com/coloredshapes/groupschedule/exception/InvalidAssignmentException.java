/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidAssignmentException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -2800509818150269007L;
	private static final String errCode = "0005";

	private Long assignmentId;

	public InvalidAssignmentException(Long groupId) {
		this.assignmentId = groupId;
	}
	
	public Long getAssignmentId() {
		return assignmentId;
	}

	@Override
	public String getMessage() {
		return "Assignment#" + assignmentId + " does not exist";
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}