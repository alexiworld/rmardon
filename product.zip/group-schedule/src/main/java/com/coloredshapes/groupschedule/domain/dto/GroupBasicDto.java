/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.enums.GroupStatus;


public class GroupBasicDto extends IdDto {


	@NotNull
	@Size(min = 1)
	protected String name;
	
	@NotNull
	@Size(min = 1, max = 8)
	protected String shortName;

	protected String description;

	protected Long imageId;
	
	//@Enumerated(EnumType.STRING)
	protected GroupStatus status;
	
	protected Long parentId;

	
	/**
	 * Gets the group name.
	 * 
	 * @return	the group name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the group name.
	 * 
	 * @param groupName	the group name
	 */
	public void setName(String groupName) {
		this.name = groupName;
	}

	/**
	 * Gets the group short name.
	 * 
	 * @return the group short name
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * Sets the group name.
	 * 
	 * @param shortName	the group short name
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	
	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 * 
	 * @param description	the description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Gets the image identifier.
	 * 
	 * @return the image identifier
	 */
	public Long getImageId() {
		return imageId;
	}

	/**
	 * Sets the image identifier.
	 * 
	 * @param imageId 	the image identifier to set
	 */
	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	/**
	 * Gets the group status.
	 * 
	 * @return	the group status
	 */
	//@JsonIgnore
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public GroupStatus getStatus() {
		return status;
	}

	/**
	 * Sets the group status.
	 * 
	 * @param status	the group status to set
	 */
	//@JsonIgnore
	public void setStatus(GroupStatus status) {
		this.status = status;
	}

	/**
	 * Gets the parent identifier.
	 * 
	 * @return	the parent identifier
	 */
	public Long getParentId() {
		return parentId;
	}

	/**
	 * Sets the parent identifier.
	 * 
	 * @param parentId	the parent identifier to set
	 */
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	
    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("name", name) 
        	.append("shortName", shortName) 
        	.append("description", description) 
        	.append("status", status) 
            .append("parentId", parentId)   
            .toString();
    }

}