/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.security;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * <code>SecurityUtil</code> type is an interface to manage time blocks.
 * 
 * User: developer
 * Date: 30/07/12
 * Time: 12:34 PM
 */
public class SecurityUtil {
	
	private static final int ITERATION_NUMBER = 1000;

	/**
	 * create a hashed password with a randomly generated salt <br>
	 * and set the hashed password and the salt to the member
	 * 
	 * @param member
	 *            . Post condition: member's hashed password and salt are set
	 * @throws NoSuchAlgorithmException
	 */
	public static String[] getHashedPasswordAndSalt(final String password)
			throws NoSuchAlgorithmException {
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		// Salt generation 64 bits long
		byte[] bSalt = new byte[8];
		random.nextBytes(bSalt);
		// Digest computation
		byte[] bDigest = getHash(ITERATION_NUMBER, password, bSalt);
		String hashedPassword = byteToBase64(bDigest);
		String salt = byteToBase64(bSalt);
		return new String[] { hashedPassword, salt };
	}

	/**
	 * 
	 * @param password
	 * @return true if password is strong enough; false otherwise
	 */
	public static boolean isPasswordStrongEnough(final String password) {
		// TODO: add the implemention
		return true;
	}

	public static byte[] getHash(int iterationNb, String password, byte[] salt)
			throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		digest.reset();
		digest.update(salt);
		byte[] input = digest.digest(password.getBytes());
		for (int i = 0; i < iterationNb; i++) {
			digest.reset();
			input = digest.digest(input);
		}
		return input;
	}
	
	public static String encrypt(final String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA");
			md.update(password.getBytes("UTF-8"));
			return byteToBase64(md.digest());
		} catch (Exception e) {
			throw new RuntimeException("Encryption failed.", e);
		}
	}

	/**
	 * From a base 64 representation, returns the corresponding byte[]
	 * 
	 * @param data
	 *            String The base64 representation
	 * @return byte[]
	 * @throws IOException
	 */
	public static byte[] base64ToByte(String data) throws IOException {
		BASE64Decoder decoder = new BASE64Decoder();
		return decoder.decodeBuffer(data);
	}

	/**
	 * From a byte[] returns a base 64 representation
	 * 
	 * @param data
	 *            byte[]
	 * @return String
	 * @throws IOException
	 */
	public static String byteToBase64(byte[] data) {
		BASE64Encoder endecoder = new BASE64Encoder();
		return endecoder.encode(data);
	}

}