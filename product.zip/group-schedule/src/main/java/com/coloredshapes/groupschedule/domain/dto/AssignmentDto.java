/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.enums.AssignmentStatus;

public class AssignmentDto extends IdDto {

	// There might be cases in which groupId is not used and for performance reasons 
	// the field is set to null to exclude group in response to the service consumer.
	private Long userId;

	private Long roleId;
	
	private RoleDto role;
 	
	private Hours hours = new Hours();
	
	private Double rate;
	
	protected AssignmentStatus status;

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Hours getHours() {
		return hours;
	}

	public void setHours(Hours hours) {
		this.hours = hours;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}
	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
    public AssignmentStatus getStatus() {
		return status;
	}

	public void setStatus(AssignmentStatus status) {
		this.status = status;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("userId", userId) 
        	.append("roleId", roleId) 
        	.append("role", role) 
        	.append("hours", hours) 
            .append("rate", rate)   
            .append("status", status)   
            .toString();
    }

}