/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonProperty;
import org.dozer.Mapping;


public class UserProfileDto extends UserBasicDto {

	@NotNull
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String phoneNumber;
	
	@NotNull
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String mobileNumber;
	
	@NotNull
	private String address;
	
	@NotNull
	private String city;
	
	//@NotNull
	//@Pattern(regexp = "^((AB)|(BC)|(MB)|(NB)|(NL)|(NT)|(NS)|(NU)|(ON)|(PE)|(QC)|(SK)|(YT))$")
	//private String province;

	@NotNull
	private String region;

	@NotNull
	private String country;
	
	@NotNull
	@Pattern(regexp = "^(([A-Z]\\d[A-Z]\\s\\d[A-Z]\\d)|(\\d{5}))$")
	private String postalCode;
	
	private String dateTimeZone;

	private UserStatus status;
	
	private String qualification;

	
	@JsonProperty("phone")
	public String getPhoneNumber() {
		return phoneNumber;
	}

	@JsonProperty("phone")
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@JsonProperty("mobile")
	public String getMobileNumber() {
		return mobileNumber;
	}

	@JsonProperty("mobile")
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	//public String getProvince() {
	//	return province;
	//}
	//
	//public void setProvince(String province) {
	//	this.province = province;
	//}
	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the date time zone
	 */
	@JsonProperty("dateTimeZone")
	@Mapping("dateTimeZoneAsID")
	public String getDateTimeZone() {
		return dateTimeZone;
	}

	/**
	 * @param dateTimeZone
	 *            the date time zone to set
	 */
	@JsonProperty("dateTimeZone")
	public void setDateTimeZone(String dateTimeZone) {
		this.dateTimeZone = dateTimeZone;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("phoneNumber", phoneNumber) 
        	.append("mobileNumber", mobileNumber) 
            .append("address", address)   
            .append("city", city)
            //.append("province", province) 
            .append("region", region) 
            .append("country", country) 
        	.append("postalCode", postalCode) 
            .append("dateTimeZone", dateTimeZone)   
            .append("status", status)
        	.append("qualification", qualification) 
            .toString();
    }	
}