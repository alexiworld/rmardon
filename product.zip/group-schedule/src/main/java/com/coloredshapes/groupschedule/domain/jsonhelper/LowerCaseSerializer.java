/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

/**
 * <code>LowerCaseSerializer</code> is a class used to serialize text in lower case.
 */
public class LowerCaseSerializer extends JsonSerializer<String> {

	@Override
	public void serialize(String value, JsonGenerator jgen, SerializerProvider provider) 
	throws IOException, JsonProcessingException {
		if (value == null) {
			jgen.writeString((String) null);
		} else {
			jgen.writeString(value.toLowerCase());
		}
	}

}
