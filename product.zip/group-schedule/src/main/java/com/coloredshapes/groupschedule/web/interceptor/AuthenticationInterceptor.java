package com.coloredshapes.groupschedule.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.coloredshapes.groupschedule.Constants;
import com.coloredshapes.groupschedule.web.util.Utilities;

public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle->handler: " + handler);
		}
		
		String servletPath = request.getServletPath();
		
		if (servletPath != null && (
			servletPath.startsWith("/css/")    || 
			servletPath.startsWith("/images/") || 
			servletPath.startsWith("/scripts/"))) {
			return true;
		}
		
		if (!"/login.html".equals(servletPath) &&
			!"/doLogin.html".equals(servletPath)) {
			HttpSession session = request.getSession();
			if (session.getAttribute(Constants.USER_ID) == null) {
				String contentType = request.getHeader("content-type");
				if (contentType != null && contentType.contains("application/json")) {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					response.flushBuffer();
				} else {
					response.sendRedirect(request.getContextPath() + "/login.html");
				}
				
				return false;
			} else {
				Utilities.setUser((String) session.getAttribute(Constants.USER_ID));
				Utilities.setRequestorAuth((String) session.getAttribute(Constants.REQUESTOR_AUTH));
			}
		}
		
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("postHandle->handler: " + handler);
			logger.debug("postHandle->modelAndView: " + modelAndView);
		}
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		logger.debug("afterCompletion->handler: " + handler);
		logger.debug("afterCompletion->modelAndView: " + ex);
		super.afterCompletion(request, response, handler, ex);
	}
}