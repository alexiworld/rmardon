/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.entity;

import javax.persistence.Embedded;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.groupschedule.domain.jsonhelper.IdSerializer;

/**
 * <code>BaseEntity</code> is parent class of all entities.
 */
@MappedSuperclass
public abstract class BaseEntity {
	
	/**
	 * The serial version UID
	 */
	public static final long serialVersionUID = -4365005313791506749L;

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Version
    private Integer version;

    @JsonIgnore
    public Integer getVersion() {
        return version;
    }
    
    // for audit 
 	@Embedded
 	private Stamp stamp = new Stamp();
 	
    @JsonIgnore
    public void setVersion(Integer version) {
        this.version = version;
    }

    //@JsonIgnore
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getId() {
        return this.id;
    }

    //@JsonIgnore
	@JsonDeserialize(using = IdDeserializer.class)
    public void setId(Long id) {
        this.id = id;
    }

    /**
	 * @return the stamp
	 */
    @JsonIgnore
	public Stamp getStamp() {
		return stamp;
	}

	/**
	 * @param stamp the stamp to set
	 */
    @JsonIgnore
	public void setStamp(Stamp stamp) {
		this.stamp = stamp;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
    		.append("id", id)
            .toString();
    }
    
    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BaseEntity)) return false;

        BaseEntity that = (BaseEntity) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (version != null ? !version.equals(that.version) : that.version != null) return false;

        return true;
    }

    /** 
     * Returns the hash code of this object.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
