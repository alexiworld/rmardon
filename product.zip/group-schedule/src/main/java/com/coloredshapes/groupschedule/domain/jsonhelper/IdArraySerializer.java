/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.jsonhelper;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.coloredshapes.groupschedule.utils.StandardUtils;

/**
 * <code>LongArraySerializer</code> is a class responsible for
 * serialization of Long[] to a JSON array of strings. Default implementation
 * had some problem with rounding the Long numbers and this was causing an issue
 * when these numbers are references to some information (e.g. a number
 * representing date event key.)
 */
public class IdArraySerializer extends JsonSerializer<Long[]> {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Override
	public void serialize(Long[] values, JsonGenerator jgen,
			SerializerProvider provider) throws IOException,
			JsonProcessingException {
		if (logger.isDebugEnabled()) {
			logger.debug("serialize " + Arrays.asList(values));
		}
		jgen.writeStartArray();
		for (Long value : values) {
			if (value == null) {
				jgen.writeString((String) null);
			} else {
				String idStr;
				if (StandardUtils.isTransferEncodedIds()) {
					idStr = StandardUtils.encodeLong(value);
				} else {
					idStr = value.toString();
				}
				jgen.writeString(idStr);
			}
		}
		jgen.writeEndArray();
	}

}