/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class EncryptionException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -2800509818150269007L;
	private static final String errCode = "0005";

	private String message;
	
	public EncryptionException(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}