/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum UserStatus {
    
	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED;

	public static UserStatus fromString(String status) {
		if (status != null) {
			for (UserStatus userStatus : UserStatus.values()) {
				if (status.equalsIgnoreCase(userStatus.name())) {
					return userStatus;
				}
			}
		}
		return null;
	}
    
}
