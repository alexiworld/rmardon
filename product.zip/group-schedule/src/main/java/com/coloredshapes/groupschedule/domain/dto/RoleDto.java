/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.groupschedule.domain.enums.RoleStatus;

public class RoleDto extends IdDto {

	// There might be cases in which groupId is not used and for performance reasons 
	// the field is set to null to exclude group in response to the service consumer.
	@NotNull
	private Long groupId;
	
	@NotNull
	@Size(min = 1)
	private String name;
	
	@NotNull
	@Size(min = 1, max = 8)
	private String shortName;
	
    private String color;
	
    private String description;
	
	private String qualification;

	private String note;

 	private Hours hours = new Hours();

 	private Double rate;

 	private RoleStatus status;
 	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
 	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Hours getHours() {
		return hours;
	}

	public void setHours(Hours hours) {
		this.hours = hours;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}
	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
    public RoleStatus getStatus() {
		return status;
	}

	public void setStatus(RoleStatus status) {
		this.status = status;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("groupId", groupId) 
            .append("name", name) 
            .append("shortName", shortName) 
        	.append("description", description) 
            .append("qualification", qualification)   
         	.append("color", color) 
        	.append("note", note) 
        	.append("hours", hours) 
        	.append("rate", rate) 
        	.append("status", status) 
            .toString();
    }
	
}