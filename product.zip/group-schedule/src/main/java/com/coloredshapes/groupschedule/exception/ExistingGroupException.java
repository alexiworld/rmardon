/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class ExistingGroupException extends CoreServicesException {

	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 645646451L;
	private static final String errCode = "0003";

	private String groupEmail;
	private Long groupId;

	public ExistingGroupException(String groupEmail) {
		this.groupEmail = groupEmail;
	}

	public ExistingGroupException(Long groupId) {
		this.groupId = groupId;
	}
	
	public String getGroupEmail() {
		return groupEmail;
	}

	public Long getGroupId() {
		return groupId;
	}

	@Override
	public String getMessage() {
		if (groupId != null) {
			return "Group#" + groupId + " already exists";
		} else {
			return "Group with email " + groupEmail + " already exists";
		}
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}