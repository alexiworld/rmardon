/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidMembershipConfirmationException extends CoreServicesException {
	
	/**
	 * This class serial version UID 
	 */
	private static final long serialVersionUID = 9061900473140468503L;
	private static final String errCode="0004";
	
	@Override
	public String getErrorCode() {
		return errCode;
	}

}
