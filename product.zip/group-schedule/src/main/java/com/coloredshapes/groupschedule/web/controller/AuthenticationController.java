/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.web.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.coloredshapes.groupschedule.Constants;
import com.coloredshapes.groupschedule.domain.dto.UserCompleteDto;
import com.coloredshapes.groupschedule.service.ImageService;
import com.coloredshapes.groupschedule.service.remote.RemoteCoreService;
import com.coloredshapes.groupschedule.web.util.Utilities;

/**
 * <code>AuthenticationController</code> handles login requests.
 */
@Controller
public class AuthenticationController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The remote core service.
	 */
	@Autowired
	private RemoteCoreService remoteCoreService;

	/**
	 * The image service.
	 */
	@Autowired
	private ImageService imageService;

	/**
	 * Prepares the data required to show the login page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/login.html", method = RequestMethod.GET)
	public String showLoginPage(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("/login.html controller reached.");
		}
		return Constants.LOGIN;
	}

	/**
	 * Prepares the data required to show the login page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/logout.html", method = RequestMethod.GET)
	public String showLoginPageAfterLogout(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("/logout.html controller reached.");
		}
		
		HttpSession session = request.getSession();
		session.removeAttribute(Constants.USER);
		session.removeAttribute(Constants.USER_ID);
		session.removeAttribute(Constants.USER_EMAIL);
		session.removeAttribute(Constants.REQUESTOR_AUTH);

		return Constants.LOGIN;
	}
	
	/**
	 * Prepares the data required to show the login page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/doLogin.html", method = RequestMethod.POST)
	public String showInitialPage(HttpServletRequest request, 
								  @RequestParam String email, 
								  @RequestParam String password) {
		if (logger.isDebugEnabled()) {
			logger.debug("/doLogin.html controller reached.");
			logger.debug("schedulor: " + email);
		}

		// Will be restored once MyOwnGroup app becomes first class web citizen app.
		//password = SecurityUtil.encrypt(password);

		if (logger.isDebugEnabled()) {
			logger.debug("password: " + password);
		}

		UserCompleteDto user = null;
		try {
			user = remoteCoreService.authenticate(email, password);
		} catch (Exception e) {
		}
		
		if (user != null) {
			//ServletContext servletContext = request.getSession().getServletContext();
			String requestorAuth = Utilities.getRequestorAuth(email, password);
			
			HttpSession session = request.getSession();
			session.setAttribute(Constants.USER, user);
			session.setAttribute(Constants.USER_ID, user.getId().toString());
			session.setAttribute(Constants.USER_EMAIL, email);
			session.setAttribute(Constants.REQUESTOR_AUTH, requestorAuth);

			//try {
			//	String storagePath = servletContext.getRealPath("img/logos");
			//	String logoFilePath = imageService.createLogoFile(storagePath, "1");
			//	
			//	String logoWebPath = null;
			//	if (logoFilePath != null) {
			//		int idx = logoFilePath.lastIndexOf(File.separatorChar);
			//		if (idx > 0) {
			//			logoWebPath = request.getContextPath() + "/images/logos/" + logoFilePath.substring(idx + 1); 
			//		}
			//	}
			//	
			//	if (logoWebPath != null) {
			//		session.setAttribute(Constants.LOGO, logoWebPath);
			//	}
			//} catch (Exception e) {
			//	if (logger.isErrorEnabled()) {
			//		logger.error("Failed to prepare the logo due to " + e);
			//	}
			//}
			
			return "redirect:" + Constants.MAIN + ".html";
		} else {
			return Constants.LOGIN;
		}
	}

	/**
	 * Prepares the data required to show the main page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/main.html", method = RequestMethod.GET)
	public String showMainPage(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("/main.html controller reached.");
		}
		return Constants.MAIN;
	}

	/**
	 * Prepares the data required to show the groups page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/groups.html", method = RequestMethod.GET)
	public String showGroupsPage(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("/groups.html controller reached.");
		}
		return "groups";
	}

	/**
	 * Prepares the data required to show html page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/{page}", method = RequestMethod.GET)
	public String showHtmlPage(@PathVariable String page) {
		if (logger.isDebugEnabled()) {
			logger.debug("/{page} controller reached.");
		}
		
		// no need of stripping the extension off
		//int idx = page.lastIndexOf('.');
		//page = page.substring(0, idx);
		return page;
	}

//	/**
//	 * Extracts the top group name from the server name (URL) and sets 
//	 * it as a request attribute, which later will be used for display.
//	 * 
//	 * @param request	the http servlet request
//	 */
//	private void setGroupNameFromServerName(HttpServletRequest request) {
//		String serverName = request.getServerName();
//		if (serverName != null) {
//			int idx = serverName.indexOf('.');
//			if (idx > 0) {
//				String group = serverName.substring(0, idx);
//				request.setAttribute(Constants.GROUP_ID, group);
//			}
//		}
//	}
	
}