/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidRoleException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -2800509818150269007L;
	private static final String errCode = "0005";

	private Long roleId;

	public InvalidRoleException(Long groupId) {
		this.roleId = groupId;
	}
	
	public Long getRoleId() {
		return roleId;
	}

	@Override
	public String getMessage() {
		return "Role#" + roleId + " does not exist";
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}