/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum ContentLimit {
    BASIC,
    PROFILE, //TODO: Replace PROFILE with EXTENDED
    COMPLETE
}
