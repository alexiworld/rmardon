/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidTakeOverRequestStatusException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 1863525804916877616L;
	private static final String errCode = "0012";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
