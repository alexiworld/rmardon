/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.reports;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

/**
 * <code>ReportsProxy</code> is a proxy to core services
 * that acts as a scripted data source for the reports.
 */
public class ReportsProxy {

	/** The Constant for REQUESTOR_AUTH. */
	public static final String REQUESTOR_AUTH = "Requestor-Authentication";
	
	private static RestOperations restOperations = new RestTemplate();
	
	public static String dispatchToTarget(String auth, String path, String body, String params) {
		try {
			System.out.println("[PATH>] " + path);
			System.out.println("[PROXY>]" + body);
			System.out.println("[PARAMS>]" + params);
			
			System.out.println("[PROXY PATH]" + path);
			path = "http://localhost:8080/core-services" + path + '?' + params;
			System.out.println("[TARGET PATH]" + path);
			

			HttpHeaders headers = new HttpHeaders();
			headers.set(REQUESTOR_AUTH, auth);

			HttpEntity<String> data = new HttpEntity<String>(body, headers);
			ResponseEntity<String> response = restOperations.exchange(path, HttpMethod.GET, data, String.class);
			String content = ((response.getBody() != null) ? response.getBody() : ""); 

			System.out.println("[PROXY<]" + content);
			return content;
		} catch (Exception e) {
			// TODO: Investigate on BIRT exception handling techniques. For now, an empty array will
			// be returned to avoid the exception dialogs displayed by BIRT viewer.
			// BEAWARE: Malicious users would be able to obtain the report java script code revealed
			// by BIRT viewer exception dialog. That is a security hole and actions must be taken to
			// prevent leak of confidential information. As a quick win, service exceptions would be 
			// replaced by [], which provides satisfactory solution at the present time. 
			return "[]";
		}
	}

	
	public static void main(String[] args) throws Exception {
		//http://localhost:8080/core-services/users/1/frontgroups?&contentLimit=BASIC&contentStatus=ACTIVE
		dispatchToTarget("rmardon@gmail.com|password", "/users/1/frontgroups", "", "contentLimit=BASIC&contentStatus=ACTIVE");
	}

}