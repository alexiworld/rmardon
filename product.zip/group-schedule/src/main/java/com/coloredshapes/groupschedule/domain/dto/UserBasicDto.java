/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;

import com.coloredshapes.groupschedule.domain.jsonhelper.LowerCaseDeserializer;

public class UserBasicDto extends IdDto {

	@NotNull
	@Size(min = 1)
	private String firstName;
	
	@NotNull
	@Size(min = 1)
	private String lastName;
	
	@NotNull
	@Size(min = 1, max = 8)
	private String shortName;

	protected Long imageId;
	
	@NotNull
	@Size(min = 1, max = 100)
	@Pattern(regexp = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
	private String email;
	
	@Size(min = 3, max = 18)
	private String password;
	
	private boolean isTempPassword;

	/**
	 * Gets the first name.
	 * 
	 * @return	the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 * 
	 * @param firstName		the first name to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 * 
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 * 
	 * @param lastName		the last name to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the short name.
	 * 
	 * @return	the short name
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * Sets the short name.
	 * 
	 * @param shortName		the short name to set
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	/**
	 * Gets the image identifier.
	 * 
	 * @return the image identifier
	 */
	public Long getImageId() {
		return imageId;
	}

	/**
	 * Sets the image identifier.
	 * 
	 * @param imageId 	the image identifier to set
	 */
	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	/**
	 * Gets the email.
	 * 
	 * @return	the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 * 
	 * @param email		the email to set
	 */
	@JsonDeserialize(using = LowerCaseDeserializer.class)
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the password.
	 * 
	 * @return	the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 * 
	 * @param password		the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Is the password is temporary
	 * 
	 * @return	true if password is temporary, false otherwise
	 */
	public boolean isTempPassword() {
		return isTempPassword;
	}

	/**
	 * Sets if password is temporary.
	 * 
	 * @param isTempPassword	if password is temporary to set
	 */
	public void setTempPassword(boolean isTempPassword) {
		this.isTempPassword = isTempPassword;
	}
	
    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("firstName", firstName) 
            .append("lastName", lastName) 
            .append("shortName", shortName) 
            .append("email", email) 
			.append("password", password) 
			.append("isTempPassword", isTempPassword)
            .toString();
    }	

}