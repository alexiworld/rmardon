/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service.stub;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.coloredshapes.groupschedule.service.ScheduleService;

/**
 * <code>ScheduleServiceStub</code> type is the stub implementation
 * of <code>SchedulerService</code> interface to manage schedules, etc.
 */
@Service
public class ScheduleServiceStub implements ScheduleService {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

}