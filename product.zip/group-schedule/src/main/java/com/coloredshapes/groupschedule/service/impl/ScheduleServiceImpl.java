/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.coloredshapes.groupschedule.service.ScheduleService;

/**
 * <code>SchedulerServiceImpl</code> type is the default implementation
 * of <code>SchedulerService</code> interface to manage schedules, etc.
 */
@Service
public class ScheduleServiceImpl implements ScheduleService {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

}