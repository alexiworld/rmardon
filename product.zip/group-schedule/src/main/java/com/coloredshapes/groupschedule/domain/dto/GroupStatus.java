/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

public enum GroupStatus {

	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED;

	public static GroupStatus fromString(String status) {
		if (status != null) {
			for (GroupStatus groupStatus : GroupStatus.values()) {
				if (status.equalsIgnoreCase(groupStatus.name())) {
					return groupStatus;
				}
			}
		}
		return null;
	}

}
