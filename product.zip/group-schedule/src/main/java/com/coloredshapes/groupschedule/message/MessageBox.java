/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.message;

import java.util.LinkedList;
import java.util.List;

/**
 * <code>MessageBox</code> represent a box for keeping
 * the user messages. The specific use of this is when
 * the UM sends a shift assignment request the response
 * will be sent back as a message having the same ref
 * number as the immediate response.
 * 
 * User: developer
 * Date: 15/07/12
 * Time: 13:28 AM
 */
public class MessageBox {
	
	List<String> messages = new LinkedList<String>();

	/**
	 * Read all the messages.
	 * 
	 * @return all the messages from the box
	 */
	public List<String> readMessages() {
		List<String> lastMessages = null;
		synchronized (messages) {
			lastMessages = new LinkedList<String>(messages);
			messages.clear();
		}
		return lastMessages;
	}

	/**
	 * Drops a message to this box.
	 * 
	 * @param message the message to be added
	 */
	public void addMessage(String message) {
		synchronized (messages) {
			messages.add(message);
		}
	}
	
}