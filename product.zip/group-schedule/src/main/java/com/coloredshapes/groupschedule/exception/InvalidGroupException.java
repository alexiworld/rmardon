/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.exception;

public class InvalidGroupException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -2800509818150269007L;
	private static final String errCode = "0005";

	private String groupEmail;
	private Long groupId;

	public InvalidGroupException(String groupEmail) {
		this.groupEmail = groupEmail;
	}

	public InvalidGroupException(Long groupId) {
		this.groupId = groupId;
	}
	
	public String getGroupEmail() {
		return groupEmail;
	}

	public Long getGroupId() {
		return groupId;
	}

	@Override
	public String getMessage() {
		if (groupId != null) {
			return "Group#" + groupId + " does not exist";
		} else {
			return "Group with groupEmail " + groupEmail + " does not exist";
		}
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}