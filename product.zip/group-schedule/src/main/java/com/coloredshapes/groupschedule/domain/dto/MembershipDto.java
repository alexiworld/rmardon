/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.dto;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;

import com.coloredshapes.groupschedule.domain.enums.MembershipStatus;
import com.coloredshapes.groupschedule.domain.jsonhelper.LowerCaseDeserializer;

public class MembershipDto extends IdDto {
	
	/**
	 * This class serial version UID
	 */
	public static final long serialVersionUID = 6545654645L;
	
	private Long groupId;
	
	private Long userId;

	private String userEmail;
	
	private MembershipStatus membershipStatus;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	@JsonIgnore
	public String getUserEmail() {
		return userEmail;
	}

	@JsonDeserialize(using = LowerCaseDeserializer.class)
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public MembershipStatus getMembershipStatus() {
		return membershipStatus;
	}

	public void setMembershipStatus(MembershipStatus membershipStatus) {
		this.membershipStatus = membershipStatus;
	}

}