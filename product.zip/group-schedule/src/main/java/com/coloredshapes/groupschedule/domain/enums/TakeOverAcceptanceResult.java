/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.groupschedule.domain.enums;

public enum TakeOverAcceptanceResult {
	SUCCESS("success"),
	TIME_CONFLICT("time conflict"),
	CANCELLED("cancelled"),
	ALREADY_TAKEN("already taken");
	
	private String value;
	
	TakeOverAcceptanceResult(String value) {
	    this.value = value;
	}
	
	public String value() {
		return this.value;
	}
	
	public String toString(){
	    return this.value;
	}
}
