function getDoubleFromTime(time,partOfDay,startOrEnd) //part of Day =1 if Am and 2 if PM and part Of Day=3; am but startTime was pm
{
	
	if(time.length == 0) {
		return 0.0;
	}
	
	var parts = null;
	var converted=0;
	if(time.indexOf(':')!=-1)
		parts = time.split(":");
	else if(time.indexOf('.')!=-1)
		parts = time.split(".");
	else if(time.indexOf(';')!=-1)
		parts = time.split(";");
	else if(time.indexOf(' ')!=-1)
		parts = time.split(" ");
	else if(time.indexOf(',')!=-1)
		parts = time.split(",");

	if(parts==null)
	{
		if((time.length == 1)||(time.length == 2))
		{
		var temp=time/1;
		
		converted=temp%12;
		}
	}
	else
	{
		if(parts.length == 1)
		{
			var temp2=parts[0]/1;
			
			converted=temp2%12;
		}
		else
		{
		
		var whole = 1;
		var fraction = -60.0;
		
		
			whole = parts[0]/1;
			fraction = parts[1]%60;
		
	
		
		converted= whole+(fraction/60.0);
		
		}
	}
	if(((converted==0)&&(partOfDay==1)&&(startOrEnd=="end"))||((partOfDay==3)&&(startOrEnd=="end")))
	{
		converted+=24;
	}
	if((partOfDay==2))
	{
		converted+=12;
	}
	return converted;
	
}


function insertAt(array, index) {
    var arrayToInsert = Array.prototype.splice.apply(arguments, [2]);
    return insertArrayAt(array, index, arrayToInsert);
}

function insertArrayAt(array, index, arrayToInsert) {
    Array.prototype.splice.apply(array, [index, 0].concat(arrayToInsert));
    return array;
}

// Usage:
//
// if you want to insert specific values whether constants or variables:
// insertAt(arr, 1, "x", "y", "z");
//
// OR if you have an array:
// var arrToInsert = ["x", "y", "z"];
// insertArrayAt(arr, 1, arrToInsert);