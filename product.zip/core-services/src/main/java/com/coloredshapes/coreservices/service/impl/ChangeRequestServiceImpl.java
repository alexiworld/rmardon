/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.QueueService;
import com.coloredshapes.coreservices.service.ChangeRequestService;

@Service
public class ChangeRequestServiceImpl implements ChangeRequestService {
	/**
	 * The message service
	 */
	@Autowired
	private QueueService queueService;
	
	@Autowired
	private UserDao userDao;

	@Override
	public String sendChangeRequest(Long userId, Long[] eventIds) throws InvalidUserException {
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}
		queueService.enqueueEventChangeRequest(eventIds);
		return null;
	}

}
