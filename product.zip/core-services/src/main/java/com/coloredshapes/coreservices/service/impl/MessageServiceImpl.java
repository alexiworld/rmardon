/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.coloredshapes.coreservices.dao.MessageDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.MessageDto;
import com.coloredshapes.coreservices.domain.dto.MessageDtos;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.MembershipRequest;
import com.coloredshapes.coreservices.domain.entity.Message;
import com.coloredshapes.coreservices.domain.entity.MessageContent;
import com.coloredshapes.coreservices.domain.entity.TakeOverEvent;
import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.UserConfirmation;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>MessageService</code> type is the default service 
 * implementation for sending e-mails out.
 */
@Service
public class MessageServiceImpl implements MessageService {

    private static final String NEW_LINE = System.getProperty("line.separator"); 

    /**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private MailSender mailSender;
	
	@Autowired
	private SimpleMailMessage templateMessage;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private MessageDao messageDao;
	
	@Resource(name = "envProperties")
	private Properties envProperties;
	
	private String baseContextPath;
	private String membershipAcceptancePath;
	private String userConfirmationPath;
	private String acceptTakeOverRequestPath;
	private String declineTakeOverRequestPath;

	@Override
	public void sendRegistrationConfirmationRequest(UserConfirmation confirm, User user) {
		if (userConfirmationPath == null) {
			initUserConfirmationPath();
		}
		
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
		msg.setTo(user.getEmail());
		msg.setText("Dear "
			+ user.getFirstName()
			+ " "
			+ user.getLastName()
			+ ", please click this link to confirm your registration with 'My Own Schedule'"
			+ NEW_LINE
			+ userConfirmationPath
			+ "?refNum=" + confirm.getRefNum());
		
		if (logger.isDebugEnabled()) {
			logger.debug("Sending an email: " + msg);
		}
		try {
			this.mailSender.send(msg);
		} catch (MailException ex) {

			if (logger.isErrorEnabled()) {
				logger.error("Failed to send an email due to " + ex);
			}
		}
	}

	@Override
	public void sendTemporaryPassword(User user,String password) {
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
		msg.setTo(user.getEmail());
		msg.setText("Dear "
			+ user.getFirstName()
			+ " "
			+ user.getLastName()
			+ ", please use this temporary password to reset your password with 'My Own Schedule':"
			+ NEW_LINE
			+ password
		);
		if (logger.isDebugEnabled()) {
			logger.debug("Sending an email: " + msg);
		}

		try {
			this.mailSender.send(msg);
		} catch (MailException ex) {
			if (logger.isErrorEnabled()) {
				logger.error("Failed to send an email due to " + ex);
			}
		}
	}

	@Async
	@Override
	public void sendMembershipRequest(MembershipRequest membershipReq, User user, Group group) {
		if (membershipAcceptancePath == null) {
			initMembershipAcceptancePath();
		}
	
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
		msg.setTo(user.getEmail());
		msg.setText("Dear "
			+ user.getFirstName()
			+ " "
			+ user.getLastName()
			+ ", please click this link to confirm your membership with "
			+ group.getName()
			+ NEW_LINE
			+ membershipAcceptancePath
			+ "?userId=" + user.getId() 
			+ "&refNum="  + membershipReq.getReferenceId()
		);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Sending an email: " + msg);
		}

		try {
			this.mailSender.send(msg);
		} catch (MailException ex) {
			if (logger.isErrorEnabled()) {
				logger.error("Failed to send an email due to " + ex);
			}
		}
	}

    @Override
	public void sendTakeOverRequest(TakeOverRequest takeOverRequest){
		if (acceptTakeOverRequestPath == null || declineTakeOverRequestPath == null) {
			initTakeOverRequestPaths();
		}

		final String formatter = "EEE, d MMM yyyy HH:mm:ss";
		List<TakeOverEvent> takeOverEvents = takeOverRequest.getTakeOverEvents();
		for (TakeOverEvent takeOverEvent : takeOverEvents) {
			SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
			User user = takeOverEvent.getUser();
			final String pathParameters = "?refNum="
					+ takeOverRequest.getId() 
					+ "&userId="
					+ user.getId();
			msg.setTo(takeOverEvent.getUser().getEmail());
			msg.setText("Dear "
				+ user.getFirstName()
				+ " "
				+ user.getLastName()
				+ ", you have a take over request from "
				+ takeOverRequest.getGroup().getName()
				+ " starting at "
				+ takeOverEvent.getStartTime().withZone(DateTimeZone.forID(user.getDateTimeZoneAsID())).toString(formatter)
				+ " to "
				+ takeOverEvent.getEndTime().withZone(DateTimeZone.forID(user.getDateTimeZoneAsID())).toString(formatter)
				+ NEW_LINE
				+ "Please remove the conflicting event you have and click the following link to accept the request"
				+ NEW_LINE
				+ acceptTakeOverRequestPath
				+ pathParameters
				+ NEW_LINE
				+ "To decline the request,please chick the following link"
				+ NEW_LINE
				+ declineTakeOverRequestPath
				+ pathParameters
			);
			
			if (logger.isDebugEnabled()) {
				logger.debug("Sending an email: " + msg);
			}
			
			try {
				this.mailSender.send(msg);
			} catch (MailException ex) {
				if (logger.isErrorEnabled()) {
					logger.error("Failed to send an email due to " + ex);
				}
			}
		}
	}


	@Override
	public void sendTakeOverCancellation(TakeOverRequest tor) {
		final String formatter = "EEE, d MMM yyyy HH:mm:ss";
		List<TakeOverEvent> takeOverEvents = tor.getTakeOverEvents();
		for (TakeOverEvent takeOverEvent : takeOverEvents) {
			SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
			User user=takeOverEvent.getUser();
			msg.setTo(takeOverEvent.getUser().getEmail());
			msg.setText("Dear "
				+ user.getFirstName()
				+ " "
				+ user.getLastName()
				+ ", your take over request from "
				+ tor.getGroup().getName()
				+ " starting at "
				+ takeOverEvent.getStartTime().withZone(DateTimeZone.forID(user.getDateTimeZoneAsID())).toString(formatter)
				+ " to "
				+ takeOverEvent.getEndTime().withZone(DateTimeZone.forID(user.getDateTimeZoneAsID())).toString(formatter)
				+ " has been cancelled, you can no longer accept it."
			);
			
			if (logger.isDebugEnabled()) {
				logger.debug("Sending an email: " + msg);
			}
			
			try {
				this.mailSender.send(msg);
			} catch (MailException ex) {

				if (logger.isErrorEnabled()) {
					logger.error("Failed to send an email due to " + ex);
				}
			}
		}
	}

	/**
	 * Sends out email for recently assigned events from group to users 
	 * for the specified time period.
	 * 
	 * @param group		the group
	 * @param users	the users to be notified
	 * @param timePeriod	the time period
	 */
	@Override
	public void sendCollectiveMessage(Group group, List<User> users, TimePeriodDto timePeriod) {
		for (User user : users) {
			SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
			msg.setTo(user.getEmail());
			msg.setSubject("Event assignments");
			msg.setText("Dear "
				+ user.getFirstName()
				+ " "
				+ user.getLastName()
				+ ","
				+ NEW_LINE
				+ group.getName()
				+ " has assigned you event(s) for the period from " 
				+ timePeriod.getStartTime().toString("dd.MM.yyyy HH:mm")
				+ " to "
				+ timePeriod.getEndTime().toString("dd.MM.yyyy HH:mm")
				+ "."
				+ NEW_LINE);

			try {
				if (logger.isDebugEnabled()) {
					logger.debug("Sending an email: " + msg);
				}
				this.mailSender.send(msg);
			} catch (MailException ex) {
				if (logger.isErrorEnabled()) {
					logger.error("Failed to send an email due to " + ex);
				}
			}
		}
	}

	@Async
	private void sendMessages(List<Message> messages) {
		for (Message message : messages) {
			MessageContent content = message.getContent();
			User recipient = message.getRecipient();

			SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
			msg.setTo(recipient.getEmail());
			msg.setSubject(content.getSubject());
			msg.setText(content.getBody());

			try {
				if (logger.isDebugEnabled()) {
					logger.debug("Sending email: " + msg);
				}
				this.mailSender.send(msg);
			} catch (MailException ex) {
				if (logger.isErrorEnabled()) {
					logger.error("Failed to send email due to " + ex);
				}

				try {
					Thread.sleep(1000);
					if (logger.isDebugEnabled()) {
						logger.debug("Sending an email: " + msg);
					}
					this.mailSender.send(msg);

					if (logger.isDebugEnabled()) {
						logger.debug("Retry successful");
					}
				} catch (MailException mex) {
					if (logger.isErrorEnabled()) {
						logger.error("Failed to resend email due to " + mex);
					}
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	/**
	 * Sends message(s).
	 * 
	 * @param messageDto	the message DTO (may contain sender, recipients, channel, etc.)
	 * @return map with user Ids as keys and message newly created Ids as values
	 */
	@Override
	@Transactional
	public Map<Long, Long> sendMessage(MessageDto messageDto) {
		String body = messageDto.getBody();
		List<String> vars = StandardUtils.parseVariableNames(body);

		Map<Long, Long> result = new HashMap<Long, Long>();
		List<Message> messages = new LinkedList<Message>();

		List<Long> recipientIds;
		if (messageDto.getRecipient() != null) {
			recipientIds = new LinkedList<Long>();
			recipientIds.add(messageDto.getRecipient());
		} else {
			recipientIds = messageDto.getRecipients();
		}
			
		if (CollectionUtils.isEmpty(vars)) {
			MessageContent content = new MessageContent();
			content.setSubject(messageDto.getSubject());
			content.setBody(body);
			content.setTime(messageDto.getTime());
			content.setChannel(messageDto.getChannel());
			
			Long senderId = messageDto.getSender();
			User sender = userDao.getUser(senderId);
			
			if (recipientIds != null) {
				for (Long recipientId : recipientIds) {
					User recipient = userDao.getUser(recipientId);
					
					Message message = new Message();
					message.setContent(content);
					message.setSender(sender);
					message.setRecipient(recipient);
					messageDao.create(message);
					
					result.put(recipientId, message.getId());
					messages.add(message);
				}
			}
		} else {
			Long senderId = messageDto.getSender();
			User sender = userDao.getUser(senderId);
			
			if (recipientIds != null) {
				for (Long recipientId : recipientIds) {
					User recipient = userDao.getUser(recipientId);

					for (String var : vars) {
						String key = var;
						String value = "";
						switch (var) {
							case "recipient" : {
								value = recipient.getFirstName() + " " + recipient.getLastName(); 
								break;
							}
							case "recipientFirstName" : {
								value = recipient.getFirstName(); 
								break;
							}
							case "recipientLastName" : {
								value = recipient.getFirstName(); 
								break;
							}
							case "recipientId" : {
								value = "" + recipientId; 
								break;
							}
							case "sender" : {
								value = sender.getFirstName() + " " + sender.getLastName(); 
								break;
							}
							case "senderFirstName" : {
								value = sender.getFirstName(); 
								break;
							}
							case "senderLastName" : {
								value = sender.getLastName(); 
								break;
							}
							case "senderId" : {
								value = "" + senderId; 
								break;
							}
						}
						body = StandardUtils.replaceVariable(key, value, body);
					}
					
					MessageContent content = new MessageContent();
					content.setSubject(messageDto.getSubject());
					content.setBody(body);
					content.setTime(messageDto.getTime());
					content.setChannel(messageDto.getChannel());

					Message message = new Message();
					message.setContent(content);
					message.setSender(sender);
					message.setRecipient(recipient);
					messageDao.create(message);
					
					result.put(recipientId, message.getId());
					messages.add(message);
				}
			}
		}
		
		
		sendMessages(messages);
		return result;
	}
	
	/**
	 * Get user messages.
	 *  
	 * @param userId	the user id
	 * @return	the messages
	 */
	@Override
	@Transactional(readOnly=true)
	public MessageDtos readMessages(Long userId) {
		Validate.notNull(userId,"User id is missing");
		Map<Long, String> users = new HashMap<Long, String>();
		
		List<Message> messages = messageDao.getMessages(userId);
		List<MessageDto> messageDtos = new ArrayList<MessageDto>(messages.size());
		for (Message message : messages) {
			MessageContent content = message.getContent();

			User sender = message.getSender();
			User recipient = message.getRecipient();
			
			users.put(sender.getId(), sender.getFirstName() + " " + sender.getLastName());
			users.put(recipient.getId(), recipient.getFirstName() + " " + recipient.getLastName());

			MessageDto messageDto = new MessageDto();
			messageDto.setId(message.getId());
			messageDto.setSubject(content.getSubject());
			messageDto.setBody(content.getBody());
			messageDto.setTime(content.getTime());
			messageDto.setChannel(content.getChannel());
			messageDto.setSender(sender.getId());
			messageDto.setRecipient(recipient.getId());
			messageDto.setOpened(message.isOpened());
			
			messageDtos.add(messageDto);
		}
		
		MessageDtos result = new MessageDtos();
		result.setMessages(messageDtos);
		result.setUsers(users);
		
		return result;
	}
	
	/**
	 * Deletes user message.
	 * 
	 * @param userId		the user id
	 * @param messageId		the message id
	 */
	@Override
	@Transactional
	public void deleteMessage(Long userId, Long messageId) {
		Message message = messageDao.find(messageId);
		if (message.getSender().getId() == userId) {
			message.setVisibleToSender(false);
		} else if (message.getRecipient().getId() == userId) {
			message.setVisibleToRecipient(false);
		}
	}
	
	/**
	 * Deletes user messages.
	 * 
	 * @param userId		the user id
	 * @param messageIds	the message ids
	 */
	@Override
	@Transactional
	public void deleteMessages(Long userId, List<Long> messageIds) {
		for (Long messageId : messageIds) {
			deleteMessage(userId, messageId);
		}
	}

	
	/**
	 * Deletes all user messages.
	 * 
	 * @param userId		the user id
	 */
	@Override
	@Transactional
	public void deleteMessages(Long userId) {
		List<Message> messages = messageDao.getMessages(userId);
		for (Message message : messages) {
			if (message.getSender().getId() == userId) {
				message.setVisibleToSender(false);
			} else if (message.getRecipient().getId() == userId) {
				message.setVisibleToRecipient(false);
			}
		}
	}
	
	/**
	 * Deletes messages between the user and somebody else.
	 * 
	 * Please note that other user will still be able to
	 * see the messages.
	 * 
	 * @param userId		the user id
	 * @param fromtoUserId	the other user id
	 */
	@Override
	@Transactional
	public void deleteMessagesFromTo(Long userId, Long fromtoUserId) {
		List<Message> messages = messageDao.getMessagesBetween(userId, fromtoUserId);
		for (Message message : messages) {
			if (message.getSender().getId() == userId) {
				message.setVisibleToSender(false);
			}
			if (message.getRecipient().getId() == userId) {
				message.setVisibleToRecipient(false);
			}
		}
	}


	
	/**
	 * initialize the URL path for confirming user registration
	 */
    private void initUserConfirmationPath() {
    	userConfirmationPath = getContextPath() + envProperties.getProperty("userConfirmationPath");
    }
	
	/**
	 * initialize the URL path for confirming membership request
	 */
	private void initMembershipAcceptancePath() {
		membershipAcceptancePath = getContextPath() + envProperties.getProperty("membershipAcceptancePath");
	}
	
	/**
	 * initialize the URL path for accepting TakeOverRequest
	 */
	private void initTakeOverRequestPaths() {
		acceptTakeOverRequestPath  = getContextPath() + envProperties.getProperty("acceptTakeOverRequestPath");
		declineTakeOverRequestPath = getContextPath() + envProperties.getProperty("declineTakeOverRequestPath");
	}

	/**
	 * initialize the context path used as a base for all URL paths
	 */
	private String getContextPath() {
		if (baseContextPath == null) {
			baseContextPath = envProperties.getProperty("protocol") + "://"
				+ envProperties.getProperty("hostName")    + ":"
				+ envProperties.getProperty("port")        + "/"
				+ envProperties.getProperty("contextName") + "/";
		}
		return baseContextPath;
	}

}