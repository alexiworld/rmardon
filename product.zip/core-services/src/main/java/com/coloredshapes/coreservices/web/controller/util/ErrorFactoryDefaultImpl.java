/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller.util;

import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.coloredshapes.coreservices.exception.CoreServicesException;
import com.coloredshapes.coreservices.web.dto.ErrorResp;

/**
 * <code>ErrorFactoryDefaultImpl</code> is default implementation 
 * of factory creating error DTOs<br>
 * It read error message by error code from property file
 * 
 */
@Service
public class ErrorFactoryDefaultImpl implements ErrorFactory {

	@Resource(name = "errProperties")
	private Properties errProperties;

	@Override
	public ErrorResp creatError(Exception ex) {
		ErrorResp err = new ErrorResp();
		if (ex instanceof CoreServicesException) {
			CoreServicesException e = (CoreServicesException) ex;
			err.setErrCode(e.getErrorCode());
			err.setMessage(errProperties.getProperty(e.getErrorCode()));
		} else if (ex instanceof MethodArgumentNotValidException) {
			MethodArgumentNotValidException e = (MethodArgumentNotValidException) ex;
			List<ObjectError> allErrors = e.getBindingResult().getAllErrors();
			String msg = "";
			for (ObjectError validErr : allErrors) {
				if (msg.length() != 0) {
					msg = msg + ";";
				}
				msg = msg + validErr.getDefaultMessage();
				err.setErrCode("1000");
				err.setMessage(msg);
			}
		} else if (ex instanceof ConstraintViolationException) {
			ConstraintViolationException e = (ConstraintViolationException) ex;
			Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
			String msg = "";
			for (ConstraintViolation<?> constraintViolation : constraintViolations) {
				if (msg.length() != 0) {
					msg = msg + ",";
				}
				msg = msg + constraintViolation.getPropertyPath();
				err.setErrCode("1000");
				err.setMessage("invalid " + msg);
			}
		} else {
			err.setErrCode("9999");
			err.setMessage(errProperties.getProperty("9999"));
		}
		return err;
	}

}
