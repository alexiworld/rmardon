/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.MessageDto;
import com.coloredshapes.coreservices.domain.dto.MessageDtos;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.service.UserService;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>MessageController</code> handles message requests to REST services. The supported operations are 
 * sending, retrieving and deletion of messages, etc.
 */
@Controller
public class MessageController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The message service.
	 */
	@Autowired
	private MessageService messageService;

	/**
	 * The user service.
	 */
	@Autowired
	private UserService userService;

	/**
	 * REST service for persisting events
	 * 
	 * @param events
	 *            events to be stored
	 * @param userId
	 *            the user adding the events
	 * @return events not stored
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<Long, Long> sendMessage(@RequestBody MessageDto messageDto)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("messageDto: " + messageDto);
		}

		Map<Long, Long> outcome = messageService.sendMessage(messageDto);
		return outcome;
	}

	
	/**
	 * REST service for reading user messages. The user Id is not
	 * specified because it is retrieved from the header.
	 * 
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public MessageDtos getMessages()
	throws Exception {
		Long userId    = Long.valueOf(StandardUtils.getUser());
		MessageDtos messageDtos = messageService.readMessages(userId);
		return messageDtos;
	}
	
	/**
	 * REST service for deleting message. The user Id is not
	 * specified because it is retrieved from the header.
	 * 
	 * @param messageId		the message's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages/fromto/{userId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void deleteMessagesFromTo(@PathVariable("userId") String fromtoUserIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("from/to user id: " + fromtoUserIdCode);
		}

		Long userId = Long.valueOf(StandardUtils.getUser());
		Long fromtoUserId = StandardUtils.decodeLong(fromtoUserIdCode);
		messageService.deleteMessagesFromTo(userId, fromtoUserId);
	}
	
	/**
	 * REST service for deleting message. The user Id is not
	 * specified because it is retrieved from the header.
	 * 
	 * @param messageId		the message's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages/{messageId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void deleteMessage(@PathVariable("messageId") String messageIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("message id: " + messageIdCode);
		}

		Long userId    = Long.valueOf(StandardUtils.getUser());
		Long messageId = StandardUtils.decodeLong(messageIdCode);
		messageService.deleteMessage(userId, messageId);
	}

	/**
	 * REST service for deleting messages. The user Id is not
	 * specified because it is retrieved from the header.
	 * 
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void deleteMessages(@RequestBody String[] messageIdCodes)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("message ids: " + Arrays.asList(messageIdCodes));
		}

		Long userId = Long.valueOf(StandardUtils.getUser());
		if (messageIdCodes.length == 0) {
			messageService.deleteMessages(userId);
		} else {
			Long[] messageIds = StandardUtils.decodeLongs(messageIdCodes);
			messageService.deleteMessages(userId, Arrays.asList(messageIds));
		}
	}

	/**
	 * REST service for deleting message. The user Id is not
	 * specified because it is retrieved from the header.
	 * 
	 * @param messageId		the message's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/messages/users/{namePrefix}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<Long, String> getUsers(@PathVariable("namePrefix") String namePrefix)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("user name prefix: " + namePrefix);
		}

		Map<Long, String> result = userService.getCoUsersByNamePrefix(namePrefix);
		
		/*
		Map<Long, String> users = new LinkedHashMap<Long, String>();
		users.put(1L, "Richard Mardon");
		users.put(2L, "Jeff Smith");
		users.put(4L, "Albert Young");
		users.put(5L, "Samantha Wong");
		
		Map<Long, String> result = new LinkedHashMap<Long, String>();
		for (Map.Entry<Long, String> entry : users.entrySet()) {
			if (entry.getValue().toUpperCase().startsWith(namePrefix.toUpperCase())) {
				result.put(entry.getKey(), entry.getValue());
			}
		}
		*/

		return result;
	}
	
}