/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.domain.entity.UserAgreement;

public interface UserAgreementService {

	public UserAgreement getLastestAgreement();
	
	public boolean isLatestAgreementAccepted(Long userId);
	
	public void acceptLatestAgreement(Long userId);

}
