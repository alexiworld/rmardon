/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.MessageDao;
import com.coloredshapes.coreservices.domain.entity.Message;
import com.coloredshapes.coreservices.domain.entity.Message_;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.User_;

@Repository
public class MessageDaoImpl extends BaseJpaImpl<Message> implements MessageDao {

	@Override
	public void saveMessage(Message message) {
		super.create(message);
	}

	@Override
	public List<Message> getMessages(Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Message> criteria = criteriaBuilder.createQuery(Message.class);
		
		Root<Message> messageRoot = criteria.from(Message.class);
		Join<Message, User> messageSender    = messageRoot.join(Message_.sender);
		Join<Message, User> messageRecipient = messageRoot.join(Message_.recipient);

		Predicate senderPredicate = criteriaBuilder.equal(messageSender.get(User_.id), userId);
		Predicate visibleToSenderPredicate = criteriaBuilder.isTrue(messageRoot.get(Message_.visibleToSender));
		Predicate recipientPredicate = criteriaBuilder.equal(messageRecipient.get(User_.id), userId);
		Predicate visibleToRecipientPredicate = criteriaBuilder.isTrue(messageRoot.get(Message_.visibleToRecipient));
		
		Predicate predicate = criteriaBuilder.or(
				criteriaBuilder.and(senderPredicate, visibleToSenderPredicate),
				criteriaBuilder.and(recipientPredicate, visibleToRecipientPredicate));
		
		criteria.select(messageRoot);
		criteria.where(predicate);
		
		List<Message> messages = entityManager.createQuery(criteria).getResultList();
		return messages;
	}

	@Override
	public List<Message> getMessagesBetween(Long user1Id, Long user2Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Message> criteria = criteriaBuilder.createQuery(Message.class);
		
		Root<Message> messageRoot = criteria.from(Message.class);
		Join<Message, User> messageSender    = messageRoot.join(Message_.sender);
		Join<Message, User> messageRecipient = messageRoot.join(Message_.recipient);
		
		List<Long> users = new LinkedList<Long>();
		users.add(user1Id);
		users.add(user2Id);

		Predicate senderPredicate = messageSender.get(User_.id).in(users);
		Predicate visibleToSenderPredicate = criteriaBuilder.isTrue(messageRoot.get(Message_.visibleToSender));
		Predicate recipientPredicate = messageRecipient.get(User_.id).in(users);
		Predicate visibleToRecipientPredicate = criteriaBuilder.isTrue(messageRoot.get(Message_.visibleToRecipient));
		
		Predicate predicate = criteriaBuilder.and(
				criteriaBuilder.and(senderPredicate, visibleToSenderPredicate),
				criteriaBuilder.and(recipientPredicate, visibleToRecipientPredicate));
		
		criteria.select(messageRoot);
		criteria.where(predicate);
		
		List<Message> messages = entityManager.createQuery(criteria).getResultList();
		return messages;
	}
	
	@Override
	public int deleteMessage(Long userId, List<Long> messageIds) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMessages(Long userId, List<Long> messageIds) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMessages(Long userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	/*
	@Override
	public List<Message> getMessagesByUserId(Long userId) {
		TypedQuery<Message> query = entityManager.createQuery(
		        "SELECT message FROM Message message WHERE message.user.id = :userId", Message.class);
	    query.setParameter("userId", userId); 

	    List<Message> resultList = query.getResultList();

		return resultList;
	}

	@Override
	public int deleteMessagesForUser(Long userId) {
		Query query = entityManager.createQuery(
							"DELETE FROM Message m WHERE m.user.id =  :userId");
		int deletedCount = query.setParameter("userId", userId).executeUpdate();
		return deletedCount;
	}
	*/

}
