/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.report.dto.RolePayDto;
import com.coloredshapes.coreservices.report.dto.UserPayDto;
import com.coloredshapes.coreservices.service.ReportService;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>ReportController</code> acts as data source for reports engine.
 */
@Controller
public class ReportController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The report service.
	 */
	@Autowired
	private ReportService reportService;

	/**
	 * REST service for retrieving user pays
	 * 
	 * @param groupId
	 *            the group id requesting the report
	 * @param startTime
	 *            the start time
	 * @param endTime
	 *            the end time
	 * @return list of user pays
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/report/userPays/{groupId}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<UserPayDto> getUserPays(@PathVariable("groupId") String groupIdCode, 
										@RequestParam Long startTime, 
										@RequestParam Long endTime)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("groupId: " + groupIdCode);
			logger.debug("startTime: " + startTime);
			logger.debug("endTime: " + endTime);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		TimePeriodDto timePeriod = new TimePeriodDto(startTime, endTime);

		List<UserPayDto> userPays = reportService.getUserPays(groupId, timePeriod);
		
		if (logger.isDebugEnabled()) {
			logger.debug("userPays: " + userPays);
		}

		return userPays;
	}

	/**
	 * REST service for retrieving role pays
	 * 
	 * @param groupId
	 *            the group id requesting the report
	 * @param startTime
	 *            the start time
	 * @param endTime
	 *            the end time
	 * @return list of role pays
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/report/rolePays/{groupId}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<RolePayDto> getRolePays(@PathVariable("groupId") String groupIdCode, 
										@RequestParam Long startTime, 
										@RequestParam Long endTime)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("groupId: " + groupIdCode);
			logger.debug("startTime: " + startTime);
			logger.debug("endTime: " + endTime);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		TimePeriodDto timePeriod = new TimePeriodDto(startTime, endTime);

		List<RolePayDto> rolePays = reportService.getRolePays(groupId, timePeriod);
		
		if (logger.isDebugEnabled()) {
			logger.debug("rolePays: " + rolePays);
		}

		return rolePays;
	}

}