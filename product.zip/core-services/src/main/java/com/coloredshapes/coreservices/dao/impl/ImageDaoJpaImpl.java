/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.ImageDao;
import com.coloredshapes.coreservices.domain.entity.Image;
import com.coloredshapes.coreservices.domain.entity.Image_;

@Repository
public class ImageDaoJpaImpl  extends BaseJpaImpl<Image> implements ImageDao {

	public Image getImage(String file) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Image> criteria = criteriaBuilder.createQuery(Image.class);
		Root<Image> imageRoot = criteria.from( Image.class );
		criteria.select( imageRoot );
		criteria.where( criteriaBuilder.equal( imageRoot.get(Image_.file), file) );
		criteria.orderBy(criteriaBuilder.desc(imageRoot.get(Image_.id)));
		
		List<Image> resultList = entityManager.createQuery(criteria).setMaxResults(1).getResultList();
		if (resultList.size() < 1) {
			return null;
		} else {
			return resultList.get(0);
		}
	}

}