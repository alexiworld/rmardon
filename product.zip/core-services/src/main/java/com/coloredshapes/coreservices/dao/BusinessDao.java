/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.Business;

public interface BusinessDao extends GenericDao<Business> {
	
	void createBusiness(Business business);
	
	Business getBusinessByGroupId(Long groupId);
	
	void deleteBusinessByGroupId(Long groupId);

}
