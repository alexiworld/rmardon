/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.TakeOverEvent;

public interface TakeOverEventDao extends GenericDao<TakeOverEvent> {

	public TakeOverEvent getTakeOverEvent(Long torId, Long userId);

}
