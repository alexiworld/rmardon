/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.utils;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class RandomUtils {

	private static SecureRandom sRandom;

	public static long getRandomNum() {
		if (sRandom == null) {
			try {
				sRandom = SecureRandom.getInstance("SHA1PRNG");
			} catch (NoSuchAlgorithmException e) {

				e.printStackTrace();
			}
		}

		return sRandom.nextLong();
	}
}
