/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.interceptor;

import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.coloredshapes.coreservices.service.SecurityService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Component
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());
	
	@Autowired
	private SecurityService securityService;

	@Resource(name = "envProperties")
	private Properties envProperties;

	private boolean isReportURI(HttpServletRequest request) {
		return (request.getRequestURI().indexOf("/report/") >= 0);
	}
	
	private Long extractReportGroupId(HttpServletRequest request) {
		String requestURI = request.getRequestURI();
		int pos = requestURI.lastIndexOf('/');
		String groupIdCode = requestURI.substring(pos+1);
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		return groupId;
	}
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle->URI: " + request.getRequestURI());
			logger.debug("preHandle->handler: " + handler);
		}
		
		if (isReportURI(request)) {
			String user = StandardUtils.getUser();
			Long userId = Long.valueOf(user);
			Long groupId = extractReportGroupId(request);
			securityService.authorized(userId, groupId);
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle->Authorization succeeded");
		}

		return true;
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("postHandle->handler: " + handler);
			logger.debug("postHandle->modelAndView: " + modelAndView);
		}
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		logger.debug("afterCompletion->handler: " + handler);
		logger.debug("afterCompletion->ex: " + ex);
		super.afterCompletion(request, response, handler, ex);
	}
	
}