/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

@Entity
@Table(name = "user_confirmation")
public class UserConfirmation extends BaseEntity {
	
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "reference_number")
	private String refNum;

	@Column(name = "registration_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime registrationTime;

	@Column(name = "confirmation_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime confirmationTime;

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	public DateTime getRegistrationTime() {
		return registrationTime;
	}

	public void setRegistrationTime(DateTime registrationTime) {
		this.registrationTime = registrationTime;
	}

	public DateTime getConfirmationTime() {
		return confirmationTime;
	}

	public void setConfirmationTime(DateTime confirmTime) {
		this.confirmationTime = confirmTime;
	}

    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("userId", userId) 
            .append("refNum", refNum) 
        	.append("registrationTime", registrationTime) 
            .append("confirmationTime", confirmationTime) 
            .toString();
    }	

}