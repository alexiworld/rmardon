/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.utils;

import static com.coloredshapes.coreservices.utils.RandomUtils.getRandomNum;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalTime;

import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.SourceType;

/**
 * <code>EventUtils</code> type is an utility 
 * class proving helper methods.
 */
public class EventUtils {
	
	/**
	 * The logger for this class
	 */
	protected final static Log logger = LogFactory.getLog(EventUtils.class);

	/**
	 * Determines if two date events can be compacted. The first date event must 
	 * start before or at the same time as the second event for a valid use of this 
	 * operation. With this assumption is mind two date events can be compacted if the 
	 * first ends prior or at the same time as the second one starts.
	 * 
	 * @param dateEvent1	the first date event
	 * @param dateEvent2	the second date event
	 * @return	true if both date events can be compacted; false otherwise.  
	 */
	public static boolean canBeCompacted(DateEventDto dateEvent1, DateEventDto dateEvent2) {
		return dateEvent1.getEndTime().getMillis() >= dateEvent2.getStartTime().getMillis();
	}

	/**
	 * Compact the user scheduled overlapping date events.
	 * 
	 * @param dateEvents	the date events instance
	 */
	public static void compactDateEvents(DateEventsDto dateEvents) {
		if (dateEvents != null) {
			compactDateEvents(dateEvents.getDateEvents());
		}
	}

	/**
	 * Compact the user scheduled overlapping date events.
	 * 
	 * @param dateEvents	the date events instance
	 */
	public static void compactDateEvents(List<DateEventDto> dateEvents) {
		if (CollectionUtils.isNotEmpty(dateEvents)) {
			// Sort date events in ascending order, see the comparator for more details.  
			Collections.sort(dateEvents, new DateEventComparator());
			if (logger.isDebugEnabled()) {
				logger.debug("Sorted date events: " + dateEvents);
			}
			
			// Compact overlapping date events
			DateEventDto prevDateEvent = null;
			Iterator<DateEventDto> iterator = dateEvents.iterator(); 
			while (iterator.hasNext()) {
				DateEventDto nextDateEvent = iterator.next();
				if (nextDateEvent.isUserOwned()) {
					if (prevDateEvent != null) {
						if (logger.isDebugEnabled()) {
							logger.debug("Try to compact: " + prevDateEvent);
							logger.debug("With: "    + nextDateEvent);
						}
						
						if (EventUtils.canBeCompacted(prevDateEvent, nextDateEvent)) {
							if (logger.isDebugEnabled()) {
								logger.debug("Compact: " + prevDateEvent);
								logger.debug("With: "    + nextDateEvent);
							}
							
							prevDateEvent.setEndTime(new DateTime(
								Math.max(
									prevDateEvent.getEndTime().getMillis(), 
									nextDateEvent.getEndTime().getMillis()
							)));
							iterator.remove();
							continue;
						}
					}
					prevDateEvent = nextDateEvent;
				}
			}
		}
	}
	
	/**
	 * Builds a event entity from date event, group, and user.
	 * 
	 * @param dateEvent		the date event
	 * @param group					the group (optional)
	 * @param user				the user (mandatory)
	 * @return	the event entity
	 */
	public static Event toEvent(DateEventDto dateEvent, User user, Group group, Assignment assignment) {
		Event event = new Event();
		event.setId(dateEvent.getId());
		event.setStartTime(dateEvent.getStartTime());
		event.setEndTime(dateEvent.getEndTime());
		event.setNote(dateEvent.getNote());
		event.setSourceType(group != null ? SourceType.GROUP : SourceType.USER);
		event.setUser(user);
		event.setGroup(group);
		event.setAssignment(assignment);
		return event;
	}
	
	/**
	 * Builds an date event from event entity.
	 * 
	 * @param event		event entity
	 * @return	the date event 
	 */
	public static DateEventDto toDateEvent(Event event) {
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setId(event.getId());
		dateEvent.setStartTime(event.getStartTime());
		dateEvent.setEndTime(event.getEndTime());
		dateEvent.setNote(event.getNote());
		dateEvent.setUserId(event.getUser().getId());
		if (SourceType.GROUP.equals(event.getSourceType()) &&
			event.getGroup() != null &&
			event.getAssignment() != null) {
			dateEvent.setGroupId(event.getGroup().getId());
			dateEvent.setAssignmentId(event.getAssignment().getId());
		}
		return dateEvent;
	}

	/**
	 * Builds an date event from event entity.
	 * 
	 * @param event		event entity
	 * @param includeUser	true to include user name, false otherwise
	 * @param includeGroup	true to include group name, false otherwise
	 * @return	the date event 
	 */
	public static DateEventDto toDateEvent(Event event, boolean includeUser, boolean includeGroup) {
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setId(event.getId());
		dateEvent.setStartTime(event.getStartTime());
		dateEvent.setEndTime(event.getEndTime());
		dateEvent.setNote(event.getNote());
		dateEvent.setUserId(event.getUser().getId());
		dateEvent.setUser(event.getUser().getShortName());
		if (SourceType.GROUP.equals(event.getSourceType()) &&
			event.getGroup() != null &&
			event.getAssignment() != null) {
			dateEvent.setGroupId(event.getGroup().getId());
			dateEvent.setGroup(event.getGroup().getShortName());
			dateEvent.setAssignmentId(event.getAssignment().getId());
		}
		return dateEvent;
	}

	/**
	 * Converts day events to date events.
	 * 
	 * @param repeatableEvents		day events 
	 * @param timePeriod		time period for which day events to be converted to date events
	 * @return	the date events 
	 */
	public static List<DateEventDto> toDateEvents(List<RepeatableEvent> repeatableEvents, TimePeriodDto timePeriod) {
		List<DateEventDto> dateEvents = new LinkedList<DateEventDto>();
		DateTime indexTime = timePeriod.getStartTime().withTime(0, 0, 0, 0);
		DateTime endTime   = timePeriod.getEndTime();

		while (indexTime.isBefore(endTime)) {
			int dayOfWeek = indexTime.getDayOfWeek();
			for (RepeatableEvent repeatableEvent : repeatableEvents) {
				if (dayOfWeek == repeatableEvent.getDayOfWeek().ordinal() + 1) {
					DateTimeZone dateTimeZone = repeatableEvent.getUser().getDateTimeZone();
					
					LocalTime dayStartTime = repeatableEvent.getStartTime();
					LocalTime dayEndTime = repeatableEvent.getEndTime();
					DateTime dateStartTime = toDateTime(indexTime, dayStartTime, dateTimeZone);
					DateTime dateEndTime = toDateTime(indexTime, dayEndTime, dateTimeZone);
					
					DateEventDto dateEvent = new DateEventDto();
					dateEvent.setId(getRandomNum());
					dateEvent.setStartTime(dateStartTime);
					dateEvent.setEndTime(dateEndTime);
					dateEvent.setNote(repeatableEvent.getNote());
					dateEvent.setUserId(repeatableEvent.getUser().getId());
					dateEvent.setGroupId(null);
					dateEvent.setAssignmentId(null);
					
					dateEvents.add(dateEvent);
				}
			}
			indexTime = indexTime.plusDays(1);
		}

		return dateEvents;
	}
	
	/**
	 * Gets the date time using separate date and time parts providers.
	 * 
	 * Helpful resources:
	 * http://www.bagonca.com/blog/2011/03/05/understanding-time-zone-detection-in-javascript/
	 * https://github.com/scottwater/jquery.detect_timezone
	 * http://usertype.sourceforge.net/xref-test/org/jadira/usertype/dateandtime/joda/testmodel/JodaDateTimeZoneAsStringHolder.html
	 * 
	 * @param dateProvider	the date provider
	 * @param timeProvider	the time provider
	 * @return	the newly constructed date time
	 */
	public static DateTime toDateTime(DateTime dateProvider, LocalTime timeProvider, DateTimeZone dateTimeZone) {
		return new DateTime(
			dateProvider.getYear(), 
			dateProvider.getMonthOfYear(), 
			dateProvider.getDayOfMonth(),
			timeProvider.getHourOfDay(),
			timeProvider.getMinuteOfHour(),
			timeProvider.getSecondOfMinute(),
			timeProvider.getMillisOfSecond(),
			//timeProvider.getChronology());
			//dateProvider.getZone());
			dateTimeZone); // use user time zone
 	}
	
	/**
	 * Determines the time period containing all date events.
	 * 
	 * @param dateEvents	the date events.
	 * @return	the time period containing all date events
	 */
	public static TimePeriodDto getTimePeriod(List<DateEventDto> dateEvents) {
		DateTime startTime = null;
		DateTime endTime   = null;
		for (DateEventDto dateEvent : dateEvents) {
			if (startTime == null && endTime == null) {
				startTime = dateEvent.getStartTime();
				endTime = dateEvent.getEndTime();
			} else {
				if (startTime.isAfter(dateEvent.getStartTime())) {
					startTime = dateEvent.getStartTime();
				}
				if (endTime.isBefore(dateEvent.getEndTime())) {
					endTime = dateEvent.getEndTime();
				}
			}
		}
		return new TimePeriodDto(startTime, endTime);
	}

}