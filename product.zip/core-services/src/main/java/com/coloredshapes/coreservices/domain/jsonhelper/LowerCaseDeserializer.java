/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

public class LowerCaseDeserializer extends JsonDeserializer<String> {

	@Override
	public String deserialize(JsonParser jp, DeserializationContext ctxt)
	throws IOException, JsonProcessingException {
		String value = jp.getText();
		if (StringUtils.isEmpty(value)) {
			return null;
		} else {
			return value.toLowerCase();
		}
	}

}
