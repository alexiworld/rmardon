/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

public interface KeyGenerationService {

	public Long getRandomExtKey();

}
