/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestOperations;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.HandlerMapping;

import com.coloredshapes.coreservices.domain.dto.GroupCompleteDto;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>ServiceAdminController</code> provides information
 * for the present version, date of build, and mode of core
 * services application.
 */
@Controller
public class ServiceAdminController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Value("${version:NA}")
	private String version;

	@Value("${datetime:NA}")
	private String datetime;

	@Value("${mode:NA}")
	private String mode;
	
	//Autowiring would not work when there is not unique bean of type RestOperations
	//@Autowired
	//private RestOperations restOperations;
	@Resource(name="restDefaultTemplate")
	private RestOperations restOperations;

	/**
	 * REST service for retrieving events
	 * 
	 * @param userKey			the user key for whom the events are requested
	 * @param startTime			the start time
	 * @param endTime			the end time
	 * @param timeBlockTypes	types of events to be retrieved (USER, GROUP)
	 * @param groupKeys			group events to be retrieve only for group keys			
	 * @return	a map of types and events
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/serviceInfo", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String, String> getServiceInfo()
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("version: " + version);
			logger.debug("datetime: " + datetime);
			logger.debug("mode: " + mode);
		}
		
		Map<String,String> serviceInfo = new LinkedHashMap<String,String>();
		serviceInfo.put("version", version);
		serviceInfo.put("datetime", datetime);
		serviceInfo.put("mode", mode);
		
		if (logger.isDebugEnabled()) {
			logger.debug("serviceInfo: " + serviceInfo);
		}

		return serviceInfo;
	}

	@RequestMapping(value = "displaymode", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void updateDateRepresentation(
			@RequestParam(required=false, defaultValue="false") boolean dateAsText, 
			@RequestParam(required=false, defaultValue="true" ) boolean encodedIds) 
	throws Exception {
		StandardUtils.setTransferDateAsText(dateAsText);
		StandardUtils.setTransferEncodedIds(encodedIds);
	}

	@RequestMapping(value = { "/target/{path1}/{path2}/{path3:.*}", "/target/{path1}/{path2}/{path3:.*}/{path4:.*}"})//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String, String> requestTarget(
			@PathVariable String path1, 
			@PathVariable String path2,
			@PathVariable String path3,
			@PathVariable String path4, 
			@RequestBody GroupCompleteDto group,
			@RequestHeader Map<String, String> headers,
			@RequestParam Map<String, String> params) 
	throws Exception {
		System.out.println("path1: " + path1);
		System.out.println("path2: " + path2);
		System.out.println("path3: " + path3);
		System.out.println("path4: " + path4);
		System.out.println("params: " + params);
		System.out.println("[HEADERS>]" + headers);
		//String text = new String(request);
		//String text2 = new String(request.getBody(), "UTF-8");
		//System.out.println("[TARGET]" + text);
		Map<String, String> map = new HashMap<String, String>();
		map.put("key", "value");
		return map;
	}
	
	//http://stackoverflow.com/questions/4542489/match-the-rest-of-the-url-using-spring-3-requestmapping-annotation
	//http://stackoverflow.com/questions/3686808/spring-3-requestmapping-get-path-value
	//http://stackoverflow.com/questions/5954793/using-springs-requestmapping-with-wildcards
	//http://www.dzone.com/tutorials/java/spring/spring-annotation-controller-1.html
	//http://stackoverflow.com/questions/2513031/multiple-spring-requestmapping-annotations
	//http://stackoverflow.com/questions/12173854/request-mapping-url-pattern-in-spring-mvc3
	//http://static.springsource.org/spring/docs/3.0.x/javadoc-api/org/springframework/web/bind/annotation/RequestMapping.html
	
	@RequestMapping(value = { "/proxy/{path1}/{path2}/{path3:.*}", "/proxy/{path1}/{path2}/{path3:.*}/{path4:.*}"})//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<byte[]> requestProxy(
			@PathVariable String path1, 
			@PathVariable String path2,
			@PathVariable String path3,
			@PathVariable String path4, 
			HttpEntity<byte[]> request,
			WebRequest webRequest,
			HttpServletRequest httpRequest,
			@RequestParam Map<String, String> params) 
	throws Exception {
		System.out.println("path1: " + path1);
		System.out.println("path2: " + path2);
		System.out.println("path3: " + path3);
		System.out.println("path4: " + path4);
		String text = new String(request.getBody());
		System.out.println("[PROXY>]" + text);
		System.out.println("[HEADERS>]" + request.getHeaders().toSingleValueMap());
		
		String path = (String) webRequest.getAttribute( HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST );
		System.out.println("[PROXY PATH]" + path);
		
		HttpMethod method = HttpMethod.valueOf(httpRequest.getMethod());
		
//		GroupCompleteDto group = new GroupCompleteDto();
//		group.setId(4L);
//		group.setParentId(3L);
//		group.setName("BUSINESS NAME 3");
//		group.setPhoneNumber("(778)123-4567");
//		group.setAddress("Address 3");
//		group.setCity("Vancouver 3");
//		group.setProvince("BC");
//		group.setPostalCode("12345");
//		group.setEmail("contacts4@cs.com");
//		group.setStatus(GroupStatus.PENDING);
//
//		HttpEntity<GroupCompleteDto> data = new HttpEntity<GroupCompleteDto>(group, request.getHeaders());
//		ResponseEntity<byte[]> response = restOperations.exchange(
//				"http://localhost:8080/core-services/target/path1/path2/path3/path4", 
//				HttpMethod.POST, data, byte[].class, params);
//		text = new String(response.getBody());
//		System.out.println("[PROXY<]" + text);

		//RestTemplate restOperations = new RestTemplate();
		HttpEntity<byte[]> data = new HttpEntity<byte[]>(request.getBody(), request.getHeaders());
		ResponseEntity<byte[]> response = restOperations.exchange(
				"http://localhost:8080/core-services/target/path1/path2/path3/path4", 
				method,//HttpMethod.POST, 
				data, byte[].class, params);
		text = new String(response.getBody());
		System.out.println("[PROXY<]" + text);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(request.getHeaders().toSingleValueMap());
		headers.setContentLength(response.getBody().length);
		
		//ResponseEntity<byte[]> responsex = new ResponseEntity<byte[]>(request.getBody(), request.getHeaders(), HttpStatus.OK);
		ResponseEntity<byte[]> responsex = new ResponseEntity<byte[]>(response.getBody(), headers, HttpStatus.OK);
		
		return responsex;
	}


	@RequestMapping(value = { "/proxytext/{path1}/{path2}/{path3:.*}", "/proxytext/{path1}/{path2}/{path3:.*}/{path4:.*}"})//, method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String> requestProxyText(
			@PathVariable String path1, 
			@PathVariable String path2,
			@PathVariable String path3,
			@PathVariable String path4, 
			HttpEntity<String> request,
			WebRequest webRequest,
			HttpServletRequest httpRequest,
			@RequestParam Map<String, String> params) 
	throws Exception {
		System.out.println("path1: " + path1);
		System.out.println("path2: " + path2);
		System.out.println("path3: " + path3);
		System.out.println("path4: " + path4);
		
		String text = request.getBody();
		System.out.println("[PROXY>]" + text);
		System.out.println("[PROXY HEADERS>]" + request.getHeaders().toSingleValueMap());
		
		String path = (String) webRequest.getAttribute( HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST );
		System.out.println("[PROXY PATH]" + path);
		
		HttpMethod method = HttpMethod.valueOf(httpRequest.getMethod());
		
		ResponseEntity<String> response = restOperations.exchange(
				"http://localhost:8080/core-services/target/path1/path2/path3/path4", 
				method,//HttpMethod.POST, 
				request, String.class, params);
		text = response.getBody();
		System.out.println("[PROXY<]" + text);
		System.out.println("[PROXY HEADERS<]" + response.getHeaders());
	
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(request.getHeaders().toSingleValueMap());
		headers.setContentLength(text.length());

		ResponseEntity<String> responsex = new ResponseEntity<String>(text, headers, HttpStatus.OK);
		
		return responsex;
	}
}