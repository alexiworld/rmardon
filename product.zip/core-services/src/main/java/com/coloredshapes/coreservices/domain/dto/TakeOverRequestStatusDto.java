/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

public class TakeOverRequestStatusDto {
	
	/**
	 * unique identifier of the TOR
	 */
	private Long torId;	
	private String status;

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getTorId() {
		return torId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setTorId(Long torId) {
		this.torId = torId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("torId", torId) 
        	.append("status", status) 
            .toString();
    }

}