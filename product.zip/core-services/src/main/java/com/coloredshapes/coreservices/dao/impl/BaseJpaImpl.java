/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import static com.coloredshapes.coreservices.utils.RandomUtils.getRandomNum;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.coloredshapes.coreservices.dao.GenericDao;
import com.coloredshapes.coreservices.domain.entity.BaseEntity;
import com.coloredshapes.coreservices.domain.entity.ExternalKeyEntity;
import com.coloredshapes.coreservices.domain.entity.Stamp;
import com.coloredshapes.coreservices.utils.StandardUtils;

public class BaseJpaImpl<T> implements GenericDao<T> {
	protected EntityManager entityManager;
	private Class<T> type;

	// @Autowired
	// private KeyGenerationService keyGenerationService;

	@SuppressWarnings("all")
	public BaseJpaImpl() {
		Type t = getClass().getGenericSuperclass();
		t = ((ParameterizedType) t).getActualTypeArguments()[0];
		type = (Class) t;
	}

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public long countAll(Map<String, Object> params) {
		// FIXME implement this
		return 0;
	}

	@Override
	public T create(T t) {
		if (t instanceof ExternalKeyEntity) {
			ExternalKeyEntity entity = (ExternalKeyEntity) t;
			entity.setExtKey(getRandomNum());
		}
		if (t instanceof BaseEntity) {
			BaseEntity baseEntity = (BaseEntity) t;
			Stamp stamp = StandardUtils.getCreateStamp();
			baseEntity.setStamp(stamp);
		}

		this.entityManager.persist(t);
		return t;
	}

	@Override
	public void delete(Object id) {
		this.entityManager.remove(this.entityManager.getReference(type, id));

	}

	@Override
	public T find(Object id) {
		return (T) this.entityManager.find(type, id);
	}


	@Override
	public T findOneBy(String param, Object value) {
		T o = buildQuery(param, value).getSingleResult();
		return o;
	}

	@Override
	public T findOneBy(Map<String, Object> params) {
		T o = buildQuery(params).getSingleResult();
		return o;
	}
	

	@Override
	public List<T> findManyBy(String param, Object value) {
		List<T> os = buildQuery(param, value).getResultList();
		return os;
	}

	
	@Override
	public List<T> findManyBy(Map<String, Object> params) {
		List<T> os = buildQuery(params).getResultList();
		return os;
	}

	private TypedQuery<T> buildQuery(String param, Object value) {
		String queryString = "from " + type.getSimpleName() + " o where o." + param + " = :" + param;
		if (value instanceof Collection) {
			queryString = "from " + type.getSimpleName() + " o where o." + param + " in (:" + param + ")";
		}
		TypedQuery<T> query = this.entityManager.createQuery(queryString, type).setParameter(param, value);
		return query;
	}

	private TypedQuery<T> buildQuery(Map<String, Object> params) {
		StringBuilder queryString = new StringBuilder();
		queryString.append("from ");
		queryString.append(type.getSimpleName());
		queryString.append(" o where ");
		
		boolean isFirst = true;
		for (Iterator<Map.Entry<String, Object>> iter = params.entrySet().iterator(); iter.hasNext(); ) {
			Map.Entry<String, Object> entry = iter.next();
			
			if (isFirst) {
				isFirst = false;
			} else {
				queryString.append(" and ");
			}
			
			if (entry.getValue() instanceof Collection) {
				queryString.append("o.");
				queryString.append(entry.getKey());
				queryString.append(" in (:");
				queryString.append(entry.getKey());
				queryString.append(")");
			} else {
				queryString.append("o.");
				queryString.append(entry.getKey());
				queryString.append(" = :");
				queryString.append(entry.getKey());
			}
		}
		
		TypedQuery<T> query = this.entityManager.createQuery(queryString.toString(), type);
		for (Iterator<Map.Entry<String, Object>> iter = params.entrySet().iterator(); iter.hasNext(); ) {
			Map.Entry<String, Object> entry = iter.next();
			query.setParameter(entry.getKey(), entry.getValue());
		}
		
		return query;
	}

	@Override
	public T update(T t) {
		if (t instanceof BaseEntity) {
			BaseEntity baseEntity = (BaseEntity) t;
			Stamp stamp = StandardUtils.getUpdateStamp(baseEntity.getStamp());
			baseEntity.setStamp(stamp);
		}
		return this.entityManager.merge(t);
	}

}