/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.RoleDao;
import com.coloredshapes.coreservices.domain.entity.Role;

@Repository
public class RoleDaoJpaImpl  extends BaseJpaImpl<Role> implements RoleDao {

}