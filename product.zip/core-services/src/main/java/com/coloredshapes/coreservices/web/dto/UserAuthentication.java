/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.dto;

/**
 * <code>UserAuthentication</code> is used for authenticating requests.
 *
 */
public class UserAuthentication {

	private String email;
	private String password;

	/**
	 * Gets the email.
	 * 
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 * 
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the password.
	 * 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 * 
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
