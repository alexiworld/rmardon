/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.AssignmentDao;
import com.coloredshapes.coreservices.domain.entity.Assignment;

@Repository
public class AssignmentDaoJpaImpl  extends BaseJpaImpl<Assignment> implements AssignmentDao {

}