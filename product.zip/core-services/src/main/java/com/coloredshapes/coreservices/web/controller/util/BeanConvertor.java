/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller.util;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.utils.StandardUtils;

public class BeanConvertor {
	
	public static Map<String,MembershipStatus> toMembershipStatusesMap(List<Membership> memberships){
		Map<String, MembershipStatus> map= new LinkedHashMap<String, MembershipStatus>();
		for (Membership membership : memberships) {
			map.put(toKey(membership.getGroup()), membership.getMembershipStatus());
		}
		return Collections.unmodifiableMap(map);
	}
	
	public static String toKey(Group group) { // when used as label - value#text
		return StandardUtils.encodeLong(group.getId()) + "#" + group.getName();
	}

}