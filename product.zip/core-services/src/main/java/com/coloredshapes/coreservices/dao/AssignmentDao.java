/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.Assignment;

public interface AssignmentDao extends GenericDao<Assignment> {
	
}
