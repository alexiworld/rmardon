/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.MembershipDao;
import com.coloredshapes.coreservices.dao.MembershipRequestDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.MembershipDto;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.MembershipRequest;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.MembershipRequestStatus;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.exception.ExistingEventException;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidMembershipConfirmationException;
import com.coloredshapes.coreservices.exception.InvalidMembershipException;
import com.coloredshapes.coreservices.exception.InvalidMembershipStatusException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.MembershipService;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Service
public class MembershipServiceImpl implements MembershipService {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private EventDao eventDao;
	
	@Autowired
	private MembershipRequestDao membershipRequestDao;

	@Autowired
	private MessageService messageService;

	@Autowired
	private MembershipDao membershipDao;

	//@Autowired
	//private QueueService messageService;
	
	@Resource(name="dozerBeanMapper")
	private DozerBeanMapper beanMapper;

	@Override
	@Transactional(readOnly = true)
	public List<MembershipDto> getGroupMemberships(Long groupId)
	throws InvalidGroupException {
		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		Group topGroup = group.getTopGroup();
		List<Membership> memberships = topGroup.getMemberships();
		
		return toMembershipDtos(memberships);
	}

	@Override
	@Transactional(readOnly = true)
	public List<MembershipDto> getUserMemberships(Long userId)
	throws InvalidUserException {
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}
		List<Membership> memberships = user.getMemberships();
		return toMembershipDtos(memberships);
	}
	
	private MembershipDto toMembershipDto(Membership membership) {
		MembershipDto membershipDto = new MembershipDto();
		membershipDto.setGroupId(membership.getGroup().getId());
		membershipDto.setGroupName(membership.getGroup().getName());
		membershipDto.setUserId(membership.getUser().getId());
		membershipDto.setMembershipStatus(membership.getMembershipStatus());
		return membershipDto;
	}

	private List<MembershipDto> toMembershipDtos(List<Membership> memberships) {
		List<MembershipDto> membershipDtos = new ArrayList<MembershipDto>(memberships.size());
		for (Membership membership : memberships) {
			membershipDtos.add(toMembershipDto(membership));
		}
		return membershipDtos;
	}
	
	@Override
	@Transactional
	public void initiateMembership(MembershipDto membershipDto) {
		Long groupId = membershipDto.getGroupId();
		if (groupId == null) {
			throw new IllegalArgumentException("The group initiating membeship is missing.");
		}
		
		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}

		// Membership is needed to be established between the top group and user, so 
		// the top and all sub groups have legal access to user profile and limited 
		// access to his/her events.
		Group topGroup = group.getTopGroup();
		if (topGroup == null) {
			throw new InvalidGroupException((Long) null);
		}
		
		Long topGroupId = topGroup.getId();
		if (topGroupId == null) {
			throw new IllegalArgumentException("The top group initiating membeship is missing.");
		}

		String userEmail = membershipDto.getUserEmail();
		if (userEmail == null) {
			throw new IllegalArgumentException("The user email when initiating membeship is missing.");
		}

		User user = userDao.getUser(userEmail);
		if (user == null) {
			throw new InvalidUserException(userEmail);
		}

		List<Membership> memberships = topGroup.getMemberships();
		for (Membership membership : memberships) {
			if (membership.getUser().getId() == user.getId()) {
				return; // Already a member, no need of invitation.
			}
		}

		//TODO: To be merged with Membership entity in the future
		MembershipRequest membershipReq = new MembershipRequest(); 
		membershipReq.setGroupId(topGroupId);
		membershipReq.setUserId(user.getId());
		membershipReq.setUserEmail(userEmail);
		membershipReq.setCreateDate(new Date());
		membershipReq.setStatus(MembershipRequestStatus.OPEN);
		UUID refId = UUID.randomUUID();
		membershipReq.setReferenceId(refId.toString());

		messageService.sendMembershipRequest(membershipReq, user, group);
		membershipRequestDao.createMembershipRequest(membershipReq);
	}

	@Override
	@Transactional
	public void confirmMembership(Long userId, String refId)
			throws InvalidMembershipConfirmationException,
			InvalidGroupException, InvalidUserException {

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		MembershipRequest membershipReq = membershipRequestDao
				.getMembershipRequestByRefIdAndUserId(refId, user.getId());
		if (membershipReq == null || 
			MembershipRequestStatus.DECLINED.equals(membershipReq.getStatus())) {
			throw new InvalidMembershipConfirmationException();
		}
		if (membershipReq.getConfirmationDate() != null) {
			return;
		}

		// Database should timestamp the insertion and changes to events in the table
		// Normally the interceptor takes care of setting up the user for stamping the
		// records. However, in this case the request comes by clicking on a link and a
		// special handling is needed.
		//
		// TODO: decide which one to use for stamping the record in the database user 
		// id does not change, but email does. on the other side emails are being used 
		// in Group Schedule tool for identification. The latter can be work arounded 
		// by using the group id. 
		StandardUtils.setUser(user.getEmail()); 

		membershipReq.setConfirmationDate(new Date());
		membershipReq.setStatus(MembershipRequestStatus.ACCEPTED);
		membershipRequestDao.updateMembershipRequest(membershipReq);

		Group group = groupDao.getGroup(membershipReq.getGroupId());
		if (group == null) {
			throw new InvalidGroupException(membershipReq.getGroupId());
		}

		// Membership is needed to be established between the top group 
		// and user, so the top and all sub groups have legal access to 
		// user profile and limited access to his/her events.
		group = group.getTopGroup();

		Membership existingMembership = membershipDao
			.getMembershipByTopGroupIdAndUserId(group.getId(), user.getId());
		// already accepted it before
		if (existingMembership != null) {
			logger.info("Membership already exists. Group id:" + group.getId()
					+ " , user id:" + user.getId());
		} else {
			final Membership membership = new Membership();
			membership.setUser(user);
			membership.setGroup(group);
			membership.setMembershipStatus(MembershipStatus.ACTIVE);
			membershipDao.createMembership(membership);
		}
	}

	@Override
	@Transactional
	public void updateUserMemberships(Long userId, Map<Long, String> statuses) 
	throws InvalidUserException, InvalidMembershipStatusException, ExistingEventException {
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}
		
		List<Membership> memberships = user.getMemberships();

		for (Membership membership : memberships) {
			if (membership.getMembershipStatus().equals(MembershipStatus.INACTIVE) || 
				membership.getMembershipStatus().equals(MembershipStatus.PENDING)) {
				throw new InvalidMembershipStatusException();
			}
			
			if (hasEventsForMembership(membership)) {
				throw new ExistingEventException();
			}
			
			Group group = membership.getGroup();
			Long groupId = group.getId();
			String status = statuses.get(groupId);
			if (status != null) {
				membership.setMembershipStatus(MembershipStatus.valueOf(status));
			}
		}

		userDao.update(user);
	}
	
	@Override
	@Transactional
	public void updateGroupMemberships(Long groupId, Map<Long, String> statuses) 
	throws InvalidUserException, InvalidMembershipStatusException, ExistingEventException {
		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		List<Membership> memberships = group.getMemberships();

		for (Membership membership : memberships) {
			if (membership.getMembershipStatus().equals(MembershipStatus.INACTIVE) || 
				membership.getMembershipStatus().equals(MembershipStatus.PENDING)) {
				throw new InvalidMembershipStatusException();
			}
			
			if (hasEventsForMembership(membership)) {
				throw new ExistingEventException();
			}
			
			User user = membership.getUser();
			Long userId = user.getId();
			String status = statuses.get(userId);
			if (status != null) {
				membership.setMembershipStatus(MembershipStatus.valueOf(status));
			}
		}

		groupDao.update(group);
	}
	
	@Override
	@Transactional
	public void inactivateMemberships(Long groupId, List<String> userEmails, boolean forceDelete) 
	throws InvalidGroupException {
		Validate.notNull(groupId, "Group id is missing");
		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}

		// Membership is needed to be established between the top group 
		// and user, so the top and all sub groups have legal access to 
		// user profile and limited access to his/her events.
		group = group.getTopGroup();

		for (String userEmail : userEmails) {
			User user = userDao.getUser(userEmail);
			if (user == null) {
				logger.warn("user " + userEmails + " doesn't exist.");
				continue;
			}
			
			Membership membership = membershipDao.getMembershipByTopGroupIdAndUserId(group.getId(), user.getId());
			//already an membership relationship
			if (membership != null) {
				if (forceDelete) {
					eventDao.deleteTopAndSuccessorGroupEvents(group.getId(), user.getId());
					inactivateMembership(membership);
				} else {
					if (hasEventsForMembership(membership)) {
						// if there is an event with that group, can't invactivate the membership
					} else {
						inactivateMembership(membership);
					}
				}
			} else {
				List<MembershipRequest> membershipReqList = 
					membershipRequestDao.getMembershipRequestByGroupIdAndUserId(group.getId(), user.getId());
				//check if user has outstanding membership requests if no existing membership relationship
				if (membershipReqList != null) {
					for (MembershipRequest membershipReq : membershipReqList) {
						membershipReq.setStatus(MembershipRequestStatus.CANCELLED);
						membershipRequestDao.update(membershipReq);
					}	
				}		
			}
		}
	}

	@Override
	@Transactional
	public void deleteMembership(MembershipDto membershipDto) 
	throws InvalidGroupException, InvalidUserException, InvalidMembershipException {
		Long groupId = membershipDto.getGroupId();
		Long userId = membershipDto.getUserId();
		
		Validate.notNull(groupId, "Group id is missing");
		Validate.notNull(userId, "User id is missing");

		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		// Membership is needed to be established between the top group 
		// and user, so the top and all sub groups have legal access to 
		// user profile and limited access to his/her events.
		group = group.getTopGroup();

		Membership membership = membershipDao.getMembershipByTopGroupIdAndUserId(group.getId(), user.getId());
		if (membership != null) {
			throw new InvalidMembershipException(groupId, userId);
		}
				
		eventDao.deleteTopAndSuccessorGroupEvents(group.getId(), user.getId());
		membershipDao.delete(membership);
	}

	private void inactivateMembership(Membership membership) {
		membership.setMembershipStatus(MembershipStatus.INACTIVE);
		membershipDao.update(membership);
	}
	
	private boolean hasEventsForMembership(Membership membership) {
		List<Event> events = eventDao.getTopAndSuccessorGroupsEvents(
				membership.getGroup().getId(), membership.getUser().getId());
		return events.size() > 0;
	}

}