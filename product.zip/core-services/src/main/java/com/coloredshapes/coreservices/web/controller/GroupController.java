/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.GroupBasicDto;
import com.coloredshapes.coreservices.domain.dto.GroupCompleteDto;
import com.coloredshapes.coreservices.domain.dto.IdDto;
import com.coloredshapes.coreservices.domain.dto.RoleDto;
import com.coloredshapes.coreservices.domain.dto.UserBasicDto;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.service.GroupService;
import com.coloredshapes.coreservices.service.ManagementService;
import com.coloredshapes.coreservices.service.UserService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Controller
public class GroupController extends BaseController {
	
	private static final Logger logger = LoggerFactory.getLogger(GroupController.class);
	
	@Autowired
	private GroupService groupService;

	@Autowired
	private UserService userService;

	@Autowired
	private ManagementService managementService;

	@RequestMapping(value = "/groups/{groupId}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public GroupBasicDto getGroup(@PathVariable("groupId") String groupIdCode, 
			                      @RequestParam ContentLimit contentLimit,
			                      @RequestParam ContentStatus contentStatus)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("get group with id: " + groupIdCode);
			logger.debug("content limit: " + contentLimit);
			logger.debug("content status: " + contentStatus);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		return groupService.getGroup(groupId, contentLimit, contentStatus);
	}
	
	@RequestMapping(value = "/groups", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	//@Transactional
	public IdDto createGroup(@RequestBody GroupCompleteDto groupDto) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("create group: " + ReflectionToStringBuilder.toString(groupDto));
		}
		
		Long groupId = groupService.createGroup(groupDto);
		UserBasicDto userDto = userService.getCurrentUser();
		
		RoleDto roleDto = StandardUtils.getAdminRole();
		roleDto.setGroupId(groupId);
		managementService.createRole(roleDto);
		
		AssignmentDto assignmentDto = new AssignmentDto();
		assignmentDto.setUserId(userDto.getId());
		assignmentDto.setRoleId(roleDto.getId());
		
		managementService.createAssignment(assignmentDto);

		IdDto idDto = new IdDto(groupId); // encodes automatically the group Id for json
		return idDto;
	}
	
	@RequestMapping(value = "/groups/{groupId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void updateGroup(@PathVariable("groupId") String groupIdCode, 
			                @RequestBody GroupCompleteDto groupDto) 
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("update group with id: " + groupIdCode);
			logger.debug("update group: " + ReflectionToStringBuilder.toString(groupDto));
		}
		
		if (groupIdCode == null) {
			throw new InvalidGroupException(groupIdCode);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		
		if (groupId == null || groupDto == null || !groupId.equals(groupDto.getId())) {
			throw new InvalidGroupException(groupId);
		}
		
		groupService.updateGroup(groupDto);
	}

	@RequestMapping(value = "/groups/{groupId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void removeGroup(@PathVariable("groupId") String groupIdCode) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("update group with id: " + groupIdCode);
		}
		
		if (groupIdCode == null) {
			throw new InvalidGroupException(groupIdCode);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		
		if (groupId == null) {
			throw new InvalidGroupException(groupId);
		}
		
		groupService.removeGroup(groupId);
	}

	/*
	@RequestMapping(value = "/groups/{groupId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void deleteGroup(@PathVariable("groupId") String groupIdCode) 
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("delete group with id: " + groupIdCode);
		}
		
		if (groupIdCode == null) {
			throw new InvalidGroupException(groupIdCode);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		
		if (groupId == null) {
			throw new InvalidGroupException(groupId);
		}
		
		groupService.deleteGroup(groupId);
	}
	*/

	@RequestMapping(value = "/groups/statuses", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void changeGroupStatus(@RequestBody LinkedHashMap<String, ArrayList<Long>> statuses) throws Exception {
		groupService.updateGroupStatus(statuses);
	}
	
	/**
	 * REST service to retrieve user front groups.
	 * 
	 * @param groupIdCode		the encoded user ID
	 * @return	list of user front groups
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/users/{userId}/frontgroups", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public GroupBasicDto[] getUserFrontGroups(@PathVariable("userId") String userIdCode,
										      @RequestParam ContentLimit contentLimit,
							                  @RequestParam ContentStatus contentStatus)
    throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("user id: " + userIdCode);
			logger.debug("content status: " + contentStatus);
		}

		Long userId = StandardUtils.decodeLong(userIdCode);

		List<GroupBasicDto> groups = groupService.getUserFrontGroups(userId, contentLimit, contentStatus);
		
		if (logger.isDebugEnabled()) {
			logger.debug("groups: " + groups);
		}

		return groups.toArray(new GroupBasicDto[0]);
	}
	
	/**
	 * REST service to retrieve user groups.
	 * 
	 * @param groupIdCode		the encoded user ID
	 * @return	list of user groups
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/users/{userId}/groups", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public GroupBasicDto[] getUserGroups(@PathVariable("userId") String userIdCode,
										 @RequestParam ContentLimit contentLimit,
							             @RequestParam ContentStatus contentStatus)
    throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("user id: " + userIdCode);
			logger.debug("content status: " + contentStatus);
		}

		Long userId = StandardUtils.decodeLong(userIdCode);

		List<GroupBasicDto> groups = groupService.getUserGroups(userId, contentLimit, contentStatus);
		
		if (logger.isDebugEnabled()) {
			logger.debug("groups: " + groups);
		}

		return groups.toArray(new GroupBasicDto[0]);
	}

}