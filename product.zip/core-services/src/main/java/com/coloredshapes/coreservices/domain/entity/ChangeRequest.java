/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "change_request")
public class ChangeRequest extends BaseEntity {

	@OneToOne
	@JoinColumn(name = "event_id", unique = false, nullable = false, updatable = false)
	private Event event;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private ChangeRequestStatus status;

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}

	public ChangeRequestStatus getStatus() {
		return status;
	}

	public void setStatus(ChangeRequestStatus status) {
		this.status = status;
	}

	public static enum ChangeRequestStatus {
		PENDING
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("event", event) 
            .append("status", status) 
            .toString();
    }

}