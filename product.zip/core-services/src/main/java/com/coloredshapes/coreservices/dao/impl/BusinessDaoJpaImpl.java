/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.BusinessDao;
import com.coloredshapes.coreservices.domain.entity.Business;
import com.coloredshapes.coreservices.domain.entity.Business_;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Group_;

@Repository
public class BusinessDaoJpaImpl  extends BaseJpaImpl<Business> implements BusinessDao {

	@Override
	public void createBusiness(Business business) {
		create(business);
		entityManager.flush();
	}

	@Override
	public Business getBusinessByGroupId(Long groupId) {
		CriteriaQuery<Business> criteria = entityManager.getCriteriaBuilder().createQuery(Business.class);
		
		Root<Business> businessRoot = criteria.from( Business.class );
		Join<Business, Group> businessGroup = businessRoot.join(Business_.group);
		criteria.select( businessRoot );
		criteria.where( entityManager.getCriteriaBuilder().equal( businessGroup.get(Group_.id), groupId) );

		List<Business> resultList = entityManager.createQuery( criteria ).getResultList();
		if (resultList.size() < 1) {
			return null;
		} else {
			return resultList.get(0);
		}
	}

	@Override
	public void deleteBusinessByGroupId(Long groupId) {
		String deleteHQL = "delete from Business b where group_id = :groupId";
		Query query = entityManager.createQuery(deleteHQL);
		query.setParameter("groupId", groupId); 
		query.executeUpdate();
	}

}