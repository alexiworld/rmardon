/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.TakeOverRequestDao;
import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;

@Repository
public class TakeOverRequestDaoJpaImpl extends BaseJpaImpl<TakeOverRequest> 
                                       implements TakeOverRequestDao {

	@Override
	public TakeOverRequest getTakeOverRequestById(Long torId) {
		TypedQuery<TakeOverRequest> query = entityManager.createQuery(
		        "SELECT tor FROM TakeOverRequest tor WHERE tor.id = :torId ", TakeOverRequest.class);
		query.setParameter("torId", torId); 
	
		List<TakeOverRequest> resultList = query.getResultList();
		if (resultList.size() > 0) {
			return resultList.get(0);
		} else {
			return null;
		}
	}

}