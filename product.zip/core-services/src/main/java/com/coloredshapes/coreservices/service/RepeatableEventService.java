/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.dto.RepeatableEventDto;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.exception.ExistingUserException;
import com.coloredshapes.coreservices.exception.InvalidUserException;

public interface RepeatableEventService {

	public Map<Outcome, List<RepeatableEventDto>> createRepeatableEvents(List<RepeatableEventDto> eventDtos, Long userId) throws InvalidUserException ;
	
	public Map<DayOfWeek, List<RepeatableEventDto>>  getRepeatableEvents(Long userId) ;
	
	/**
	 * Deletes user repeatable events. If a caller attempts to delete an event
	 * not belonging to the user, that event will be ignored.
	 * 
	 * @param userId
	 *            identifies the user whose events to delete
	 * @param eventIds
	 *            identifies which events to delete
	 * @throws ExistingUserException
	 * @throws InvalidUserException
	 */
	public void  deleteRepeatableEvent(Long userId, List<Long> eventIds) throws ExistingUserException, InvalidUserException;

}
