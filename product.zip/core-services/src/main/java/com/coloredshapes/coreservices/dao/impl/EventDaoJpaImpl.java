/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Event_;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Group_;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.User_;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;

/**
 * <code>EventDaoJpaImpl</code> class is JPA type of 
 * implementation of <code>EventDao</code> interface.
 */
@Repository
public class EventDaoJpaImpl extends BaseJpaImpl<Event> implements EventDao {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * Retrieves events for specific user and time period. The results are filtered based on the
	 * following criteria:
	 * - retrieve only user private events  
	 * - retrieve events assigned to a user by all or specific groups
	 * - retrieve combination of above
	 * 
	 * @param startTime		the start time of query
	 * @param endTime		the end time of query
	 * @param userId		the user id
	 * @param sourceTypes	list of source types 
	 * @param groupIds		optionally the group Ids
	 * @return	list of event entities
	 */
	@Override
	public List<Event> getEventsByUserId(DateTime startTime, DateTime endTime, Long userId, SourceType[] sourceTypes, Long[] groupIds) {
		boolean userEventsIncluded = false;
		boolean groupEventsIncluded   = false;
		for (SourceType sourceType : sourceTypes) {
			if (SourceType.USER.equals(sourceType)) {
				userEventsIncluded = true;
			}
			if (SourceType.GROUP.equals(sourceType)) {
				groupEventsIncluded = true;
			}
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("userEventsIncluded: " + userEventsIncluded);
			logger.debug("groupEventsIncluded: " + groupEventsIncluded);
		}
		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Event> criteria = criteriaBuilder.createQuery(Event.class);

		Root<Event> eventRoot = criteria.from(Event.class);
		Join<Event, User> eventUser = eventRoot.join( Event_.user );
		//timeBlockRoot.fetch( Event_.user );
		Join<Event, Group> eventGroup = null;
		if (groupEventsIncluded) {
			eventGroup = eventRoot.join( Event_.group, userEventsIncluded ? JoinType.LEFT : JoinType.INNER);
			//timeBlockRoot.fetch( Event_.group, userEventsIncluded ? JoinType.LEFT : JoinType.INNER );
		}
		
		Predicate userIdPredicate = criteriaBuilder.equal(eventUser.get(User_.id), userId);
		Predicate timeRulesPredicate = buildTimeRulesPredicate(eventRoot.<DateTime>get(Event_.startTime), 
				                                               eventRoot.<DateTime>get(Event_.endTime), 
				                                               startTime, endTime);		
		Predicate sourceTypePredicate = eventRoot.<SourceType>get(Event_.sourceType).in(Arrays.asList(sourceTypes));

		Predicate compositePredicate = criteriaBuilder.and(userIdPredicate, timeRulesPredicate, sourceTypePredicate);
		if (groupEventsIncluded && ArrayUtils.isNotEmpty(groupIds)) {
			Predicate groupSpecifiedPredicate = eventGroup.get(Group_.id).in(Arrays.asList(groupIds));
			Predicate groupNullPredicate = criteriaBuilder.isNull(eventRoot.<Group>get(Event_.group));
			Predicate groupPredicate = criteriaBuilder.or(groupSpecifiedPredicate, groupNullPredicate);
			compositePredicate = criteriaBuilder.and(compositePredicate, groupPredicate);
		}
		
		criteria.select(eventRoot);
		criteria.where(compositePredicate);

		List<Event> resultList = entityManager.createQuery(criteria).getResultList();

		//TypedQuery<Event> createdQuery = entityManager.createQuery(
		//		//"select ev from Event ev join ev.user m where m.userId = 1", Event.class);
		//		"select ev from Event ev where ev.user.userId = 1", Event.class);
		//List<Event> resultListQ = createdQuery.getResultList();

		return resultList;
	}
	
	/**
	 * Retrieves users events for specific time period. 
	 * 
	 * @param startTime		the start time of query
	 * @param endTime		the end time of query
	 * @param userIds	the user Ids
	 * @return	list of event entities
	 */
	@Override
	public List<Event> getEventsByUserIds(DateTime startTime, DateTime endTime, Long[] userIds) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Event> criteria = criteriaBuilder.createQuery(Event.class);

		Root<Event> eventRoot = criteria.from(Event.class);
		eventRoot.join( Event_.group, JoinType.LEFT );
		Join<Event, User> eventUser = eventRoot.join( Event_.user );
		
		Predicate userIdsPredicate = eventUser.get(User_.id).in(Arrays.asList(userIds));
		Predicate timeRulesPredicate  = buildTimeRulesPredicate(eventRoot.<DateTime>get(Event_.startTime), 
                                                                eventRoot.<DateTime>get(Event_.endTime), 
                                                                startTime, endTime);		
		Predicate compositePredicate = criteriaBuilder.and(userIdsPredicate, timeRulesPredicate);
		
		criteria.select(eventRoot);
		criteria.where(compositePredicate);

		List<Event> resultList = entityManager.createQuery(criteria).getResultList();
		return resultList;
	}
	
	/**
	 * Persists the list of event entities.
	 * 
	 * @param events	the list of event entities
	 * @return	a map containing two entries, the first entry is the list of event entities 
	 * persisted successfully, the second entry is the list of not persisted event entities  
	 */
	@Override
	public Map<Outcome, List<Event>> createEvents(List<Event> events) {
		if (logger.isDebugEnabled()) {
			logger.debug("Creating " + events);
		}
		
		List<Event> successes = new LinkedList<Event>();
		List<Event> failures  = new LinkedList<Event>();
		for (Event event : events) { 
			try {
				if (eventDoesNotConflict(event)) {
					create(event);
					//entityManager.persist(timeBlock);
					successes.add(event);
				} else {
					failures.add(event);
				}
			} catch (Exception ex) {
				if (logger.isWarnEnabled()) {
					logger.warn("Failed to create " + event + " due to " + ex);
				}
				failures.add(event);
			}
		}

		entityManager.flush();
		
		Map<Outcome, List<Event>> result = new HashMap<Outcome, List<Event>>();
		result.put(Outcome.SUCCESS, successes);
		result.put(Outcome.FAILURE, failures);
		
		return result;
	}
	
	/**
	 * Deletes all events having any of the specified Ids.
	 * 
	 * @param userId		provided if the user is performing the deletion
	 * @param groupId		provided if the group is performing the deletion
	 * @param eventIds		the event Ids
	 * @return	a map containing two entries, the first entry is the list of event Ids, 
	 * which entities have been successfully deleted, the second entry are for the ones that
	 * have not been deleted.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<Outcome, List<Long>> deleteEvents(Long userId, Long groupId, List<Long> eventIds) {
		List<Long> successes = null;
		List<Long> failures  = null;
		
		//TODO as far as I know when a delete HQL is executed, the rows in DB will be deleted,
		//but if any objects that are cached in persistent context will not know their corresponding rows are deleted. by David
		//DB and persistent context will be out of sync
		String deleteHQL = "delete from Event ev where ev.id in :eventIds";
		if (userId != null) {
			deleteHQL += " and user_id = :userId"; 
		}
		if (groupId != null) {
			deleteHQL += " and group_id = :groupId";
		} else {
			deleteHQL += " and group_id = null";
		}
		
		Query query = entityManager.createQuery(deleteHQL);
		
		query.setParameter("eventIds", eventIds);
		if (userId != null) {
			query.setParameter("userId", userId); 
		}
		if (groupId != null) {
			query.setParameter("groupId", groupId); 
		}
		
		int numberOfDeletedEvents = query.executeUpdate();

		if (logger.isDebugEnabled()) {
			logger.debug("numberOfDeletedEvents: " + numberOfDeletedEvents);
		}

		if (numberOfDeletedEvents != eventIds.size()) {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<Long> criteria = criteriaBuilder.createQuery(Long.class);

			Root<Event> eventRoot = criteria.from(Event.class);
			Predicate eventIdPredicate = 
				eventRoot.get(Event_.id).in(eventIds);
			
			criteria.select(eventRoot.get(Event_.id));
			criteria.where(eventIdPredicate);

			failures = entityManager.createQuery(criteria).getResultList();
			successes = new LinkedList<Long>(CollectionUtils.subtract(eventIds, failures));
		} else {
			successes = new LinkedList<Long>(eventIds);
			failures  = Collections.<Long>emptyList();
		}
		
		Map<Outcome, List<Long>> result = new HashMap<Outcome, List<Long>>();
		result.put(Outcome.SUCCESS, successes);
		result.put(Outcome.FAILURE, failures);
		
		return result;
	}
	
	/**
	 * delete all group event of a user with the group as identify by the userId and groupId
	 * @param userId specify whose events to delete
	 * @param groupId specify of which group, the user's group event should be delete
	 * @return the total number of rows that have been deleted
	 */
	@Deprecated
	@Override
	public int deleteEvents(Long userId, Long groupId) {
		String deleteHQL = "delete from Event ev where";

		boolean userIdPresent  = (userId  != null);
		boolean groupIdPresent = (groupId != null);
		
		//The 'where' bug is introduced to prevent deletion of all events in the database 
		//if (userIdPresent || groupIdPresent) {
		//	deleteHQL += " where";
		//}

		if (userIdPresent) {
			deleteHQL += " user_id = :userId)"; 
		}
		
		if (groupIdPresent) {
			deleteHQL += " and group_id = :groupId";
		} else {
			deleteHQL += " and group_id = null";
		}
		
		Query query = entityManager.createQuery(deleteHQL);
		
		if (userIdPresent) {
			query.setParameter("userId", userId); 
		}
		if (groupIdPresent) {
			query.setParameter("groupId", groupId); 
		}
		
		int numberOfDeletedEvents = query.executeUpdate();

		return numberOfDeletedEvents;
	}

	/**
	 * Checks if a event conflicts with any of the existing
	 * events in the database.
	 * 
	 * @param event		the event to use for the check
	 * @return	true if the event is in conflict, false otherwise.
	 */
	private boolean eventDoesNotConflict(Event event) {
		String selectHQL = null;
		if (SourceType.USER.equals(event.getSourceType())) {
			// Overlapping times blocked by same user are allowed
			// This branch ensures the time to be blocked by user 
			// does not conflict with some other time already being
			// blocked by some group.
			selectHQL = "SELECT ev FROM Event ev WHERE"
			+ " ((ev.startTime between :startTime and :endTime)"
	        + " or (ev.endTime between :startTime and :endTime)" 
			+ " or (ev.startTime < :startTime and ev.endTime > :endTime))" 
	        + " and ev.user.id = :userId"
			+ " and ev.sourceType != 'USER'";
		} else {
			// This branch ensures the time to be blocked by an group 
			// is not in conflict with some other time on user's 
			// schedule.
			selectHQL = "SELECT ev FROM Event ev WHERE"
			+ " ((ev.startTime between :startTime and :endTime)"
	        + " or (ev.endTime between :startTime and :endTime)" 
			+ " or (ev.startTime < :startTime and ev.endTime > :endTime))" 
	        + " and ev.user.id = :userId";
		}
		TypedQuery<Event> query = entityManager.createQuery(selectHQL, Event.class);
	    query.setParameter("startTime", event.getStartTime());
	    query.setParameter("endTime", event.getEndTime()); 
	    query.setParameter("userId", event.getUser().getId()); 
	    query.setMaxResults(1);
	    List<Event> resultList = query.getResultList();
	    
		if (logger.isDebugEnabled()) {
			logger.debug(event + " is in conflict with " + resultList);
		}
	    
		return CollectionUtils.isEmpty(resultList);
	}

	/**
	 * Builds a time rules predicate used to filter events contained or overlapping the specified time period.
	 * 
	 * @param startTimeExpression	the expression for event start time
	 * @param endTimeExpression		the expression for event end time
	 * @param startTime				the query start time 
	 * @param endTime				the query end time
	 * @return	the time rules predicate used to filter events
	 */
	private Predicate buildTimeRulesPredicate(Expression<DateTime> startTimeExpression, 
			                                  Expression<DateTime> endTimeExpression, 
			                                  DateTime startTime, DateTime endTime) {
		// There are 4 different cases of query period overlapping or containing a event and all these are covered by
		// the following 4 search criteria called for short rules.
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		
		// rule 1: query start time <= event start time && query end time >= event end time
		Predicate timeRule1SubRule1 = criteriaBuilder.greaterThanOrEqualTo(startTimeExpression, startTime);
		Predicate timeRule1SubRule2 = criteriaBuilder.lessThanOrEqualTo(endTimeExpression, endTime);
		Predicate timeRule1 = criteriaBuilder.and(timeRule1SubRule1, timeRule1SubRule2);
		
		// rule 2: query start time <= event start time && query end time >= event start time
		// && query end time <= event end time
		Predicate timeRule2SubRule1 = criteriaBuilder.greaterThanOrEqualTo(startTimeExpression, startTime);
		Predicate timeRule2SubRule2 = criteriaBuilder.lessThanOrEqualTo(startTimeExpression, endTime);
		Predicate timeRule2SubRule3 = criteriaBuilder.greaterThanOrEqualTo(endTimeExpression, endTime);
		Predicate timeRule2 = criteriaBuilder.and(timeRule2SubRule1, timeRule2SubRule2, timeRule2SubRule3);
		
		// rule 3: query start time >= event start time && query end time <= event end time
		Predicate timeRule3SubRule1 = criteriaBuilder.lessThanOrEqualTo(startTimeExpression, startTime);
		Predicate timeRule3SubRule2 = criteriaBuilder.greaterThanOrEqualTo(endTimeExpression, endTime);
		Predicate timeRule3 = criteriaBuilder.and(timeRule3SubRule1, timeRule3SubRule2);
		
		// rule 4: query start time >= event start time && query start time <= event end time
		// && query end time >= event end time
		Predicate timeRule4SubRule1 = criteriaBuilder.lessThanOrEqualTo(startTimeExpression, startTime);
		Predicate timeRule4SubRule2 = criteriaBuilder.greaterThanOrEqualTo(endTimeExpression, startTime);
		Predicate timeRule4SubRule3 = criteriaBuilder.lessThanOrEqualTo(endTimeExpression, endTime);
		Predicate timeRule4 = criteriaBuilder.and(timeRule4SubRule1, timeRule4SubRule2, timeRule4SubRule3);
		
		Predicate timeRulesPredicate = criteriaBuilder.or(timeRule1, timeRule2, timeRule3, timeRule4);		
		return timeRulesPredicate;
	}

	@Deprecated
	@Override
	public List<Event> getGroupEventsForUser(Long groupId, Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Event> criteria = criteriaBuilder.createQuery(Event.class);
		
		final Root<Event> eventRoot = criteria.from( Event.class );
		Join<Event, Group> eventGroup = eventRoot.join( Event_.group);
		Join<Event, User> eventUser = eventRoot.join( Event_.user);
		Predicate userPredicate  = criteriaBuilder.equal(eventUser.get(User_.id), userId);
		Predicate groupPredicate  = criteriaBuilder.equal(eventGroup.get(Group_.id), groupId);
		Predicate endTimeGreaterThanNowPredicate=criteriaBuilder.greaterThanOrEqualTo(eventRoot.<DateTime>get(Event_.endTime), new DateTime());
		Predicate compositePredicate = criteriaBuilder.and(userPredicate,groupPredicate,endTimeGreaterThanNowPredicate);
		criteria.where(compositePredicate);
		TypedQuery<Event> createQuery = entityManager.createQuery( criteria );
		createQuery.setMaxResults(1);
		return createQuery.getResultList();
	}

	/**
	 * Deletes all events for a user involving top or successor groups
	 * 
	 * @param topGroupId
	 *            the top group identifier
	 * @param userId
	 *            the user identifier
	 * @return the total number of rows that have been deleted
	 */
	@Override
	public int deleteTopAndSuccessorGroupEvents(Long topGroupId, Long userId) {
		String deleteHQL = "delete from Event ev where";

		boolean userIdPresent = ( userId != null );
		boolean topGroupIdPresent = ( topGroupId != null );
		
		//The 'where' bug is introduced to prevent deletion of all events in the database
		//if (userIdPresent || topGroupIdPresent) {
		//	deleteHQL += " where";
		//}

		if (userIdPresent) {
			deleteHQL += " user_id = :userId"; 
		}
		
		if (topGroupIdPresent) {
			deleteHQL += " and group_id in (select g.id from Group g where g.topGroup.id = :topGroupId)";
		} else {
			deleteHQL += " and group_id = null";
		}
		
		Query query = entityManager.createQuery(deleteHQL);
		
		if (userIdPresent) {
			query.setParameter("userId", userId); 
		}
		if (topGroupIdPresent) {
			query.setParameter("topGroupId", topGroupId); 
		}
		
		int numberOfDeletedEvents = query.executeUpdate();
		return numberOfDeletedEvents;
	}

	/**
	 * Retrieves all events for a user involving top or successor groups
	 * 
	 * @param topGroupId
	 *            the top group identifier
	 * @param userId
	 *            the user identifier
	 * @return group events
	 */
	@Override
	public List<Event> getTopAndSuccessorGroupsEvents(Long topGroupId, Long userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Event> criteria = criteriaBuilder.createQuery(Event.class);
		
		final Root<Event> eventRoot = criteria.from( Event.class );
		Join<Event, Group> eventGroup = eventRoot.join( Event_.group);
		Join<Event, User> eventUser = eventRoot.join( Event_.user);
		Predicate userPredicate  = criteriaBuilder.equal(eventUser.get(User_.id), userId);
		Predicate groupPredicate  = criteriaBuilder.equal(eventGroup.get(Group_.topGroup), topGroupId);
		Predicate endTimeGreaterThanNowPredicate=criteriaBuilder.greaterThanOrEqualTo(eventRoot.<DateTime>get(Event_.endTime), new DateTime());
		Predicate compositePredicate = criteriaBuilder.and(userPredicate, groupPredicate, endTimeGreaterThanNowPredicate);
		criteria.where(compositePredicate);
		TypedQuery<Event> createQuery = entityManager.createQuery( criteria );
		createQuery.setMaxResults(1);
		return createQuery.getResultList();
	}

}