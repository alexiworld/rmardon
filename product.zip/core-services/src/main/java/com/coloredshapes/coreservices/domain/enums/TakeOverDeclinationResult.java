/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.enums;

public enum TakeOverDeclinationResult {
    SUCCESS("success");
    
    private String value;

    TakeOverDeclinationResult(String value) {
        this.value = value;
    }
    
    public String value() {
    	return this.value;
    }
    
    public String toString(){
        return this.value;
    }

}
