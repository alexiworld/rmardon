/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.Constants;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.exception.AuthenticationException;
import com.coloredshapes.coreservices.exception.AuthorizationException;
import com.coloredshapes.coreservices.security.SecurityUtil;
import com.coloredshapes.coreservices.service.SecurityService;

/**
 * <code>SecurityServiceImpl</code> type is default implementation
 * of the <code>SecurityService</code> interface. 
 */
@Service
public class SecurityServiceImpl implements SecurityService {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The user DAO
	 */
	@Autowired
	private UserDao userDao;
		
	/**
	 * Authenticate user by id and password.
	 * 
	 * @param userId	the user id
	 * @param password	the user password
	 * @throws AuthenticationException if the user credentials are not valid, or an exception
	 * was raised during encryption.
	 */
	@Override
	@Transactional(readOnly=true)
	public Long authenticate(Long userId, String password) throws AuthenticationException {
		User user = userDao.getUser(userId);
		if(user == null) {
			//NOTE: Prevent leaking information which user ids are valid or not.
			//throw new InvalidUserException(userId);
			throw new AuthenticationException();
		}

		String hashedOldPass = null;
		try {
			hashedOldPass = SecurityUtil.getHashInBase64(password, user.getSalt());
		} catch (NoSuchAlgorithmException e) {
			throw new AuthenticationException();
		} catch (IOException e) {
			throw new AuthenticationException();
		}
		
		if(!user.getHashedPassword().equals(hashedOldPass)){
			throw new AuthenticationException();
		}

		return user.getId();
	}

	/**
	 * Authenticate user by email and password.
	 * 
	 * @param email		the user email
	 * @param password	the user password
	 * @throws AuthenticationException if the user credentials are not valid, or an exception
	 * was raised during encryption.
	 */
	@Override
	@Transactional(readOnly=true)
	public Long authenticate(String email, String password) throws AuthenticationException {
		User user = userDao.getUser(email);
		if(user == null) {
			//NOTE: Prevent leaking information which emails are valid or not.
			//throw new InvalidUserException(email);
			throw new AuthenticationException();
		}

		String hashedOldPass = null;
		try {
			hashedOldPass = SecurityUtil.getHashInBase64(password, user.getSalt());
		} catch (NoSuchAlgorithmException e) {
			throw new AuthenticationException();
		} catch (IOException e) {
			throw new AuthenticationException();
		}
		
		if(!user.getHashedPassword().equals(hashedOldPass)){
			throw new AuthenticationException();
		}
		
		return user.getId();
	}


	/**
	 * Validates if user is authorized to manage the group.
	 * 
	 * @param userId	the user id
	 * @param groupId	the group id
	 * @throws AuthorizationException if the user does not have admin rights
	 * on the group.
	 */
	@Transactional(readOnly=true)
	public void authorized(Long userId, Long groupId) throws AuthorizationException {
		User user = userDao.getUser(userId);
		if(user == null) {
			//NOTE: Prevent leaking information which user ids are valid or not.
			//throw new InvalidUserException(userId);
			throw new AuthenticationException();
		}
		
		//NOTE: Group is not verified because if users are not authorized to 
		//see it should not also be aware if the group exist or not.

		List<Assignment> assignments = user.getAssignments();
		for (Assignment assignment : assignments) {
			if (assignment.getGroup().getId() == groupId && 
				Constants.ADMIN_ROLE.equals(assignment.getRole().getName())) {
				return;
			}
		}
		
		throw new AuthorizationException();
	}

}