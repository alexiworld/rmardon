/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.coloredshapes.coreservices.domain.enums.MembershipStatus;

// TODO: Consider the need of similar class Friendship
// connecting users

@Entity
@Table(name = "membership")
public class Membership extends BaseEntity {
	
	/**
	 * This class serial version UID
	 */
	public static final long serialVersionUID = 6545654645L;

	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "group_id", nullable = false)
	private Group group;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "membership_status", nullable = false)
	private MembershipStatus membershipStatus;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	public MembershipStatus getMembershipStatus() {
		return membershipStatus;
	}

	public void setMembershipStatus(MembershipStatus membershipStatus) {
		this.membershipStatus = membershipStatus;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("user", (user == null ? user : user.getId())) 
            .append("group", (group == null ? group : group.getId())) 
        	.append("membershipStatus", membershipStatus) 
            .toString();
    }

}