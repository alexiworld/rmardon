/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.joda.time.DateTime;

/**
 * <code>MessageDto</code> is DTO 
 *
 */
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class MessageDto extends IdDto {

	@Size(max = 64)
	private String subject;
	
	@NotNull
	@Size(min = 1, max = 512)
	private String body;
	
	@NotNull
	private DateTime time;
	
	@NotNull
	private Long sender;
	
	//@NotNull
	private Long recipient;
	
	//@NotNull
	private List<Long> recipients;
	
	@Size(max = 64)
	private String channel;
	
	private Boolean opened;
	
	/**
	 * @return the subject
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the body
	 */
	public String getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(String body) {
		this.body = body;
	}

	/**
	 * @return the time
	 */
	public DateTime getTime() {
		return time;
	}

	/**
	 * @param time the time to set
	 */
	public void setTime(DateTime time) {
		this.time = time;
	}

	/**
	 * @return the sender
	 */
	public Long getSender() {
		return sender;
	}

	/**
	 * @param sender the sender to set
	 */
	public void setSender(Long sender) {
		this.sender = sender;
	}
	
	/**
	 * @return the recipient
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Long getRecipient() {
		return recipient;
	}

	/**
	 * @param recipient the recipient to set
	 */
	public void setRecipient(Long recipient) {
		this.recipient = recipient;
	}

	/**
	 * @return the recipients
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<Long> getRecipients() {
		return recipients;
	}

	/**
	 * @param recipients the recipients to set
	 */
	public void setRecipients(List<Long> recipients) {
		this.recipients = recipients;
	}

	/**
	 * @return the opened
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Boolean getOpened() {
		return opened;
	}

	/**
	 * @param opened the opened to set
	 */
	public void setOpened(Boolean opened) {
		this.opened = opened;
	}

	/**
	 * @return the channel
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("subject", subject) 
            .append("body", body) 
            .append("time", time) 
        	.append("sender", sender) 
            .append("recipient", recipient)   
         	.append("recipients", recipients)   
         	.append("opened", opened)   
         	.append("channel", channel) 
            .toString();
    }

}