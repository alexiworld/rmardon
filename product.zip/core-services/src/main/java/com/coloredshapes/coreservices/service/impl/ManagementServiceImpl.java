/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static java.lang.Boolean.TRUE;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.Validate;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.AssignmentDao;
import com.coloredshapes.coreservices.dao.BusinessDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.MembershipDao;
import com.coloredshapes.coreservices.dao.RoleDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.RoleDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Role;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.AssignmentStatus;
import com.coloredshapes.coreservices.domain.enums.RoleStatus;
import com.coloredshapes.coreservices.exception.InvalidAssignmentException;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidRoleException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.GroupService;
import com.coloredshapes.coreservices.service.ManagementService;
import com.coloredshapes.coreservices.service.UserService;

@Service
public class ManagementServiceImpl implements ManagementService {
	
	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private BusinessDao businessDao;

	@Autowired
	private AssignmentDao assignmentDao;

	@Autowired
	private MembershipDao membershipDao;
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private GroupService groupService;

	@Autowired
	private UserService userService;

	@Autowired
	private RoleDao roleDao;
	
	@Resource(name="dozerBeanMapper")
	private DozerBeanMapper beanMapper;

	@Override
	@Transactional
	public void addUser(Long groupId, Long userId) {
		Validate.notNull(groupId, "Group id is missing");
		Validate.notNull(userId, "User id is missing");

		Group group = groupDao.getGroup(groupId);
		if(group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		User user = userDao.getUser(userId);
		if(user == null) {
			throw new InvalidGroupException(userId);
		}

		// It is sufficient to add the user to users of group. The following examples confirm
		// this understanding. The side having Many2Many with mapping attribute is not used.
		// http://www.roseindia.net/hibernate/hibernate4/HibernateManytoMany.shtml
		// http://viralpatel.net/blogs/hibernate-many-to-many-annotation-mapping-tutorial/
		// http://www.mkyong.com/hibernate/hibernate-many-to-many-relationship-example-annotation/

		group.getUsers().add(user);
		//user.getGroups().add(group);
		groupDao.update(group);
		//userDao.update(user); // TODO: Might not be needed, omitting could save an update SQL statement. 
	}

	@Override
	@Transactional
	public void addUser(Long groupId, UserCompleteDto userDto) {
		Validate.notNull(groupId, "Group id is missing");

		Group group = groupDao.getGroup(groupId);
		if(group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		Long userId = userService.createUser(userDto);
		Validate.notNull(userId, "User id is missing");

		User user = userDao.getUser(userId);
		if(user == null) {
			throw new InvalidGroupException(userId);
		}
		
		group.getUsers().add(user);
		user.getGroups().add(group);
		groupDao.update(group);
		userDao.update(user); // TODO: Might not be needed, omitting could save an update SQL statement. 
	}

	@Override
	@Transactional
	public void removeUser(Long groupId, Long userId) {
		Validate.notNull(groupId, "Group id is missing");
		Validate.notNull(userId, "User id is missing");

		Group group = groupDao.getGroup(groupId);
		if(group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		User user = userDao.getUser(userId);
		if(user == null) {
			throw new InvalidGroupException(userId);
		}

		List<Assignment> assignments = group.getAssignments();
		for (Iterator<Assignment> iterator = assignments.iterator(); iterator.hasNext();) {
			Assignment assignment = iterator.next();
			if (assignment.getUser().getId() == user.getId()) {
				assignment.setStatus(AssignmentStatus.INACTIVE);
			}
		}

		// TODO: remove user from a top group might be associated with cancelling his/her membership.
		// This would however require 1) when adding the user to a group to add the user to the top
		// group (btw, adding to the top group might trigger "initiate a membership" step)
		// 2) checking all other sub groups of top group of the selected group to see if the user is
		// present and if none of them has it cancel the membership.
		// 3) DO NOT CANCEL MEMBERSHIP when removing the user from a group (+ simple, - would require 
		// "initiate a membership" to be called separately from addUser unless otherwise is decided) 
		
		group.getUsers().remove(user);
		user.getGroups().remove(group);
		groupDao.update(group);
		userDao.update(user); // TODO: Might not be needed, omitting could save an update SQL statement. 
	}

	@Override
	@Transactional
	public void createRole(RoleDto roleDto) {
		Validate.notNull(roleDto, "Role is missing");
		Long groupId = roleDto.getGroupId();
		Validate.notNull(groupId, "Group id is missing");

		Group group = groupDao.getGroup(groupId);
		if(group == null) {
			throw new InvalidGroupException(groupId);
		}
		
		Role role = beanMapper.map(roleDto, Role.class);
		role.setGroup(group);
		role.setStatus(RoleStatus.PENDING);
		role.setStatus(RoleStatus.ACTIVE);

		roleDao.create(role);
		//group.getRoles() will return the newly added role
		//group.getRoles().add(role);
		//groupDao.update(group);
		
		roleDto.setId(role.getId());
	}

	@Override
	@Transactional
	public void updateRole(RoleDto roleDto) {
		Validate.notNull(roleDto, "Role is missing");
		Long groupId = roleDto.getGroupId();
		Validate.notNull(groupId, "Group id is missing");

		Role role = roleDao.find(roleDto.getId());
		if(role == null) {
			throw new InvalidGroupException(roleDto.getId());
		}
		
		RoleStatus status = role.getStatus();
		if (roleDto.getStatus() == null) {
			roleDto.setStatus(status);
		}

		beanMapper.map(roleDto, role);
		roleDao.update(role);
	}

	@Override
	@Transactional
	public void removeRole(Long roleId) {
		Validate.notNull(roleId, "Role id is missing");

		Role role = roleDao.find(roleId);
		if(role == null) {
			throw new InvalidGroupException(roleId);
		}
		
		Group group = role.getGroup();
		
		/*
		// Delete existing assignments to this role. 
		// TODO: Handle the case when there are scheduled events related to this role.
		List<Assignment> assignments = group.getAssignments();
		for (Iterator<Assignment> iterator = assignments.iterator(); iterator.hasNext();) {
			Assignment assignment = iterator.next();
			if (assignment.getRole().getId() == role.getId()) {
				iterator.remove();
				assignmentDao.delete(assignment);
			}
		}
		
		group.getRoles().remove(role);
		groupDao.update(group);
		*/

		role.setStatus(RoleStatus.INACTIVE);
		
		List<Assignment> assignments = group.getAssignments();
		for (Iterator<Assignment> iterator = assignments.iterator(); iterator.hasNext();) {
			Assignment assignment = iterator.next();
			if (assignment.getRole().getId() == role.getId()) {
				assignment.setStatus(AssignmentStatus.INACTIVE);
			}
		}

		groupDao.update(group);
	}

	@Override
	@Transactional
	public void createAssignment(AssignmentDto assignmentDto) {
		Validate.notNull(assignmentDto, "Assignment DTO is missing");

		Long roleId = assignmentDto.getRoleId();
		Long userId = assignmentDto.getUserId();
		
		Validate.notNull(roleId, "Role id is missing");
		Validate.notNull(userId, "User id is missing");
		
		Role role = roleDao.find(roleId);
		if(role == null) {
			throw new InvalidRoleException(roleId);
		}
		
		Group group = role.getGroup();
		
		User user = userDao.getUser(userId);
		if(user == null) {
			throw new InvalidGroupException(userId);
		}
		
		// The user will automatically join the group if s/he is assigned a role in group
		boolean found = false;
		List<User> groupUsers = group.getUsers();
		for (User groupUser : groupUsers) {
			if (groupUser.getId() == userId) {
				found = true;
			}
		}
		if (!found) {
			groupUsers.add(user);
			groupDao.update(group);
			// or another alternative is
			// addUser(group.getId(), user.getId());
		}
		
		Assignment assignment = new Assignment();
		assignment.setGroup(group);
		assignment.setRole(role);
		assignment.setUser(user);
		assignment.setHours(assignmentDto.getHours());
		assignment.setRate(assignment.getRate());
		assignment.setStatus(AssignmentStatus.PENDING);
		assignment.setStatus(AssignmentStatus.ACTIVE);
		
		assignmentDao.create(assignment);
		
		group.getAssignments().add(assignment);
		//groupDao.update(group); // TODO: Might not be needed, omitting could save an update SQL statement.
		
		user.getAssignments().add(assignment);
		//userDao.update(user); // TODO: Might not be needed, omitting could save an update SQL statement.
		
		assignmentDto.setId(assignment.getId());
	}
	
	@Override
	@Transactional
	public void updateAssignment(AssignmentDto assignmentDto) {
		Validate.notNull(assignmentDto, "Assignment DTO is missing");
		Long userId = assignmentDto.getUserId();
		Validate.notNull(userId, "User id is missing");
		Long roleId = assignmentDto.getRoleId();
		Validate.notNull(roleId, "Role id is missing");

		Assignment assignment = assignmentDao.find(assignmentDto.getId());
		if(assignment == null) {
			throw new InvalidAssignmentException(assignmentDto.getId());
		}
		
		beanMapper.map(assignmentDto, assignment);
		assignmentDao.update(assignment);
	}
	
	@Override
	@Transactional
	public void removeAssignment(Long assignmentId) {
		Validate.notNull(assignmentId, "Assignment id is missing");
		
		Assignment assignment = assignmentDao.find(assignmentId);
		if(assignment == null) {
			throw new InvalidRoleException(assignmentId);
		}

		/*
		Group group = assignment.getGroup();
		User user = assignment.getUser();

		group.getAssignments().remove(assignment);
		groupDao.update(group); // TODO: Might not be needed, omitting could save an update SQL statement.
		
		user.getAssignments().remove(assignment);
		userDao.update(user); // TODO: Might not be needed, omitting could save an update SQL statement. 

		assignmentDao.delete(assignmentId);
		*/
		
		assignment.setStatus(AssignmentStatus.INACTIVE);
		assignmentDao.update(assignment);
	}

	/** 
	 * Creates a new user and assign him/her a new or existing role.
	 * 
	 * Note: groupId is optional parameter for limiting the scope to
	 * a specific group.
	 */
	@Override
	@Transactional
	public void createUserAssignments(UserCompleteDto userDto, Long groupId) {
		if (userDto == null) {
			throw new InvalidUserException((Long) null);
		}

		if (userDto == null || userDto.getId() != null) {
			throw new InvalidUserException((Long) null);
		}

		// The user Id will automatically be updated in the DTO 
		// and hence there is no need to collect the return value
		userService.createUser(userDto);

		updateUserAssignments(userDto, groupId);
	}
	
	/** 
	 * Adds a new role or select a different role that exists
	 * and updates the assignment to refer to newly created or 
	 * selected role.
	 * 
	 * Note: groupId is optional parameter for limiting the scope to
	 * a specific group.
	 */
	@Override
	@Transactional
	public void updateUserAssignments(UserCompleteDto userDto, Long groupId) {
		if (userDto == null) {
			throw new InvalidUserException((Long) null);
		}

		if (userDto == null || userDto.getId() == null) {
			throw new InvalidUserException((Long) null);
		}

		//
		// If the user has not been previously added to the group at the time
		// of assignment the user will be automatically added to the group.
		//
		
		User user = userDao.getUser(userDto.getId());

		if (user == null) {
			throw new InvalidUserException(userDto.getId());
		}
		
		boolean foundGroup = false;
		List<Group> groups = user.getGroups();
		for (Group group : groups) {
			if (group.getId() == groupId) {
				foundGroup = true;
				break;
			}
		}
		
		if (!foundGroup) {
			addUser(groupId, userDto.getId());
		}

		//
		// When user DTO contains all assignments any other previously 
		// persisted assignments will be considered as to be deleted.
		//
		
		if (TRUE.equals(userDto.getContainsAllAssignments())) {
			//TODO: This must delete only assignments under the selected group!!!

			// NOTE that methods returning assignments by status might be good to be added to group and user types. 
			// RESULT CPU time will be saved by filtering the resources subject to interest prior processing them.
			List<Assignment> assignments = user.getAssignments(AssignmentStatus.ACTIVE);
			List<AssignmentDto> assignmentDtos = userDto.getAssignments();
			List<Assignment> deletedAssignments = new LinkedList<Assignment>(); 
			for (Assignment assignment : assignments) {
				boolean found = false;
				for (AssignmentDto assignmentDto : assignmentDtos) {
					if (assignment.getId() == assignmentDto.getId()) {
						if (groupId == null || 
							groupId.equals(assignment.getGroup().getId())) {
							found = true;
							break;
						}
					}
				}
				if (!found) {
					deletedAssignments.add(assignment);
				}
			}

			for (Assignment deletedAssignment : deletedAssignments) {
				Group group = deletedAssignment.getGroup();
				List<Assignment> groupAssignments = group.getAssignments();
				groupAssignments.remove(deletedAssignment);
				user.getAssignments().remove(deletedAssignment);
				// ATTEMPT to preserve data from physical deletion.
				// assignmentDao.delete(deletedAssignment.getId());
				removeAssignment(deletedAssignment.getId());
			}
		}
		
		//
		// Create new or update existing assignments coming together with
		// user DTO.
		//
			
		List<AssignmentDto> assignmentDtos = userDto.getAssignments();
		for (AssignmentDto assignmentDto : assignmentDtos) {
	    	if (assignmentDto != null) {
	    		RoleDto roleDto = assignmentDto.getRole();
				
	    		if (assignmentDto.getRoleId() == null) {
					if (assignmentDto.getRole() == null) {
						throw new InvalidRoleException((Long) null);
					} 
					
					Long roleId = roleDto.getId();
					if (roleId != null) {
						throw new InvalidRoleException(roleId);
					}
					
					createRole(roleDto);
					assignmentDto.setRoleId(roleDto.getId());
				}

	    		Long assignmentId = assignmentDto.getId();
	    		if (assignmentId != null) {
	    			Assignment assignment = assignmentDao.find(assignmentId);
	    			
	    			user = assignment.getUser();
	    			if (!user.getId().equals(userDto.getId())) {
	    				throw new InvalidUserException(userDto.getId());
	    			}

	    			Role role = roleDao.find(assignmentDto.getRoleId());
	    			assignment.setRole(role);
	    			
	    			assignment.setHours(assignmentDto.getHours());
	    			assignment.setRate(assignmentDto.getRate());
	    			
	    			assignmentDao.update(assignment);
	    		} else {
					assignmentDto.setUserId(userDto.getId());
					createAssignment(assignmentDto);
	    		}
	    	}
		}
	}
	
}