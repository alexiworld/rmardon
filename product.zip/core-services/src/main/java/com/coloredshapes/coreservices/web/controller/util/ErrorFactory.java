/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller.util;

import com.coloredshapes.coreservices.web.dto.ErrorResp;

/**
 * <code>ErrorFactory</code> is a factory creating error DTOs
 *
 */
public interface ErrorFactory {
	
	ErrorResp creatError(Exception ex);

}
