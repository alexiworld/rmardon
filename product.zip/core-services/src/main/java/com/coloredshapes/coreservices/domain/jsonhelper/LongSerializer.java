/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

/**
 * <code>LongSerializer</code> is a class used
 * to proper serialization of Long numbers.
 */
public class LongSerializer extends JsonSerializer<Long> {

	@Override
	public void serialize(Long value, JsonGenerator jgen,
			SerializerProvider provider) throws IOException,
			JsonProcessingException {
        String s=String.valueOf(value);
		jgen.writeString(s);
		
	}

}
