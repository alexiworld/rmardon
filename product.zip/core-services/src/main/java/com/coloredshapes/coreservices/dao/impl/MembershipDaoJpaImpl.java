/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.MembershipDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.exception.InvalidUserException;
@Repository
public class MembershipDaoJpaImpl extends BaseJpaImpl<Membership> implements MembershipDao {

	@Autowired
	private  UserDao userDao;

	@Override
	public void createMembership(final Membership membership) {
		create(membership);
	}

	@Override
	public List<Membership> getMembershipListByUserId(Long userId) throws InvalidUserException {
		User user = userDao.getUser(userId);
		List<Membership> membership = user.getMemberships();
		return membership;
	}
	
	@Override
	public Membership getMembershipByTopGroupIdAndUserId(final Long topGroupId, final Long userId)  {
		TypedQuery<Membership> query = entityManager.createQuery(
		        "SELECT gm FROM Membership gm WHERE gm.group.id= :groupId and gm.user.id = :userId ", Membership.class);
	    query.setParameter("groupId", topGroupId); 
	    query.setParameter("userId", userId);
	    List<Membership> resultList = query.setMaxResults(1).getResultList();
	    if (resultList==null || resultList.size()==0){
	    	return null;
	    } else {
	    	return resultList.get(0);
	    }
	}

}