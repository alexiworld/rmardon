/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.lang.Validate;
import org.dozer.DozerBeanMapper;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.RepeatableEventDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.RepeatableEventDto;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.RepeatableEventService;

@Service
public class RepeatableEventServiceImpl implements RepeatableEventService {
	
	@Autowired
	private RepeatableEventDao repeatableEventDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private EventDao eventDao;
	
	@Resource(name = "envProperties")
	private Properties envProperties;
	
	@Resource(name="dozerBeanMapper")
	private DozerBeanMapper beanMapper;
	
	/**
	 * Creates repeatable events.
	 * 
	 * @param events
	 *            events to be saved
	 * @param userId
	 *            indicating for whom are the events
	 * @return the outcome of this operation
	 */
	@Override
	@Transactional
	public Map<Outcome, List<RepeatableEventDto>>  createRepeatableEvents(final List<RepeatableEventDto> eventDtos, final Long userId) throws InvalidUserException {
		Validate.notNull(userId,"user key is empty");
		
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}
		
		Map<Outcome, List<RepeatableEventDto>> outcome = new LinkedHashMap<Outcome, List<RepeatableEventDto>>();
		List<RepeatableEventDto> success = new LinkedList<RepeatableEventDto>();
		List<RepeatableEventDto> failure = new LinkedList<RepeatableEventDto>();
		outcome.put(Outcome.SUCCESS, success);
		outcome.put(Outcome.FAILURE, failure);
		
		for (RepeatableEventDto eventDto : eventDtos) {
			RepeatableEvent event = new RepeatableEvent();
			event.setDayOfWeek(eventDto.getDayOfWeek());
			event.setStartTime(eventDto.getStartTime());
			event.setEndTime(eventDto.getEndTime());
			event.setNote(eventDto.getNote());
			
			//check group event conflict
			DateTime now = new DateTime();
			int maxAllowableWeek = Integer.parseInt((String) envProperties.get("maxAllowableWeek"));
			DateTime maxEndTime = now.plusWeeks(maxAllowableWeek);
			SourceType[] sourceTypes = new SourceType[] { SourceType.GROUP };
			List<Event> userEvents = eventDao.getEventsByUserId(now, maxEndTime, userId, sourceTypes, null);
			boolean groupEventConflict = false;
			for (Event userEvent : userEvents) {
				DateTime startTime = userEvent.getStartTime();
				DateTime endTime = userEvent.getEndTime();
				//start and end date the same day and as day as the day block
				if((event.getDayOfWeek().ordinal()+1==startTime.getDayOfWeek()) && (startTime.getDayOfWeek()==endTime.getDayOfWeek())){
					if((event.getStartTime().getMillisOfDay() >= startTime.getMillisOfDay() && event.getStartTime().getMillisOfDay() <= endTime.getMillisOfDay())||
					   (event.getEndTime().getMillisOfDay()   >= startTime.getMillisOfDay() && event.getEndTime().getMillisOfDay()   <= endTime.getMillisOfDay())||
					   (event.getStartTime().getMillisOfDay() <= startTime.getMillisOfDay() && event.getEndTime().getMillisOfDay()   >= endTime.getMillisOfDay())){
						groupEventConflict=true;
						break;
					}
				} else if (event.getDayOfWeek().ordinal() + 1 == startTime.getDayOfWeek()) {
					if(event.getStartTime().getMillisOfDay() >= startTime.getMillisOfDay()){
						groupEventConflict=true;
						break;
					}
				} else if (event.getDayOfWeek().ordinal() + 1 == endTime.getDayOfWeek()) {
					if (event.getStartTime().getMillisOfDay() <= endTime.getMillisOfDay()) {
						groupEventConflict=true;
						break;
					}
				} else {
					//no conflict
				}
			}

			//if group block conflict ,place the this day event in the que
			if (groupEventConflict){
				failure.add(eventDto);
				continue;
			}
			
            //check day event conflict
			RepeatableEvent conflictEvent = repeatableEventDao.
				getRepeatableEventStartOrEndBetween(event.getDayOfWeek(), event.getStartTime(), event.getEndTime(), userId);
			//no conflict 
			if (conflictEvent == null) {
				event.setUser(user);
				repeatableEventDao.create(event);
				eventDto.setId(event.getId());
				success.add(eventDto);
			} else {
				// has conflict
				failure.add(eventDto);
			}
		}
		
		
		return outcome;
	}
	
	/**
	 * Retrieves a user's repeatable events (i.e a period of time in a week day)
	 * 
	 * @param userId
	 *            indicating the user who's events to retrieve
	 * @return map of repeatable events grouped by day of week
	 */
	@Override
	@Transactional(readOnly=true)
	public Map<DayOfWeek, List<RepeatableEventDto>> getRepeatableEvents(Long userId) {
		Validate.notNull(userId,"user id is empty");
		List<RepeatableEvent> repeatableEvents = repeatableEventDao.getRepeatableEventByUserId(userId);
		Collections.sort(repeatableEvents);
		
		Map<DayOfWeek, List<RepeatableEventDto>> repeatableEventsMap = new LinkedHashMap<DayOfWeek, List<RepeatableEventDto>>();
		for (RepeatableEvent repeatableEvent : repeatableEvents) {
			/*
			Let's not kill the fish with nuclear weapon
			BeanMappingBuilder builder = new BeanMappingBuilder() {
				protected void configure() {
					mapping(User.class, UserCompleteDto.class)
						.exclude("user").exclude("userId");
				}
			};
			DozerBeanMapper beanMapper = new DozerBeanMapper();
			beanMapper.addMapping(builder);
			RepeatableEventDto repeatableEventDto = beanMapper.map(repeatableEvent, RepeatableEventDto.class);
			*/
			// The day of week for this operation is not passed via DTO to avoid information redundancy
			RepeatableEventDto repeatableEventDto = new RepeatableEventDto();
			repeatableEventDto.setId(repeatableEvent.getId());
			repeatableEventDto.setStartTime(repeatableEvent.getStartTime());
			repeatableEventDto.setEndTime(repeatableEvent.getEndTime());
			repeatableEventDto.setNote(repeatableEvent.getNote());
			
			List<RepeatableEventDto> repeatableEventsByDayOfWeek = repeatableEventsMap.get(repeatableEvent.getDayOfWeek());
			if (repeatableEventsByDayOfWeek != null) {
				repeatableEventsByDayOfWeek.add(repeatableEventDto);
			} else {
				repeatableEventsByDayOfWeek = new LinkedList<RepeatableEventDto>();
				repeatableEventsByDayOfWeek.add(repeatableEventDto);
				repeatableEventsMap.put(repeatableEvent.getDayOfWeek(), repeatableEventsByDayOfWeek);
			}
		}
 
		return repeatableEventsMap;
	}

	@Override
	@Transactional
	public void deleteRepeatableEvent(Long userId, List<Long> eventIds) throws InvalidUserException {
		Validate.notNull(userId,"user id is empty");
		User user = userDao.getUser(userId);
		if(user==null){
			throw new InvalidUserException(userId);
		}
		repeatableEventDao.deleteRepeatableEventsOfUser(userId, eventIds);
	}

}