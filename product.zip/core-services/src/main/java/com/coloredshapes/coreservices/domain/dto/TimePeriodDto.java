/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.exception.InvalidEventException;

/**
 * <code>TimePeriodDto</code> class represents a period of
 * time with start and end time.
 */
public class TimePeriodDto implements Comparable<TimePeriodDto>{
	
	private DateTime startTime;
	private DateTime endTime;

    /**
     * Creates a time period instance
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     */
    public TimePeriodDto(Long startTime, Long endTime) {
        this(new DateTime(startTime), new DateTime(endTime));
    }

    /**
     * Creates a time period instance
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     */
    public TimePeriodDto(DateTime startTime, DateTime endTime) {
        validateBeforeCreate(startTime,endTime);
        this.startTime = startTime;
        this.endTime = endTime;
    }

    /**
     * Validates times before creating the period instance.
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     * @throws InvalidEventException is raised if the start time appears to be later than the end time.
     */
    private static void validateBeforeCreate(DateTime startTime, DateTime endTime) throws InvalidEventException {
        if(endTime.isBefore(startTime)){
            throw new InvalidEventException("End Time must be after Start Time");
        }
    }

    /**
     * Gets the start time
     * 
     * @return	the start time
     */
    public DateTime getStartTime(){
    	return startTime;
    }

    /**
     * Gets the end time
     * 
     * @return	the end time
     */
    public DateTime getEndTime(){
        return endTime;
    }

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("startTime", startTime)
            .append("endTime", endTime)
            .toString();
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof TimePeriodDto)) return false;

        TimePeriodDto timePeriod = (TimePeriodDto) that;

        return new EqualsBuilder()
	        .append(startTime, timePeriod.startTime)
	        .append(endTime, timePeriod.endTime)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
	        .append(startTime)
	        .append(endTime)
	        .hashCode();
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(TimePeriodDto that) {
        if (this == that) return 0;

        int result = this.startTime.compareTo(that.startTime);
        if (result == 0) {
        	result = this.endTime.compareTo(that.endTime);
        }
        return result;
    }

    /**
     * Compares two time periods for conflicts.
     * 
     * @param that	the other time period to compare
     * @return	true if time periods overlap, false otherwise
     */
    public boolean conflictsWith(TimePeriodDto that) {
        if (this.equals(that) || this==that){
            return true;
        }
        if(this.startTime.isAfter(that.endTime)){
            return false;
        }
        if(this.endTime.isBefore(that.startTime)){
            return false;
        }
        return true;
    }
}
