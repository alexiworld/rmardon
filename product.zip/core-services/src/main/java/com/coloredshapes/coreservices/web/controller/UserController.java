/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import static com.coloredshapes.coreservices.Constants.NO_GROUP_LIMITED;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.CompositeDto;
import com.coloredshapes.coreservices.domain.dto.UserBasicDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.ManagementService;
import com.coloredshapes.coreservices.service.UserAgreementService;
import com.coloredshapes.coreservices.service.UserService;
import com.coloredshapes.coreservices.utils.StandardUtils;
import com.coloredshapes.coreservices.web.dto.ChangePasswordReq;

@Controller
public class UserController extends BaseController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private UserAgreementService userAgreementService;
	
	@Autowired
	private ManagementService managementService;

	/**
	 * REST service for group to retrieve the list of active users.
	 * 
	 * @param groupId		the group Id
	 * @return	list of active users
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/groups/{groupId}/users", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Long[] getGroupUsers(@PathVariable("groupId") String groupIdCode,
            					@RequestParam ContentStatus contentStatus)
    throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("content status: " + contentStatus);
		}

		Long groupId = StandardUtils.decodeLong(groupIdCode);

		List<Long> userIds = userService.getGroupUserIds(groupId, contentStatus);
		
		if (logger.isDebugEnabled()) {
			logger.debug("userIds: " + userIds);
		}

		return userIds.toArray(new Long[0]);
	}
	
	/**
	 * REST service for group to retrieve the user profiles.
	 * 
	 * @param emails			user identifiers (id or email)
	 * @param contentLimit		the amount information to be present in the response
	 * @param contentStatus		the type information to be included (active vs inactive)
	 * @return	list of users with their details
	 * @throws Exception	raised in case something goes wrong
	 */
	// TODO: Consider filtering of roles by group, which might be optional request parameter. The gain is that
	// admin roles (depending on how many groups user is member of) will be returned only for selected group
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<UserBasicDto> getUsers(@RequestParam(value="users", required=true) String userIdCodeOrEmails, 
			                           @RequestParam(value="groupId", required=false) String groupIdCode, 
			   						   @RequestParam ContentLimit contentLimit,
									   @RequestParam ContentStatus contentStatus)
	throws Exception {
		String[] tokens = StringUtils.split(userIdCodeOrEmails, ',');
		if (tokens == null || tokens.length == 0) {
			return Collections.emptyList();
		}

		List<Long> userIds = new LinkedList<Long>();
		List<String> userEmails = new LinkedList<String>();

		for (String token : tokens) {
			if (token.indexOf('@') >= 0) {
				String userEmail = token;
				userEmails.add(userEmail);
			} else {
				String userIdCode = token;
				Long userId = StandardUtils.decodeLong(userIdCode);
				userIds.add(userId);
			}
		}

		Long groupId = StandardUtils.decodeLong(groupIdCode);

		List<UserBasicDto> users = new ArrayList<UserBasicDto>(userEmails.size() + userIds.size());
		if (userIds.size() > 0) {
			List<UserBasicDto> usersBasedOnIds = 
					userService.getUsers(userIds.toArray(new Long[0]), contentLimit, contentStatus, groupId);
			users.addAll(usersBasedOnIds);
		}
		if (userEmails.size() > 0) {
			List<UserBasicDto> usersBasedOnEmails = 
					userService.getUsers(userEmails.toArray(new String[0]), contentLimit, contentStatus, groupId);
		    users.addAll(usersBasedOnEmails);
		}
		
		return users;
	}
	
	@RequestMapping(value = "/users/{userId}", method = RequestMethod.GET)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.OK)
	public UserBasicDto getUser(@PathVariable("userId") String userIdCode, 
					            @RequestParam ContentLimit contentLimit,
					            @RequestParam ContentStatus contentStatus)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("get group with id: " + userIdCode);
			logger.debug("content limit: " + contentLimit);
			logger.debug("content status: " + contentStatus);
		}

		Long userId = StandardUtils.decodeLong(userIdCode);
		return userService.getUser(userId, contentLimit, contentStatus, NO_GROUP_LIMITED);
	}

	/**
	 * REST service for user to retrieve his/her couser profiles.
	 * 
	 * @param contentLimit		the amount information to be present in the response
	 * @param contentStatus		the type information to be included (active vs inactive)
	 * @return	list of composite DTOs, each one having group and cousers details
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/cousers", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<CompositeDto> getGroupsCoUsers(@RequestParam ContentLimit contentLimit,
									   	       @RequestParam ContentStatus contentStatus)
	throws Exception {
		Long userId = Long.valueOf(StandardUtils.getUser());
		List<CompositeDto> groupsCoUsers = userService.getGroupsCoUsers(userId, contentLimit, contentStatus);
		return groupsCoUsers;
	}

	@RequestMapping(value = "/users", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String,String> postUser(@RequestBody UserCompleteDto userDto, @RequestParam(required=false) String groupIdCode) 
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("user: " + ReflectionToStringBuilder.toString(userDto));
			logger.debug("group id: " + groupIdCode);
		}
		
		Map<String, String> resp = new LinkedHashMap<String, String>();

		if (userDto.getAssignments() == null) {
			Long userId = userService.createUser(userDto);
			String userIdCode = StandardUtils.encodeLong(userId);
			resp.put("userId", userIdCode);
		} else {
			Long groupId = StandardUtils.decodeLong(groupIdCode);
			managementService.createUserAssignments(userDto, groupId);
			String userIdCode = StandardUtils.encodeLong(userDto.getId());
			resp.put("userId", userIdCode);
			// TODO: return assignment and role Ids too.
		}
		
		return resp;		
	}
	
	@RequestMapping(value = "/users/{userId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void updateUser(@PathVariable("userId") String userIdCode, @RequestBody UserCompleteDto userDto) 
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("user id: " + userIdCode);
			logger.debug("user: " + ReflectionToStringBuilder.toString(userDto));
		}

		if (userIdCode == null) {
			throw new InvalidUserException(userIdCode);
		}
		
		Long userId = StandardUtils.decodeLong(userIdCode);
		
		if (userId == null || userDto == null || !userId.equals(userDto.getId())) {
			throw new InvalidGroupException(userId);
		}
		
		userService.updateUser(userDto);
	}
	
	/**
	 * REST service for confirming user registration.
	 * 
	 * @param refNum		the reference number for member invitation
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/users/confirmation", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	public void updateUserStatus(@RequestParam(required=true) String refNum)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("reference number: " + refNum);
		}

		userService.confirmUserRegistration(refNum);
	}
	
	/**
	 * REST service for changing password request.A temp passwword will be sent to user's email
	 * 
	 * @param userId		the user's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/authentications", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public UserCompleteDto userAuthentication()
	throws Exception {
		Long userId = Long.valueOf(StandardUtils.getUser());
		UserCompleteDto userDto = (UserCompleteDto) 
			userService.getUser(userId, ContentLimit.COMPLETE, ContentStatus.ACTIVE, NO_GROUP_LIMITED);
		boolean isLatestAgreementAccepted = userAgreementService.isLatestAgreementAccepted(userId);
		userDto.setMustAcceptAgreement(!isLatestAgreementAccepted);
		return userDto;
	}

	/**
	 * REST service for changing password request.A temp passwword will be sent to user's email
	 * 
	 * @param userId		the user's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/authentications/{email}/recovery-passwords", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void recoveryOfPassword(@PathVariable String email)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("email: " + email);
		}

		userService.sendChangePasswordRequest(StringUtils.lowerCase(email));
	}
	
	
	/**
	 * REST service for changing password request.A temp passwword will be sent to user's email
	 * 
	 * @param userId		the user's Id
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/authentications/{email}/change-passwords", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void changeOfPassword(@PathVariable String email, @RequestBody ChangePasswordReq req)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("email: " + email);
			logger.debug("change password request: " + ReflectionToStringBuilder.toString(req));
		}

		userService.changePassword(StringUtils.lowerCase(email), 
								   req.getOldPassword(), 
								   req.getNewPassword());
	}

}