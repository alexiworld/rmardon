/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;
import com.coloredshapes.coreservices.exception.InvalidEventException;

/**
 * <code>DateEventDto</code> is a class representing a
 * time slot blocked by a user with a specific note
 * or by a group with a specific note.
 */
public class DateEventDto implements Comparable<DateEventDto> {
	
	private Long id;
	private DateTime startTime;
	private DateTime endTime;
	private Long userId;
	private String user;
	private Long groupId;
	private String group;
	private Long assignmentId;
	private String note;

    /**
     * Creates an date event instance.
     */
	public DateEventDto() {
	}
	
    /**
     * Creates an date event instance.
     * 
     * @param id			the event id
     * @param startTime		the start time
     * @param endTime		the end time
     * @param userId		the user id
     * @param note			the user note
     */
    public DateEventDto(Long id, DateTime startTime, DateTime endTime, Long userId, String note) {
        this(id, startTime, endTime, userId, null, null, note);
    }

    /**
     * Creates an assigined event instance.
     * 
     * @param id			the event id
     * @param startTime		the start time
     * @param endTime		the end time
     * @param userId		the user id
     * @param groupId		the group id
     * @param assignmentId  the assignment id
     * @param note			the user note or group tag
     */
    public DateEventDto(Long id, DateTime startTime, DateTime endTime, Long userId, Long groupId, Long assignmentId, String note) {
        validateBeforeCreate(startTime,endTime);
    	this.id = id;
        this.startTime = startTime;
        this.endTime = endTime;
        this.userId = userId;
        this.groupId = groupId;
        this.assignmentId = assignmentId;
        this.note = note;
    }

    /**
     * Validates times before creating the period instance.
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     * @throws InvalidEventException is raised if the start time appears to be later than the end time.
     */
    private static void validateBeforeCreate(DateTime startTime, DateTime endTime) throws InvalidEventException {
        if(endTime.isBefore(startTime)){
            throw new InvalidEventException("End Time must be after Start Time");
        }
    }
    
	/**
	 * Sets the id
	 * 
	 * @param id the id to set
	 */
	@JsonProperty("eventId")
	@JsonDeserialize(using = IdDeserializer.class)
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the event id
	 * 
	 * @return the id
	 */
	@JsonProperty("eventId")
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getId() {
		return id;
	}

	/**
     * Sets the start time.
     * 
	 * @param startTime the start time to set
	 */
    @JsonDeserialize(using=DateDeserializer.class)
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	/**
     * Gets the start time
     * 
     * @return	the start time
     */
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getStartTime(){
    	return startTime;
    }

	/**
	 * Sets the end time.
	 * 
	 * @param endTime the end time to set
	 */
    @JsonDeserialize(using=DateDeserializer.class)
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	/**
     * Gets the end time
     * 
     * @return	the end time
     */
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getEndTime(){
        return endTime;
    }

	/**
	 * Sets the user id
	 * 
	 * @param userId the user id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user id
	 * 
	 * @return the user id
	 */
	@JsonSerialize(using=IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}

	/**
	 * Sets the user
	 * 
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Gets the user 
	 * 
	 * @return the user
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getUser() {
		return user;
	}

	/**
	 * Sets the group id
	 * 
	 * @param groupId the group id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * Gets the group id
	 * 
	 * @return the group id
	 */
	@JsonSerialize(using=IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getGroupId() {
		return groupId;
	}
	
	/**
	 * Sets the group 
	 * 
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * Gets the group 
	 * 
	 * @return the group
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getGroup() {
		return group;
	}

	/**
	 * Sets the assignment id
	 * 
	 * @param assignmentId the assignment id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setAssignmentId(Long assignmentId) {
		this.assignmentId = assignmentId;
	}

	/**
	 * Gets the assignment id
	 * 
	 * @return the assignment id
	 */
	@JsonSerialize(using=IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getAssignmentId() {
		return assignmentId;
	}

	/**
	 * Sets the note
	 * 
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

    /**
     * Gets the note
     * 
	 * @return the note
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getNote() {
		return note;
	}

	/**
	 * Checks if the event is owned by a user.
	 * 
	 * @return true if the event is owned by a user, false otherwise
	 */
	@JsonIgnore
	public boolean isUserOwned() {
		return (groupId == null);
	}

	/**
	 * Checks if the event is owned by an group.
	 * 
	 * @return true if the event is owned by an group, false otherwise
	 */
	@JsonIgnore
	public boolean isGroupOwned() {
		return (groupId != null);
	}

	/**
	 * Checks if the event is owned by the specified user.
	 * 
	 * @return true if the event is owned by the specified user, false otherwise
	 */
	@JsonIgnore
	public boolean isOwnedByUser(String userKey) {
		return (this.userId.equals(userKey));
	}
	
	/**
	 * Checks if the event is owned by the specified group.
	 * 
	 * @return true if the event is owned by the specified group, false otherwise
	 */
	@JsonIgnore
	public boolean isOwnedByGroup(String groupKey) {
		return (this.groupId != null && this.groupId.equals(groupKey));
	}
	
    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("id", id) 
        	.append("userId", userId) 
            .append("groupId", groupId) 
        	.append("startTime", startTime) //.toString("dd.MM.yyyy HH:mm")
            .append("endTime", endTime)   //.toString("dd.MM.yyyy HH:mm")
            .append("note", note)
            .toString();
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof DateEventDto)) return false;

        DateEventDto otherDateEvent = (DateEventDto) that;

        return new EqualsBuilder()
	        .append(id, otherDateEvent.id)
	        .append(startTime, otherDateEvent.startTime)
	        .append(endTime, otherDateEvent.endTime)
	        .append(userId, otherDateEvent.userId)
	        .append(groupId, otherDateEvent.groupId)
	        .append(note, otherDateEvent.note)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user id is always present, while the group id not.
     * To improve the searching performance in a map the hash
     * code only takes the user id into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
	        .append(id)
	        .append(startTime)
	        .append(endTime)
	        .append(note)
	        .append(userId)
	        .hashCode();
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(DateEventDto that) {
        if (this == that) return 0;

        return new CompareToBuilder()
	        .append(startTime, that.startTime)
	        .append(endTime, that.endTime)
	        .append(userId, that.userId)
	        .append(groupId, that.groupId)
	        .append(note, that.note)
	        .append(id, that.id)
	        .toComparison();
    }

    /**
     * Compares two time periods for conflicts.
     * 
     * @param that	the other time period to compare
     * @return	true if time periods overlap, false otherwise
     */
    public boolean conflictsWith(DateEventDto that) {
        if (this.equals(that) || this==that){
            return true;
        }
        if(this.startTime.isAfter(that.endTime)){
            return false;
        }
        if(this.endTime.isBefore(that.startTime)){
            return false;
        }
        return true;
    }
    
}