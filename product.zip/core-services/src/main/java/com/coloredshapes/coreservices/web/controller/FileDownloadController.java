package com.coloredshapes.coreservices.web.controller;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.ImageDto;
import com.coloredshapes.coreservices.service.ImageService;
 
/**
 * <code>FileDownloadController</code> is used to download photos.
 * http://stackoverflow.com/questions/5673260/downloading-a-file-from-spring-controllers
 *
 */
@Controller
public class FileDownloadController {

	private static final Logger logger = LoggerFactory.getLogger(FileDownloadController.class);

    private final static String saveDirectory = 
    	System.getProperty("user.home") + "/coloredshapes/core-services/photos/"; 
        
    static {
    	File f = new File(saveDirectory);
    	f.mkdir();
    }

    @Autowired
	private ImageService imageService;

    @RequestMapping(value = "/read/{fileName:.*}", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public HttpEntity<byte[]> read(@PathVariable("fileName") String fileName) 
    throws IOException {
		if (logger.isDebugEnabled()) {
			logger.debug("file name: " + fileName);
		}

    	ImageDto image = imageService.readImage(fileName);
    	if (image == null) return null;
    	
    	byte[] documentBody = image.getBytes();
    	String contentType = image.getType();
    	int idx = contentType.indexOf('/');
    	String type = contentType.substring(0, idx);
    	String subtype = contentType.substring(idx+1);
    	
        HttpHeaders header = new HttpHeaders();
        header.setContentType(new MediaType(type, subtype));
        header.setContentLength(documentBody.length);

        return new HttpEntity<byte[]>(documentBody, header);
    }

    @RequestMapping(value = "/download/{fileName:.*}", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public HttpEntity<byte[]> download(@PathVariable("fileName") String fileName) 
    throws IOException {
		if (logger.isDebugEnabled()) {
			logger.debug("file name: " + fileName);
		}

    	File file = new File(saveDirectory + fileName);
    	if (!file.exists()) return null;
    	
    	FileInputStream fos = new FileInputStream(file);
    	DataInputStream dis = new DataInputStream(fos);
    	
        byte[] documentBody = new byte[dis.available()];
        dis.readFully(documentBody);
        dis.close();
        
        int idx = fileName.lastIndexOf('.');
        String subtype = fileName.substring(idx+1);

        HttpHeaders header = new HttpHeaders();
        if (subtype != null) {
        	header.setContentType(new MediaType("image", subtype));
        } else {
        	header.setContentType(new MediaType("image"));
        }
        //header.set("Content-Disposition",
        //           "attachment; filename=" + fileName.replace(" ", "_"));
        header.setContentLength(documentBody.length);

        return new HttpEntity<byte[]>(documentBody, header);
    }
    
	//@RequestMapping(value = "/download/{fileName:.*}", method = RequestMethod.GET)
	//@ResponseBody
	//public FileSystemResource download(@PathVariable("fileName") String fileName) {
	//	File file = new File(saveDirectory + fileName);
	//	return new FileSystemResource(file); 
	//}

}