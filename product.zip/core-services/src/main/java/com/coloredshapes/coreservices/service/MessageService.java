/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.dto.MessageDto;
import com.coloredshapes.coreservices.domain.dto.MessageDtos;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.MembershipRequest;
import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.UserConfirmation;

/**
 * <code>MessageService</code> type is an interface 
 * for sending e-mails out.
 */
public interface MessageService {
	
	void sendRegistrationConfirmationRequest(UserConfirmation confim, User user);

	void sendTemporaryPassword(User user, String password);

	void sendMembershipRequest(MembershipRequest membershipReq, User user, Group group);

	void sendTakeOverRequest(TakeOverRequest sfr);

	void sendTakeOverCancellation(TakeOverRequest sfr);

	/**
	 * Sends out a message from group to users.  
	 * 
	 * @param group		the group
	 * @param users	the users to be notified
	 * @param timePeriod	the time period
	 */
	void sendCollectiveMessage(Group group, List<User> users, TimePeriodDto timePeriod);

	/**
	 * Sends message(s).
	 * 
	 * @param messageDto	the message DTO (may contain sender, recipients, channel, etc.)
	 * @return map with user Ids as keys and message newly created Ids as values
	 */
	Map<Long, Long> sendMessage(MessageDto messageDto);
	
	/**
	 * Get user messages.
	 *  
	 * @param userId	the user id
	 * @return	the messages
	 */
	MessageDtos readMessages(Long userId);
	
	/**
	 * Deletes user message.
	 * 
	 * @param userId		the user id
	 * @param messageId		the message id
	 */
	void deleteMessage(Long userId, Long messageId);
	
	/**
	 * Deletes user messages.
	 * 
	 * @param userId		the user id
	 * @param messageIds	the message ids
	 */
	void deleteMessages(Long userId, List<Long> messageIds);

	
	/**
	 * Deletes all user messages.
	 * 
	 * @param userId		the user id
	 */
	void deleteMessages(Long userId);

	
	/**
	 * Deletes messages between the user and somebody else.
	 * 
	 * Please note that other user will still be able to
	 * see the messages.
	 * 
	 * @param userId		the user id
	 * @param fromtoUserId	the other user id
	 */
	public void deleteMessagesFromTo(Long userId, Long fromtoUserId);

}