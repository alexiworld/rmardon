/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;

public class RequestedEvent {
	
	private Long userId;
	
	/**
	 * start time of the event
	 */
	@NotNull
	@Column(name="start_time")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime startTime;
	
	/**
	 * end time of the event
	 */
	@NotNull
	@Column(name="end_time")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime endTime;
	
	
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@JsonSerialize(using = DateSerializer.class)
	public DateTime getStartTime() {
		return startTime;
	}
	
    @JsonDeserialize(using=DateDeserializer.class)
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}
    
    @JsonSerialize(using = DateSerializer.class)
	public DateTime getEndTime() {
		return endTime;
	}
    
    @JsonDeserialize(using=DateDeserializer.class)
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

}
