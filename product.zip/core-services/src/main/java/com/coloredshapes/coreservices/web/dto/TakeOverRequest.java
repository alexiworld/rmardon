/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.dto;

import java.util.ArrayList;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.coloredshapes.coreservices.domain.entity.TakeOverEvent;

/**
 * <code>TakeOverRequest</code> is class for capturing the data for a take over request (TOR).
 */

public class TakeOverRequest {
	/**
	 * unique key of the TOR
	 */
	private Long eventKey;	
	
	/**
	 * group key
	 */
	private String groupKey;
	
	/**
	 * take over request note
	 */
	private String note;

	/**
	 * list of take over events
	 */
	private TakeOverEvents takeOverEvents;
	
	public String getNote() {
		return note;
	}
	
	public void setNote(String note) {
		this.note = note;
	}
	
	public String getGroupKey() {
		return groupKey;
	}
	
	public void setGroupKey(String groupKey) {
		this.groupKey = groupKey;
	}
	
	public Long getEventKey() {
		return eventKey;
	}
	
	public void setEventKey(Long extKey) {
		this.eventKey = extKey;
	}
	
	public TakeOverEvents getTakeOverEvents() {
		return takeOverEvents;
	}
	
	public void setTakeOverEvents(TakeOverEvents requestedShifts) {
		this.takeOverEvents = requestedShifts;
	}
	
	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
    		.append("eventKey", eventKey) 
            .append("groupKey", groupKey) 
            .append("note", note)
            .toString();
    }
	
	@SuppressWarnings("serial")
	public static class TakeOverEvents extends ArrayList<TakeOverEvent>{}

}