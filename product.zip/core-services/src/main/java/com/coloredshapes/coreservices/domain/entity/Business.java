/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

@Entity
@Table(name = "business")
public class Business extends BaseEntity {

	/**
	 * This class serial version UID
	 */
	public static final long serialVersionUID = 6545645654L;
	
	@Transient
	private Long groupId;

	@NotNull
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "group_id", unique = true)
	private Group group;
	
	@NotNull
	@Column(name = "business_name", unique = true)
	private String businessName;
	
	@NotNull
	@Column(name = "business_number", unique = true)
	private String businessNumber;
	
	@NotNull
	@Column(name = "incorporated_name", unique = true)
	private String incorporatedName;
	
	@NotNull
	@Column(name = "tax_number", unique = true, length=14)
	@Size(min = 0, max = 14)
	@Pattern(regexp="^([a-zA-Z0-9]*)$")
	private String taxNumber;
	
	@NotNull
	@Column(name = "industry") // TODO can be a reference to Industry entity
	private String industry;

	@JsonSerialize(using = IdSerializer.class)
	public Long getGroupId() {
		return groupId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getBusinessNumber() {
		return businessNumber;
	}

	public void setBusinessNumber(String businessNumber) {
		this.businessNumber = businessNumber;
	}

	public String getIncorporatedName() {
		return incorporatedName;
	}

	public void setIncorporatedName(String incorporatedName) {
		this.incorporatedName = incorporatedName;
	}

	public String getTaxNumber() {
		return taxNumber;
	}

	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("groupId", groupId == null ? group.getId() : groupId) 
            .append("businessName", businessName) 
        	.append("businessNumber", businessNumber) 
            .append("incorporatedName", incorporatedName)   
            .append("taxNumber", taxNumber)   
            .append("industry", industry)   
            .toString();
    }

}