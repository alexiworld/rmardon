/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.domain.dto.ImageDto;

/**
 * <code>ImageService</code> type is an interface to manage images.
 */
public interface ImageService {

	/**
	 * Stores an image.
	 * 
	 * @param image	the image to store
	 * 
	 * @return	the newly stored image id, or in other words the entity identifier.
	 */
	Long storeImage(ImageDto imageDto);
	
	/**
	 * Reads an image by ID.
	 * 
	 * @param imageId	the image identifier
	 * 
	 * @return	the image DTO
	 */
	ImageDto readImage(Long imageId);

	/**
	 * Reads an image by file name.
	 * 
	 * @param file	the file name
	 * 
	 * @return	the image DTO
	 */
	ImageDto readImage(String file);

}