/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class InvalidMembershipConfirmationException extends CoreServicesException {
	
	/**
	 * This class serial version UID 
	 */
	private static final long serialVersionUID = 9061900473140468503L;
	private static final String errCode="0011";
	
	@Override
	public String getErrorCode() {
		return errCode;
	}

}
