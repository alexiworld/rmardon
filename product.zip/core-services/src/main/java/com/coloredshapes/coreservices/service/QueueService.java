/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.TakeOverAcceptanceDto;

/**
 * <code>QueueService</code> type is an interface 
 * to send messages.
 */
public interface QueueService {

	/**
	 * Enqueues the events assignment by publishing it to the exchange. 
	 * 
	 * @param dateEventsPatch	a holder for not added/deleted events
	 */
	void enqueueDateEventsPatch(DateEventsPatchDto dateEventsPatch);
	
	/**
	 * Enqueues the event change request to the MQ
	 * 
	 * @param event ids, a list of ids specifying which events to be changed(delete)
	 */
	void enqueueEventChangeRequest(Long[] eventIds);
	
	void enqueueTakeOverAcceptance(TakeOverAcceptanceDto torAcpt);

	void enqueueTakeOverDeclination(TakeOverAcceptanceDto torAcpt);

}