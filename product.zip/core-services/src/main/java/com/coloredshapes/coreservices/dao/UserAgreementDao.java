/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.UserAgreement;

public interface UserAgreementDao extends GenericDao<UserAgreement>{
	
	UserAgreement getLastestAgreement();

}
