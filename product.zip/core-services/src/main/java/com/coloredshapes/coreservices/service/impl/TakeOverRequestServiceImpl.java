/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.TakeOverEventDao;
import com.coloredshapes.coreservices.dao.TakeOverRequestDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.TakeOverAcceptanceDto;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.TakeOverEvent;
import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.TakeOverAcceptanceResult;
import com.coloredshapes.coreservices.domain.enums.TakeOverDeclinationResult;
import com.coloredshapes.coreservices.domain.enums.TakeOverStatus;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidTakeOverRequestException;
import com.coloredshapes.coreservices.exception.InvalidTakeOverRequestStatusException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.EventService;
import com.coloredshapes.coreservices.service.QueueService;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.service.TakeOverRequestService;

@Service
public class TakeOverRequestServiceImpl implements TakeOverRequestService {
	
    @Autowired
    private TakeOverRequestDao takeOverRequestDao;
    
    @Autowired
    private MessageService messageService;
    
	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private TakeOverEventDao takeOverEventDao;
	
	@Autowired
	private EventService eventService;
	
	@Autowired
	private QueueService queueService;
	
	@Override
	@Transactional
	public void sendTakeOverRequest(TakeOverRequest tor) {
		Validate.notNull(tor.getGroupId(),"group key is empty");
		
		Group group = groupDao.getGroup(tor.getGroupId());
		if(group == null) {
			throw new InvalidGroupException(tor.getGroupId());
		}
		
		List<TakeOverEvent> takeOverEvents = tor.getTakeOverEvents();
		tor.setGroup(group);
		tor.setStatus(TakeOverStatus.OPEN);
		
		for (int i = 0; i < takeOverEvents.size(); i++) {
			TakeOverEvent takeOverEvent = takeOverEvents.get(i);
			User user = userDao.getUser(takeOverEvent.getUserId());
			if (user != null) {
				takeOverEvent.setUser(user);
				takeOverEvent.setStatus(TakeOverStatus.OPEN);
			} else {
				takeOverEvents.remove(i);
			}
		}
		
		messageService.sendTakeOverRequest(tor);
		takeOverRequestDao.create(tor);
	}

	@Override
	@Transactional
	public TakeOverDeclinationResult declineTakeOverRequest(Long torId, Long userId) {
		Validate.notNull(torId,"torId is empty");
		Validate.notNull(userId,"userId is empty");
		
		TakeOverRequest tor = takeOverRequestDao.getTakeOverRequestById(torId);
		if (tor == null) {
        	throw new InvalidTakeOverRequestException();
        }

        User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId) ;
		}
		
		TakeOverEvent toe = takeOverEventDao.getTakeOverEvent(tor.getId(), user.getId());
		if (toe == null) {
			throw new InvalidTakeOverRequestException();
		}
		
		TakeOverEvent userTakeOverEvent = null;
		
		List<TakeOverEvent> takeOverEvents = tor.getTakeOverEvents();
		for (TakeOverEvent takeOverEvent : takeOverEvents) {
			if (takeOverEvent.getUser().getId() == user.getId()) {
				userTakeOverEvent = takeOverEvent;
				break;
			}
		}

		if (userTakeOverEvent == null) {
			throw new InvalidTakeOverRequestException();
		}
		
		TakeOverAcceptanceDto takeOverAcceptance = new TakeOverAcceptanceDto();
		takeOverAcceptance.setTakeOverRequestId(tor.getId());
		takeOverAcceptance.setDeclinedByUser(user.getFirstName() + user.getLastName());

		userTakeOverEvent.setStatus(TakeOverStatus.DECLINED);
		takeOverRequestDao.update(tor);
		queueService.enqueueTakeOverDeclination(takeOverAcceptance);
		
		return TakeOverDeclinationResult.SUCCESS;
		
	}

	@Override
	@Transactional
	public TakeOverAcceptanceResult acceptTakeOverRequest(Long torId, Long userId) {
		Validate.notNull(torId,"torId is empty");
		Validate.notNull(userId,"userId is empty");

		TakeOverRequest tor = takeOverRequestDao.getTakeOverRequestById(torId);
		if (tor == null) {
        	throw new InvalidTakeOverRequestException();
        }
		
		if (tor.getAcceptedByUser() != null) {
			return TakeOverAcceptanceResult.ALREADY_TAKEN;
		}

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		TakeOverEvent event = takeOverEventDao.getTakeOverEvent(tor.getId(), user.getId());
		if (event == null) {
			throw new InvalidTakeOverRequestException();
		}
		
		TakeOverEvent userTakeOverEvent = null;
		
		List<TakeOverEvent> takeOverEvents = tor.getTakeOverEvents();
		for(TakeOverEvent takeOverEvent : takeOverEvents){
			if(takeOverEvent.getUser().getId() == user.getId()){
				userTakeOverEvent = takeOverEvent;
				break;
			}
		}
		if (userTakeOverEvent == null) {
			throw new InvalidTakeOverRequestException();
		}		
		
		DateEventsDto dateEvents = new DateEventsDto();
		dateEvents.setUserId(userId);
		dateEvents.setGroupId(tor.getGroup().getId());
		dateEvents.setDateEvents(new ArrayList<DateEventDto>());
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setStartTime(event.getStartTime());
		dateEvent.setEndTime(event.getEndTime());
		dateEvent.setGroupId(tor.getGroup().getId());
		dateEvent.setUserId(userId);
		dateEvent.setNote(tor.getGroupId() + "|" + event.getNote());
		dateEvents.getDateEvents().add(dateEvent);;
		List<DateEventsDto> listOfDateEvents = new ArrayList<DateEventsDto>();
		listOfDateEvents.add(dateEvents);
		
		Map<Outcome, List<DateEventsDto>> createdEvents = 
			eventService.createEvents(tor.getGroup().getId(), listOfDateEvents);
		List<DateEventsDto> successfulEvents = createdEvents.get(Outcome.SUCCESS);
		
		if (successfulEvents.size() == 0) {
			//no successful block
			return TakeOverAcceptanceResult.TIME_CONFLICT;
		}
		DateEventsDto returnedEvents = successfulEvents.get(0);
		
		if (returnedEvents.getDateEvents().size() == 0) {
			//no successful block
			return TakeOverAcceptanceResult.TIME_CONFLICT;
		} else {
			dateEvent = returnedEvents.getDateEvents().get(0);
			TakeOverAcceptanceDto takeOverAcceptance = new TakeOverAcceptanceDto();
			takeOverAcceptance.setAcceptedByUser(user.getFirstName() + user.getLastName());
			takeOverAcceptance.setTakeOverRequestId(tor.getId());
			takeOverAcceptance.setEventId(dateEvent.getId());
			tor.setStatus(TakeOverStatus.ACCEPTED);
			tor.setAcceptedByUser(user);
			
			userTakeOverEvent.setStatus(TakeOverStatus.ACCEPTED);
			takeOverRequestDao.update(tor);
			queueService.enqueueTakeOverAcceptance(takeOverAcceptance);
		}
		
		return TakeOverAcceptanceResult.SUCCESS;
	}

	@Override
	@Transactional
	public void cancelTakeOverRequest(final Long torId) {
		TakeOverRequest tor = takeOverRequestDao.getTakeOverRequestById(torId);
		
		if (tor == null) {
        	throw new InvalidTakeOverRequestException();
        }
		
		if(TakeOverStatus.ACCEPTED.equals(tor.getStatus()) || tor.getAcceptedByUser() != null) {
			throw new InvalidTakeOverRequestStatusException();
		}
		
		tor.setStatus(TakeOverStatus.CANCELLED);
		
		takeOverRequestDao.update(tor);
		messageService.sendTakeOverCancellation(tor);
	}

}