/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.LocalTime;

import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.jsonhelper.LocalTimeDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.LocalTimeSerializer;
import com.coloredshapes.coreservices.exception.InvalidEventException;

/**
 * <code>RepeatableEvent</code> is a class representing a
 * repeatable event created by a user with a specific note.
 * 
 * TODO: Use <code>RepeatableEventDto</code> for transferring
 * in and out repeatable events. Day Of Week in some cases
 * is needed to be exposed, but to use 
 * @JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
 * it would require to clear the day of week when the value
 * is not to be transferred out. Clearing it however would
 * delete the information from the entity and it will be lost.
 * Therefore, DTO is better to be used for mediation with
 * external parties. 
 */
@Entity
@Table(name="repeatable_event")
public class RepeatableEvent extends BaseEntity implements Comparable<RepeatableEvent>{
	
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id", nullable=false)
	private User user;

	@Enumerated
    @Column(name="day_of_week", nullable=false)
    private DayOfWeek dayOfWeek;
    
	@Column(name="start_time", nullable=false)
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentLocalTime")
    private LocalTime startTime;
    
	@Column(name="end_time", nullable=false)
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentLocalTime")
    private LocalTime endTime;
    
	@Column(name="note")
    private String note;

	public RepeatableEvent() {
	}
    
    public RepeatableEvent(DayOfWeek dayOfWeek, LocalTime startTime, LocalTime endTime) {
        validateBeforeCreate(startTime,endTime);
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public static RepeatableEvent createRepeatableEvent(DayOfWeek dayOfWeek, String startTime, String endTime){
        LocalTime start = LocalTime.parse(startTime);
        LocalTime end = LocalTime.parse(endTime);
        validateBeforeCreate(start,end);
        return new RepeatableEvent(dayOfWeek,start,end);
    }

    private static void validateBeforeCreate(LocalTime startTime, LocalTime endTime) throws InvalidEventException {
		if (startTime.isAfter(endTime)) {
			throw new InvalidEventException("Start Time must be before End Time");
		}
		if (endTime.isBefore(startTime)) {
			throw new InvalidEventException("End Time must be after Start Time");
		}
    }

    @JsonSerialize(using = LocalTimeSerializer.class)
    public LocalTime getStartTime(){
        return new LocalTime(startTime.getHourOfDay(),startTime.getMinuteOfHour(),startTime.getSecondOfMinute(),startTime.getMillisOfSecond(),startTime.getChronology());
    }
    
    @JsonSerialize(using = LocalTimeSerializer.class)
    public LocalTime getEndTime(){
        return new LocalTime(endTime.getHourOfDay(),endTime.getMinuteOfHour(),endTime.getSecondOfMinute(),endTime.getMillisOfSecond(),endTime.getChronology());
    }

    @JsonIgnore
    public User getUser() {
		return user;
	}
    
    @JsonIgnore
	public void setUser(User user) {
		this.user = user;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}
	
	@JsonIgnore
	public DayOfWeek getDayOfWeek(){
        return dayOfWeek;
    }

	@JsonIgnore
	public void setDayOfWeek(DayOfWeek dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	
	@JsonDeserialize(using = LocalTimeDeserializer.class)
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}
	
	@JsonDeserialize(using = LocalTimeDeserializer.class)
	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	/**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     * <p>The implementor must ensure <tt>sgn(x.compareTo(y)) ==
     * -sgn(y.compareTo(x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
     * implies that <tt>x.compareTo(y)</tt> must throw an exception iff
     * <tt>y.compareTo(x)</tt> throws an exception.)
     * <p/>
     * <p>The implementor must also ensure that the relation is transitive:
     * <tt>(x.compareTo(y)&gt;0 &amp;&amp; y.compareTo(z)&gt;0)</tt> implies
     * <tt>x.compareTo(z)&gt;0</tt>.
     * <p/>
     * <p>Finally, the implementor must ensure that <tt>x.compareTo(y)==0</tt>
     * implies that <tt>sgn(x.compareTo(z)) == sgn(y.compareTo(z))</tt>, for
     * all <tt>z</tt>.
     * <p/>
     * <p>It is strongly recommended, but <i>not</i> strictly required that
     * <tt>(x.compareTo(y)==0) == (x.equals(y))</tt>.  Generally speaking, any
     * class that implements the <tt>Comparable</tt> interface and violates
     * this condition should clearly indicate this fact.  The recommended
     * language is "Note: this class has a natural ordering that is
     * inconsistent with equals."
     * <p/>
     * <p>In the foregoing description, the notation
     * <tt>sgn(</tt><i>expression</i><tt>)</tt> designates the mathematical
     * <i>signum</i> function, which is defined to return one of <tt>-1</tt>,
     * <tt>0</tt>, or <tt>1</tt> according to whether the value of
     * <i>expression</i> is negative, zero or positive.
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     * @throws ClassCastException   if the specified object's type prevents it
     *                              from being compared to this object.
     */
    @Override
    public int compareTo(RepeatableEvent that) {
		if (this.dayOfWeek.ordinal() < that.dayOfWeek.ordinal()) {
			return -1;
		} else if (this.dayOfWeek.ordinal() > that.dayOfWeek.ordinal()) {
			return 1;
		} else {
			return this.startTime.compareTo(that.startTime);
		}
    }

    public boolean conflictsWith(RepeatableEvent that) {
		if (this.equals(that) || this == that) {
			return true;
		}
		if (this.startTime.isAfter(that.endTime)) {
			return false;
		}
		if (this.endTime.isBefore(that.startTime)) {
			return false;
		}
		return true;
    }

    @Override
    public String toString(){
        return "" + dayOfWeek + " ["+startTime.toString("HH:mm")+" - "+endTime.toString("HH:mm")+"]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RepeatableEvent)) return false;

        RepeatableEvent repeatableEvent = (RepeatableEvent) o;

        if (dayOfWeek != repeatableEvent.dayOfWeek) return false;
        if (!endTime.equals(repeatableEvent.endTime)) return false;
        if (!startTime.equals(repeatableEvent.startTime)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = dayOfWeek.hashCode();
        result = 31 * result + startTime.hashCode();
        result = 31 * result + endTime.hashCode();
        return result;
    }
    
}