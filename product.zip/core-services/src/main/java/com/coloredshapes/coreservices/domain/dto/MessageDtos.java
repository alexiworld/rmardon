/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * <code>MessageDto</code> is DTO 
 *
 */
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class MessageDtos {

	private List<MessageDto> messages;
	
	// Later String might be replaced by UserXXXDto.
	// This would not require any contract changes.
	private Map<Long, String> users;

	/**
	 * @return the messages
	 */
	public List<MessageDto> getMessages() {
		return messages;
	}

	/**
	 * @param messages the messages to set
	 */
	public void setMessages(List<MessageDto> messages) {
		this.messages = messages;
	}

	/**
	 * @return the users
	 */
	public Map<Long, String> getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(Map<Long, String> users) {
		this.users = users;
	}


	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("messages", messages) 
            .append("users", users) 
            .toString();
    }

}