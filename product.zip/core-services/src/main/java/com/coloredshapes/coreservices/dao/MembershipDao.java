/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.exception.InvalidUserException;

public interface MembershipDao extends GenericDao<Membership> {
	
	void createMembership(Membership emp);

	List<Membership> getMembershipListByUserId(Long userId) throws InvalidUserException;

	Membership getMembershipByTopGroupIdAndUserId(Long groupId, Long userId);

}
