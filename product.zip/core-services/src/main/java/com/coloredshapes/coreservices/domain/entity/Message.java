/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="message")
public class Message extends BaseEntity {
	
	@NotNull
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="message_content_id")
	private MessageContent content;

	@NotNull
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name="sender_user_id")
	private User sender;

	@NotNull
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name="recipient_user_id")
	private User recipient;

	@Column(name = "opened")
	private boolean opened;

	@Column(name = "sender_visible")
	private boolean visibleToSender = true;

	@Column(name = "recipient_visible")
	private boolean visibleToRecipient = true;
	
    /**
	 * @return the content
	 */
	public MessageContent getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(MessageContent content) {
		this.content = content;
	}

	/**
	 * @return the sender
	 */
	public User getSender() {
		return sender;
	}

	/**
	 * @param sender the sender to set
	 */
	public void setSender(User sender) {
		this.sender = sender;
	}

	/**
	 * @return the recipient
	 */
	public User getRecipient() {
		return recipient;
	}

	/**
	 * @param recipient the recipient to set
	 */
	public void setRecipient(User recipient) {
		this.recipient = recipient;
	}

	/**
	 * @return the opened
	 */
	public boolean isOpened() {
		return opened;
	}

	/**
	 * @param opened the opened to set
	 */
	public void setOpened(boolean opened) {
		this.opened = opened;
	}

	/**
	 * @return the visibleToSender
	 */
	public boolean isVisibleToSender() {
		return visibleToSender;
	}

	/**
	 * @param visibleToSender the visibleToSender to set
	 */
	public void setVisibleToSender(boolean visibleToSender) {
		this.visibleToSender = visibleToSender;
	}

	/**
	 * @return the visibleToRecipient
	 */
	public boolean isVisibleToRecipient() {
		return visibleToRecipient;
	}

	/**
	 * @param visibleToRecipient the visibleToRecipient to set
	 */
	public void setVisibleToRecipient(boolean visibleToRecipient) {
		this.visibleToRecipient = visibleToRecipient;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("content", content) 
        	.append("sender", sender) 
        	.append("recipient", recipient) 
        	.append("opened", opened) 
        	.append("visibleToSender", visibleToSender) 
        	.append("visibleToRecipient", visibleToRecipient) 
        	.toString();
    }

}