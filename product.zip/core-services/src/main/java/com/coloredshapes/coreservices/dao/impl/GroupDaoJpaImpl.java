/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Group_;

@Repository
public class GroupDaoJpaImpl  extends BaseJpaImpl<Group> implements GroupDao {

	@Override
	public Group getGroup(Long groupId) {
		return entityManager.find(Group.class, groupId);
	}

	public List<Group> getGroups(Long[] groupIds) {
		CriteriaQuery<Group> criteria = entityManager.getCriteriaBuilder().createQuery(Group.class);
		Root<Group> groupRoot = criteria.from( Group.class );
		criteria.select( groupRoot );

		//@SuppressWarnings("unused")
		//Metamodel m = entityManager.getMetamodel();

		criteria.where(groupRoot.get(Group_.id).in((Object[]) groupIds));
		return  entityManager.createQuery( criteria ).getResultList();
	}

	@Override
	public void createGroup(Group group) {
		// group without a parent is considered a top group
		Long parentGroupId = group.getParentId();
		if (parentGroupId != null) {
			Group parentGroup = getGroup(parentGroupId);
			if (parentGroup != null) {
				group.setTopGroup(parentGroup.getTopGroup());
			}
		}
		
		// TODO: Consider what is better and change it later if needed:
		// 1) top group property is set even for the top group itself
		// 2) top group property is set to null for the top group
		// Both have advantages/disadvantages. Due to the fact at the 
		// present time top group is used in a few places to save us
		// time and prevent defects the first option has been selected.
		if (group.getTopGroup() == null) {
			group.setTopGroup(group);
		}

		create(group);
		entityManager.flush();
	}

}