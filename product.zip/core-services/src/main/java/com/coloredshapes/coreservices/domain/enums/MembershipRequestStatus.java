/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.enums;

public enum MembershipRequestStatus {

	OPEN,
	CANCELLED,
	ACCEPTED,
	DECLINED

}
