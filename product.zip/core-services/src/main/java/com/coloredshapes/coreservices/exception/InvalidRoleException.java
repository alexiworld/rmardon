/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class InvalidRoleException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -2800509818150269007L;
	private static final String errCode = "0014";

	private Long roleId;

	public InvalidRoleException(Long roleId) {
		this.roleId = roleId;
	}
	
	public Long getRoleId() {
		return roleId;
	}

	@Override
	public String getMessage() {
		return "Role#" + roleId + " does not exist";
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}