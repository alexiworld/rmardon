/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

import com.coloredshapes.coreservices.exception.CoreServicesException;

public class InvalidMembershipStatusException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -1154156497518775569L;
	private static final String errCode = "0013";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
