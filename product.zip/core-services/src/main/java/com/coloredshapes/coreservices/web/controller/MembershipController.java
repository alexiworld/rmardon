/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.MembershipDto;
import com.coloredshapes.coreservices.service.MembershipService;
import com.coloredshapes.coreservices.utils.StandardUtils;
import com.coloredshapes.coreservices.web.dto.ConfirmMembershipResult;

@Controller
public class MembershipController extends BaseController {
	
	@Autowired
	private MembershipService membershipService; 

	@RequestMapping(value = "/groups/{groupId}/memberships", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<MembershipDto> getGroupMemberships(@PathVariable("groupId") String groupIdCode) 
	throws Exception {
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		List<MembershipDto> memberships = membershipService.getGroupMemberships(groupId);
		return memberships;
	}
	
	@RequestMapping(value = "/users/{userId}/memberships", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<MembershipDto> getUserMemberships(@PathVariable("userId") String userIdCode) 
	throws Exception {
		Long userId = StandardUtils.decodeLong(userIdCode);
		List<MembershipDto> memberships = membershipService.getUserMemberships(userId);
		return memberships;
	}
	

	@RequestMapping(value = "/memberships/invitation", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void initiateMembership(@RequestBody MembershipDto membership) throws Exception {
		membershipService.initiateMembership(membership);
	}
	
	@RequestMapping(value = "/memberships/acceptance", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public String confirmMembership(@RequestParam("userId") String userIdCode, @RequestParam("refNum") String refNum) throws Exception {
		try {
			Long userId = StandardUtils.decodeLong(userIdCode);
			membershipService.confirmMembership(userId, refNum);
		} catch (Exception e) {
			logger.error("Failed to process membership acceptance", e);
			return ConfirmMembershipResult.FAILED.getMessage();
		}
		return ConfirmMembershipResult.SUCCESSFUL.getMessage();
	}
	
	@RequestMapping(value = "/groups/{groupId}/memberships/statuses", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void updateGroupMemberships(
			@PathVariable("groupId") String groupIdCode, 
			@RequestBody Map<String, String> codedStatuses)
	throws Exception {
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		Map<Long, String> statuses = new LinkedHashMap<Long, String>();
		for (Map.Entry<String, String> codedStatus : codedStatuses.entrySet()) {
			String userIdCode = codedStatus.getKey();
			Long userId = StandardUtils.decodeLong(userIdCode);
			statuses.put(userId, codedStatus.getValue());
		}
		membershipService.updateUserMemberships(groupId, statuses);
	}
	
	@RequestMapping(value = "/users/{userId}/memberships/statuses", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void updateUserMemberships(
			@PathVariable("userId") String userIdCode, 
			@RequestBody Map<String, String> codedStatuses)
	throws Exception {
		Long userId = StandardUtils.decodeLong(userIdCode);
		Map<Long, String> statuses = new LinkedHashMap<Long, String>();
		for (Map.Entry<String, String> codedStatus : codedStatuses.entrySet()) {
			String groupIdCode = codedStatus.getKey();
			Long groupId = StandardUtils.decodeLong(groupIdCode);
			statuses.put(groupId, codedStatus.getValue());
		}
		membershipService.updateUserMemberships(userId, statuses);
	}
	
	@RequestMapping(value = "/groups/{groupId}/memberships/inactive", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void inactivateMemberships(
			@PathVariable("groupId") String groupIdCode, 
			@RequestParam(required=false) Boolean forceDelete,
			@RequestBody List<String> userEmails) 
	throws Exception {
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		membershipService.inactivateMemberships(groupId, userEmails, forceDelete);
	}

}