/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.ChangeRequestService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Controller
public class ChangeRequestController extends BaseController {
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	@Value("${amqp.eventChangeRequestQueue}")
	private String eventChangeRequestQueue;
	
	@Autowired
	private ChangeRequestService changeRequestService;
	@RequestMapping(value = "eventChangeReq/{userId}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void sendEventChangeRequest(@PathVariable("userId") String userIdCode, @RequestBody String[] eventIdCodes) 
	throws InvalidUserException{
		Long userId = StandardUtils.decodeLong(userIdCode);
		Long[] eventIds = StandardUtils.decodeLongs(eventIdCodes);
		changeRequestService.sendChangeRequest(userId, eventIds);
	}
	
	
	@RequestMapping(value = "/eventChangeReq", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public String getEventChangeRequestFromQueue() throws Exception {
		Message receive = amqpTemplate.receive(eventChangeRequestQueue);
		byte[] body = receive.getBody();
		String s = new String(body);
		if (logger.isDebugEnabled()) {
			logger.debug("event keys: " );
		}
		return s;
	}
}