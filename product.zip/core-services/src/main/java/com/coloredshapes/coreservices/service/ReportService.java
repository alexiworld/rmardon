/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;

import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.report.dto.RolePayDto;
import com.coloredshapes.coreservices.report.dto.UserPayDto;

/**
 * <code>ReportService</code> type defines the reporting service 
 * contract. The service is acting as data source for the reports.
 */
public interface ReportService {

	/**
	 * Retrieve payments to users for specified group and period.
	 * 
	 * @param groupId		the group
	 * @param timePeriod	the period
	 * @return	collection of user pay
	 */
	List<UserPayDto> getUserPays(Long groupId, TimePeriodDto timePeriod);

	/**
	 * Retrieve payments to roles for specified group and period.
	 * 
	 * @param groupId		the group
	 * @param timePeriod	the period
	 * @return	collection of position pay
	 */
	List<RolePayDto> getRolePays(Long groupId, TimePeriodDto timePeriod);

}