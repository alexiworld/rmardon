/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;
import com.coloredshapes.coreservices.service.EventService;
import com.coloredshapes.coreservices.utils.RandomUtils;
import com.coloredshapes.coreservices.utils.StandardUtils;
import com.coloredshapes.coreservices.web.dto.ReferenceNumber;

/**
 * <code>EventController</code> handles date events requests to REST services. The supported operations are 
 * adding, retrieving and removing of events, etc.
 */
@Controller
public class EventController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The event service.
	 */
	@Autowired
	private EventService eventService;

	/**
	 * The AMQP template
	 */
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${amqp.queue:ColoredShapes.Queue.Services}")
	private String queue;
    
	

	/**
	 * REST service for persisting events
	 * 
	 * @param events
	 *            events to be stored
	 * @param userId
	 *            the user adding the events
	 * @return events not stored
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/users/{userId}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	//public DateEventDto[] addEvents(@RequestBody DateEventDto[] events, @PathVariable("userId") String userIdCode)
	public Map<Outcome, DateEventsDto> addEvents(@RequestBody DateEventDto[] events, @PathVariable("userId") String userIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("userId: " + userIdCode);
			logger.debug("events: " + Arrays.asList(events));
		}

		Long userId = StandardUtils.decodeLong(userIdCode);
		
		DateEventsDto dateEvents = new DateEventsDto();
		dateEvents.setUserId(userId);
		dateEvents.setDateEvents(new LinkedList<DateEventDto>(Arrays.asList(events)));
		
		Map<Outcome, DateEventsDto> outcomes = eventService.createEvents(dateEvents);
		/*
		DateEventsDto failedDateEvents = outcomes.get(Outcome.FAILURE);
		
		//TODO: At the moment the message says only startTime and endTime will be returned
		//If needed set the other fields to 'null' to omit them in the response 
		if (failedDateEvents != null && failedDateEvents.getDateEvents() != null) {
			return failedDateEvents.getDateEvents().toArray(new DateEventDto[0]);
		} else {
			return new DateEventDto[0];
		}
		*/
		return outcomes;
	}

	/**
	 * REST service for retrieving events
	 * 
	 * @param userId
	 *            the user id for whom the events are requested
	 * @param startTime
	 *            the start time
	 * @param endTime
	 *            the end time
	 * @param eventTypes
	 *            types of events to be retrieved (USER, GROUP)
	 * @param groupIds
	 *            group events to be retrieve only for group Ids
	 * @return a map of types and events
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/users/{userId}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String, DateEventsDto> getEvents(@PathVariable("userId") String userIdCode, 
			@RequestParam Long startTime, @RequestParam Long endTime, 
			@RequestParam String eventTypes, @RequestParam(required=false) String groupIds)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("userId: " + userIdCode);
			logger.debug("startTime: " + startTime);
			logger.debug("endTime: " + endTime);
			logger.debug("eventTypes: " + eventTypes);
			logger.debug("groupIds: " + groupIds);
		}
		
		Long userId = StandardUtils.decodeLong(userIdCode);
		TimePeriodDto timePeriod = new TimePeriodDto(startTime, endTime);

		int counter = 0;
		String[] groupOfEventTypes = eventTypes.split(",");
		SourceType[] sourceTypes = new SourceType[groupOfEventTypes.length];
		for (String eventType : groupOfEventTypes) {
			sourceTypes[counter++] = SourceType.valueOf(eventType); 
		}
		Long[] groupOfGroupIds = StandardUtils.decodeLongs(
			StringUtils.isEmpty(groupIds)? new String[0] : groupIds.split(","));
		
		Map<String,DateEventsDto> dateEventsBySourceTypes = 
			eventService.getEvents(userId, timePeriod, sourceTypes, groupOfGroupIds);
		
		if (logger.isDebugEnabled()) {
			logger.debug("eventsGroupedBySourceTypes: " + dateEventsBySourceTypes);
		}

		return dateEventsBySourceTypes;
	}

	/**
	 * REST service for retrieving events
	 * 
	 * @param groupId
	 *            the id of group requesting the events
	 * @param startTime
	 *            the start time
	 * @param endTime
	 *            the end time
	 * @param userIds
	 *            the user Ids group admin is interested in
	 * @return a list of events
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public List<DateEventsDto> getEvents(
			@RequestParam("groupId") String groupIdCode, 
			@RequestParam Long startTime, 
			@RequestParam Long endTime, 
			@RequestParam("userIds") String userIdCodes)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("groupId: " + groupIdCode);
			logger.debug("startTime: " + startTime);
			logger.debug("startTime: " + endTime);
			logger.debug("userIds: " + userIdCodes);
		}
			
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		Long[] userIds = StandardUtils.decodeLongs(userIdCodes.split(","));
		TimePeriodDto timePeriod = new TimePeriodDto(startTime, endTime);

		List<DateEventsDto> dateEvents = 
			eventService.getEvents(groupId, timePeriod, userIds);
		
		if (logger.isDebugEnabled()) {
			logger.debug("eventsGroupedBySourceTypes: " + dateEvents);
		}
		
		return dateEvents;
	}

	/**
	 * REST service for deletion of events.
	 * 
	 * @param eventIds
	 *            Ids of events to be deleted
	 * @return list of events not being deleted
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/users/{userId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public String[] deleteEvents(@PathVariable("userId") String userIdCode, @RequestBody String[] eventIdCodes)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("eventsToBeDeleted: " + Arrays.asList(eventIdCodes));
		}

		Long userId = StandardUtils.decodeLong(userIdCode);
		Long[] eventIds = StandardUtils.decodeLongs(eventIdCodes);
		Map<Outcome, List<Long>> outcomes = 
				eventService.deleteEvents(userId, null, Arrays.asList(eventIds));
		List<Long> eventsNotDeleted = outcomes.get(Outcome.FAILURE);
		
		if (logger.isDebugEnabled()) {
			logger.debug("eventsNotDeleted: " + eventsNotDeleted);
		}

		if (CollectionUtils.isNotEmpty(eventsNotDeleted)) {
			return eventsNotDeleted.toArray(new String[0]);
		} else {
			return new String[0];
		}
	}
	
	/**
	 * REST service for assigning events i.e. adding/deletion of events.
	 * 
	 * @param dateEventsPatch
	 *            the instance holding the events to be deleted/added
	 * @return the date events patch and result of applying it
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/synchPatch", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public DateEventsPatchDto synchDateEventsPatch(@RequestBody DateEventsPatchDto dateEventsPatch)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("date events patch: " + dateEventsPatch);
		}
		
		ReferenceNumber referenceNumber = new ReferenceNumber("" + RandomUtils.getRandomNum()); 
		dateEventsPatch.setRefNum(referenceNumber.getRefNum());
		DateEventsPatchDto returnedDateEventsPatch = eventService.synchDateEventsPatch(dateEventsPatch);

		if (logger.isDebugEnabled()) {
			logger.debug("date events patch result: " + returnedDateEventsPatch);
		}
		
		return returnedDateEventsPatch;
	}
	
	/**
	 * REST service for assigning events i.e. adding/deletion of events.
	 * 
	 * @param dateEventsPatch
	 *            the instance holding the events to be deleted/added
	 * @return the reference number
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/asynchPatch", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ReferenceNumber asynchDateEventsPatch(@RequestBody DateEventsPatchDto dateEventsPatch)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("date events patch: " + dateEventsPatch);
		}
		
		ReferenceNumber referenceNumber = new ReferenceNumber("" + RandomUtils.getRandomNum()); 
		dateEventsPatch.setRefNum(referenceNumber.getRefNum());
		eventService.asynchDateEventsPatch(dateEventsPatch);

		if (logger.isDebugEnabled()) {
			logger.debug(String.format(
				"Date events patch is enqueued for processing. (Ref#%s)", referenceNumber.getRefNum()
			));
		}
		
		return referenceNumber;
	}

	/**
	 * REST service for reading group assignments from the queue.
	 * 
	 * @return the first date events patch in the queue
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/events/byDate/asynchPatch", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public DateEventsPatchDto getAsynchDateEventsPatch() throws Exception {
		DateEventsPatchDto dateEventsPatch = (DateEventsPatchDto) amqpTemplate.receiveAndConvert(queue);

		if (logger.isDebugEnabled()) {
			logger.debug("dateEventsPatch: " + dateEventsPatch);
		}
		
		return dateEventsPatch;
	}

}