/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static com.coloredshapes.coreservices.Constants.NO_GROUP_LIMITED;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.ObjectUtils;
import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.MessageDao;
import com.coloredshapes.coreservices.dao.UserAgreementDao;
import com.coloredshapes.coreservices.dao.UserConfirmationDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.CompositeDto;
import com.coloredshapes.coreservices.domain.dto.GroupBasicDto;
import com.coloredshapes.coreservices.domain.dto.UserBasicDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.domain.dto.UserProfileDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.UserAgreement;
import com.coloredshapes.coreservices.domain.entity.UserConfirmation;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;
import com.coloredshapes.coreservices.domain.enums.UserStatus;
import com.coloredshapes.coreservices.exception.AuthenticationException;
import com.coloredshapes.coreservices.exception.EncryptionException;
import com.coloredshapes.coreservices.exception.ExistingUserException;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.security.SecurityUtil;
import com.coloredshapes.coreservices.service.GroupService;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.service.UserService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private GroupService groupService;
	
	@Autowired
	private UserConfirmationDao userConfirmationDao;

	// Management service will call User service to create the user
	//@Autowired  // The idea is to minimize the inter dependencies
	//private ManagementService managementService;	

	@Autowired
	private MessageService messageService;	
	
	@Autowired
	private UserAgreementDao userAgreementDao;
	
	@Autowired
	private MessageDao messageDao;
	
	@Resource(name="dozerBeanMapper")
	private DozerBeanMapper beanMapper;
    
	@Override
	@Transactional(readOnly=true)
	public UserBasicDto getCurrentUser() {
		String user = StandardUtils.getUser();
		if (user == null) return null;
		
		UserBasicDto currentUser = null;
		if (user.indexOf('@') >= 0) {
			String email = user;
			currentUser = getUser(email, ContentLimit.BASIC, ContentStatus.ACTIVE, NO_GROUP_LIMITED);
		} else {
			Long userId = Long.valueOf(user);
			currentUser = getUser(userId, ContentLimit.BASIC, ContentStatus.ACTIVE, NO_GROUP_LIMITED);
		}
		
		return currentUser;
	}
	
	@Override
	@Transactional(readOnly=true)
	public UserBasicDto getUser(String email, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		User user = userDao.getUser(email);
		UserBasicDto userDto = null;
		if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
			userDto = toUserDto(user, contentLimit, contentStatus, groupId);
		}
		return userDto;
	}
	
	@Override
	@Transactional(readOnly=true)
	public UserBasicDto getUser(Long userId, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		User user = userDao.getUser(userId);
		UserBasicDto userDto = null;
		if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
			userDto = toUserDto(user, contentLimit, contentStatus, groupId);
		}
		return userDto;
	}

	@Override
	@Transactional(readOnly=true)
	public List<UserBasicDto> getUsers(Long[] userIds, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		List<User> users = userDao.getUsers(userIds);
		List<UserBasicDto> userDtos = new ArrayList<UserBasicDto>(users.size());
		for (User user : users) {
			if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
				userDtos.add(toUserDto(user, contentLimit, contentStatus, groupId));
			}
		}
		return userDtos;
	}
	
	@Override
	@Transactional(readOnly=true)
	public UserBasicDto getUsers(String email, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		User user = userDao.getUser(email);
		UserBasicDto userDto = null;
		if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
			userDto = toUserDto(user, contentLimit, contentStatus, groupId);
		}
		return userDto;
	}

	@Override
	@Transactional(readOnly=true)
	public List<UserBasicDto> getUsers(String[] emails, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		List<User> users = userDao.getUsers(emails);
		List<UserBasicDto> userDtos = new ArrayList<UserBasicDto>(users.size());
		for (User user : users) {
			if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
				userDtos.add(toUserDto(user, contentLimit, contentStatus, groupId));
			}
		}
		return userDtos;
	}

	@Override
	@Transactional(readOnly=true)
	// replacement for getGroupActiveUserIds, contentStatus = ContentStatus.ACTIVE
	public List<Long> getGroupUserIds(Long groupId, ContentStatus contentStatus) {
		if (groupId == null) {
			throw new IllegalArgumentException("Group id is missing.");
		}

		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}

		List<User> users = group.getUsers();
		List<Long> userIds = new ArrayList<Long>(users.size());
		for (User user : users) {
			if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
				userIds.add(user.getId());
			}
		}
		
		return userIds;
	}

	@Override
	@Transactional(readOnly=true)
	public List<UserBasicDto> getGroupUsers(Long groupId, ContentLimit contentLimit, ContentStatus contentStatus) {
		if (groupId == null) {
			throw new IllegalArgumentException("Group id is missing.");
		}

		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new InvalidGroupException(groupId);
		}

		List<User> users = group.getUsers();
		List<UserBasicDto> userDtos = new ArrayList<UserBasicDto>(users.size());
		for (User user : users) {
			if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
				UserBasicDto userDto = toUserDto(user, contentLimit, contentStatus, groupId);
				userDtos.add(userDto);
			}
		}

		return userDtos;
	}

	@Override
	@Transactional(readOnly=true)
	public Map<Long, String> getCoUsersByNamePrefix(String namePrefix) {
		Long userId = Long.valueOf(StandardUtils.getUser());
		User requestor = userDao.getUser(userId);
		
		List<Group> groups = requestor.getGroups();
		List<Long> groupIds = new ArrayList<Long>(groups.size());
		for (Group group : groups) {
			groupIds.add(group.getId());
		}
		
		List<User> users = userDao.getUsersByNamePrefix(namePrefix, groupIds);
		Map<Long, String> cousers = new HashMap<Long, String>(users.size());
		for (User user : users) {
			cousers.put(user.getId(), user.getFirstName() + ' ' + user.getLastName());
		}
		return cousers;
	}

	@Override
	@Transactional(readOnly=true)
	public List<CompositeDto> getGroupsCoUsers(Long userId, ContentLimit contentLimit, ContentStatus contentStatus) {
		User requestor = userDao.getUser(userId);
		
		// This can be optimized to retrieve all the users with less statements, but hoping the cache will
		// be sufficient at the beginning.

		List<Group> groups = requestor.getGroups();
		List<CompositeDto> groupsCoUsers = new ArrayList<CompositeDto>(groups.size());

		for (Group group : groups) {
			Long groupId = group.getId();
			
			GroupBasicDto groupXXXDto = groupService.getGroup(groupId, contentLimit, contentStatus);
			
			List<User> users = group.getUsers();
			List<UserBasicDto> userXXXDtos = new ArrayList<UserBasicDto>(users.size()); 
			for (User user : users) {
				if (user.getId() == userId) continue; // skip the requestor
				UserBasicDto userDto = toUserDto(user, contentLimit, contentStatus, groupId);
				userXXXDtos.add(userDto);
			}
			
			CompositeDto groupCoUsers = new CompositeDto();
			groupCoUsers.setGroup(groupXXXDto);
			groupCoUsers.setUsers(userXXXDtos);
			groupsCoUsers.add(groupCoUsers);
		}
		
		return groupsCoUsers;
	}

	private UserBasicDto toUserDto(User user, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId) {
		UserBasicDto userXXXDto;
		if (ContentLimit.BASIC.equals(contentLimit)) {
			UserBasicDto userBasicDto = beanMapper.map(user, UserBasicDto.class);
			userXXXDto = userBasicDto;
		} else if (ContentLimit.PROFILE.equals(contentLimit)) {
			UserProfileDto userProfileDto = beanMapper.map(user, UserProfileDto.class);
			userXXXDto = userProfileDto;
		} else {
			BeanMappingBuilder builder = new BeanMappingBuilder() {
				protected void configure() {
					mapping(User.class, UserCompleteDto.class)
						.exclude("assignments");
				}
			};
			DozerBeanMapper beanMapper = new DozerBeanMapper();
			beanMapper.addMapping(builder);
			UserCompleteDto userCompleteDto = beanMapper.map(user, UserCompleteDto.class);
						
			List<Assignment> assignments = user.getAssignments(); 
			List<AssignmentDto> assignmentDtos = new ArrayList<AssignmentDto>(assignments.size());
			for (Assignment assignment : assignments) {
				if (groupId != null && !ObjectUtils.equals(groupId, assignment.getGroup().getId())) {
					continue;
				}
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), assignment.getStatus().name())) {
					AssignmentDto assignmentDto = beanMapper.map(assignment, AssignmentDto.class);
					assignmentDto.setUserId(assignment.getUser().getId()); // try it with mapper
					assignmentDto.setRoleId(assignment.getRole().getId()); // configuration
					// assignmentDto.setRole(null);    // to avoid double serialization of roles
					assignmentDtos.add(assignmentDto);
				}
			}
			userCompleteDto.setAssignments(assignmentDtos);

			/*
			UserCompleteDto userCompleteDto = beanMapper.map(user, UserCompleteDto.class);
			
			// [20131011] Assignments not matching specified content status will be excluded
			if (contentStatus != null) {
				List<AssignmentDto> assignments = userCompleteDto.getAssignments();
				for (Iterator<AssignmentDto> iterator = assignments.iterator(); iterator.hasNext();) {
					AssignmentDto assignmentDto = iterator.next();
					if (!StringUtils.equals(contentStatus.name(), assignmentDto.getStatus().name())) {
						iterator.remove();
					}
				}
			}
			*/
			
			userXXXDto = userCompleteDto;
		}
		return userXXXDto;
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean userExists(final Long userId) {
		User user = userDao.getUser(userId);
		return !(user==null);
	}
	
	@Override
	@Transactional(readOnly = true)
	public boolean emailExists(final String email) {
		User user = userDao.getUser(email);
		return !(user==null);
	}
	
	@Override
    @Transactional
    public Long createUser(final UserCompleteDto userDto) {
		if (userDto.getId() != null) {
			throw new IllegalArgumentException("The user to be created should not have id specified.");
		}
		
		if (emailExists(userDto.getEmail())) {
    		throw new ExistingUserException(userDto.getEmail());
    	}
    	
		User user = beanMapper.map(userDto, User.class);

        try {
			SecurityUtil.sethHashPasswordAndSalt(user);
		} catch (NoSuchAlgorithmException e) {
			throw new EncryptionException("Failed to encrypt");
		}
        user.setStatus(UserStatus.ACTIVE);
        user.setIsTempPassword(false);
        
        UserAgreement lastestAgreement = userAgreementDao.getLastestAgreement();
        user.setAgreementVersion(lastestAgreement.getTextVersion());

    	userDao.createUser(user);
    	userDto.setId(user.getId());
    	
    	//messageService.sendRegistrationConfirmationRequest(userConfirmation, profileTemplate);
        return user.getId(); 
    }
	
	@Override
	@Transactional
	public void updateUser(UserCompleteDto userDto) {
		Validate.notNull(userDto, "user is missing");
		Validate.notNull(userDto.getId(), "User id is missing");
		
		User oldUser = userDao.getUser(userDto.getId());
		if (oldUser == null) {
			throw new InvalidUserException(userDto.getId()) ;
		}
		
		UserStatus status = oldUser.getStatus();
		if (userDto.getStatus() == null) {
			userDto.setStatus(status);
		}
		
		// Preserve internal reserved fields from overriding from outside
		userDto.setTempPassword(oldUser.getIsTempPassword());
		userDto.setAgreementVersion(oldUser.getAgreementVersion());
		userDto.setMustAcceptAgreement(oldUser.getMustAcceptAgreement());
		
		/*
		Authentication is done by the AuthenticationInterceptor
		String password = userDto.getPassword();
		String hashPassInput;
		try {
			hashPassInput = SecurityUtil.getHashInBase64(
				StringUtils.trimToEmpty(password), oldUser.getSalt());
		} catch (Exception e) {
			throw new EncryptionException("Failed to encrypt");
		}
		if(!oldUser.getHashedPassword().equals(hashPassInput)){
			throw new AuthenticationException();
		}
		*/
		
		beanMapper.map(userDto, oldUser);
		userDao.update(oldUser);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void removeUser(Long userId) {
		User user = userDao.getUser(userId);
		user.setStatus(UserStatus.INACTIVE);
		userDao.update(user);
	}
	
	@Override
	@Transactional
	public void confirmUserRegistration(String refNum) {
		UserConfirmation confirm = userConfirmationDao.findByRefNum(refNum);
		User user = userDao.find(confirm.getUserId());
		user.setStatus(UserStatus.ACTIVE);
		userDao.update(user);
		
		// Database should timestamp the insertion and changes to events in the table
		// Normally the interceptor takes care of setting up the user for stamping the
		// records. However, in this case the request comes by clicking on a link and a
		// special handling is needed.
		//
		// TODO: decide which one to use for stamping the record in the database user 
		// key does not change, but email does. on the other side emails are being used 
		// in Schedule Group tool for identification. The latter can be work arounded 
		// by using the group key. will be added to design meetings agenda.
		StandardUtils.setUser(user.getEmail()); 
		
		confirm.setConfirmationTime(new DateTime());
		userConfirmationDao.update(confirm);
	}
	
	/**
	 * create a temp password and send the password to user's email.<br>
	 * user can use this password to change to a new one he wants
	 * @param userKey
	 * @throws IOException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidUserException 
	 */
	@Override
	@Transactional
	public void sendChangePasswordRequest(String email) {
		Validate.notEmpty(email,"User email is missing");
		
		User user = userDao.getUser(email);
		if (user == null) {
			throw new InvalidUserException(email) ;
		}
		
		String randomPassword;
		String hashWithSalt;
		try {
			randomPassword = SecurityUtil.getRandomPassword();
			hashWithSalt = SecurityUtil.hashWithSalt(randomPassword,user.getSalt());
		} catch (Exception e) {
			throw new EncryptionException("Failed to encrypt");
		}

		user.setHashedPassword(hashWithSalt);
		user.setIsTempPassword(true);
		messageService.sendTemporaryPassword(user,randomPassword);
		userDao.update(user);
	}
	
	/**
	 * change the user's(as identified by the userKey) password to the new one <br>
	 * if the old password matches the one in the DB
	 * @throws InvalidUserException 
	 */
	@Override
	@Transactional
	public void changePassword(String email, String oldPassowrd, String newPassword) {
		Validate.notEmpty(email,"User email is missing");
		Validate.notEmpty(oldPassowrd,"oldPassowrd is missing");
		Validate.notEmpty(newPassword,"newPassword is missing");
		
		User user = userDao.getUser(email);
		if (user == null) {
			throw new InvalidUserException(email) ;
		}
		
		String hashedOldPass = null;
		try {
			hashedOldPass = SecurityUtil.getHashInBase64(oldPassowrd, user.getSalt());
		} catch (Exception e) {
			throw new EncryptionException("Failed to encrypt");
		}
		
		if(user.getHashedPassword().equals(hashedOldPass)){
			user.setPassword(newPassword);
			
			try {
				SecurityUtil.sethHashPasswordAndSalt(user);
			} catch (Exception e) {
				throw new EncryptionException("Failed to encrypt");
			}
			
			if(Boolean.TRUE.equals(user.getIsTempPassword())) {
			   user.setIsTempPassword(false);
			}
			
			userDao.update(user);
		} else {
			throw new AuthenticationException();
		}
	}

//	/**
//	 * Retrieve messages for a user by id
//	 */
//	@Override
//	@Transactional(readOnly=true)
//	public List<Message> getUserMessages(Long userId) {
//		Validate.notNull(userId,"User id is missing");
//		return messageDao.getMessagesByUserId(userId);
//	}
//	
//	@Override
//	@Transactional()
//	public void deleteUserMessages(Long userId) {
//		Validate.notNull(userId,"User id is missing");
//		messageDao.deleteMessagesForUser(userId);
//	}

	
//	// authentication is done by the interceptor, prior removing this method check
//	@Deprecated    // to see if must accept user agreement flag is properly passed
//	@Override
//	@Transactional(readOnly=true)
//	public UserCompleteDto authenticateUser(final String email, final String password) {
//		Validate.notEmpty(email,"User email is missing");
//		Validate.notEmpty(password,"Password is missing");
//
//		User user = userDao.getUser(email);
//		if (user == null) {
//			throw new InvalidUserException(email) ;
//		}
//		
//		String hashedOldPass = null;
//		try {
//			hashedOldPass = SecurityUtil.getHashInBase64(password, user.getSalt());
//		} catch (Exception e) {
//			throw new EncryptionException("Failed to encrypt");
//		}
//		
//		if (user.getHashedPassword().equals(hashedOldPass)) {
//			UserAgreement lastestAgreement = userAgreementDao.getLastestAgreement();
//			if (lastestAgreement.getTextVersion() <= user.getAgreementVersion()) {
//				user.setMustAcceptAgreement(false);
//			} else {
//				user.setMustAcceptAgreement(true);
//			}
//
//			UserCompleteDto userDto = (UserCompleteDto) toUserDto(user, ContentLimit.COMPLETE, ContentStatus.ACTIVE, NO_GROUP_LIMITED);
//			return userDto;
//		} else {
//			throw new AuthenticationException();
//		}
//	}
	
}