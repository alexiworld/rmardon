/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;

import com.coloredshapes.coreservices.domain.RequestedEvent;

public class RequestedEventListDeserializer extends JsonDeserializer<List<RequestedEvent>> {

	@Override
	public List<RequestedEvent> deserialize(JsonParser jp,
			DeserializationContext ctxt) throws IOException,
			JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();  
		String rawText=jp.getText();
		//String str=jp.nextToken().asString();
		//System.out.println(rawText);
		List<RequestedEvent> requestedEventList =
			    mapper.readValue(rawText, TypeFactory.collectionType(List.class, RequestedEvent.class));
		return requestedEventList;
	}

}
