/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class CoreServicesException extends RuntimeException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 5955320098374356362L;
	private static final String errCode = "0001";

	public String getErrorCode() {
		return errCode;
	}

}