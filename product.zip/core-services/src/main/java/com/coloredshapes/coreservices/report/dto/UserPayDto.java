/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.report.dto;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.joda.time.DateTime;

public class UserPayDto {

	@NotNull
	private String group;

	@NotNull
	private String user;
	
	@NotNull
	private double pay;
	
	@NotNull
	private DateTime startTime;

	@NotNull
	private DateTime endTime;

    /**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}


	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the pay
	 */
	public double getPay() {
		return pay;
	}

	/**
	 * @param pay the pay to set
	 */
	public void setPay(double pay) {
		this.pay = pay;
	}

	/**
	 * @param pay the pay to add
	 */
	public void addPay(double pay) {
		this.pay += pay;
	}

	/**
	 * @return the startTime
	 */
	public DateTime getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public DateTime getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("group", group) 
        	.append("user", user) 
            .append("pay", pay)   
            .append("startTime", startTime)   
            .append("endTime", endTime)   
            .toString();
    }

}