/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.enums.SourceType;
import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;

/**
 * <code>Event</code> is entity class used to
 * persist information about a time slot blocked 
 * with a specific note or tag.
 */
@Entity
@Table(name="event")
public class Event extends BaseEntity implements Comparable<Event> {

	public static final long serialVersionUID = 4217203685202244736L;

	@NotNull
	@Column(name="start_time")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime startTime;
	
	@NotNull
	@Column(name="end_time")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime endTime;
	
	@NotNull
	@ManyToOne
	@JoinColumn(name="user_id", nullable=false)
	private User user;
    
	@Column(name="note")
    private String note;
    
	// TODO: Review if group is really needed since it 
	// is indirectly accessible via assignment property
	@ManyToOne
    @JoinColumn(name="group_id")
	private Group group;
    
	@ManyToOne
    @JoinColumn(name="assignment_id")
	private Assignment assignment;
    
	@NotNull
    @Enumerated(EnumType.STRING)
    @Column(name="source_type")
    private SourceType sourceType;
    
	@JsonSerialize(using = DateSerializer.class)
	public DateTime getStartTime() {
		return startTime;
	}

	@JsonDeserialize(using = DateDeserializer.class)
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	@JsonSerialize(using = DateSerializer.class)
	public DateTime getEndTime() {
		return endTime;
	}

	@JsonDeserialize(using = DateDeserializer.class)
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	@JsonIgnore
	public User getUser() {
		return user;
	}

	@JsonIgnore
	public void setUser(User user) {
		this.user = user;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@JsonIgnore
	public Group getGroup() {
		return group;
	}

	@JsonIgnore
	public void setGroup(Group group) {
		this.group = group;
	}
	
	@JsonIgnore
	public Assignment getAssignment() {
		return assignment;
	}

	@JsonIgnore
	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}

	@JsonIgnore
	public SourceType getSourceType() {
		return sourceType;
	}

	@JsonIgnore
	public void setSourceType(SourceType sourceType) {
		this.sourceType = sourceType;
	}
    
    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(Event that) {
    	return this.startTime.compareTo(that.startTime);
    }

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
	        .append("startTime", startTime) 
	        .append("endTime", endTime)   
        	.append("user", (user.getId() + "#" + user.getEmail())) 
            .append("group", (group != null ? group.getId() + "#" + group.getName() : ""))
            .append("assignment", (assignment != null ? assignment.getId() + "#" + assignment.getRole().getName() : ""))
            .append("note", note)
            .toString();
    }
    
    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof Event)) return false;

        Event otherEvent = (Event) that;

        return new EqualsBuilder()
	        .append(startTime, otherEvent.startTime)
	        .append(endTime, otherEvent.endTime)
	        .append(user, otherEvent.user)
	        .append(group, otherEvent.group)
	        .append(assignment, otherEvent.assignment)
	        .append(note, otherEvent.note)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user key is always present, while the group key not.
     * To improve the searching performance in a map the hash
     * code only takes the user key into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
	        .append(startTime)
	        .append(endTime)
	        .append(user)
	        .append(group)
	        .append(assignment)
	        .append(note)
	        .hashCode();
    }

}