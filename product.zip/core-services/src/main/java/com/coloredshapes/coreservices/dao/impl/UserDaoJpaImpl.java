/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.User_;

@Repository
public class UserDaoJpaImpl extends BaseJpaImpl<User> implements UserDao {

	@Override
	public User getUser(Long id) {
		User user = entityManager.find(User.class, id);
		return user;
	}

	@Override
	public List<User> getUsers(Long[] userIds) {
		CriteriaQuery<User> criteria = entityManager.getCriteriaBuilder().createQuery(User.class);
		Root<User> userRoot = criteria.from( User.class );
		criteria.select( userRoot );

		//@SuppressWarnings("unused")
		//Metamodel m = entityManager.getMetamodel();

		criteria.where(userRoot.get(User_.id).in((Object[]) userIds));
		return  entityManager.createQuery( criteria ).getResultList();
	}
	
	@Override
	public User getUser(String email) {
		CriteriaQuery<User> criteria = entityManager.getCriteriaBuilder().createQuery(User.class);
		
		Root<User> userRoot = criteria.from( User.class );
		criteria.select( userRoot );
		criteria.where( entityManager.getCriteriaBuilder().equal( userRoot.get("email"), email) );

		List<User> resultList = entityManager.createQuery(criteria).getResultList();
		if (resultList.size() < 1) {
			return null;
		} else {
			return resultList.get(0);
		}
	}

	@Override
	public List<User> getUsers(String[] emails) {
		CriteriaQuery<User> criteria = entityManager.getCriteriaBuilder().createQuery(User.class);
		Root<User> userRoot = criteria.from( User.class );
		criteria.select( userRoot );

		//@SuppressWarnings("unused")
		//Metamodel m = entityManager.getMetamodel();

		criteria.where(userRoot.get(User_.email).in((Object[]) emails));
		return  entityManager.createQuery( criteria ).getResultList();
	}

	@Override
	public long getUserByFirstAndLastName(String firstName, String lastName) {
		TypedQuery<Long> createQuery = entityManager.createQuery(
				"select count(*) from User m where m.firstName = :firstName and m.lastName = :lastName", Long.class);
		createQuery.setParameter("firstName", firstName);
		createQuery.setParameter("lastName", lastName);
		Long count = createQuery.getSingleResult();
		//System.out.println("count:"+count);
		return count;
	}

	@Override
	public List<User> getUsersByNamePrefix(String namePrefix, List<Long> groupIds) {
		TypedQuery<User> createQuery = entityManager.createQuery(
				//"select u from User u where str(u.firstName || ' ' || u.lastName) like :namePrefix and u.groups.id in :groupIds", User.class);
				"select u from User u join u.groups as group with group.id in :groupIds where str(u.firstName || ' ' || u.lastName) like :namePrefix", User.class); //
		createQuery.setParameter("namePrefix", namePrefix + '%');
		createQuery.setParameter("groupIds", groupIds);
		List<User> users = createQuery.getResultList();
		return users;
	}
	
	@Override
	public void createUser(User user) {
		create(user);
	}

}