/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import com.coloredshapes.coreservices.domain.entity.User;

public interface UserDao extends GenericDao<User> {

	User getUser(Long userId);

	List<User> getUsers(Long[] userIds);

	User getUser(String email);

	List<User> getUsers(String[] emails);

	long getUserByFirstAndLastName(String firstName, String lastName);
	
	List<User> getUsersByNamePrefix(String namePrefix, List<Long> groupIds);

	void createUser(User user);

}
