/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.MembershipRequestDao;
import com.coloredshapes.coreservices.domain.entity.MembershipRequest;

@Repository
public class MembershipRequestDaoJpaImpl  extends BaseJpaImpl<MembershipRequest> implements MembershipRequestDao {

	@Override
	public void createMembershipRequest(MembershipRequest membershipReq) {
		create(membershipReq);
		entityManager.flush();
	}

	@Override
	public MembershipRequest getMembershipRequestByRefIdAndUserId(String refId, Long userId) {
		TypedQuery<MembershipRequest> query = entityManager.createQuery(
		        "SELECT mr FROM MembershipRequest mr WHERE mr.userId = :userId and mr.referenceId=:referenceId", MembershipRequest.class);
	    query.setParameter("userId", userId); 
	    query.setParameter("referenceId", refId); 
		return query.getSingleResult();
	}
	
	@Override
	public List<MembershipRequest> getMembershipRequestByGroupIdAndUserId(Long groupId, Long userId) {
		TypedQuery<MembershipRequest> query = entityManager.createQuery(
		        "SELECT mr FROM MembershipRequest mr WHERE mr.userId = :userId and mr.groupId=:groupId", MembershipRequest.class);
	    query.setParameter("userId", userId); 
	    query.setParameter("groupId", groupId); 
	    
		return query.getResultList();
	}

	@Override
	public void updateMembershipRequest(MembershipRequest membershipReq) {
		update(membershipReq);
	}

}
