/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.utils;

import java.util.Comparator;

import com.coloredshapes.coreservices.domain.dto.DateEventDto;

/**
 * <code>DateEventComparator</code> is comparator for date events 
 * to be used to sort date events based on the start and end times
 * only.
 */
public class DateEventComparator implements Comparator<DateEventDto> {

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(DateEventDto dateEvent1, DateEventDto dateEvent2) {
		long result = dateEvent1.getStartTime().getMillis() - dateEvent2.getStartTime().getMillis();
		if (result == 0) {
			result = dateEvent1.getEndTime().getMillis() - dateEvent2.getEndTime().getMillis();
		}
		return result == 0 ? 0 : (result > 0 ? 1 : -1);
	}

}