/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.Role;

public interface RoleDao extends GenericDao<Role> {
	
}
