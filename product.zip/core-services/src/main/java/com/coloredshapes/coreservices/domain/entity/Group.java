/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.enums.AssignmentStatus;
import com.coloredshapes.coreservices.domain.enums.GroupStatus;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.enums.RoleStatus;
import com.coloredshapes.coreservices.domain.enums.UserStatus;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;
import com.coloredshapes.coreservices.utils.StandardUtils;

//TODO: Create annotation class for validation enforcing
//not null values for specific fields e.g. business ones,
//address, phone numbers, etc. for business groups.

@Entity
@Table(name = "usergroup")
public class Group extends BaseEntity {

	/**
	 * This class serial version UID
	 */
	public static final long serialVersionUID = 6545645654L;
	
	@NotNull
	@Column(name = "name")
	private String name;
	
	@NotNull
	@Column(name = "short_name")
	@Size(min = 1, max = 8)
	private String shortName;

	@Column(name = "description")
	private String description;
	
	//@Transient
	// The field is marked transient because it is not persisted in the database. It is
	// used to identify the parent group to which a newly created group is to be added 
	// as a child. The value is null when a top group is to be created.
	@Column(name = "parent_id")
	private Long parentId;
	
	//@ManyToOne
	//@JoinColumn(name="parent_group", nullable = true)
	//private Group parentGroup;

	// TODO: Allow a group to be promoted to top group for all its descendants. The
	// group becoming top group can have a parent group and therefore different top 
	// group. This solution would enable membership to be supported on any/specific 
	// level.
	@ManyToOne
	@JoinColumn(name="top_id", nullable = true)
	private Group topGroup;

	@JsonIgnore
	// DESIGN CONSIDERATIONS:
	// To minimize dependencies between entities memberships will be obtained via MembershipDao by 
	// passing groupId. If eager fetch later is required one to many relationship will be restored.
	@OneToMany(cascade=CascadeType.ALL, mappedBy="group", fetch = FetchType.LAZY, orphanRemoval = true)
	private List<Membership> memberships;

	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	@JoinColumn(name="parent_id")
	private List<Group> subGroups;

	// http://www.roseindia.net/hibernate/hibernate4/HibernateManytoMany.shtml
	// http://viralpatel.net/blogs/hibernate-many-to-many-annotation-mapping-tutorial/
	// http://www.mkyong.com/hibernate/hibernate-many-to-many-relationship-example-annotation/
	//
	// DESIGN CONSIDERATIONS:
	// To minimize dependencies between entities users will be obtained via UserDao by passing 
	// groupId. If eager fetch later is required many to many relationship will be restored.
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name="user_usergroup", 
		joinColumns={ @JoinColumn(name="group_id", nullable = false, updatable = false)}, 
		inverseJoinColumns={ @JoinColumn(name="user_id", nullable = false, updatable = false)})
	private List<User> users;

	@JsonIgnore
	@OneToMany(cascade=CascadeType.ALL, mappedBy="group", fetch = FetchType.LAZY, orphanRemoval = true)
	private List<Role> roles;

	@JsonIgnore
	@OneToMany(mappedBy="group", fetch = FetchType.LAZY)
	private List<Assignment> assignments;

	@Column(name = "on_board_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime onBoardDate;
	
	@Column(name = "deactivated_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime deactivatedDate;
	
	//@NotNull
	@Size(min = 0, max = 20)
	@Column(name = "phone_number")
	//The phone number regex, but permitting empty values. Replaced by Size(min = 0) for simplicity.
	//@Pattern(regexp = "^((\\s){0}|([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4}))$")
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String phoneNumber;
	
	//@NotNull
	@Size(min = 0, max = 20)
	@Column(name = "mobile_number")
	//The phone number regex, but permitting empty values. Replaced by Size(min = 0) for simplicity.
	//@Pattern(regexp = "^((\\s){0}|([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4}))$")
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String mobileNumber;
	
	//@NotNull
	@Column(name = "address")
	private String address;
	
	//@NotNull
	@Column(name = "city")
	private String city;
	
	//@NotNull
	//@Pattern(regexp = "^((AB)|(BC)|(MB)|(NB)|(NL)|(NT)|(NS)|(NU)|(ON)|(PE)|(QC)|(SK)|(YT))$")
	//@Column(name = "province")
	//private String province;
	
	//@NotNull
	@Column(name = "region")
	private String region;
	
	//@NotNull
	@Column(name = "country")
	private String country;
	
	//@NotNull
	@Pattern(regexp = "^(([A-Z]\\d[A-Z]\\s\\d[A-Z]\\d)|(\\d{5}))$")
	@Column(name = "postal_code")
	private String postalCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
	@Column(name = "email")
	private String email;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private GroupStatus status;

	public String getName() {
		return name;
	}

	public void setName(String groupName) {
		this.name = groupName;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonSerialize(using = IdSerializer.class)
	public Long getParentId() {
		return parentId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Group getTopGroup() {
		return topGroup;
	}

	public void setTopGroup(Group topGroup) {
		this.topGroup = topGroup;
	}

	public List<Membership> getMemberships() {
		return memberships;
	}

	public List<Membership> getMemberships(MembershipStatus status) {
		List<Membership> filteredMemberships = new ArrayList<Membership>(memberships.size());
		for (Membership membership : memberships) {
			if (ObjectUtils.equals(membership.getMembershipStatus(), status)) {
				filteredMemberships.add(membership);
			}
		}
		return filteredMemberships;
	}

	public void setMemberships(List<Membership> memberships) {
		this.memberships = memberships;
	}

	public List<Group> getSubGroups() {
		return subGroups;
	}

	public void setSubGroups(List<Group> subGroups) {
		this.subGroups = subGroups;
	}
	
	public List<User> getUsers() {
		return users;
	}

	public List<User> getUsers(UserStatus status) {
		List<User> filteredUsers = new ArrayList<User>(users.size());
		for (User user : users) {
			if (ObjectUtils.equals(user.getStatus(), status)) {
				filteredUsers.add(user);
			}
		}
		return filteredUsers;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public List<Role> getRoles(RoleStatus status) {
		List<Role> filteredRoles = new ArrayList<Role>(roles.size());
		for (Role role : roles) {
			if (ObjectUtils.equals(role.getStatus(), status)) {
				filteredRoles.add(role);
			}
		}
		return filteredRoles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public List<Assignment> getAssignments() {
		return assignments;
	}

	public List<Assignment> getAssignments(AssignmentStatus status) {
		List<Assignment> filteredAssignments = new ArrayList<Assignment>(assignments.size());
		for (Assignment assignment : assignments) {
			if (ObjectUtils.equals(assignment.getStatus(), status)) {
				filteredAssignments.add(assignment);
			}
		}
		return filteredAssignments;
	}

	public void setAssignments(List<Assignment> assignments) {
		this.assignments = assignments;
	}

	@JsonSerialize(using = DateSerializer.class, include = JsonSerialize.Inclusion.NON_NULL)
	public DateTime getOnBoardDate() {
		return onBoardDate;
	}

	public void setOnBoardDate(DateTime onBoardDate) {
		this.onBoardDate = onBoardDate;
	}

	@JsonSerialize(using = DateSerializer.class, include = JsonSerialize.Inclusion.NON_NULL)
	public DateTime getDeactivatedDate() {
		return deactivatedDate;
	}

	public void setDeactivatedDate(DateTime deactivatedDate) {
		this.deactivatedDate = deactivatedDate;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		if (StringUtils.isBlank(phoneNumber)) {
			this.phoneNumber = null;
		} else {
			this.phoneNumber = phoneNumber;
		}
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		if (StringUtils.isBlank(mobileNumber)) {
			this.mobileNumber = null;
		} else {
			this.mobileNumber = mobileNumber;
		}
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	//public String getProvince() {
	//	return province;
	//}
	//
	//public void setProvince(String province) {
	//	this.province = province;
	//}
	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonIgnore
	public GroupStatus getStatus() {
		return status;
	}

	@JsonIgnore
	public void setStatus(GroupStatus status) {
		this.status = status;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("name", name) 
        	.append("shortName", shortName) 
        	.append("description", description) 
            .append("parentId", parentId) 
        	.append("topGroup", (topGroup == null ? topGroup : topGroup.getId())) 
            .append("memberships", StandardUtils.toEntityString(memberships))   
            .append("subGroups", StandardUtils.toEntityString(subGroups))   
            .append("users", StandardUtils.toEntityString(users))   
            .append("roles", StandardUtils.toEntityString(roles))   
            .append("assignments", StandardUtils.toEntityString(assignments))   
            .append("onBoardDate", onBoardDate)
            .append("deactivatedDate", deactivatedDate)
            .append("phoneNumber", phoneNumber)
            .append("mobileNumber", mobileNumber)
            .append("address", address)
            .append("city", city)
            //.append("province", province) 
            .append("region", region) 
            .append("country", country) 
            .append("postalCode", postalCode)
            .append("email", email)
            .append("status", status)
            .toString();
    }

}