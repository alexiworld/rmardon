/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.dto;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * <code>ReferenceNumber</code> is a class representing
 * a reference number for specific operation or action.
 */
public class ReferenceNumber {
	
	private String refNum;

    /**
     * Creates a reference number instance.
     */
	public ReferenceNumber(String refNum) {
		this.refNum = refNum;
	}
	
	/**
	 * Sets the reference number.
	 * 
	 * @param refNum the reference number to set
	 */
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	/**
	 * Gets the reference number.
	 * 
	 * @return the reference number
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getRefNum() {
		return refNum;
	}
	
    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
    	return new ToStringBuilder(this)
	    	.append("refNUm", refNum)
	    	.toString();
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
    	if (this == that) return true;
        if (!(that instanceof ReferenceNumber)) return false;

        ReferenceNumber otherReferenceNumber = (ReferenceNumber) that;
        return new EqualsBuilder()
	        .append(refNum, otherReferenceNumber.refNum)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user key is always present, while the group key not.
     * To improve the searching performance in a map the hash
     * code only takes the user key into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
    	return new HashCodeBuilder(17, 37).append(refNum).hashCode();
    }
   
}