/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.UserAgreementDao;
import com.coloredshapes.coreservices.domain.entity.UserAgreement;

@Repository
public class UserAgreementDaoImpl extends BaseJpaImpl<UserAgreement> implements UserAgreementDao {

	@Override
	public UserAgreement getLastestAgreement() {
		TypedQuery<UserAgreement> query = entityManager.createQuery(
		        "SELECT agreement FROM UserAgreement agreement ORDER BY agreement.textVersion DESC", UserAgreement.class);

	    List<UserAgreement> resultList = query.setMaxResults(1).getResultList();
	    if(resultList==null || resultList.size()==0){
	    	return null;
	    }else{
	    	return resultList.get(0);
	    }
	}

	
}
