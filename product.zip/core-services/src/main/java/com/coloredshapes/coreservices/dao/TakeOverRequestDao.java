/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;

public interface TakeOverRequestDao extends GenericDao<TakeOverRequest>{

	TakeOverRequest getTakeOverRequestById(Long torId);

}
