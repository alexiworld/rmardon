/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class AuthorizationException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -5661476068936857057L;
	private static final String errCode = "0003";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
