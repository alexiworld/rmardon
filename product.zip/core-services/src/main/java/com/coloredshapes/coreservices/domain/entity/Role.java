/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.coloredshapes.coreservices.domain.enums.RoleStatus;

@Entity
@Table(name = "role")
public class Role extends BaseEntity {

	/**
	 * The serial version UID
	 */
	public static final long serialVersionUID = -8094593518067498358L;

	@ManyToOne
	@JoinColumn(name="group_id", nullable = false) 
	private Group group;

	@NotNull
	@Column(name = "name")
	@Size(min = 1)
	private String name;
	
	@NotNull
	@Column(name = "short_name")
	@Size(min = 1, max = 8)
	private String shortName;
	
	@Column(name = "description")
    private String description;
	
	@Column(name = "qualification")
	private String qualification;
	
	@Column(name = "color")
    private String color;

	@Column(name = "note")
	private String note;
	
  	@Embedded
 	private Hours hours = new Hours();

 	@Column(name = "rate")
    private Double rate;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private RoleStatus status;
	
	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Hours getHours() {
		return hours;
	}

	public void setHours(Hours hours) {
		this.hours = hours;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}
	
    public RoleStatus getStatus() {
		return status;
	}

	public void setStatus(RoleStatus status) {
		this.status = status;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("group", (group == null ? group : group.getId())) 
        	.append("name", name) 
        	.append("shortName", shortName) 
        	.append("description", description) 
            .append("qualification", qualification)   
            .append("color", color) 
        	.append("note", note) 
         	.append("hours", hours) 
         	.append("rate", rate) 
         	.append("status", status) 
            .toString();
    }

}