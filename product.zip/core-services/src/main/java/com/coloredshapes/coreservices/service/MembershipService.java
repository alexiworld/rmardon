/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.dto.MembershipDto;

public interface MembershipService {
	
	public List<MembershipDto> getGroupMemberships(Long groupId);
	
	public List<MembershipDto> getUserMemberships(Long userId);
	
	public void initiateMembership(MembershipDto membership);

	public void confirmMembership(final Long userId, final String refNum);
	
	public void updateGroupMemberships(Long userId, Map<Long, String> statuses);

	public void updateUserMemberships(Long userId, Map<Long, String> statuses);
	
	public void inactivateMemberships(Long groupId, List<String> userEmails, boolean forceDelete);

	public void deleteMembership(MembershipDto membership);
}
