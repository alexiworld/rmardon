/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.enums.GroupStatus;
import com.coloredshapes.coreservices.domain.jsonhelper.LowerCaseDeserializer;

public class GroupProfileDto extends GroupBasicDto {

	protected BusinessDto business;
	
	// Group instances with BusinessDto would be validated by class level validator/annotation to
	// ensure phone number, address, etc. are provided. These fields are optional for simple groups
	//@NotNull
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	protected String phoneNumber;
	
	//@NotNull
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String mobileNumber;

	//@NotNull
	protected String address;
	
	//@NotNull
	protected String city;
	
	//@NotNull
	//@Pattern(regexp = "^((AB)|(BC)|(MB)|(NB)|(NL)|(NT)|(NS)|(NU)|(ON)|(PE)|(QC)|(SK)|(YT))$")
	//protected String province;

	//@NotNull
	private String region;
	
	//@NotNull
	private String country;
	
	//@NotNull
	@Pattern(regexp = "^(([A-Z]\\d[A-Z]\\s\\d[A-Z]\\d)|(\\d{5}))$")
	protected String postalCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
	protected String email;

	//@Enumerated(EnumType.STRING)
	protected GroupStatus status;

	/**
	 * Gets the business.
	 * 
	 * @return	the business.
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public BusinessDto getBusiness() {
		return business;
	}

	/**
	 * Sets the business.
	 * 
	 * @param business		the business to set
	 */
	public void setBusiness(BusinessDto business) {
		this.business = business;
	}

	/**
	 * Gets the phone number.
	 * 
	 * @return	the phone number
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 * 
	 * @param phoneNumber		the phone number to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Gets the mobile number.
	 * 
	 * @return	the mobile number
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Sets the mobile number.
	 * 
	 * @param mobileNumber		the mobile number to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * Gets the address.
	 * 
	 * @return	the address
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 * 
	 * @param address		the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the city.
	 * 
	 * @return	the city
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 * 
	 * @param city		the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the region (state, province).
	 * 
	 * @return	the region (state, province)
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getRegion() {
		return region;
	}

	/**
	 * Sets the region (state, province).
	 * 
	 * @param region	the region (state, province)
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	
	/**
	 * Gets the country.
	 * 
	 * @return the country
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 * 
	 * @param country		the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the postal code (zip).
	 * 
	 * @return	the postal code (zip)
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code (zip).
	 * 
	 * @param postalCode	the postal code (zip) to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the email.
	 * 
	 * @return	the email
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 * 
	 * @param email		the email to set
	 */
	@JsonDeserialize(using = LowerCaseDeserializer.class)
	public void setEmail(String email) {
		this.email = email;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("business", business) 
            .append("phoneNumber", phoneNumber)
            .append("mobileNumber", mobileNumber)
            .append("address", address)
            .append("city", city)
            .append("region", region) 
            .append("postalCode", postalCode)
            .append("email", email)
            .append("status", status)
            .toString();
    }

}