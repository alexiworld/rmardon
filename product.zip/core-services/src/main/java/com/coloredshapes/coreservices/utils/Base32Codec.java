package com.coloredshapes.coreservices.utils; 

import java.util.Arrays; 
import java.util.Random; 

/**
 * https://groups.google.com/forum/?fromgroups#!topic/objectify-appengine/4y4O2pCIgG0
 * Thanks to jd for sharing the code
 *
 */
public class Base32Codec 
{ 
        private final char[] values = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ,'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z'}; 
        private final boolean correct; 
         
        public Base32Codec() 
        { 
                correct = true; 
        } 

        public Base32Codec(boolean correct) 
        { 
                this.correct = correct; 
        } 
                 
        public String encodeInt(int key) 
        { 
                char[] chars = new char[7]; 
                int check = 0; 
                for (int i = 0; i < 32; i += 5) 
                { 
                        // take next 5 bits from the input 
                        int index = (key & (31 << i)) >>> i; 
                         
                        // keep a check sum 
                        check ^= index; 
                         
                        // on the last char use 3 bits from the check sum 
                        if (i == 30) 
                        { 
                                // mix up the checksum then use bits 3,4 and 5 
                                index |= ((check << 2) ^ check ^ (check >>> 2)) & 28; 
                        } 
                         
                        chars[i / 5] = values[index]; 
                } 
                return new String(chars); 
        } 

        public long decodeLong(String code) 
        { 
                if (code.length() != 14) 
                { 
                        throw new IllegalArgumentException("Wrong number of chars"); 
                } 
                int first = decodeInt(code.substring(0, 7)); 
                int second = decodeInt(code.substring(7)); 
                long value = 0; 
                value |= first; 
                value &= Long.MAX_VALUE; // remove sign bit if set 
                value |= (long) second << 32; 
                return value; 
        } 
         
        public int decodeInt(String code) 
        { 
                if (code.length() != 7) 
                { 
                        throw new IllegalArgumentException("Expected 7 characters"); 
                } 

                int key = 0; 
                int check = 0; 
                int index = 0; 
                for (int i = 0; i < 7; i++) 
                { 
                        char c = Character.toUpperCase(code.charAt(i)); 

                        if (correct) 
                        { 
                                // correct some mistakes 
                                if (c == 'O') 
                                { 
                                        c = '0'; 
                                } 
                                else if (c =='L') 
                                { 
                                        c = '1'; 
                                } 
                                else if (c == 'I') 
                                { 
                                        c = '1'; 
                                } 
                        } 

                        index = Arrays.binarySearch(values, c); 
                        if (index < 0) 
                        { 
                                throw new IllegalArgumentException("Invalid character " + c); 
                        } 
                         
                        if (i == 6) 
                        { 
                                // only use the last 2 bits for check sum 
                                check ^= index & 3; 
                        } 
                        else 
                        { 
                                check ^= index; 
                        } 
                        key |= index << (i * 5); 
                } 

                if ((((check << 2) ^ check ^ (check >>> 2)) & 28) != (index & 28)) 
                { 
                        throw new IllegalArgumentException("Failed checksum"); 
                } 

                return key; 
        } 

        public String encodeLong(long value) 
        { 
                int first = 0; 
                first |= value; 
                int second = 0; 
                second |= value >>> 32; 
                return encodeInt(first) + encodeInt(second); 
        } 
         
        public static void main(String[] args) 
        { 
                Base32Codec codec = new Base32Codec(true); 
                 
                Random random = new Random(); 
                 
                for (int i = 0; i < 100; i++) 
                { 
                        // get a 25 bit random number 
                        int value = random.nextInt(0x01FFFFFF); 
                         
                        String encoded = codec.encodeInt(value); 
                         
                        int decoded = codec.decodeInt(encoded); 
                         
                        System.out.println(decoded == value); 
                } 
        } 
         
} 