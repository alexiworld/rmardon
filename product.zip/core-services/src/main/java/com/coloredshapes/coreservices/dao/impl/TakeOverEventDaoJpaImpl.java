/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;

import com.coloredshapes.coreservices.dao.TakeOverEventDao;
import com.coloredshapes.coreservices.domain.entity.TakeOverEvent;

@Service
public class TakeOverEventDaoJpaImpl extends BaseJpaImpl<TakeOverEvent> implements TakeOverEventDao{



	@Override
	public TakeOverEvent getTakeOverEvent(
			Long torId, Long userId) {
		TypedQuery<TakeOverEvent> query = entityManager.createQuery(
		        "SELECT tor FROM TakeOverEvent tor WHERE  tor.takeOverRequest.id=:torId and tor.user.id = :userId ", TakeOverEvent.class);
		query.setParameter("torId", torId); 
		query.setParameter("userId", userId); 	
		List<TakeOverEvent> resultList = query.getResultList();
		if(resultList.size()>0){
			return resultList.get(0);
		}else{
			return null;
		}
	}  

}
