/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.dto;

/**
 * DTO that wraps error code and error message in the response
 * 
 */
public class ErrorResp {

	private String errCode;
	private String message;

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}