/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

import org.codehaus.jackson.annotate.JsonProperty;

public class ExistingEventException extends RuntimeException {

	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 7772317263452596168L;
	private static final String errCode = "0005";

	@JsonProperty("errCode")
	public String getErrorCode() {
		return errCode;
	}
	
}
