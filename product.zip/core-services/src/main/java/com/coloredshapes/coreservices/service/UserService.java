/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.dto.CompositeDto;
import com.coloredshapes.coreservices.domain.dto.UserBasicDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;

public interface UserService {

	public UserBasicDto getCurrentUser();
	
	public UserBasicDto getUser(String email, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId);
	
	public UserBasicDto getUser(Long userId, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId);

	public List<UserBasicDto> getUsers(Long[] userIds, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId);

	public UserBasicDto getUsers(String email, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId);

	public List<UserBasicDto> getUsers(String[] emails, ContentLimit contentLimit, ContentStatus contentStatus, Long groupId);

	public List<Long> getGroupUserIds(Long groupId, ContentStatus contentStatus);

	public List<UserBasicDto> getGroupUsers(Long groupId, ContentLimit contentLimit, ContentStatus contentStatus);
	
	public Map<Long, String> getCoUsersByNamePrefix(String namePrefix);
	
	public List<CompositeDto> getGroupsCoUsers(Long userId, ContentLimit contentLimit, ContentStatus contentStatus);
	
    public boolean userExists(Long userId);
    
	public boolean emailExists(String email);

    public Long createUser(UserCompleteDto user);
    
	public void updateUser(UserCompleteDto user);
	
	public void removeUser(Long userId);
	
	public void confirmUserRegistration(String refNum);

	public void changePassword(String email, String oldPassowrd, String newPassword);

	public void sendChangePasswordRequest(String email);

//	public List<Message> getUserMessages(Long userId);
//	
//	public void deleteUserMessages(Long userId);

//	// authentication is done by the interceptor, prior removing this method check
//	@Deprecated    // to see if must accept user agreement flag is properly passed
//	public UserCompleteDto authenticateUser(String email, String password);
	
}