/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.service.UserAgreementService;
import com.coloredshapes.coreservices.service.UserService;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>UserAgreementsController</code> handles user agreements 
 * requests to REST services. 
 */
@Controller
public class UserAgreementsController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private UserAgreementService userAgreementService;
	
	@Autowired
	private UserService userService;
	
	/**
	 * REST service for retrieving users agreement
	 * 
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/userAgreement", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public String getAgreement() throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("getAgreement is called.");
		}
		
		return userAgreementService.getLastestAgreement().getText();
	}
	
	/**
	 * REST service for accepting users agreement
	 * 
	 * @param userId
	 *            the user key for whom the events are requested
	 * @throws Exception
	 *             raised in case something goes wrong
	 */
	@RequestMapping(value = "/userAgreement/{userId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void acceptAgreement(@PathVariable("userId") String userIdCode) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("acceptAgreement is called.");
			logger.debug("userId: " + userIdCode);
		}

		Long userId = StandardUtils.decodeLong(userIdCode);
		userAgreementService.acceptLatestAgreement(userId);
	}

}