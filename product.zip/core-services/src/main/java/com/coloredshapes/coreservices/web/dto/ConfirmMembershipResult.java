/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.dto;

public enum ConfirmMembershipResult {

       SUCCESSFUL("The membership confirmation is successful"),
       FAILED("The membership confirmation has failed");
       
       private String message;
       
       ConfirmMembershipResult(String message){
    	   this.message=message;
       }
       
       public String getMessage(){
    	   return message;
       }
}
