/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.joda.time.LocalTime;

import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.LocalTimeDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.LocalTimeSerializer;
import com.coloredshapes.coreservices.exception.InvalidEventException;

/**
 * <code>RepeatableEventDto</code> is a class representing a
 * repeatable event created by a user with a specific note.
 */
public class RepeatableEventDto implements Comparable<RepeatableEventDto> {
	
	private Long id;
    private DayOfWeek dayOfWeek;
    private LocalTime startTime;
    private LocalTime endTime;
	private Long userId;
	private String user;
	private String note;

    /**
     * Creates a repeatable event instance.
     */
	public RepeatableEventDto() {
	}

    /**
     * Creates a repeatable event instance.
     * 
     * @param dayOfWeek		the day of week to be set
     * @param startTime		the start time to be set
     * @param endTime		the end time to be set
     */
    public RepeatableEventDto(DayOfWeek dayOfWeek, LocalTime startTime, LocalTime endTime) {
        validateBeforeCreate(startTime,endTime);
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    /**
     * Creates a repeatable event instance.
     * 
     * @param dayOfWeek		the day of week to be set
     * @param startTime		the start time to be set
     * @param endTime		the end time to be set
     */
    public static RepeatableEventDto createRepeatableEvent(DayOfWeek dayOfWeek, String startTime, String endTime) {
        LocalTime start = LocalTime.parse(startTime);
        LocalTime end = LocalTime.parse(endTime);
        validateBeforeCreate(start,end);
        return new RepeatableEventDto(dayOfWeek,start,end);
    }

    /**
     * Validates times before creating the period instance.
     * 
     * @param startTime		the start time
     * @param endTime		the end time
     * @throws InvalidEventException is raised if the start time appears to be later than the end time.
     */
    private static void validateBeforeCreate(LocalTime startTime, LocalTime endTime) throws InvalidEventException {
		if (startTime.isAfter(endTime)) {
			throw new InvalidEventException("Start Time must be before End Time");
		}
		if (endTime.isBefore(startTime)) {
			throw new InvalidEventException("End Time must be after Start Time");
		}
    }

	/**
	 * Sets the id
	 * 
	 * @param id the id to set
	 */
	@JsonProperty("eventId")
	@JsonDeserialize(using = IdDeserializer.class)
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Gets the event id
	 * 
	 * @return the id
	 */
	@JsonProperty("eventId")
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getId() {
		return id;
	}

	/**
	 * Sets the day of the week
	 * 
	 * @param dayOfWeek 	the day of the week to set
	 */
	@JsonIgnore
	public void setDayOfWeek(DayOfWeek dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	
	/**
	 * Gets the day of the week
	 * 
	 * @return the day of the week
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public DayOfWeek getDayOfWeek(){
        return dayOfWeek;
    }

	/**
     * Sets the start time.
     * 
	 * @param startTime the start time to set
	 */
	@JsonDeserialize(using = LocalTimeDeserializer.class)
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	/**
     * Gets the start time
     * 
     * @return	the start time
     */
    @JsonSerialize(using = LocalTimeSerializer.class)
    public LocalTime getStartTime(){
        return new LocalTime(startTime.getHourOfDay(),startTime.getMinuteOfHour(),startTime.getSecondOfMinute(),startTime.getMillisOfSecond(),startTime.getChronology());
    }

	/**
	 * Sets the end time.
	 * 
	 * @param endTime the end time to set
	 */
	@JsonDeserialize(using = LocalTimeDeserializer.class)
	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	/**
     * Gets the end time
     * 
     * @return	the end time
     */
    @JsonSerialize(using = LocalTimeSerializer.class)
    public LocalTime getEndTime(){
        return new LocalTime(endTime.getHourOfDay(),endTime.getMinuteOfHour(),endTime.getSecondOfMinute(),endTime.getMillisOfSecond(),endTime.getChronology());
    }

	/**
	 * Sets the user id
	 * 
	 * @param userId the user id to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user id
	 * 
	 * @return the user id
	 */
	@JsonSerialize(using=IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}

	/**
	 * Sets the user
	 * 
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Gets the user 
	 * 
	 * @return the user
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getUser() {
		return user;
	}

	/**
	 * Sets the note
	 * 
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

    /**
     * Gets the note
     * 
	 * @return the note
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getNote() {
		return note;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return "" + dayOfWeek + " ["+startTime.toString("HH:mm")+" - "+endTime.toString("HH:mm")+"]";
        
        /* PROPOSAL:
        return new ToStringBuilder(this)
        	.append("dayOfWeek", dayOfWeek) 
        	.append("startTime", startTime) //.toString("HH:mm")
            .append("endTime", endTime)     //.toString("HH:mm")
            .append("note", note)
            .toString();
        */
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
    	if (this == that) return true;
        if (!(that instanceof RepeatableEventDto)) return false;

        RepeatableEventDto otherRepeatableEvent = (RepeatableEventDto) that;

        if (dayOfWeek != otherRepeatableEvent.dayOfWeek) return false;
        if (!endTime.equals(otherRepeatableEvent.endTime)) return false;
        if (!startTime.equals(otherRepeatableEvent.startTime)) return false;

        return true;
        
        /* PROPOSAL:
        if (this == that) return true;
        if (!(that instanceof RepeatableEventDto)) return false;

        RepeatableEventDto otherRepeatableEvent = (RepeatableEventDto) that;

        return new EqualsBuilder()
	        .append(id, otherRepeatableEvent.id)
	        .append(dayOfWeek, otherRepeatableEvent.dayOfWeek)
	        .append(startTime, otherRepeatableEvent.startTime)
	        .append(endTime, otherRepeatableEvent.endTime)
	        .append(userId, otherRepeatableEvent.userId)
	        .append(note, otherRepeatableEvent.note)
	        .isEquals();
	    */
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user id is always present, while the group id not.
     * To improve the searching performance in a map the hash
     * code only takes the user id into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        int result = dayOfWeek.hashCode();
        result = 31 * result + startTime.hashCode();
        result = 31 * result + endTime.hashCode();
        return result;

        /* PROPOSAL:
		return new HashCodeBuilder(17, 37)
	        .append(id)
	        .append(dayOfWeek)
	        .append(startTime)
	        .append(endTime)
	        .append(note)
	        .append(userId)
	        .hashCode();
	    */
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(RepeatableEventDto that) {
		if (this.dayOfWeek.ordinal() < that.dayOfWeek.ordinal()) {
			return -1;
		} else if (this.dayOfWeek.ordinal() > that.dayOfWeek.ordinal()) {
			return 1;
		} else {
			return this.startTime.compareTo(that.startTime);
		}

		/* PROPOSAL:
		if (this == that) return 0;

        return new CompareToBuilder()
	        .append(dayOfWeek.ordinal(), that.dayOfWeek.ordinal())
	        .append(startTime, that.startTime)
	        .toComparison();
	    */
    }


    /**
     * Compares two time periods for conflicts.
     * 
     * @param that	the other time period to compare
     * @return	true if time periods overlap, false otherwise
     */
    public boolean conflictsWith(RepeatableEventDto that) {
		if (this.equals(that) || this == that) {
			return true;
		}
		if (this.startTime.isAfter(that.endTime)) {
			return false;
		}
		if (this.endTime.isBefore(that.startTime)) {
			return false;
		}
		return true;
    }

}