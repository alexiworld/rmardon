/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.enums;

/**
 * <code>Outcome</code> is a class representing the
 * outcome of some operation. At the present time
 * two values are included - success, failure. Later
 * the set can be extended.
 */
public enum Outcome {
	
    SUCCESS("Success"),
    FAILURE("Failure");
    
    private String value;

    Outcome(String value) {
        this.value = value;
    }
    
    public String value() {
    	return this.value;
    }
    
    public String toString(){
        return this.value;
    }
    
}
