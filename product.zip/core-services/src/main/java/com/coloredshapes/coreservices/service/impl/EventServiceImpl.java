/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static com.coloredshapes.coreservices.utils.EventUtils.getTimePeriod;
import static com.coloredshapes.coreservices.utils.EventUtils.toDateEvent;
import static com.coloredshapes.coreservices.utils.EventUtils.toDateEvents;
import static com.coloredshapes.coreservices.utils.EventUtils.toEvent;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.AssignmentDao;
import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.MessageDao;
import com.coloredshapes.coreservices.dao.RepeatableEventDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.MessageDto;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;
import com.coloredshapes.coreservices.service.EventService;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.service.QueueService;
import com.coloredshapes.coreservices.utils.EventUtils;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>EventServiceImpl</code> type is an implementation
 * of the <code>EventService</code> interface. It is used 
 * to manage events.
 */
@Service
public class EventServiceImpl implements EventService {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The event DAO
	 */
	@Autowired
	private EventDao eventDao;

	/**
	 * The repeatable event DAO
	 */
	@Autowired
	private RepeatableEventDao repeatableEventDao;

	/**
	 * The user DAO
	 */
	@Autowired
	private UserDao userDao;
	
	/**
	 * The group DAO
	 */
	@Autowired
	private GroupDao groupDao;
	
	/**
	 * The assignment DAO
	 */
	@Autowired
	private AssignmentDao assignmentDao;
	
	/**
	 * The Message DAO
	 */
	@Autowired
	private MessageDao messageDao;
	
	/**
	 * The notification DAO
	 */
	@Autowired
	private MessageService messageService;

	/**
	 * The message service
	 */
	@Autowired
	private QueueService queueService;
	
	/**
	 * The max allowable weeks from now onward.
	 */
	@Value("#{envProperties['maxAllowableWeek']}") 
	private int maxAllowableWeeks;
	
	/**
	 * Retrieves events for specific time period. The results are in groups based on their source type.
	 * The supported source types at the present time are "user" and "group". If the "group" source type
	 * is selected, groupKey can be provided as optional parameter to filter only events for that group.
	 * 
	 * This operation normally serves a user willing to retrieve his/her events.
	 * 
	 * @param userId		the key of the user making the request
	 * @param timePeriod	the time period
	 * @param sourceTypes	list of source types 
	 * @param groupIds		optionally groups can be provided if the source type "GROUP" is specified
	 * @return	a map with source types and date events
	 */
	@Override
	@Transactional(readOnly=true)
	public Map<String,DateEventsDto> getEvents(Long userId, TimePeriodDto timePeriod, SourceType[] sourceTypes, Long[] groupIds) {
		Validate.notNull(userId,"User requesting the events is missing.");
		List<Event> events = 
				eventDao.getEventsByUserId(
						timePeriod.getStartTime(), 
						timePeriod.getEndTime(),
						userId, 
						sourceTypes,
						groupIds);
		
		Map<String,DateEventsDto> mapOfDateEvents = Collections.<String,DateEventsDto>emptyMap();
		
		if (CollectionUtils.isNotEmpty(events)) {
			mapOfDateEvents = new LinkedHashMap<String,DateEventsDto>();
			for (Event event : events) {
				String sourceType = event.getSourceType().toString();
				DateEventsDto dateEvents = mapOfDateEvents.get(sourceType);
				if (dateEvents == null) {
					dateEvents = new DateEventsDto();
					dateEvents.setDateEvents(new LinkedList<DateEventDto>());
					mapOfDateEvents.put(sourceType, dateEvents);
				}
				dateEvents.getDateEvents().add(toDateEvent(event, /* includeUser = */ false, /* includeGroup = */ true));
			} 
		}
		
		// Concatenate overlapping date events scheduled by the user.
		EventUtils.compactDateEvents(mapOfDateEvents.get(SourceType.USER.toString()));
		
		return mapOfDateEvents;
	}
	
	/**
	 * Retrieves the list of date events for specific time period. All events added by groups 
	 * different from the specified group will be treated as user events for the reason of
	 * confidentiality. Therefore, information such as other group keys and tags will not be 
	 * exposed.
	 * 
	 * This operation serves a group willing for specific period to retrieve the events of 
	 * specific users. It provides the group not only with date events, but also day events 
	 * converted to date events.
	 * 
	 * @param groupId		the group making the request
	 * @param timePeriod	the time period
	 * @param userIds	the users for which group is requesting the events
	 * @return	a list of date events, the number corresponds to the number of user keys
	 */
	@Override
	@Transactional(readOnly=true)
	public List<DateEventsDto> getEvents(Long groupId, TimePeriodDto timePeriod, Long[] userIds) {
		if (groupId == null) {
			throw new IllegalArgumentException("Group requesting the events is missing.");
		}

		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new IllegalArgumentException("Group#" + groupId + " does not exist.");
		}

		// TODO: To improve the performance users could be examined for their membership status first
		// and the ones not having active status could be excluded from the queries for events and
		// in the response to add date events with the same time frame as the one of the query.
		List<Event> events = 
				eventDao.getEventsByUserIds(
						timePeriod.getStartTime(), 
						timePeriod.getEndTime(), 
						userIds);
		
		Map<Long, DateEventsDto> mapOfDateEvents = new LinkedHashMap<Long, DateEventsDto>();
		for (Long userId : userIds) {
			DateEventsDto dateEvents = mapOfDateEvents.get(userId);
			if (dateEvents == null) {
				dateEvents = new DateEventsDto();
				dateEvents.setUserId(userId);
				dateEvents.setDateEvents(new LinkedList<DateEventDto>());
				mapOfDateEvents.put(userId, dateEvents);
			}
		}

		if (CollectionUtils.isNotEmpty(events)) {
			for (Event event : events) {
				User user = event.getUser();
				Long userId = user.getId();
				
				DateEventsDto dateEvents = mapOfDateEvents.get(userId);
				DateEventDto dateEvent = toDateEvent(event);
				if (groupId != dateEvent.getGroupId()) {
					// Prevent the group from being able to differentiate other groups' time
					// blocks from the user reserved events. For any event not
					// reserved by this group the following information will be erased - 
					// 1. event key (to prevent the group from having access to it)
					// 2. the user note (in case of a user reserved event)
					// 3. the group key and tag info (in case of other group's event)
					dateEvent.setId(null);
					dateEvent.setNote(null);
					dateEvent.setGroupId(null);
					dateEvent.setAssignmentId(null);
				}
				dateEvents.getDateEvents().add(dateEvent);
			} 
		} 

		for (Long userId : userIds) {
			List<RepeatableEvent> repeatableEvents = repeatableEventDao.getRepeatableEventByUserId(userId);
			if (CollectionUtils.isEmpty(repeatableEvents)) continue; // skip users with no day events
			List<DateEventDto> dateEvents = toDateEvents(repeatableEvents, timePeriod);
			for (DateEventDto dateEvent : dateEvents) {
				// Prevent the group from being able to differentiate other groups' time
				// blocks from the user reserved events. For any event not
				// reserved by this group the following information will be erased - 
				// 1. event key (to prevent the group from having access to it)
				// 2. the user note of day time converted to date time event
				dateEvent.setId(null);
				dateEvent.setNote(null);
			}
			mapOfDateEvents.get(userId).getDateEvents().addAll(dateEvents);
		}
		
		// Update events for users with not active membership status with the specified group
		for (Long userId : userIds) {
			User user = userDao.getUser(userId);
			if (user == null) continue; // skip an invalid user key
			List<Membership> memberships = user.getMemberships();
			if (CollectionUtils.isNotEmpty(memberships)) {
				MembershipStatus membershipStatus = null;
				for (Membership membership : memberships) {
					// NOTE:   Membership is established once with the top level group, so
					// checking is no longer based on the specified group as it used to be
					// if (groupKey.equals(membership.getGroup().getGroupKey())) {
					if (group.getTopGroup().getId() == membership.getGroup().getId()) {
						membershipStatus = membership.getMembershipStatus();
						break;
					}
				}
				if (!MembershipStatus.ACTIVE.equals(membershipStatus)) {
					DateEventsDto notActiveDateEvents = new DateEventsDto();
					notActiveDateEvents.setUserId(userId);
					notActiveDateEvents.setDateEvents(new ArrayList<DateEventDto>());
					DateEventDto notActiveDateEvent = new DateEventDto();
					notActiveDateEvent.setUserId(userId);
					notActiveDateEvent.setStartTime(timePeriod.getStartTime());
					notActiveDateEvent.setEndTime(timePeriod.getEndTime());
					notActiveDateEvents.getDateEvents().add(notActiveDateEvent);
					mapOfDateEvents.put(userId, notActiveDateEvents);
				}
			}
		}

		List<DateEventsDto> listOfDateEvents = new ArrayList<DateEventsDto>(mapOfDateEvents.size());
		listOfDateEvents.addAll(mapOfDateEvents.values());
		
		// Concatenate overlapping date events
		for (Iterator<DateEventsDto> iterator = listOfDateEvents.iterator(); iterator.hasNext();) {
			EventUtils.compactDateEvents(iterator.next());
		}
		
		return listOfDateEvents;
	}
	
	/**
	 * Creates date events.
	 * 
	 * @param dateEvents	the date events
	 * @return	a map containing two entries, the first entry is the list of event entities 
	 * persisted successfully, the second entry is the list of not persisted event entities  
	 */
	@Override
    @Transactional
    public Map<Outcome, DateEventsDto> createEvents(DateEventsDto dateEvents) {
		Long userId = dateEvents.getUserId();

		if (userId == null) {
			throw new IllegalArgumentException("User requesting the events is missing.");
		}

		User user = userDao.getUser(userId);

		if (user == null) {
			throw new IllegalArgumentException("User#" + userId + " does not exist.");
		}

		List<RepeatableEvent> repeatableEvents = repeatableEventDao.getRepeatableEventByUserId(userId);
		TimePeriodDto timePeriod = getTimePeriod(dateEvents.getDateEvents());
		List<DateEventDto> dateTimeConvertedEvents = toDateEvents(repeatableEvents, timePeriod);

		// There are two types of conflicting events to be rejected:
		// 1. events far in the future, beyond a specific time moment
		// 2. proposed events conflicting with existing events 
		DateTime maxAllowableEndTime = DateTime.now().plusWeeks(maxAllowableWeeks);
		List<DateEventDto> conflictingDateEvents = new LinkedList<DateEventDto>(); 
		for (Iterator<DateEventDto> iterator = dateEvents.getDateEvents().iterator(); iterator.hasNext();) {
			DateEventDto dateEvent = iterator.next();
			
			// Do not allow blocking time beyond specific time in the future
			if (maxAllowableEndTime.isBefore(dateEvent.getEndTime())) {
				iterator.remove();
				conflictingDateEvents.add(dateEvent);
				continue;
			}
					
			// Overlapping date or day times blocked by same user are allowed
			if (dateEvent.isUserOwned()) continue; // therefore skip this
			
			// Remove conflicting date events
			for (DateEventDto dateTimeConvertedEvent : dateTimeConvertedEvents) {
				if (dateEvent.conflictsWith(dateTimeConvertedEvent)) {
					conflictingDateEvents.add(dateEvent);
					iterator.remove();
					break;
				}
			}
		}
		
		// Convert date events to entity events

		List<Event> events = new ArrayList<Event>(dateEvents.getDateEvents().size());
		for (DateEventDto dateEvent : dateEvents.getDateEvents()) {
			events.add(toEvent(dateEvent, user, null, null));
		}
		
		// Create the entity events
		
		Map<Outcome, List<Event>> outcomes = eventDao.createEvents(events);
		List<Event> eventsCreated    = outcomes.get(Outcome.SUCCESS);
		List<Event> eventsNotCreated = outcomes.get(Outcome.FAILURE);
		
		// Prepare the result

		Map<Outcome, DateEventsDto> result = new HashMap<Outcome, DateEventsDto>();
		DateEventsDto dateEventsCreated    = new DateEventsDto();
		DateEventsDto dateEventsNotCreated = new DateEventsDto();
		result.put(Outcome.SUCCESS, dateEventsCreated);
		result.put(Outcome.FAILURE, dateEventsNotCreated);
		
		// Prepare the created date events
		
		dateEventsCreated.setUserId(userId);
		dateEventsCreated.setDateEvents(new LinkedList<DateEventDto>());

		if (CollectionUtils.isNotEmpty(eventsCreated)) {
			for (Event event : eventsCreated) {
				dateEventsCreated.getDateEvents().add(toDateEvent(event)); 
			}
		}

		// Prepare the date events not being created
		
		dateEventsNotCreated.setUserId(userId);
		dateEventsNotCreated.setDateEvents(new LinkedList<DateEventDto>());

		if (CollectionUtils.isNotEmpty(conflictingDateEvents)) {
			dateEventsNotCreated.getDateEvents().addAll(conflictingDateEvents);
		}

		if (CollectionUtils.isNotEmpty(eventsNotCreated)) {
			for (Event event : eventsNotCreated) {
				dateEventsNotCreated.getDateEvents().add(toDateEvent(event)); 
			}
		}
		
		return result;
	}
	
	/**
	 * Creates events for one or more users.
	 * 
	 * This operation serves groups to create events for one or more
	 * users.
	 * 
	 * @param groupId
	 *            key of the group blocking users time
	 * @param listOfDateEvents
	 *            list of the date events
	 * @return a map containing two entries, the first entry is the list of 
	 *         event entities persisted successfully, the second entry is the
	 *         list of not persisted event entities
	 */
	@Override
    @Transactional
    public Map<Outcome, List<DateEventsDto>> createEvents(Long groupId, List<DateEventsDto> listOfDateEvents) {
		if (groupId == null) {
			throw new IllegalArgumentException("Group creating the events is missing.");
		}

		int listOfDateTimeBlocksSize = listOfDateEvents.size();
		Map<Outcome, List<DateEventsDto>> result = new HashMap<Outcome, List<DateEventsDto>>();
		List<DateEventsDto> listOfDateEventsCreated    = new ArrayList<DateEventsDto>(listOfDateTimeBlocksSize);
		List<DateEventsDto> listOfDateEventsNotCreated = new ArrayList<DateEventsDto>(listOfDateTimeBlocksSize);
		result.put(Outcome.SUCCESS, listOfDateEventsCreated);
		result.put(Outcome.FAILURE, listOfDateEventsNotCreated);

		Group group = groupDao.getGroup(groupId);
		if (group == null) {
			throw new IllegalArgumentException("Group#" + groupId + " does not exist.");
		}

		DateTime maxAllowableEndTime = DateTime.now().plusWeeks(maxAllowableWeeks);
		for (DateEventsDto dateEvents : listOfDateEvents) {
			if (logger.isDebugEnabled()) {
				logger.debug("Process " + dateEvents);
			}

			Long userId = dateEvents.getUserId();
			User user = userDao.getUser(userId);
			
			if (user == null) {
				throw new IllegalArgumentException("User " + userId + " does not exist.");
			}
			
			// Do not persist events for users that are not in an active membership relationship with this group
			List<Membership> memberships = user.getMemberships();
			if (CollectionUtils.isNotEmpty(memberships)) {
				MembershipStatus membershipStatus = null;
				for (Membership membership : memberships) {
					// NOTE:   Membership is established once with the top level group, so
					// checking is no longer based on the specified group as it used to be
					// if (groupKey.equals(membership.getGroup().getGroupKey())) {
					if (group.getTopGroup().getId() == membership.getGroup().getId()) {
						membershipStatus = membership.getMembershipStatus();
						break;
					}
				}
				if (!MembershipStatus.ACTIVE.equals(membershipStatus)) {
					listOfDateEventsNotCreated.add(dateEvents);
					if (logger.isDebugEnabled()) {
						logger.debug("Due to not active relationship " + dateEvents + " will not be stored.");
					}
					continue;
				}
			}

			List<RepeatableEvent> repeatableEvents = repeatableEventDao.getRepeatableEventByUserId(userId);
			TimePeriodDto timePeriod = getTimePeriod(dateEvents.getDateEvents());
			List<DateEventDto> dateTimeConvertedBlocks = toDateEvents(repeatableEvents, timePeriod);

			// There are two types of conflicting events:
			// 1. events far in the future, beyond a specific time moment
			// 2. proposed events conflicting with existing events 
			List<DateEventDto> conflictingDateEvents = new LinkedList<DateEventDto>(); 
			for (Iterator<DateEventDto> iterator = dateEvents.getDateEvents().iterator(); iterator.hasNext();) {
				DateEventDto dateEvent = iterator.next();
				
				// Do not allow blocking time beyond specific time in the future
				if (maxAllowableEndTime.isBefore(dateEvent.getEndTime())) {
					iterator.remove();
					conflictingDateEvents.add(dateEvent);
					continue;
				}

				// Remove proposed date events conflicting with existing events
				for (DateEventDto dateTimeConvertedBlock : dateTimeConvertedBlocks) {
					if (dateEvent.conflictsWith(dateTimeConvertedBlock)) {
						conflictingDateEvents.add(dateEvent);
						iterator.remove();
						break;
					}
				}
			}
			
			// Convert valid date events to events
			
			List<Event> events = new ArrayList<Event>(dateEvents.getDateEvents().size());
			for (DateEventDto dateEvent : dateEvents.getDateEvents()) {
				Long assignmentId = dateEvent.getAssignmentId();
				Assignment assignment = assignmentDao.find(assignmentId);
				
				if (assignment == null) {
					throw new IllegalArgumentException("Assignment " + assignmentId + " does not exist.");
				}
				
				events.add(toEvent(dateEvent, user, group, assignment));
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("Store " + events);
			}

			// Create the events
			
			Map<Outcome, List<Event>> outcomes = eventDao.createEvents(events);
			List<Event> eventsCreated    = outcomes.get(Outcome.SUCCESS);
			List<Event> notCreatedEvents = outcomes.get(Outcome.FAILURE);

			if (logger.isDebugEnabled()) {
				logger.debug("Failed to store " + notCreatedEvents);
			}

			// Prepare created date events
			
			if (CollectionUtils.isNotEmpty(eventsCreated)) {
				DateEventsDto dateEventsCreated = new DateEventsDto();
				dateEventsCreated.setUserId(userId);
				
				int size = eventsCreated.size();
				dateEventsCreated.setDateEvents(new ArrayList<DateEventDto>(size));
				
				for (Event eventCreated : eventsCreated) {
					dateEventsCreated.getDateEvents().add(toDateEvent(eventCreated));
				}
				
				listOfDateEventsCreated.add(dateEventsCreated);
			}

			// Prepare date events not being created
			
			if (CollectionUtils.isNotEmpty(conflictingDateEvents) || 
				CollectionUtils.isNotEmpty(notCreatedEvents)) {
				DateEventsDto failedDateEvents = new DateEventsDto();
				failedDateEvents.setUserId(userId);
				
				int size = conflictingDateEvents.size() + notCreatedEvents.size();
				failedDateEvents.setDateEvents(new ArrayList<DateEventDto>(size));
				
				failedDateEvents.getDateEvents().addAll(conflictingDateEvents);
				for (Event failedEvent : notCreatedEvents) {
					failedDateEvents.getDateEvents().add(toDateEvent(failedEvent));
				}

				listOfDateEventsNotCreated.add(failedDateEvents);
			}
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Successfully stored " + listOfDateEventsCreated);
			logger.debug("Failed to store all " + listOfDateEventsNotCreated);
		}

		return result;
	}
	
	/**
	 * Deletes events.
	 * 
	 * @param userId		provided if the user is performing the deletion
	 * @param groupId		provided if the group is performing the deletion
	 * @param eventIds		a list of keys of events to be deleted
	 * @return	a map containing two entries, the first entry is the list of event keys, 
	 * which entities have been successfully deleted, the second entry are for the ones that
	 * have not been deleted.
	 */
	@Override
    @Transactional
	public Map<Outcome, List<Long>> deleteEvents(Long userId, Long groupId, List<Long> eventIds) {
		if (userId == null && groupId == null) {
			throw new IllegalArgumentException("Person deleting the events is missing.");
		}

		return eventDao.deleteEvents(userId, groupId, eventIds);
	}
 
	/**
	 * Assigns events to users (processed asynchronously). 
	 * 
	 * @param dateEventsPatch	a holder for events to be added/deleted
	 */
	@Async
	@Override
	@Transactional
    public void asynchDateEventsPatch(DateEventsPatchDto dateEventsPatch) {
		DateEventsPatchDto returnedDateEventsPatch = dateEventsPatch(dateEventsPatch);
		// Remove the successfully deleted/added events to minimize msg size
		returnedDateEventsPatch.setSuccessfullyDeletedEvents(null);
		returnedDateEventsPatch.setSuccessfullyAddedEvents(null);
		queueService.enqueueDateEventsPatch(returnedDateEventsPatch);
	}

	/**
	 * Assigns events to users (processed synchronously). 
	 * 
	 * @param dateEventsPatch	a holder for events to be added/deleted
	 */
	@Override
	@Transactional
	public DateEventsPatchDto synchDateEventsPatch(DateEventsPatchDto dateEventsPatch) {
		return dateEventsPatch(dateEventsPatch);
	}

    private DateEventsPatchDto dateEventsPatch(DateEventsPatchDto dateEventsPatch) {
		if (logger.isDebugEnabled()) {
			logger.debug("dateEventsPatch: " + dateEventsPatch);
		}

		Long groupId = dateEventsPatch.getGroupId();

		if (groupId == null) {
			throw new IllegalArgumentException("Group assigning the events is missing.");
		}

		DateEventsPatchDto returnedDateEventsPatch = new DateEventsPatchDto();
		returnedDateEventsPatch.setRefNum(dateEventsPatch.getRefNum());
		returnedDateEventsPatch.setGroupId(groupId);
		
		Long[] eventsToBeDeleted = dateEventsPatch.getDeletedEvents();
		if (ArrayUtils.isNotEmpty(eventsToBeDeleted)) {
			Map<Outcome, List<Long>> outcomes = deleteEvents(
					null, groupId, Arrays.asList(eventsToBeDeleted));
			
			Long[] timeBlocksDeleted = outcomes.get(Outcome.SUCCESS).toArray(new Long[0]);
			Long[] timeBlocksNotDeleted = outcomes.get(Outcome.FAILURE).toArray(new Long[0]); 

			returnedDateEventsPatch.setDeletedEvents(timeBlocksNotDeleted);
			returnedDateEventsPatch.setSuccessfullyDeletedEvents(timeBlocksDeleted);
		} else {
			returnedDateEventsPatch.setDeletedEvents(eventsToBeDeleted);
			returnedDateEventsPatch.setSuccessfullyDeletedEvents(eventsToBeDeleted);
		}

		List<DateEventsDto> timeBlocksToBeAdded = dateEventsPatch.getAddedEvents();
		if (CollectionUtils.isNotEmpty(timeBlocksToBeAdded)) {
			Map<Outcome, List<DateEventsDto>> outcomes = createEvents(groupId, timeBlocksToBeAdded);
			List<DateEventsDto> timeBlocksAdded    = outcomes.get(Outcome.SUCCESS);
			List<DateEventsDto> timeBlocksNotAdded = outcomes.get(Outcome.FAILURE);
			returnedDateEventsPatch.setAddedEvents(timeBlocksNotAdded);
			returnedDateEventsPatch.setSuccessfullyAddedEvents(timeBlocksAdded);
		} else {
			returnedDateEventsPatch.setAddedEvents(timeBlocksToBeAdded);
			returnedDateEventsPatch.setSuccessfullyAddedEvents(timeBlocksToBeAdded);
		}
		
		//add note
		createMessages(dateEventsPatch);

		if (logger.isDebugEnabled()) {
			logger.debug("returnedShiftAssignment: " + returnedDateEventsPatch);
		}
		
		return returnedDateEventsPatch;
	}

	/**
	 * Create a message for each user listed in the group assignments
	 * 
	 * @param dateEventsPatch
	 */
	private void createMessages(DateEventsPatchDto dateEventsPatch) {
		final Long[] userIds = dateEventsPatch.getUserIds();
		final String patchNote = StringUtils.trimToEmpty(dateEventsPatch.getNote());
		if (ArrayUtils.isNotEmpty(userIds) && StringUtils.isNotBlank(patchNote)) {
			final Group group = groupDao.getGroup(dateEventsPatch.getGroupId());
			String subject = MessageFormat.format("%s [%s-%s]:", group.getName(), dateEventsPatch.getStartTime(), dateEventsPatch.getEndTime());
			
			MessageDto messageDto = new MessageDto();
			messageDto.setSubject(subject);
			messageDto.setBody(patchNote);
			messageDto.setChannel("e-mail");
			messageDto.setTime(DateTime.now());
			messageDto.setSender(Long.valueOf(StandardUtils.getUser()));
			messageDto.setRecipients(Arrays.asList(userIds));
			
			messageService.sendMessage(messageDto);
		}
	}

}