/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.enums.TakeOverStatus;
import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

@Entity
@Table(name = "take_over_event")
public class TakeOverEvent extends BaseEntity {
	
	@Transient
	private Long userId;

	/**
	 * start time of the take over event
	 */
	@NotNull
	@Column(name = "start_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime startTime;

	/**
	 * end time of the take over event
	 */
	@NotNull
	@Column(name = "end_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime endTime;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;

	@Column(name="note")
    private String note;
    
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private TakeOverStatus status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "take_over_request_id")
	private TakeOverRequest takeOverRequest;

	@JsonSerialize(using = DateSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public DateTime getStartTime() {
		return startTime;
	}

	@JsonDeserialize(using = DateDeserializer.class)
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	@JsonSerialize(using = DateSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public DateTime getEndTime() {
		return endTime;
	}

	@JsonDeserialize(using = DateDeserializer.class)
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getUserId() {
		return userId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@JsonIgnore
	public User getUser() {
		return user;
	}

	@JsonIgnore
	public void setUser(User user) {
		this.user = user;
	}
	
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public TakeOverStatus getStatus() {
		return status;
	}

	public void setStatus(TakeOverStatus status) {
		this.status = status;
	}

	public TakeOverRequest getTakeOverRequest() {
		return takeOverRequest;
	}

	public void setTakeOverRequest(TakeOverRequest takeOverRequest) {
		this.takeOverRequest = takeOverRequest;
	}

    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
	        .append("startTime", startTime) 
	        .append("endTime", endTime)   
        	.append("user", (userId == null ? userId : (user == null ? user : user.getId() + "#" + user.getEmail()))) 
            .append("note", note) 
            .append("status", status)
            .append("takeOverRequest", takeOverRequest.getId())
            .toString();
    }	

}