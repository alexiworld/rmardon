/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * <code>CompositeDto</code> is flexible DTO allowing
 * to transmit any kind of information without creating
 * specific types.
 * 
 * One use could be to address serialization Map with
 * complex keys to JSON and sending it out to consumer
 * e.g. Map<GroupBasicDto, List<UserBasicDto>> will not
 * be properly serialized, but with this composite DTO
 * the map can be easily replaced by List<CompositDto>
 * with elements having the group and users fields 
 * populated.
 */
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class CompositeDto {

	private GroupBasicDto group;
	
	private UserBasicDto user;

	private AssignmentDto assignment;
	
	private RoleDto role;
	
	private List<GroupBasicDto> groups;
	
	private List<UserBasicDto> users;

	private List<AssignmentDto> assignments;
	
	private List<RoleDto> roles;

	/**
	 * @return the group
	 */
	public GroupBasicDto getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(GroupBasicDto group) {
		this.group = group;
	}

	/**
	 * @return the user
	 */
	public UserBasicDto getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(UserBasicDto user) {
		this.user = user;
	}

	/**
	 * @return the assignment
	 */
	public AssignmentDto getAssignment() {
		return assignment;
	}

	/**
	 * @param assignment the assignment to set
	 */
	public void setAssignment(AssignmentDto assignment) {
		this.assignment = assignment;
	}

	/**
	 * @return the role
	 */
	public RoleDto getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(RoleDto role) {
		this.role = role;
	}

	/**
	 * @return the groups
	 */
	public List<GroupBasicDto> getGroups() {
		return groups;
	}

	/**
	 * @param groups the groups to set
	 */
	public void setGroups(List<GroupBasicDto> groups) {
		this.groups = groups;
	}

	/**
	 * @return the users
	 */
	public List<UserBasicDto> getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(List<UserBasicDto> users) {
		this.users = users;
	}

	/**
	 * @return the assignments
	 */
	public List<AssignmentDto> getAssignments() {
		return assignments;
	}

	/**
	 * @param assignments the assignments to set
	 */
	public void setAssignments(List<AssignmentDto> assignments) {
		this.assignments = assignments;
	}

	/**
	 * @return the roles
	 */
	public List<RoleDto> getRoles() {
		return roles;
	}

	/**
	 * @param roles the roles to set
	 */
	public void setRoles(List<RoleDto> roles) {
		this.roles = roles;
	}

	/** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
	        .append("group", group)   
	        .append("user", user)
            .append("assignment", assignment)   
            .append("role", role)
            .toString();
    }	

}