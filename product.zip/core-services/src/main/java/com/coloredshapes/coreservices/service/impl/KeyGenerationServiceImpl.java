/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import com.coloredshapes.coreservices.service.KeyGenerationService;

public class KeyGenerationServiceImpl implements KeyGenerationService {
	
	private  final SecureRandom secureRandom;
	
	public KeyGenerationServiceImpl() throws NoSuchAlgorithmException {
		secureRandom=SecureRandom.getInstance( "SHA1PRNG" );
	}
	
	@Override
	public Long getRandomExtKey() {
		return secureRandom.nextLong();
	}

}
