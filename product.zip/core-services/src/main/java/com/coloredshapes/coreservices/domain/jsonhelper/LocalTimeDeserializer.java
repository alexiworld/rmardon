/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.joda.time.LocalTime;

public class LocalTimeDeserializer extends JsonDeserializer<LocalTime> {

	@Override
	public LocalTime deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		long milliSec = jp.getLongValue();
		int hour=(int) (milliSec/(3600*1000));
		int min=(int)(milliSec-hour*3600*1000)/(60*1000);
		int sec=(int) (milliSec%(60*1000))/1000;
		LocalTime time=new LocalTime(hour,min,sec);
		return time;
	}

}
