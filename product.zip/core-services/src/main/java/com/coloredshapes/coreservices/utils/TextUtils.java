/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.utils;

public class TextUtils {

	public static String getEventAssignmentText() {
		return "An event has been published by group manager.";
	}
	
}
