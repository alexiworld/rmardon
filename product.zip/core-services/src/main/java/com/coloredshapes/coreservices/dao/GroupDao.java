/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import com.coloredshapes.coreservices.domain.entity.Group;

public interface GroupDao extends GenericDao<Group> {
	
	public Group getGroup(Long groupId);

	public List<Group> getGroups(Long[] groupIds);

	public void createGroup(Group group);
	
}
