/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.UserAgreementDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.entity.UserAgreement;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.UserAgreementService;

@Service
public class UserAgreementServiceImpl implements UserAgreementService {
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private UserAgreementDao userAgreementDao;
	
    @Override
	@Transactional(readOnly=true)
	public UserAgreement getLastestAgreement() {
		return userAgreementDao.getLastestAgreement();
	}

	@Override
	@Transactional
	public boolean isLatestAgreementAccepted(Long userId) {
		Validate.notNull(userId,"User id is missing");
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId) ;
		}
		
		UserAgreement latestAgreement = userAgreementDao.getLastestAgreement();
		return ObjectUtils.equals(user.getAgreementVersion(), latestAgreement.getTextVersion());
	}

	@Override
	@Transactional
	public void acceptLatestAgreement(Long userId) {
		Validate.notNull(userId,"User id is missing");
		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId) ;
		}
		UserAgreement agreement = userAgreementDao.getLastestAgreement();
		user.setAgreementVersion(agreement.getTextVersion());
		userDao.update(user);		
	}
    
}