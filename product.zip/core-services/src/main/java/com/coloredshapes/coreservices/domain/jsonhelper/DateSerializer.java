/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.utils.StandardUtils;

public class DateSerializer extends JsonSerializer<DateTime> {

	@Override
	public void serialize(DateTime value, JsonGenerator jgen,
			SerializerProvider provider) throws IOException,
			JsonProcessingException {
		if (StandardUtils.isTransferDateAsText()) {
			jgen.writeString(value.toString("yyyy/MM/dd HH:mm:ss"));
		} else {
			jgen.writeNumber(value.getMillis());
		}

	}

}
