/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.RoleDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;

public interface ManagementService {
	
	public void addUser(Long groupId, Long userId);

	public void addUser(Long groupId, UserCompleteDto userDto);
	
	public void removeUser(Long groupId, Long userId);
	
	public void createRole(RoleDto roleDto);
	
	public void updateRole(RoleDto roleDto);
	
	public void removeRole(Long roleId);
	
	public void createAssignment(AssignmentDto assignmentDto);
	
	public void updateAssignment(AssignmentDto assignmentDto);
	
	public void removeAssignment(Long assignmentId);

	public void createUserAssignments(UserCompleteDto userDto, Long groupId);

	public void updateUserAssignments(UserCompleteDto userDto, Long groupId);

}