/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.ImageDao;
import com.coloredshapes.coreservices.domain.dto.ImageDto;
import com.coloredshapes.coreservices.domain.entity.Image;
import com.coloredshapes.coreservices.service.ImageService;

@Service
public class ImageServiceImpl implements ImageService {
	
	@Autowired
	private ImageDao imageDao;

	@Override
	@Transactional
	public Long storeImage(ImageDto imageDto) {
		Image image = new Image();
		image.setFile(imageDto.getFile());
		image.setType(imageDto.getType());
		image.setBytes(imageDto.getBytes());
		imageDao.update(image);
		return null;
	}

	@Override
	@Transactional(readOnly=true)
	public ImageDto readImage(Long imageId) {
		Image image = imageDao.find(imageId);
		if (image == null) return null;
		
		ImageDto imageDto = new ImageDto(
			image.getId(), 
			image.getFile(), 
			image.getType(), 
			image.getBytes());
		return imageDto;
	}

	@Override
	@Transactional(readOnly=true)
	public ImageDto readImage(String file) {
		//Image image = imageDao.findOneBy("file", file);
		Image image = imageDao.getImage(file);
		if (image == null) return null;
		
		ImageDto imageDto = new ImageDto(
			image.getId(), 
			image.getFile(), 
			image.getType(), 
			image.getBytes());
		return imageDto;
	}
	
}