/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * <code>EventController</code> handles date events requests to REST services. The supported operations are 
 * adding, retrieving and removing of events, etc.
 */
@Controller
public class QueueController extends BaseController {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The AMQP template
	 */
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${amqp.queue:ColoredShapes.Queue.Services}")
	private String queue;
    

	/**
	 * REST service for retrieving queue messages
	 * 
	 * @param message		message
	 * @param exchange		exchange
	 * @param routingKey	the routing key
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/queue", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void putQueueMessage(@RequestBody String message,
			@RequestParam(required=false) String exchange,
			@RequestParam(required=false) String routingKey)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("exchange: "   + exchange);
			logger.debug("routingKey: " + routingKey);
			logger.debug("message: "    + message);
		}
		
		if (StringUtils.isNotEmpty(exchange)) {
			amqpTemplate.send(exchange, routingKey, new Message(message.getBytes(), new MessageProperties()));
		} else if (StringUtils.isNotEmpty(routingKey)) {
			amqpTemplate.send(routingKey, new Message(message.getBytes(), new MessageProperties()));
		} else {
			amqpTemplate.send(new Message(message.getBytes(), new MessageProperties()));
		}
	}

	/**
	 * REST service for retrieving queue messages
	 * 
	 * @param patternKey	the pattern key
	 * @return	queue message
	 * @throws Exception	raised in case something goes wrong
	 */
	@RequestMapping(value = "/queue", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public String getQueueMessage(
			@RequestParam(required=false) String queue,
			@RequestParam(required=false) String routingKey)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("queue: " + queue);
			logger.debug("routingKey: " + routingKey);
		}

		Message message = null;
		if (StringUtils.isNotEmpty(queue)) {
			message = amqpTemplate.receive(queue);
		} else if (StringUtils.isNotEmpty(routingKey)) {
			message = amqpTemplate.receive(routingKey);
		} else {
			message = amqpTemplate.receive();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("message: " + message);
		}
		
		String result = (message == null ? "" : new String(message.getBody()));
		return result;
	}

}