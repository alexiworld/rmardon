/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller.util;

import org.apache.commons.lang.StringUtils;

import com.coloredshapes.coreservices.domain.entity.MembershipRequest;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.User;
/**
 * <code>BeanFieldsNormalizer</code> is utility class normalizing the format of beans
 *
 */
public class BeanFieldsNormalizer {

	/**
	 * convert the values of fields of the user object to normalized format
	 * @param user
	 */
	public static void normalize(User user){
		user.setEmail(StringUtils.lowerCase((user.getEmail())));
	}
	/**
	 * convert the values of fields of the MembershipRequest object to normalized format
	 * @param user
	 */
	public static void normalize(MembershipRequest empReq){
		empReq.setUserEmail(StringUtils.lowerCase(empReq.getUserEmail()));
	}
	/**
	 * convert the values of fields of the Group object to normalized format
	 * @param user
	 */
	public static void normalize(Group group){
		group.setEmail(StringUtils.lowerCase(group.getEmail()));
	}

}
