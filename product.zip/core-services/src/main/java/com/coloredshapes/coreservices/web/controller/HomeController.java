/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Prepares the data required to show html page.
	 * 
	 * @param session
	 *            the session
	 * @return the model and view
	 */
	@RequestMapping(value = "/{page}", method = RequestMethod.GET)
	public String showHtmlPage(@PathVariable String page) {
		if (logger.isDebugEnabled()) {
			logger.debug("/{page} controller reached.");
		}
		
		// no need of stripping the extension off
		//int idx = page.lastIndexOf('.');
		//page = page.substring(0, idx);
		return page;
	}

}
