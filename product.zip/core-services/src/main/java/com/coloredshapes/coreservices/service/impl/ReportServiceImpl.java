/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang.Validate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.AssignmentDao;
import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Role;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.report.dto.RolePayDto;
import com.coloredshapes.coreservices.report.dto.UserPayDto;
import com.coloredshapes.coreservices.service.ReportService;

/**
 * <code>ReportServiceImpl</code> type is an implementation
 * of the <code>ReportService</code> interface. It is used 
 * as data source for the reports.
 */
@Service
public class ReportServiceImpl implements ReportService {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The event DAO
	 */
	@Autowired
	private EventDao eventDao;

	/**
	 * The user DAO
	 */
	@Autowired
	private UserDao userDao;
	
	/**
	 * The group DAO
	 */
	@Autowired
	private GroupDao groupDao;
	
	/**
	 * The assignment DAO
	 */
	@Autowired
	private AssignmentDao assignmentDao;
	
	/**
	 * Retrieve payments to users for specified group and period.
	 * 
	 * @param groupId		the group
	 * @param timePeriod	the period
	 * @return	collection of user pay
	 */
	@Override
	@Transactional
	public List<UserPayDto> getUserPays(Long groupId, TimePeriodDto timePeriod) {
		if (logger.isDebugEnabled()) {
			logger.debug("Requested user pays");
		}

		Validate.notNull(groupId, "Group is missing.");
		Validate.notNull(timePeriod, "Time Period is missing.");
		
		DateTime startTime = timePeriod.getStartTime();
		DateTime endTime = timePeriod.getEndTime();

		Validate.notNull(startTime, "Start time is missing.");
		Validate.notNull(endTime, "End time is missing.");

		Group group = groupDao.getGroup(groupId);
		
		final TreeMap<Long, UserPayDto> usersPays = new TreeMap<Long, UserPayDto>();
		List<UserPayDto> userPays = new ArrayList<UserPayDto>();

		List<User> users = group.getUsers();
		Long[] userIds = new Long[users.size()];
		
		int i = 0;  
		for (User user : users) { 
			userIds[i++] = user.getId();
			
			UserPayDto userPayDto = new UserPayDto();
			userPayDto.setGroup(group.getName());
			userPayDto.setUser(user.getFirstName() + ' ' + user.getLastName());
			userPayDto.setStartTime(startTime);
			userPayDto.setEndTime(endTime);
			
			usersPays.put(user.getId(), userPayDto);
			userPays.add(userPayDto);
		}

		class UserPayComparator implements Comparator<UserPayDto> {
			@Override
			public int compare(UserPayDto user1PayDto, UserPayDto user2PayDto) {
				return user1PayDto.getUser().compareToIgnoreCase(user2PayDto.getUser());
			}
		};  
		Collections.sort(userPays, new UserPayComparator());

		List<Event> events = eventDao.getEventsByUserIds(startTime, endTime, userIds);
		for (Event event : events) {
			Assignment assignment = event.getAssignment();
			if (assignment == null) continue;

			Double rate = (assignment.getRate() != null ? assignment.getRate() : assignment.getRole().getRate());
			if (rate == null) continue;
			
			double hours = (event.getEndTime().getMillis() - event.getStartTime().getMillis()) / (60*60*1000); // 1h in milliseconds 

			User user = event.getUser();
			UserPayDto userPayDto = usersPays.get(user.getId());
			userPayDto.addPay(hours*rate);
		}
		
		return userPays;
	}

	/**
	 * Retrieve payments to roles for specified group and period.
	 * 
	 * @param groupId		the group
	 * @param timePeriod	the period
	 * @return	collection of role pay
	 */
	@Override
	@Transactional
	public List<RolePayDto> getRolePays(Long groupId, TimePeriodDto timePeriod) {
		if (logger.isDebugEnabled()) {
			logger.debug("Requested role pays");
		}

		Validate.notNull(groupId, "Group is missing.");
		Validate.notNull(timePeriod, "Time Period is missing.");
		
		DateTime startTime = timePeriod.getStartTime();
		DateTime endTime = timePeriod.getEndTime();

		Validate.notNull(startTime, "Start time is missing.");
		Validate.notNull(endTime, "End time is missing.");

		Group group = groupDao.getGroup(groupId);
		
		final TreeMap<Long, RolePayDto> rolesPays = new TreeMap<Long, RolePayDto>();
		List<RolePayDto> rolePays = new ArrayList<RolePayDto>();

		List<User> users = group.getUsers();
		Long[] userIds = new Long[users.size()];
		
		int i = 0;  
		for (User user : users) { 
			userIds[i++] = user.getId();
		}
		
		List<Role> roles = group.getRoles();
		for (Role role : roles) {
			RolePayDto rolePayDto = new RolePayDto();
			rolePayDto.setGroup(group.getName());
			rolePayDto.setRole(role.getName());
			rolePayDto.setStartTime(startTime);
			rolePayDto.setEndTime(endTime);
			
			rolesPays.put(role.getId(), rolePayDto);
			rolePays.add(rolePayDto);
		}

		class RolePayComparator implements Comparator<RolePayDto> {
			@Override
			public int compare(RolePayDto role1PayDto, RolePayDto role2PayDto) {
				return role1PayDto.getRole().compareToIgnoreCase(role2PayDto.getRole());
			}
		};  
		Collections.sort(rolePays, new RolePayComparator());

		List<Event> events = eventDao.getEventsByUserIds(startTime, endTime, userIds);
		for (Event event : events) {
			Assignment assignment = event.getAssignment();
			if (assignment == null) continue;

			Double rate = (assignment.getRate() != null ? assignment.getRate() : assignment.getRole().getRate());
			if (rate == null) continue;
			
			double hours = (event.getEndTime().getMillis() - event.getStartTime().getMillis()) / (60*60*1000); // 1h in milliseconds 

			Role role = event.getAssignment().getRole();
			RolePayDto rolePayDto = rolesPays.get(role.getId());
			rolePayDto.addPay(hours*rate);
		}
		
		return rolePays;
	}

}