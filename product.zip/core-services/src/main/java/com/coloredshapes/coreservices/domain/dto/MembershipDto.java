/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.jsonhelper.LowerCaseDeserializer;

public class MembershipDto extends IdDto {
	
	/**
	 * This class serial version UID
	 */
	public static final long serialVersionUID = 6545654645L;
	
	private Long groupId;
	
	private String groupName;
	
	private Long userId;

	private String userEmail;
	
	private MembershipStatus membershipStatus;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getGroupName() {
		return groupName;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@JsonIgnore
	public String getUserEmail() {
		return userEmail;
	}

	@JsonDeserialize(using = LowerCaseDeserializer.class)
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public MembershipStatus getMembershipStatus() {
		return membershipStatus;
	}

	public void setMembershipStatus(MembershipStatus membershipStatus) {
		this.membershipStatus = membershipStatus;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("groupId", groupId) 
            .append("groupName", groupName) 
            .append("userId", userId) 
            .append("userEmail", userEmail) 
        	.append("membershipStatus", membershipStatus) 
            .toString();
    }

}