/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.UserConfirmation;

public interface UserConfirmationDao extends GenericDao<UserConfirmation> {

	UserConfirmation findByRefNum(String refNum);

}
