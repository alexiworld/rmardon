/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import javax.validation.ConstraintViolationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.exception.CoreServicesException;
import com.coloredshapes.coreservices.web.controller.util.ErrorFactory;
import com.coloredshapes.coreservices.web.dto.ErrorResp;

public class BaseController {
    
	@Autowired
	private ErrorFactory errorFactory;
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorResp handleException3(MethodArgumentNotValidException ex) {
		if (logger.isErrorEnabled()) {
			logger.error(ex.getMessage());
		}
		return errorFactory.creatError(ex);
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorResp handleException4(ConstraintViolationException ex) {

		if (logger.isErrorEnabled()) {
			logger.error(ex.getMessage());
		}
		return errorFactory.creatError(ex);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public Exception handleException(Exception ex) {
		if (logger.isErrorEnabled()) {
			logger.error("Failed to handle request due to " + ex);
		}
		System.out.println(ex.getMessage());
		ex.printStackTrace();
		return ex;
	}
	
	@ExceptionHandler(CoreServicesException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorResp handleCoreServicesException(CoreServicesException ex) {
		if (logger.isWarnEnabled()) {
			logger.warn("Failed to handle request due to " + ex);
		}
		return errorFactory.creatError(ex);
	}
}
