/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

//UPDATE serviceBus.`repeatable_event` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`membership` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`membership_request` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`user_confirmation` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`take_over_request` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`event` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`group` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';
//UPDATE serviceBus.`user` SET `create_date_time`=NOW(), `create_user`='admin@coloredshapes.com';

@Embeddable
public class Stamp implements Serializable {
	
	private static final long serialVersionUID = 181973434912374L;

	@Column(name="create_user", nullable = true, length = 64)
    private String createUser;

    @Column(name="create_date_time", nullable = true, length = 64)
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    private DateTime createDateTime;

    @Column(name="update_user", nullable = true, length = 64)
    private String updateUser;

    @Column(name="update_date_time", nullable = true, length = 64)
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    private DateTime updateDateTime;
    
    @Column(name="context", nullable = true, length = 255)
    private String invocationContext; 
    
    
	/**
	 * @return the createUser
	 */
    @JsonIgnore
	public String getCreateUser() {
		return createUser;
	}

	/**
	 * @param createUser the createUser to set
	 */
    @JsonIgnore
	public void setCreateUser(String createUserId) {
		this.createUser = createUserId;
	}

	/**
	 * @return the createDateTime
	 */
    @JsonIgnore
	public DateTime getCreateDateTime() {
		return createDateTime;
	}

	/**
	 * @param createDateTime the createDateTime to set
	 */
    @JsonIgnore
	public void setCreateDateTime(DateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	/**
	 * @return the updateUser
	 */
    @JsonIgnore
	public String getUpdateUser() {
		return updateUser;
	}

	/**
	 * @param updateUser the updateUser to set
	 */
    @JsonIgnore
	public void setUpdateUser(String modifyUserId) {
		this.updateUser = modifyUserId;
	}

	/**
	 * @return the updateDateTime
	 */
    @JsonIgnore
	public DateTime getUpdateDateTime() {
		return updateDateTime;
	}

	/**
	 * @param updateDateTime the updateDateTime to set
	 */
    @JsonIgnore
	public void setUpdateDateTime(DateTime modifyDateTime) {
		this.updateDateTime = modifyDateTime;
	}

	/**
	 * @return the invocationContext
	 */
    @JsonIgnore
	public String getInvocationContext() {
		return invocationContext;
	}

	/**
	 * @param invocationContext the invocationContext to set
	 */
    @JsonIgnore
	public void setInvocationContext(String invocationContext) {
		this.invocationContext = invocationContext;
	}
    
}