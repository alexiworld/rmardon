/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.Map;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.IdDto;
import com.coloredshapes.coreservices.domain.dto.RoleDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.exception.InvalidAssignmentException;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidRoleException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.ManagementService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Controller
public class ManagementController extends BaseController {
	
	private static final Logger logger = LoggerFactory.getLogger(ManagementController.class);

	@Autowired
	private ManagementService managementService; 

	@RequestMapping(value = "/groups/{groupId}/users/{userId}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void addUser(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("userId") String userIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("user id: " + userIdCode);
		}

		Long groupId = StandardUtils.decodeLong(groupIdCode);
		Long userId = StandardUtils.decodeLong(userIdCode);
		
		managementService.addUser(groupId, userId);
	}

	@RequestMapping(value = "/groups/{groupId}/users", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void addUser(
			@PathVariable("groupId") String groupIdCode, 
			@RequestBody UserCompleteDto user)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("user: " + ReflectionToStringBuilder.toString(user));
		}

		Long groupId = StandardUtils.decodeLong(groupIdCode);
		managementService.addUser(groupId, user);
	}
	
	@RequestMapping(value = "/groups/{groupId}/users/{userId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void removeUser(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("userId") String userIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("user id: " + userIdCode);
		}

		Long groupId = StandardUtils.decodeLong(groupIdCode);
		Long userId = StandardUtils.decodeLong(userIdCode);
		
		managementService.removeUser(groupId, userId);
	}

	@RequestMapping(value = "/groups/{groupId}/roles", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public IdDto createRole(
			@PathVariable("groupId") String groupIdCode, 
			@RequestBody RoleDto role)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("role: " + ReflectionToStringBuilder.toString(role));
		}

		//Long groupId = StandardUtils.decodeLong(groupIdCode);
		managementService.createRole(role);

		IdDto idDto = new IdDto(role);
		return idDto;
	}
	
	@RequestMapping(value = "/groups/{groupId}/roles/{roleId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void updateRole(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("roleId") String roleIdCode, 
			@RequestBody RoleDto roleDto)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("role id: " + roleIdCode);
			logger.debug("role: " + ReflectionToStringBuilder.toString(roleDto));
		}

		if (groupIdCode == null) {
			throw new InvalidGroupException((Long) null);
		}
		
		if (roleIdCode == null) {
			throw new InvalidRoleException((Long) null);
		}
		
		Long groupId = StandardUtils.decodeLong(groupIdCode);
		Long roleId  = StandardUtils.decodeLong(roleIdCode);
		
		if (groupId == null || roleId == null || roleDto == null || 
			!groupId.equals(roleDto.getGroupId()) ||
			!roleId.equals(roleDto.getId())) {
			throw new InvalidRoleException(roleId);
		}

		managementService.updateRole(roleDto);
	}
	
	@RequestMapping(value = "/groups/{groupId}/roles/{roleId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void removeRole(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("roleId") String roleIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("role id: " + roleIdCode);
		}

		Long roleId = StandardUtils.decodeLong(roleIdCode);
		managementService.removeRole(roleId);
	}

	@RequestMapping(value = "/groups/{groupId}/assignments", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void addAssignment(
			@PathVariable("groupId") String groupIdCode, 
			@RequestBody AssignmentDto assignment)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("assignment: " + ReflectionToStringBuilder.toString(assignment));
		}

		Long groupId = (groupIdCode == null ? null : StandardUtils.decodeLong(groupIdCode));
		if (groupIdCode == null) {
			throw new InvalidGroupException(groupId);
		}
		
		managementService.createAssignment(assignment);
	}
	
	@RequestMapping(value = "/groups/{groupId}/assignments/{assignmentId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	public void updateAssignment(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("assignmentId") String assignmentIdCode, 
			@RequestBody AssignmentDto assignmentDto)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("assignment id: " + assignmentIdCode);
			logger.debug("assignment: " + ReflectionToStringBuilder.toString(assignmentDto));
		}

		if (groupIdCode == null) {
			throw new InvalidGroupException((Long) null);
		}
		
		if (assignmentIdCode == null) {
			throw new InvalidAssignmentException((Long) null);
		}
		
		Long assignmentId  = StandardUtils.decodeLong(assignmentIdCode);
		
		if (assignmentId == null || assignmentDto == null || 
			!assignmentId.equals(assignmentDto.getId())) {
			throw new InvalidAssignmentException(assignmentId);
		}

		managementService.updateAssignment(assignmentDto);
	}
	
	@RequestMapping(value = "/groups/{groupId}/assignments/{assignmentId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	public void removeAssignment(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("assignmentId") String assignmentIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("assignment id: " + assignmentIdCode);
		}

		//Long groupId = StandardUtils.decodeLong(groupIdCode);
		Long assignmentId = StandardUtils.decodeLong(assignmentIdCode);
		managementService.removeAssignment(assignmentId);
	}

	@RequestMapping(value = "/groups/{groupId}/userassignments", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String, String> createUserAssignments(
			@PathVariable("groupId") String groupIdCode, 
			@RequestBody UserCompleteDto userDto)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("user: " + ReflectionToStringBuilder.toString(userDto));
		}

		Long groupId = (groupIdCode == null ? null : StandardUtils.decodeLong(groupIdCode));
		if (groupId == null) {
			throw new InvalidGroupException(groupId);
		}

		if (userDto == null) {
			throw new InvalidUserException((Long) null);
		}

		managementService.createUserAssignments(userDto, groupId);
		Map<String, String> resp = StandardUtils.toMap(userDto);
		return resp;
	}
	
	@RequestMapping(value = "/groups/{groupId}/userassignments/{userId}", method = RequestMethod.PUT)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<String, String> updateUserAssignments(
	//public void updateUserAssignments(
			@PathVariable("groupId") String groupIdCode, 
			@PathVariable("userId") String userIdCode, 
			@RequestBody UserCompleteDto userDto)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("group id: " + groupIdCode);
			logger.debug("user id: " + userIdCode);
			logger.debug("user: " + ReflectionToStringBuilder.toString(userDto));
		}

		Long groupId = (groupIdCode == null ? null : StandardUtils.decodeLong(groupIdCode));
		if (groupId == null) {
			throw new InvalidGroupException(groupId);
		}

		Long userId = (userIdCode == null ? null : StandardUtils.decodeLong(userIdCode));
		if (userId == null) {
			throw new InvalidGroupException(groupId);
		}

		if (userDto == null) {
			throw new InvalidUserException((Long) null);
		}

		managementService.updateUserAssignments(userDto, groupId);
		Map<String, String> resp = StandardUtils.toMap(userDto);
		return resp;
	}

}