/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.AssignmentDao;
import com.coloredshapes.coreservices.dao.BusinessDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.MembershipDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.AssignmentDto;
import com.coloredshapes.coreservices.domain.dto.BusinessDto;
import com.coloredshapes.coreservices.domain.dto.GroupBasicDto;
import com.coloredshapes.coreservices.domain.dto.GroupCompleteDto;
import com.coloredshapes.coreservices.domain.dto.GroupProfileDto;
import com.coloredshapes.coreservices.domain.dto.RoleDto;
import com.coloredshapes.coreservices.domain.entity.Assignment;
import com.coloredshapes.coreservices.domain.entity.Business;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Role;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;
import com.coloredshapes.coreservices.domain.enums.GroupStatus;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.exception.InvalidUserException;
import com.coloredshapes.coreservices.service.GroupService;

@Service
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupDao groupDao;
	
	@Autowired
	private BusinessDao businessDao;

	@Autowired
	private AssignmentDao assignmentDao;

	@Autowired
	private MembershipDao membershipDao;
	
	@Autowired
	private UserDao userDao;
	
	//@Autowired
	//private RoleDao roleDao;
	
	@Resource(name="dozerBeanMapper")
	private DozerBeanMapper beanMapper;

	@Override
	@Transactional(readOnly=true)
	public GroupBasicDto getGroup(Long groupId, ContentLimit contentLimit, ContentStatus contentStatus) {
		Group group = groupDao.getGroup(groupId);
		GroupBasicDto groupDto = toGroupDto(group, contentLimit, contentStatus);
		return groupDto;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GroupBasicDto> getGroups(Long[] groupIds, ContentLimit contentLimit, ContentStatus contentStatus) {
		List<Group> groups = groupDao.getGroups(groupIds);
		
		List<GroupBasicDto> groupDtos = new ArrayList<GroupBasicDto>(groups.size());
		for (Group group : groups) {
			if (contentStatus == null || StringUtils.equals(contentStatus.name(), group.getStatus().name())) {
				groupDtos.add(toGroupDto(group, contentLimit, contentStatus));
			}
		}
		
		return groupDtos;
	}

	@Override
	@Transactional(readOnly=true)
	public List<Long> getUserGroupIds(Long userId, ContentStatus contentStatus) {
		if (userId == null) {
			throw new IllegalArgumentException("User id is missing.");
		}

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		List<Group> groups = user.getGroups();
		List<Long> groupIds = new ArrayList<Long>(groups.size());
		for (Group group : groups) {
			groupIds.add(group.getId());
		}
		
		return groupIds;
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Long> getUserGroupIds(String userEmail, ContentStatus contentStatus) {
		if (userEmail == null) {
			throw new IllegalArgumentException("User email is missing.");
		}

		User user = userDao.getUser(userEmail);
		if (user == null) {
			throw new InvalidUserException(userEmail);
		}

		List<Group> groups = user.getGroups();
		List<Long> groupIds = new ArrayList<Long>(groups.size());
		for (Group group : groups) {
			groupIds.add(group.getId());
		}
		
		return groupIds;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GroupBasicDto> getUserGroups(Long userId, ContentLimit contentLimit, ContentStatus contentStatus) {
		if (userId == null) {
			throw new IllegalArgumentException("User id is missing.");
		}

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		List<Group> groups = user.getGroups();
		List<GroupBasicDto> groupDtos = new ArrayList<GroupBasicDto>(groups.size());
		for (Group group : groups) {
			groupDtos.add(toGroupDto(group, contentLimit, contentStatus));
		}
		
		return groupDtos;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GroupBasicDto> getUserGroups(String userEmail, ContentLimit contentLimit, ContentStatus contentStatus) {
		if (userEmail == null) {
			throw new IllegalArgumentException("User email is missing.");
		}

		User user = userDao.getUser(userEmail);
		if (user == null) {
			throw new InvalidUserException(userEmail);
		}

		List<Group> groups = user.getGroups();
		List<GroupBasicDto> groupDtos = new ArrayList<GroupBasicDto>(groups.size());
		for (Group group : groups) {
			groupDtos.add(toGroupDto(group, contentLimit, contentStatus));
		}
		
		return groupDtos;
	}

	@Override
	@Transactional(readOnly=true)
	public List<Long> getUserFrontGroupIds(Long userId, ContentStatus contentStatus) {
		if (userId == null) {
			throw new IllegalArgumentException("User id is missing.");
		}

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		List<Group> groups = getUserFrontGroups(user, contentStatus);
		List<Long> groupIds = new ArrayList<Long>(groups.size());
		for (Group group : groups) {
			groupIds.add(group.getId());
		}
		
		return groupIds;
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Long> getUserFrontGroupIds(String userEmail, ContentStatus contentStatus) {
		if (userEmail == null) {
			throw new IllegalArgumentException("User email is missing.");
		}

		User user = userDao.getUser(userEmail);
		if (user == null) {
			throw new InvalidUserException(userEmail);
		}

		List<Group> groups = getUserFrontGroups(user, contentStatus);
		List<Long> groupIds = new ArrayList<Long>(groups.size());
		for (Group group : groups) {
			groupIds.add(group.getId());
		}
		
		return groupIds;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GroupBasicDto> getUserFrontGroups(Long userId, ContentLimit contentLimit, ContentStatus contentStatus) {
		if (userId == null) {
			throw new IllegalArgumentException("User id is missing.");
		}

		User user = userDao.getUser(userId);
		if (user == null) {
			throw new InvalidUserException(userId);
		}

		List<Group> groups = getUserFrontGroups(user, contentStatus);
		List<GroupBasicDto> groupDtos = new ArrayList<GroupBasicDto>(groups.size());
		for (Group group : groups) {
			groupDtos.add(toGroupDto(group, contentLimit, contentStatus));
		}
		
		return groupDtos;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GroupBasicDto> getUserFrontGroups(String userEmail, ContentLimit contentLimit, ContentStatus contentStatus) {
		if (userEmail == null) {
			throw new IllegalArgumentException("User email is missing.");
		}

		User user = userDao.getUser(userEmail);
		if (user == null) {
			throw new InvalidUserException(userEmail);
		}

		List<Group> groups = getUserFrontGroups(user, contentStatus);
		List<GroupBasicDto> groupDtos = new ArrayList<GroupBasicDto>(groups.size());
		for (Group group : groups) {
			groupDtos.add(toGroupDto(group, contentLimit, contentStatus));
		}
		
		return groupDtos;
	}

	@Transactional(readOnly=true)
	private List<Group> getUserFrontGroups(User user, ContentStatus contentStatus) {
		List<Group> groups = user.getGroups();
		List<Group> userFrontGroups = new ArrayList<Group>(groups.size());
		for (Group group : groups) {
			Group parentGroup = null;
			Long parentId = group.getParentId();
			if (parentId != null) {
				parentGroup = groupDao.getGroup(parentId);
			}
			
			boolean ancestorFound = false;
			while (parentGroup != null) {
				for (Group otherGroup : groups) {
					if (parentGroup.getId() == otherGroup.getId()) {
						ancestorFound = true;
						break;
					}
				}
				
				if (ancestorFound) break;

				parentId = parentGroup.getParentId();
				if (parentId != null) {
					parentGroup = groupDao.getGroup(parentId);
				}
			}
			
			if (!ancestorFound) {
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), group.getStatus().name())) {
					userFrontGroups.add(group);
				}
			}
		}
		
		return userFrontGroups;
	}

	private GroupBasicDto toGroupDto(Group group, ContentLimit contentLimit, ContentStatus contentStatus) {
		GroupBasicDto groupXXXDto;
		if (ContentLimit.BASIC.equals(contentLimit)) {
			GroupBasicDto groupBasicDto = beanMapper.map(group, GroupBasicDto.class);
			groupXXXDto = groupBasicDto;
		} else if (ContentLimit.PROFILE.equals(contentLimit)) {
			GroupProfileDto groupProfileDto = beanMapper.map(group, GroupProfileDto.class);
			Business business = businessDao.getBusinessByGroupId(group.getId());
			BusinessDto businessDto = (business == null ? null : beanMapper.map(business, BusinessDto.class));
			groupProfileDto.setBusiness(businessDto);
			groupXXXDto = groupProfileDto;
		} else {
			GroupCompleteDto groupCompleteDto = beanMapper.map(group, GroupCompleteDto.class);
			
			Business business = businessDao.getBusinessByGroupId(group.getId());
			BusinessDto businessDto = (business == null ? null : beanMapper.map(business, BusinessDto.class));
			groupCompleteDto.setBusiness(businessDto);
			
			List<User> users = group.getUsers();
			List<Long> userIds = new ArrayList<Long>(users.size());
			for (User user : users) {
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), user.getStatus().name())) {
					userIds.add(user.getId());
				}
			}
			groupCompleteDto.setUserIds(userIds);
			
			List<Group> subGroups = group.getSubGroups();
			List<GroupBasicDto> subGroupDtos = new ArrayList<GroupBasicDto>(subGroups.size());
			for (Group subGroup : subGroups) {
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), subGroup.getStatus().name())) {
					GroupBasicDto subGroupBasicDto = beanMapper.map(subGroup, GroupBasicDto.class);
					subGroupDtos.add(subGroupBasicDto);
				}
			}
			groupCompleteDto.setSubGroups(subGroupDtos);
			
			List<Role> roles = group.getRoles();
			List<RoleDto> roleDtos = new ArrayList<RoleDto>(roles.size());
			for (Role role : roles) {
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), role.getStatus().name())) {
					RoleDto roleDto = beanMapper.map(role, RoleDto.class);
					roleDtos.add(roleDto);
				}
			}
			groupCompleteDto.setRoles(roleDtos);
			
			List<Assignment> assignments = group.getAssignments(); 
			List<AssignmentDto> assignmentDtos = new ArrayList<AssignmentDto>(assignments.size());
			for (Assignment assignment : assignments) {
				if (contentStatus == null || StringUtils.equals(contentStatus.name(), assignment.getStatus().name())) {
					AssignmentDto assignmentDto = beanMapper.map(assignment, AssignmentDto.class);
					assignmentDto.setUserId(assignment.getUser().getId()); // try it with mapper
					assignmentDto.setRoleId(assignment.getRole().getId()); // configuration
					assignmentDto.setRole(null);       // to avoid double serialization of roles
					assignmentDtos.add(assignmentDto);
				}
			}
			groupCompleteDto.setAssignments(assignmentDtos);
			
			groupXXXDto = groupCompleteDto;
		}
		return groupXXXDto;
	}

	@Override
	@Transactional
	public Long createGroup(GroupCompleteDto groupDto) {
		if (groupDto.getId() != null) {
			throw new IllegalArgumentException("The group to be created should not have id specified.");
		}
		
		Group group = beanMapper.map(groupDto, Group.class);

		Group parentGroup = null;
        Long parentId = groupDto.getParentId();
        if (parentId != null) {
        	parentGroup = groupDao.getGroup(parentId);
        	if(parentGroup == null) {
        		throw new InvalidGroupException(parentId);
        	}
        	group.setTopGroup(parentGroup.getTopGroup());
        } else {
        	group.setTopGroup(group);
        }

		//TODO: is pending status correct?
		//group.setStatus(GroupStatus.PENDING);
        groupDao.create(group);
        
        if (parentGroup != null) {
        	parentGroup.getSubGroups().add(group);
        	groupDao.update(parentGroup);
        }
        
        BusinessDto businessDto = groupDto.getBusiness();
        if (businessDto != null) {
            Business business = beanMapper.map(businessDto, Business.class);
            business.setGroupId(group.getId());
            business.setGroup(group);
            businessDao.createBusiness(business);
        }
        
        return group.getId();
	}

	@Override
	@Transactional
	public void updateGroup(GroupCompleteDto groupDto) {
		Long groupId = groupDto.getId();
		Validate.notNull(groupId, "Group id is missing");
		Group oldGroup = groupDao.getGroup(groupId);
		if(oldGroup == null) {
			throw new InvalidGroupException(groupId);
		}
		
		Long oldParentId = groupDto.getParentId();
		Long newParentId = oldGroup.getParentId();

		// To preserve values of non-updateable fields references are obtained 
		// prior bean mapping, and restored back upon bean mapping completion.
		List<Group> subGroups = oldGroup.getSubGroups();
		List<Assignment> assignments = oldGroup.getAssignments();
		List<Role> roles = oldGroup.getRoles();
		
		beanMapper.map(groupDto, oldGroup);
		
		oldGroup.setSubGroups(subGroups);
		oldGroup.setAssignments(assignments);
		oldGroup.setRoles(roles);
		
		groupDao.update(oldGroup);
		
		if (newParentId != null && !newParentId.equals(oldParentId)) {
			Group newParentGroup = groupDao.getGroup(newParentId);
			Group oldParentGroup = groupDao.getGroup(oldParentId);
			if(newParentGroup == null) {
				throw new InvalidGroupException(newParentId);
			}
			// TODO: The following lines are to ensure persistence cache
			// containing the old and new parent groups has been updated 
			// at the time group is being updated. Please note that group
			// entity has parentId mapped to the same column used to 
			// determine subgroups.
			if (!newParentGroup.getSubGroups().contains(oldGroup)) {
				newParentGroup.getSubGroups().add(oldGroup);
				groupDao.update(newParentGroup);
			}
			if (oldParentGroup.getSubGroups().contains(oldGroup)) {
				oldParentGroup.getSubGroups().remove(oldGroup);
				groupDao.update(oldParentGroup);
			}
		}
	}
	
	@Override
	@Transactional
	public void updateGroupStatus(LinkedHashMap<String, ArrayList<Long>> statuses) {
	    for(Entry<String, ArrayList<Long>> entry: statuses.entrySet()) {
			final String status = entry.getKey();
			GroupStatus groupStatus = GroupStatus.fromString(status);
			if (groupStatus == null) {
				// skip invalid statuses
				continue;
			}
	    	ArrayList<Long> groupIds = entry.getValue();
	    	for (Long groupId : groupIds) {
	    		Group group = groupDao.getGroup(groupId);
	    		if (group == null) {
	    			//skip invalid groups
	    			continue;
	    		}
	    		group.setStatus(groupStatus);
	    		groupDao.update(group);
	    	}
	    }
	}
	
	// TODO: Allow a group to be promoted to top group for all its descendants. The
	// group becoming top group can have a parent group and therefore different top 
	// group. This solution would enable membership to be supported on any/specific 
	// level.
	//
	//public void promoteToTopGroup(Long groupId) {
	//	throw new NotImplementedException("Promoting to a top group might be introduced in the next version");
	//}
	//
	//public void demoteFromTopGrop(Long groupId) {
	//	throw new NotImplementedException("Demoting a top group might be introduced in the next version");
	//}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteGroup(Long groupId) {
		Validate.notNull(groupId, "Group id is missing");
		Group group = groupDao.getGroup(groupId);
		if(group == null) {
			throw new InvalidGroupException(groupId);
		}

		List<Group> subGroups = group.getSubGroups();
		for (Group subGroup : subGroups) {
			deleteGroup(subGroup.getId());
		}

		//The commented code 
		//Business business = businessDao.getBusinessByGroupId(groupId);
		//businessDao.delete(business);
		businessDao.deleteBusinessByGroupId(groupId);
		
		List<Assignment> assignments = group.getAssignments(); 
		for (Assignment assignment : assignments) {
			assignmentDao.delete(assignment);
		}
		
		//Group deletion should propagate to group roles, if it does not membershipDao would be needed.
		//List<Membership> memberships = group.getMemberships();
		//group.setMemberships(null);
		//for (Membership membership : memberships) {
		//	membershipDao.delete(membership);
		//}

		List<User> users = group.getUsers();
		for (User user : users) {
			user.getGroups().remove(group);
			userDao.update(user);
		}
		
		//Group deletion should propagate to group roles, if it does not roleDao would be needed.
		//List<Role> roles = group.getRoles();
		//for (Role role : roles) {
		//	roleDao.delete(role);
		//}
		
		groupDao.delete(groupId);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void removeGroup(Long groupId) {
		Group group = groupDao.getGroup(groupId);
		group.setStatus(GroupStatus.INACTIVE);
		groupDao.update(group);
	}

}