/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.coloredshapes.coreservices.domain.enums.AssignmentStatus;

@Entity
@Table(name = "assignment")
public class Assignment extends BaseEntity {

	/**
	 * The serial version UID of this class
	 */
	public static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name="group_id", nullable = false) 
	private Group group;

	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "role_id", nullable = false)
	private Role role;
	
  	@Embedded
 	private Hours hours = new Hours();
	
	@Column(name = "rate")
    private Double rate;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private AssignmentStatus status;
	
	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Hours getHours() {
		return hours;
	}

	public void setHours(Hours hours) {
		this.hours = hours;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}
	
    public AssignmentStatus getStatus() {
		return status;
	}

	public void setStatus(AssignmentStatus status) {
		this.status = status;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("group", (group == null ? group : group.getId())) 
            .append("user", (user == null ? user : user.getId())) 
        	.append("role", (role == null ? role : role.getId())) 
         	.append("hours", hours) 
            .append("rate", rate)   
            .append("status", status)   
            .toString();
    }

}