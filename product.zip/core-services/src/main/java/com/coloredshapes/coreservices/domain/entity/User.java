/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.hibernate.annotations.Type;
import org.joda.time.DateTimeZone;

import com.coloredshapes.coreservices.domain.enums.AssignmentStatus;
import com.coloredshapes.coreservices.domain.enums.GroupStatus;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.enums.UserStatus;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Entity
@Table(name = "user")
public class User extends BaseEntity {

	/**
	 * The serial version UID
	 */
	public static final long serialVersionUID = -8094593518067498358L;

	@NotNull
	@Column(name = "first_name")
	@Size(min = 1)
	private String firstName;
	
	@NotNull
	@Column(name = "last_name")
	@Size(min = 1)
	private String lastName;
	
	@NotNull
	@Column(name = "short_name")
	@Size(min = 1, max = 8)
	private String shortName;
	
	@NotNull
	@Column(name = "phone_number")
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String phoneNumber;
	
	@NotNull
	@Column(name = "mobile_number")
	@Pattern(regexp = "^([1-9]\\d{2}(-|\\s)?[1-9]\\d{2}(-|\\s)?\\d{4})$")
	private String mobileNumber;
	
	@NotNull
	@Column(name = "address")
	private String address;
	
	@NotNull
	@Column(name = "city")
	private String city;
	
	//@NotNull
	//@Pattern(regexp = "^((AB)|(BC)|(MB)|(NB)|(NL)|(NT)|(NS)|(NU)|(ON)|(PE)|(QC)|(SK)|(YT))$")
	//@Column(name = "province")
	//private String province;
	
	@NotNull
	@Column(name = "region")
	private String region;
	
	@NotNull
	@Column(name = "country")
	private String country;
	
	@NotNull
	@Pattern(regexp = "^(([A-Z]\\d[A-Z]\\s\\d[A-Z]\\d)|(\\d{5}))$")
	@Column(name = "postal_code")
	private String postalCode;

	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTimeZoneAsString")
	@Column(name = "date_time_zone")
	private DateTimeZone dateTimeZone;

	@NotNull
	@Size(min = 1, max = 100)
	@Pattern(regexp = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
	@Column(name = "email", unique = true)
	private String email;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private UserStatus status;
	
	@NotNull
	@Column(name = "hashed_password")
	@JsonIgnore
	private String hashedPassword;
	
	@Transient
	@Size(min = 3, max = 18)
	private String password;
	
	@Column(name = "salt")
	@JsonIgnore
	private String salt;
	
	@Column(name = "is_temp_password")
	private Boolean isTempPassword;

	@Column(name = "qualification")
	private String qualification;

	@Column(name = "agreement_version")
	private Integer agreementVersion;

	@Transient
	private Boolean mustAcceptAgreement;

	@JsonIgnore
	@OneToMany(mappedBy="user", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Membership> memberships;
	
	// http://www.roseindia.net/hibernate/hibernate4/HibernateManytoMany.shtml
	// http://viralpatel.net/blogs/hibernate-many-to-many-annotation-mapping-tutorial/
	// http://www.mkyong.com/hibernate/hibernate-many-to-many-relationship-example-annotation/
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "users")
	//@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	//@JoinTable(name="user_usergroup", joinColumns={ @JoinColumn(name="group_id")}, inverseJoinColumns={ @JoinColumn(name="user_id")})
	private List<Group> groups;

	@JsonIgnore
	@OneToMany(mappedBy="user", fetch = FetchType.LAZY)
	private List<Assignment> assignments;

	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
	private List<RepeatableEvent> repeatableEvents;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	//public String getProvince() {
	//	return province;
	//}
	//
	//public void setProvince(String province) {
	//	this.province = province;
	//}
	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonIgnore
	public UserStatus getStatus() {
		return status;
	}

	@JsonIgnore
	public void setStatus(UserStatus status) {
		this.status = status;
	}

	@JsonIgnore
	public String getHashedPassword() {
		return hashedPassword;
	}

	@JsonIgnore
	public void setHashedPassword(String hashedPassword) {
		this.hashedPassword = hashedPassword;
	}

	@JsonIgnore
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@JsonIgnore
	public String getSalt() {
		return salt;
	}

	@JsonIgnore
	public void setSalt(String salt) {
		this.salt = salt;
	}

	public Boolean getIsTempPassword() {
		return isTempPassword;
	}

	@JsonIgnore
	public void setIsTempPassword(Boolean isTempPassword) {
		this.isTempPassword = isTempPassword;
	}

	/**
	 * @return the date time zone
	 */
	@JsonIgnore
	public DateTimeZone getDateTimeZone() {
		return dateTimeZone;
	}

	/**
	 * @param dateTimeZone
	 *            the date time zone to set
	 */
	@JsonIgnore
	public void setDateTimeZone(DateTimeZone dateTimeZone) {
		this.dateTimeZone = dateTimeZone;
	}

	/**
	 * @return the date time zone
	 */
	@JsonProperty("dateTimeZone")
	public String getDateTimeZoneAsID() {
		return dateTimeZone.getID();
	}

	/**
	 * @param dateTimeZone
	 *            the date time zone to set
	 */
	@JsonProperty("dateTimeZone")
	public void setDateTimeZoneAsID(String dateTimeZone) {
		this.dateTimeZone = DateTimeZone.forID(dateTimeZone);
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Integer getAgreementVersion() {
		return agreementVersion;
	}

	@JsonIgnore
	public void setAgreementVersion(Integer agreementVersion) {
		this.agreementVersion = agreementVersion;
	}

	public Boolean getMustAcceptAgreement() {
		return mustAcceptAgreement;
	}

	@JsonIgnore
	public void setMustAcceptAgreement(Boolean mustAcceptAgreement) {
		this.mustAcceptAgreement = mustAcceptAgreement;
	}

	@JsonIgnore
	public List<Membership> getMemberships() {
		return memberships;
	}

	public List<Membership> getMemberships(MembershipStatus status) {
		List<Membership> filteredMemberships = new ArrayList<Membership>(memberships.size());
		for (Membership membership : memberships) {
			if (ObjectUtils.equals(membership.getMembershipStatus(), status)) {
				filteredMemberships.add(membership);
			}
		}
		return filteredMemberships;
	}

	@JsonIgnore
	public void setMemberships(List<Membership> membership) {
		this.memberships = membership;
	}

	public List<Group> getGroups() {
		return groups;
	}

	public List<Group> getGroups(GroupStatus status) {
		List<Group> filteredGroups = new ArrayList<Group>(groups.size());
		for (Group group : groups) {
			if (ObjectUtils.equals(group.getStatus(), status)) {
				filteredGroups.add(group);
			}
		}
		return filteredGroups;
	}

	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}

	public List<Assignment> getAssignments() {
		return assignments;
	}

	public List<Assignment> getAssignments(AssignmentStatus status) {
		List<Assignment> filteredAssignments = new ArrayList<Assignment>(assignments.size());
		for (Assignment assignment : assignments) {
			if (ObjectUtils.equals(assignment.getStatus(), status)) {
				filteredAssignments.add(assignment);
			}
		}
		return filteredAssignments;
	}

	public void setAssignments(List<Assignment> assignments) {
		this.assignments = assignments;
	}

	@JsonIgnore
	public List<RepeatableEvent> getRepeatableEvents() {
		return repeatableEvents;
	}

	@JsonIgnore
	public void setRepeatableEvents(List<RepeatableEvent> repeatableEvents) {
		this.repeatableEvents = repeatableEvents;
	}

    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("firstName", firstName) 
            .append("lastName", lastName) 
            .append("shortName", shortName) 
        	.append("phoneNumber", phoneNumber) 
        	.append("mobileNumber", mobileNumber) 
            .append("address", address)   
            .append("city", city)
            .append("region", region) 
            .append("country", country) 
        	.append("postalCode", postalCode) 
            .append("dateTimeZone", dateTimeZone)   
            .append("email", email) 
            .append("status", status)
        	.append("qualification", qualification) 
            .append("agreementVersion", agreementVersion)   
            .append("mustAcceptAgreement", mustAcceptAgreement)
            .append("memberships", StandardUtils.toEntityString(memberships)) 
            .append("groups", StandardUtils.toEntityString(groups)) 
            .append("assignments", StandardUtils.toEntityString(assignments)) 
            .append("repeatableEvents", StandardUtils.toEntityString(repeatableEvents)) 
			//.append("password", password) 
			//.append("hashedPassword", hashedPassword) 
			//.append("salt", salt)   
			//.append("isTempPassword", isTempPassword)
            .toString();
    }	

}