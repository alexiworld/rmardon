/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.exception.AuthenticationException;
import com.coloredshapes.coreservices.exception.AuthorizationException;

/**
 * <code>SecurityService</code> type defines the security service contract.
 * 
 * This service was created after finding out that authorized method in AuthorizationInterceptor fail short
 * to obtain assignments collection for a user, reason collection is lazy initialized and @Transactional on
 * interceptor's method level does not prevent closing hibernate session after DAO returns the user object.
 * 
 * One solution was to extend the persistence context as suggested in following discussion thread. It might
 * however open another problems and therefore, was more safe moving the method in a service, which ensures
 * the hibernate session used to obtain user object is still open to continue and obtain his/her assignments.
 * 
 * Authentication and Authorization walk hand by hand. Because security service provide authorization to 
 * services the next logical step is to move the authentication here in too.
 * 
 * http://forum.spring.io/forum/spring-projects/data/56569-failed-to-lazily-initialize-a-collection-of-role
 * @PersistenceContext(unitName="bigbrother", type=PersistenceContextType.EXTENDED)
 * public void setEntityManager(EntityManager entityManager) {
 *     this.entityManager = entityManager;
 * }
 */
public interface SecurityService {

	/**
	 * Authenticate user by id and password.
	 * 
	 * @param userId	the user id
	 * @param password	the user password
	 * @throws AuthenticationException if the user credentials are not valid, or an exception
	 * was raised during encryption.
	 */
	Long authenticate(Long userId, String password) throws AuthenticationException;
	/**
	 * Authenticate user by email and password.
	 * 
	 * @param email		the user email
	 * @param password	the user password
	 * @throws AuthenticationException if the user credentials are not valid, or an exception
	 * was raised during encryption.
	 */
	Long authenticate(String email, String password) throws AuthenticationException;

	/**
	 * Validates if user is authorized to manage the group.
	 * 
	 * @param userId	the user id
	 * @param groupId	the group id
	 * @throws AuthorizationException if the user does not have admin rights
	 * on the group.
	 */
	void authorized(Long userId, Long groupId) throws AuthorizationException;

}