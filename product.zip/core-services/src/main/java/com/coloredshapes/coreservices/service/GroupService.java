/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.coloredshapes.coreservices.domain.dto.GroupBasicDto;
import com.coloredshapes.coreservices.domain.dto.GroupCompleteDto;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;

public interface GroupService {
	
	public GroupBasicDto getGroup(Long groupId, ContentLimit contentLimit, ContentStatus contentStatus);

	public List<GroupBasicDto> getGroups(Long[] groupIds, ContentLimit contentLimit, ContentStatus contentStatus);

	public List<Long> getUserGroupIds(Long userId, ContentStatus contentStatus);
	
	public List<Long> getUserGroupIds(String userEmail, ContentStatus contentStatus);
	
	public List<GroupBasicDto> getUserGroups(Long userId, ContentLimit contentLimit, ContentStatus contentStatus);

	public List<GroupBasicDto> getUserGroups(String userEmail, ContentLimit contentLimit, ContentStatus contentStatus);

	public List<Long> getUserFrontGroupIds(Long userId, ContentStatus contentStatus);
	
	public List<Long> getUserFrontGroupIds(String userEmail, ContentStatus contentStatus);
	
	public List<GroupBasicDto> getUserFrontGroups(Long userId, ContentLimit contentLimit, ContentStatus contentStatus);

	public List<GroupBasicDto> getUserFrontGroups(String userEmail, ContentLimit contentLimit, ContentStatus contentStatus);

	public Long createGroup(GroupCompleteDto group);

	public void updateGroup(GroupCompleteDto groupDto);

	public void updateGroupStatus(LinkedHashMap<String, ArrayList<Long>> statuses);
	
	// TODO: Allow a group to be promoted to top group for all its descendants. The
	// group becoming top group can have a parent group and therefore different top 
	// group. This solution would enable membership to be supported on any/specific 
	// level.
	//
	//public void promoteToTopGroup(Long groupId);
	//
	//public void demoteFromTopGrop(Long groupId);
	
	public void deleteGroup(Long groupId); // completely wipes the group out

	public void removeGroup(Long groupId); // marks the group as inactive

}
