/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class InvalidMembershipException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -1154156497518775569L;
	private static final String errCode = "0012";

	private Long groupId;
	private Long userId;
	
	public InvalidMembershipException(Long groupId, Long userId) {
		super();
		this.groupId = groupId;
		this.userId = userId;
	}
	
	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
