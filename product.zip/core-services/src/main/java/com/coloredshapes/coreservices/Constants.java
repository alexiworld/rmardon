/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices;

/**
 * The Core Service Constants.
 */
public class Constants {

	/**
	 * This constant is to enable user assignments and roles for all groups to be returned.
	 * 
	 * Limiting assignments and roles to user selected group lowers the network traffic and
	 * hence decreases network latency and improves the performance. 
	 */
	public final static Long NO_GROUP_LIMITED = null;
	
	/**
	 * The admin role assigned to user providing him with access to request group schedule,
	 * create and update schedule, view user profiles, create various reports that might
	 * include strictly confidential information.
	 */
	public final static String ADMIN_ROLE = "Admin";
	
}