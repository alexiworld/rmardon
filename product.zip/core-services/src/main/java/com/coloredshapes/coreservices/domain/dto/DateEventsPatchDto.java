/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import java.util.List;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdArraySerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;
import com.coloredshapes.coreservices.domain.jsonhelper.LongArraySerializer;

/**
 * <code>DateEventsPatchDto</code> composes new events assigned to group users
 * and/or cancelled existing events. 
 */
public class DateEventsPatchDto implements Comparable<DateEventsPatchDto>, Cloneable {
	
	private String refNum;
	private Long groupId;
	private String note;
	private DateTime startTime;
	private DateTime endTime;
	private Long[] userIds;
	private Long[] deletedEvents;
	private Long[] successfullyDeletedEvents;
	private List<DateEventsDto> addedEvents;
	private List<DateEventsDto> successfullyAddedEvents;

    /**
     * Creates an events patch instance.
     */
	public DateEventsPatchDto() {
	}
	
	/**
	 * Sets the reference number.
	 * 
	 * @param refNum the reference number to set
	 */
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	/**
	 * Gets the reference number.
	 * 
	 * @return the reference number
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getRefNum() {
		return refNum;
	}

	/**
	 * Sets the group key
	 * 
	 * @param groupId the group key to set
	 */
	@JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * Gets the group key
	 * 
	 * @return the group key
	 */
	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getGroupId() {
		return groupId;
	}
	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}
		
	/**
     * Sets the start time.
     * 
	 * @param startTime the start time to set
	 */
	@JsonDeserialize(using=DateDeserializer.class) 
	public void setStartTime(DateTime startTime) {
		this.startTime = startTime;
	}

	/**
     * Gets the start time
     * 
     * @return	the start time
     */
    @JsonIgnore  
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getStartTime(){
    	return startTime;
    }

	/**
	 * Sets the end time.
	 * 
	 * @param endTime the end time to set
	 */
    @JsonDeserialize(using=DateDeserializer.class) 
	public void setEndTime(DateTime endTime) {
		this.endTime = endTime;
	}

	/**
     * Gets the end time
     * 
     * @return	the end time
     */
    @JsonIgnore 
    @JsonSerialize(using = DateSerializer.class)
    public DateTime getEndTime(){
        return endTime;
    }
	
    @JsonSerialize(using = IdArraySerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long[] getUserIds() {
		return userIds;
	}

    @JsonDeserialize(contentUsing = IdDeserializer.class)//contentAs = IdDeserializer.class)
	public void setUserIds(Long[] userIds) {
		this.userIds = userIds;
	}

	/**
	 * Sets the events to be deleted.
	 * 
	 * @param deletedEvents the events to be deleted
	 */
    public void setDeletedEvents(Long[] deletedEvents) {
		this.deletedEvents = deletedEvents;
	}

	/**
	 * Gets the events to be deleted.
	 * 
	 * @return the events to be deleted
	 */
    @JsonSerialize(using = LongArraySerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long[] getDeletedEvents() {
		return deletedEvents;
	}

	/**
	 * Sets the events successfully deleted.
	 * 
	 * @param successfullyDeletedEvents
	 *            the events successfully deleted
	 */
    public void setSuccessfullyDeletedEvents(Long[] successfullyDeletedEvents) {
		this.successfullyDeletedEvents = successfullyDeletedEvents;
	}

	/**
	 * Gets the events successfully deleted.
	 * 
	 * @return the events successfully deleted
	 */
    @JsonSerialize(using = LongArraySerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long[] getSuccessfullyDeletedEvents() {
		return successfullyDeletedEvents;
	}

	/**
	 * Sets the events to be added.
	 * 
	 * @param addedEvents the events to be added
	 */
	public void setAddedEvents(List<DateEventsDto> addedEvents) {
		this.addedEvents = addedEvents;
	}
	
	/**
	 * Gets the events to be added.
	 * 
	 * @return the events to be added
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<DateEventsDto> getAddedEvents() {
		return addedEvents;
	}
	
	/**
	 * Sets the successfully added events.
	 * 
	 * @param successfullyAddedEvents
	 *            the events successfully added
	 */
	public void setSuccessfullyAddedEvents(
			List<DateEventsDto> successfullyAddedEvents) {
		this.successfullyAddedEvents = successfullyAddedEvents;
	}

	/**
	 * Gets the events successfully added.
	 * 
	 * @return the events successfully added
	 */
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<DateEventsDto> getSuccessfullyAddedEvents() {
		return successfullyAddedEvents;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
    	return new ToStringBuilder(this)
	    	.append("groupId", groupId)
	    	.append("deletedEvents", deletedEvents)
	    	.append("successfullyDeletedEvents", successfullyDeletedEvents)
	    	.append("addedEvents", addedEvents)
	    	.append("successfullyAddedEvents", successfullyAddedEvents)
	    	.toString();
    }

    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
    	if (this == that) return true;
        if (!(that instanceof DateEventsPatchDto)) return false;

        DateEventsPatchDto otherDateTimeBlock = (DateEventsPatchDto) that;
        return new EqualsBuilder()
	        .append(groupId, otherDateTimeBlock.groupId)
	        .append(deletedEvents, otherDateTimeBlock.deletedEvents)
	        .append(addedEvents, otherDateTimeBlock.addedEvents)
	        .append(successfullyDeletedEvents, otherDateTimeBlock.successfullyDeletedEvents)
	        .append(successfullyAddedEvents, otherDateTimeBlock.successfullyAddedEvents)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user key is always present, while the group key not.
     * To improve the searching performance in a map the hash
     * code only takes the user key into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
    	return new HashCodeBuilder(17, 37).append(groupId).hashCode();
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(DateEventsPatchDto that) {
        if (this == that) return 0;

        return new CompareToBuilder()
	        .append(groupId, that.groupId)
	        .append(deletedEvents, that.deletedEvents)
	        .append(addedEvents, that.addedEvents)
	        .append(successfullyDeletedEvents, that.successfullyDeletedEvents)
	        .append(successfullyAddedEvents, that.successfullyAddedEvents)
	        .toComparison();
    }
    
}