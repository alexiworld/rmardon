/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.jsonhelper.DateDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.DateSerializer;

@Entity
@Table(name="message_content")
public class MessageContent extends BaseEntity {
	
	@Column(name="subject")
	@Size(max=64)
	private String subject;
	
	@Column(name="body")
	@Size(max=512)
	private String body;
	
	@NotNull
	@Column(name="msgtime")
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime time;
	
	@Column(name="channel")
	@Size(max=256)
	private String channel;
	
	// attachements can be added at later time
	
	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the body
	 */
	public String getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(String body) {
		this.body = body;
	}

	/**
	 * @return
	 */
	@JsonSerialize(using = DateSerializer.class)
	public DateTime getTime() {
		return time;
	}
	
	/**
	 * @param time
	 */
	@JsonIgnore
    @JsonDeserialize(using=DateDeserializer.class)
	public void setTime(DateTime time) {
		this.time = time;
	}
	
	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("subject", subject) 
        	.append("body", body) 
        	.append("time", time) 
        	.append("channel", channel) 
        	.toString();
    }

}