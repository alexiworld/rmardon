/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "user_agreement")
public class UserAgreement extends BaseEntity {
	
	@Column(name = "text_version", nullable = false)
	private Integer textVersion;
	
	@Column(name = "text", length = 65536)
	private String text;

	public Integer getTextVersion() {
		return textVersion;
	}

	public void setTextVersion(Integer textVersion) {
		this.textVersion = textVersion;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

    /** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("textVersion", textVersion) 
            .append("text", text) 
            .toString();
    }	

}
