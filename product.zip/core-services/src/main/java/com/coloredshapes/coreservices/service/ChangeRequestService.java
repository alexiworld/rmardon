/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.exception.InvalidUserException;

public interface ChangeRequestService {
	
	public String sendChangeRequest(Long userId, Long[] eventIds) throws InvalidUserException;

}
