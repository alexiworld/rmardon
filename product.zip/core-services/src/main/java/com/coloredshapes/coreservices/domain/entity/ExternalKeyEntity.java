/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.jsonhelper.LongSerializer;

/**
 * <code>ExternalKeyEntity</code> is parent class of entities 
 * that need random external key.
 */
@MappedSuperclass
public abstract class ExternalKeyEntity extends BaseEntity {
	
	//Index annotation not available in JPA
	//@Index(name="index_ext_key", columnNames="ext_key")
	@Column(name = "ext_key", unique = true)
	private Long extKey;

	@JsonSerialize(using = LongSerializer.class)
	public Long getExtKey() {
		return extKey;
	}

	@JsonIgnore
	public void setExtKey(Long extKey) {
		this.extKey = extKey;
	}

}