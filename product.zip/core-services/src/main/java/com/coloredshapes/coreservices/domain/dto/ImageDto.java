/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * <code>ImageDto</code> is DTO class used to
 * transfer images.
 */
public class ImageDto extends IdDto implements Comparable<ImageDto> {

	public static final long serialVersionUID = 4685202244732172036L;

	@NotNull
	private String file;
	
	@NotNull
	private String type;
	
	@NotNull
    private byte[] bytes;


    /**
     * Constructs image DTO.
     */
    public ImageDto() {
		super();
	}
    
    /**
     * Constructs image DTO.
     * 
     * @param id		the id
     * @param file		the file
     * @param type		the type
     * @param bytes		the bytes
     */
    public ImageDto(Long id, String file, String type, byte[] bytes) {
		super(id);
		this.file = file;
		this.type = type;
		this.bytes = bytes;
	}

	/**
     * Gets the file.
     * 
	 * @return the file
	 */
	public String getFile() {
		return file;
	}

	/**
	 * Sets the file.
	 * 
	 * @param file the file to set
	 */
	public void setFile(String file) {
		this.file = file;
	}

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 * 
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the bytes.
	 * 
	 * @return the bytes
	 */
	public byte[] getBytes() {
		return bytes;
	}

	/**
	 * Sets the bytes.
	 * 
	 * @param bytes the bytes to set
	 */
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}

	/**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p/>
     *
     * @param that the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *         is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     */
    @Override
    public int compareTo(ImageDto that) {
    	int res = this.file.compareTo(that.file);
    	if (res == 0) {
    		res = this.type.compareTo(that.type);
    	}
    	return res;
    }

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
	        .append("file", file) 
	        .append("type", type)   
            .toString();
    }
    
    /** 
     * Test this and some other object for equality.
     * 
     * @return true if both objects are considered equal, false otherwise.
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof ImageDto)) return false;

        ImageDto otherEvent = (ImageDto) that;

        return new EqualsBuilder()
	        .append(file, otherEvent.file)
	        .append(type, otherEvent.type)
	        .isEquals();
    }

    /** 
     * Returns the hash code of this object.
     * 
     * The user key is always present, while the group key not.
     * To improve the searching performance in a map the hash
     * code only takes the user key into account.
     * 
     * @return the hash code
     */
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
        	.append(file)
	        .append(type)
	        .hashCode();
    }

}