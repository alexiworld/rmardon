/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.coloredshapes.coreservices.domain.enums.MembershipRequestStatus;

//TODO: To be merged with Membership entity in the future

@Entity
@Table(name = "membership_request")
public class MembershipRequest extends BaseEntity {

	/**
	 * This class serial version UID 
	 */
	public static final long serialVersionUID = 2345654645L;

	@Column(name = "user_email")
	private String userEmail;
	
	@Column(name = "group_id")
	private Long groupId;
	
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "reference_id")
	private String referenceId;

	@Column(name = "create_date")
	private Date createDate;
	
	@Column(name = "confirmation_date")
	private Date confirmationDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false)
	private MembershipRequestStatus status;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getConfirmationDate() {
		return confirmationDate;
	}

	public void setConfirmationDate(Date confirmationDate) {
		this.confirmationDate = confirmationDate;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public MembershipRequestStatus getStatus() {
		return status;
	}

	public void setStatus(MembershipRequestStatus status) {
		this.status = status;
	}

    /** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("userEmail", userEmail) 
            .append("userId", userId) 
            .append("groupId", groupId) 
        	.append("referenceId", referenceId) 
        	.append("createDate", createDate) 
        	.append("confirmationDate", confirmationDate) 
        	.append("status", status) 
            .toString();
    }

}