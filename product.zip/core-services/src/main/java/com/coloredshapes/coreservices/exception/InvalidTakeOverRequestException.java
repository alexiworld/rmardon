/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class InvalidTakeOverRequestException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = 2905734562110730130L;
	private static final String errCode = "0015";

	@Override
	public String getErrorCode() {
		return errCode;
	}
}
