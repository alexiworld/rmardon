/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

public class TakeOverAcceptanceDto {

	private Long takeOverRequestId;
	private String acceptedByUser;
	private String declinedByUser;
	private Long eventId;

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
    public Long getTakeOverRequestId() {
		return takeOverRequestId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setTakeOverRequestId(Long takeOverRequestId) {
		this.takeOverRequestId = takeOverRequestId;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getAcceptedByUser() {
		return acceptedByUser;
	}


	public void setAcceptedByUser(String takenByUser) {
		this.acceptedByUser = takenByUser;
	}
	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public String getDeclinedByUser() {
		return declinedByUser;
	}


	public void setDeclinedByUser(String rejectedByUser) {
		this.declinedByUser = rejectedByUser;
	}

	@JsonSerialize(using = IdSerializer.class,include=JsonSerialize.Inclusion.NON_NULL)
	public Long getEventId() {
		return eventId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	/** 
     * Returns a textual representation of this object.
     * 
     * @return the textual representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
        	.append("takeOverRequestId", takeOverRequestId)
            .append("acceptedByUser", acceptedByUser)
            .append("declinedByUser", declinedByUser)
            .append("eventId", eventId)
            .toString();
    }

}
