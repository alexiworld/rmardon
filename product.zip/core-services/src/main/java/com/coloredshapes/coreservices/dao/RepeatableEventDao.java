/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import org.joda.time.LocalTime;

import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;

public interface RepeatableEventDao extends GenericDao<RepeatableEvent> {
	
	RepeatableEvent getRepeatableEventStartOrEndBetween(DayOfWeek day, LocalTime start, LocalTime end, Long userId);

	List<RepeatableEvent> getRepeatableEventByUserId(Long userId);

	void createRepeatableEvent(RepeatableEvent repeatableEvent);

	void deleteRepeatableEventsOfUser(Long userId, List<Long> events);
	
}
