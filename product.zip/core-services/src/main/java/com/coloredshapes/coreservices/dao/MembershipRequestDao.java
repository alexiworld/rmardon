/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import com.coloredshapes.coreservices.domain.entity.MembershipRequest;

public interface MembershipRequestDao extends GenericDao<MembershipRequest> {
	
	public void createMembershipRequest(MembershipRequest membershipReq);

	public MembershipRequest getMembershipRequestByRefIdAndUserId(String refId, Long userId);

	public void updateMembershipRequest(MembershipRequest membershipReq);

	public List<MembershipRequest> getMembershipRequestByGroupIdAndUserId(Long groupId, Long userId);
	
}
