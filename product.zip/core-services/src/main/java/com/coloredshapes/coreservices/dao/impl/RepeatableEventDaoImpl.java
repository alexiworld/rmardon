/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.joda.time.LocalTime;
import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.RepeatableEventDao;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
@Repository
public class RepeatableEventDaoImpl extends BaseJpaImpl<RepeatableEvent> implements RepeatableEventDao {

	@Override
	public RepeatableEvent getRepeatableEventStartOrEndBetween(DayOfWeek day, LocalTime start, LocalTime end, Long userId) {
		TypedQuery<RepeatableEvent> query = entityManager.createQuery(
		        "SELECT rev FROM RepeatableEvent rev WHERE dayOfWeek=:day and ((startTime between :start and :end) or (endTime between :start and :end)) and  rev.user.id = :userId", RepeatableEvent.class);
	    query.setParameter("day", day); 
	    query.setParameter("start", start);
	    query.setParameter("end", end); 
	    query.setParameter("userId", userId); 
	    query.setMaxResults(1);
	    List<RepeatableEvent> resultList = query.getResultList();
	    
		return resultList.size() > 0 ? resultList.get(0) : null;
	}

	@Override
	public void createRepeatableEvent(RepeatableEvent repeatableEvent) {
		create(repeatableEvent);
	}

	@Override
	public List<RepeatableEvent> getRepeatableEventByUserId(Long userId) {
		TypedQuery<RepeatableEvent> query = entityManager.createQuery(
		        "SELECT rev FROM RepeatableEvent rev WHERE rev.user.id = :userId order by rev.startTime asc ", 
		        RepeatableEvent.class);
	    query.setParameter("userId", userId); 
	    List<RepeatableEvent> resultList = query.getResultList();
	    return resultList;
	}

	@Override
	public void deleteRepeatableEventsOfUser(Long userId, List<Long> eventIds) {
		String deleteHQL = "delete from RepeatableEvent rev where rev.id in :eventIds"+
	                       " and user_id = :userId";
		
		Query query = entityManager.createQuery(deleteHQL);
		query.setParameter("eventIds", eventIds);
		query.setParameter("userId", userId);
		
		@SuppressWarnings("unused")
		int deletedRow = query.executeUpdate();
	}

}