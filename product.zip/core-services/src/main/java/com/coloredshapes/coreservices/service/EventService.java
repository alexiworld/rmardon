/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import java.util.List;
import java.util.Map;

import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;

/**
 * <code>EventService</code> type is an interface to manage events.
 */
public interface EventService {

	/**
	 * Retrieves events for specific time period. The results are in groups based on their source type.
	 * The supported source types at the present time are "user" and "group". If the "group" source type
	 * is selected, groupId can be provided as optional parameter to filter only events for that group.
	 * 
	 * This operation normally serves a user willing to retrieve his/her events.
	 * 
	 * @param userId		the id of the user making the request
	 * @param timePeriod	the time period
	 * @param sourceTypes	list of source types 
	 * @param groupIds		optionally groups can be provided if the source type "GROUP" is specified
	 * @return	a map with source types and date events
	 */
	Map<String,DateEventsDto> getEvents(Long userId, TimePeriodDto timePeriod, SourceType[] sourceTypes, Long[] groupIds);
	
	/**
	 * Retrieves the list of date events for specific time period. All events scheduled by
	 * groups different from the specified group will be treated as user events for the 
	 * reason of confidentiality. Therefore, information such as other group ids and tags 
	 * will not be exposed.
	 * 
	 * This operation serves a group willing for specific period to retrieve the events of specific 
	 * users. It provides the group not only with date events, but also day events converted
	 * to date events.
	 * 
	 * @param groupId		the group making the request
	 * @param timePeriod	the time period
	 * @param userIds		the users for which group is requesting the events
	 * @return	a list of date events, the number corresponds to the number of user keys
	 */
	List<DateEventsDto> getEvents(Long groupId, TimePeriodDto timePeriod, Long[] userIds);
	
	/**
	 * Creates date events.
	 * 
	 * @param dateEvents	the date events
	 * @return	a map containing two entries, the first entry is the list of event entities 
	 * persisted successfully, the second entry is the list of not persisted event entities  
	 */
	Map<Outcome, DateEventsDto> createEvents(DateEventsDto dateEvents);
	
	/**
	 * Creates events for one or more users.
	 * 
	 * This operation serves groups to create events for one or more users. 
	 * 
	 * @param groupId					key of the group blocking users time
	 * @param listOfDateEvents	list of the date events
	 * @return	a map containing two entries, the first entry is the list of event entities 
	 * persisted successfully, the second entry is the list of not persisted event entities  
	 */
	Map<Outcome, List<DateEventsDto>> createEvents(Long groupId, List<DateEventsDto> listOfDateEvents);
	
	/**
	 * Deletes events.
	 * 
	 * @param userId		provided if the user is performing the deletion
	 * @param groupId		provided if the group is performing the deletion
	 * @param eventIds		a list of keys of events to be deleted
	 * @return	a map containing two entries, the first entry is the list of event ids, 
	 * which entities have been successfully deleted, the second entry are for the ones that
	 * have not been deleted.
	 */
	Map<Outcome, List<Long>> deleteEvents(Long userId, Long groupId, List<Long> eventIds);

	/**
	 * Assigns events to users (processed asynchronously).
	 * 
	 * @param dateEventsPatch
	 *            a holder for events to be added/deleted
	 */
	void asynchDateEventsPatch(DateEventsPatchDto dateEventsPatch);

	/**
	 * Assigns events to users (processed synchronously). 
	 * 
	 * @param dateEventsPatch	a holder for events to be added/deleted
	 */
	DateEventsPatchDto synchDateEventsPatch(DateEventsPatchDto dateEventsPatch);

}