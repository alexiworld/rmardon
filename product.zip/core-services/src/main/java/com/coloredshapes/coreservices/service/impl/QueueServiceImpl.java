/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.TakeOverAcceptanceDto;
import com.coloredshapes.coreservices.service.QueueService;

/**
 * <code>QueueServiceImpl</code> type is an implementation
 * of the <code>QueueService</code> interface. It is used 
 * to enqueue or send messages.
 */
@Service
public class QueueServiceImpl implements QueueService {
	
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * The AMQP template
	 */
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${amqp.exchange:ColoredShapes.Exchange}")
	private String exchange;
	
	//@Value("${amqp.queue:ColoredShapes.Queue.Services}")
	//private String queue;
	
	@Value("${amqp.rotingKey:Services}")
	private String routingKey;
	
	@Value("${amqp.eventChangeRequestKey}")
	private String eventChangeRequestKey;
	
	@Value("${amqp.membershipConfirmationKey}")
	private String membershipConfirmationKey;
	
	@Value("${amqp.torAcceptanceKey}")
	private String torAcceptanceKey;
	
	@Value("${amqp.torDeclinationKey}")
	private String torDeclinationKey;
	
	/**
	 * Assigns patch to users. 
	 * 
	 * @param dateEventsPatch	a holder for events to be added/deleted
	 */
	@Override
	public void enqueueDateEventsPatch(DateEventsPatchDto dateEventsPatch) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enqueue patch: " + dateEventsPatch);
		}

		amqpTemplate.convertAndSend(exchange, routingKey, dateEventsPatch);
	}

	@Override
	public void enqueueEventChangeRequest(Long[] eventIds) {
		amqpTemplate.convertAndSend(exchange, eventChangeRequestKey, eventIds);
	}
	
	@Override
	public void enqueueTakeOverAcceptance(TakeOverAcceptanceDto toaDto) {

		if (logger.isDebugEnabled()) {
			logger.debug("TakeOverAcceptanceDto put to queue: " + toaDto);
		}
		amqpTemplate.convertAndSend(exchange, torAcceptanceKey, toaDto);
		
	}

	@Override
	public void enqueueTakeOverDeclination(
			TakeOverAcceptanceDto todDto) {
		if (logger.isDebugEnabled()) {
			logger.debug("ShiftFulfillmentRequestDecline put to queue: " + todDto);
		}
		amqpTemplate.convertAndSend(exchange, torAcceptanceKey, todDto);
		
	}
	
}