/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.enums;

public enum AssignmentStatus {

	PENDING,
	ACTIVE,
	INACTIVE,
	CLOSED;

	public static AssignmentStatus fromString(String status) {
		if (status != null) {
			for (AssignmentStatus groupStatus : AssignmentStatus.values()) {
				if (status.equalsIgnoreCase(groupStatus.name())) {
					return groupStatus;
				}
			}
		}
		return null;
	}

}
