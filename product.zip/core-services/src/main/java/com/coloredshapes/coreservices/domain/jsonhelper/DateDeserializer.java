/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.jsonhelper;

import java.io.IOException;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateDeserializer extends JsonDeserializer<DateTime> {

	@Override
	public DateTime deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		Long longValue = null;
		try {
			longValue = jp.getLongValue();
		} catch (Exception e) {
			String dateStr = jp.getText();
			DateTimeFormatter formatter = DateTimeFormat
					.forPattern("yyyy/MM/dd HH:mm:ss");
			DateTime dateTime = formatter.parseDateTime(dateStr);
			// System.out.println(dateTime);
			return dateTime;
		}
		DateTime dateTime = new DateTime(longValue);
		return dateTime;
	}

}
