/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.exception;

public class InvalidAssignmentException extends CoreServicesException {
	/**
	 * This class serial version UID
	 */
	private static final long serialVersionUID = -8150269007280050981L;
	private static final String errCode = "0008";

	private Long assignmentId;

	public InvalidAssignmentException(Long assignmentId) {
		this.assignmentId = assignmentId;
	}
	
	public Long getAssignmentId() {
		return assignmentId;
	}

	@Override
	public String getMessage() {
		return "Assignment#" + assignmentId + " does not exist";
	}

	@Override
	public String getErrorCode() {
		return errCode;
	}

}