/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;

/**
 * <code>EventDao</code> type is a DAO interface to manage events.
 */
public interface EventDao extends GenericDao<Event>{
	
	/**
	 * Retrieves events for specific user and time period. The results are filtered based on the
	 * following criteria:
	 * - retrieve only user private events  
	 * - retrieve events assigned to a user by all or specific groups
	 * - retrieve combination of above
	 * 
	 * @param startTime		the start time of query
	 * @param endTime		the end time of query
	 * @param userId		the user id
	 * @param sourceTypes	list of source types 
	 * @param groupIds		optionally the group Ids
	 * @return	list of event entities
	 */
	public List<Event> getEventsByUserId(DateTime startTime, DateTime endTime, Long userId, SourceType[] sourceTypes, Long[] groupIds);
	
	/**
	 * Retrieves users events for specific time period. 
	 * 
	 * @param startTime		the start time of query
	 * @param endTime		the end time of query
	 * @param userIds		the user Ids
	 * @return	list of event entities
	 */
	public List<Event> getEventsByUserIds(DateTime startTime, DateTime endTime, Long[] userIds);
	
	/**
	 * Persists the list of event entities.
	 * 
	 * @param events	the list of event entities
	 * @return	a map containing two entries, the first entry is the list of event entities 
	 * persisted successfully, the second entry is the list of not persisted event entities  
	 */
	public Map<Outcome, List<Event>> createEvents(List<Event> events);
	
	/**
	 * Deletes all events having any of the specified Ids.
	 * 
	 * @param userId		provided if the user is performing the deletion
	 * @param groupId		provided if the group is performing the deletion
	 * @param eventIds		the event Ids
	 * @return	a map containing two entries, the first entry is the list of event Ids, 
	 * which entities have been successfully deleted, the second entry are for the ones that
	 * have not been deleted.
	 */
	public Map<Outcome, List<Long>> deleteEvents(Long userId, Long groupId, List<Long> eventIds);
	
	/**
	 * Deletes all group events of a user with the group as identify by the userId and groupId
	 * @param userId		specify whose events to delete
	 * @param groupId		specify of which group, the user's group event should be delete
	 * @return the total number of rows that have been deleted
	 */
	@Deprecated
	public int deleteEvents(Long userId, Long groupId);
    
	/**
	 * Retrieves the first group event for a user of a particular group, mainly used
	 * as a check for if there's event for that user with a group
	 * @param groupId	the group identifier
	 * @param userId	the user identifier
	 * @return group events
	 */
	@Deprecated
	public List<Event> getGroupEventsForUser(Long groupId, Long userId);
    
	/**
	 * Deletes all events for a user involving top or successor groups
	 * 
	 * @param topGroupId
	 *            the top group identifier
	 * @param userId
	 *            the user identifier
	 * @return the total number of rows that have been deleted
	 */
	public int deleteTopAndSuccessorGroupEvents(Long topGroupId, Long userId);

	/**
	 * Retrieves all events for a user involving top or successor groups
	 * 
	 * @param topGroupId
	 *            the top group identifier
	 * @param userId
	 *            the user identifier
	 * @return group events
	 */
	public List<Event> getTopAndSuccessorGroupsEvents(Long topGroupId, Long userId);

}
