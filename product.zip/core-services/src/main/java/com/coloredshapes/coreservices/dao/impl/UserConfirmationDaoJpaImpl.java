/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.coloredshapes.coreservices.dao.UserConfirmationDao;
import com.coloredshapes.coreservices.domain.entity.UserConfirmation;

@Repository
public class UserConfirmationDaoJpaImpl  extends BaseJpaImpl<UserConfirmation> implements UserConfirmationDao{

	@Override
	public UserConfirmation findByRefNum(String refNum) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserConfirmation> createQuery = criteriaBuilder.createQuery(UserConfirmation.class);
		Root<UserConfirmation> from = createQuery.from(UserConfirmation.class);
		createQuery.where( entityManager.getCriteriaBuilder().equal( from.get("refNum"), refNum) );
		
		return entityManager.createQuery(createQuery).getSingleResult();
	}

}
