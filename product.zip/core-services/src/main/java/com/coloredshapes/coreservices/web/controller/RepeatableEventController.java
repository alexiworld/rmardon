/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.RepeatableEventDto;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.service.RepeatableEventService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Controller
public class RepeatableEventController extends BaseController {
	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	RepeatableEventService repeatableEventService;
	
	@RequestMapping(value = "events/byDay/users/{userId}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<Outcome, List<RepeatableEventDto>> postRepeatableEvents(
			@RequestBody RepeatableEventController.RepeatableEventsMap eventsMap,
			@PathVariable("userId") String userIdCode)
	throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Entered postRepeatableEvents method.");
			logger.debug("Received events map: " + eventsMap);
			logger.debug("Received userId: " + userIdCode);
		}

		List<RepeatableEventDto> repeatableEventList = new LinkedList<RepeatableEventDto>();
		for (Entry<String, RepeatableEventController.RepeatableEvents> entry : eventsMap.entrySet()) {
			RepeatableEventController.RepeatableEvents repeatableEvents = entry.getValue();
			for (RepeatableEventDto repeatableEventDto : repeatableEvents) {
				repeatableEventDto.setDayOfWeek(DayOfWeek.valueOf(entry.getKey()));
				repeatableEventList.add(repeatableEventDto);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Converted it to repeatable events: " + repeatableEventList);
		}

		Long userId = StandardUtils.decodeLong(userIdCode);
		Map<Outcome, List<RepeatableEventDto>> outcome = 
				repeatableEventService.createRepeatableEvents(repeatableEventList, userId);

		if (logger.isDebugEnabled()) {
			logger.debug("Outcome: " + outcome);
		}

		return outcome;
	}
	
	@RequestMapping(value = "events/byDay/users/{userId}", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public Map<DayOfWeek,List<RepeatableEventDto>> getRepeatableEvents(
			@PathVariable("userId") String userIdCode) 
	throws Exception {
		Long userId = StandardUtils.decodeLong(userIdCode);
		Map<DayOfWeek, List<RepeatableEventDto>> repeatableEventsMap = repeatableEventService.getRepeatableEvents(userId);
		return repeatableEventsMap;
	}
	
	@RequestMapping(value = "events/byDay/users/{userId}", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public void deleteRepeatableEvents(@PathVariable("userId") String userIdCode, @RequestBody String[] eventIdCodes) throws Exception {
		Long userId = StandardUtils.decodeLong(userIdCode);
		Long[] eventIds = StandardUtils.decodeLongs(eventIdCodes);
		repeatableEventService.deleteRepeatableEvent(userId, Arrays.asList(eventIds));
	}
	
	@SuppressWarnings("serial")
	public static class RepeatableEvents extends ArrayList<RepeatableEventDto>{}
    @SuppressWarnings("serial")
	public static class RepeatableEventsMap extends LinkedHashMap<String,RepeatableEvents>{}
}
