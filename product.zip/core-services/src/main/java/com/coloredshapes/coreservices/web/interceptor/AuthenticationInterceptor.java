/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.interceptor;

import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.exception.AuthenticationException;
import com.coloredshapes.coreservices.service.SecurityService;
import com.coloredshapes.coreservices.utils.StandardUtils;

@Component
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

	/**
	 * The logger for this class
	 */
	protected final Log logger = LogFactory.getLog(getClass());
	
	private final static String REQUESTOR_AUTH    = "Requestor-Authentication";
	private final static String SEPARATOR         = "\\|";
	private final static String REQUESTOR_UNKNOWN = "unknown";
	private final static String PARAM_USER_ID    = "userId";

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private UserDao userDao;

	@Resource(name = "envProperties")
	private Properties envProperties;
	
	private List<String> clickedLinks;  
	private String contextPath;
	
	private ReentrantLock lock = new ReentrantLock();

	public List<String> getGetURI() {
		if (clickedLinks == null) {
			lock.lock();
			try {
				clickedLinks = new LinkedList<String>();
				clickedLinks.add(getConfirmPath());
				clickedLinks.add(getUserConfirmPath());
				clickedLinks.add(getAcceptSFRPath());
				clickedLinks.add(getDeclineSFRPath());
				clickedLinks.add(getUserAgreementPath());
			} finally {
				lock.unlock();
			}
			if (logger.isDebugEnabled()) {
				logger.debug("getClickedLinks-> " + clickedLinks);
			}
		}
		return clickedLinks;
	}

	private boolean isPublicGetURI(HttpServletRequest request) {
		if (HttpMethod.GET.name().equals(request.getMethod())) {
			for (String clickedLink : getGetURI()) {
				if (StringUtils.equals(clickedLink, request.getRequestURI())) {
					return true;
				}
			}
		}
		if (request.getRequestURI().indexOf("/read/") >=0) return true;
		return false;
	}
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle->URI: " + request.getRequestURI());
			logger.debug("preHandle->handler: " + handler);
		}
		
		String requestor = REQUESTOR_UNKNOWN;
		if (isPublicGetURI(request)) {
			String userId = request.getParameter(PARAM_USER_ID);
			
			if (logger.isDebugEnabled()) {
				logger.debug("preHandle->userId: " + userId);
			}
			
			if (StringUtils.isNotEmpty(userId)) {
				requestor = userId;
			}
		} else {
			// Some operations such as registering a user or an group are assumed
			// safe because of the lack of context. This might need a revisit to 
			// ensure malicious users will not create groups and deceive users of
			// the system.
			boolean safe = false;
	
			// TODO: web app context can be set up to a different value than 'core-service' 
			// during deployment. Therefore, it would be better to replace 'equals' op with 
			// 'endsWith' op e.g. request.getRequestURI().endsWith("/group")
			
			String URI = request.getRequestURI();
			if (URI.equals(getGroupPath()) &&
				HttpMethod.POST.name().equals(request.getMethod())) {
				safe = true;
			}
	
			if (URI.equals(getUsersPath()) &&
				HttpMethod.POST.name().equals(request.getMethod())) {
				safe = true;
			}
			
			if (URI.equals(getUsersAuthenticationPath()) &&
				HttpMethod.PUT.name().equals(request.getMethod())) {
				safe = true;
			}
	
			String requestorAuthentication = request.getHeader(REQUESTOR_AUTH);
			requestor = "" + authenticate(requestorAuthentication, safe); 
		}


		StandardUtils.setUser(requestor);
		
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle->Authentication succeeded");
			logger.debug("preHandle->requestor: " + requestor);
		}

		return true;
	}

	/**
	 * Serves to authenticate the requestor and to return it.
	 * 
	 * @param requestorAuthentication	combination of requestor and token
	 * @return	the requestor
	 */
	private Long authenticate(String requestorAuthentication, boolean safe) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("authenticate->header: " + requestorAuthentication);
		}
		
		try {
			if (StringUtils.isNotEmpty(requestorAuthentication)) {
				String[] parts = requestorAuthentication.split(SEPARATOR); 
				if (parts.length == 2){
					if (safe && ("null".equals(parts[0]) || "null".equals(parts[1]))) {
						return null;
					}
					if (parts[0].indexOf('@') >= 0) {
						String email    = parts[0];
						String password = parts[1];
						if (!safe) { 
							return securityService.authenticate(email, password); 
						} else {
							return userDao.getUser(email).getId();
						}
					} else {
						String userIdCode = parts[0];
						Long userId = StandardUtils.decodeLong(userIdCode);
						String password   = parts[1];
						if (!safe) { 
							securityService.authenticate(userId, password); 
						}
						return userId;
					}
				} else {
					throw new AuthenticationException();
				}
			} else {
				throw new AuthenticationException();
			}
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error("Failed to authenticate: " + requestorAuthentication + " due to " + e);
			}
			throw new AuthenticationException();
		}
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("postHandle->handler: " + handler);
			logger.debug("postHandle->modelAndView: " + modelAndView);
		}
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		logger.debug("afterCompletion->handler: " + handler);
		logger.debug("afterCompletion->ex: " + ex);
		super.afterCompletion(request, response, handler, ex);
	}

	private String getGroupPath() {
		return getContextPath()
				+ envProperties.getProperty("groupPath");
	}
	
	private String getUsersPath() {
		return getContextPath()
				+ envProperties.getProperty("usersPath");
	}
	
	private String getUsersAuthenticationPath() {
		return getContextPath()
				+ envProperties.getProperty("usersAuthenticationPath");
	}

	private String getConfirmPath() {
		return getContextPath()
				+ envProperties.getProperty("membershipAcceptancePath");
	}

	private String getUserConfirmPath() {
		return getContextPath()
				+ envProperties.getProperty("userConfirmationPath");
	}

	private String getAcceptSFRPath() {
		return getContextPath()  
				+ envProperties.getProperty("acceptTakeOverRequestPath"); 
	}

	private String getDeclineSFRPath() {
		return getContextPath()  
				+ envProperties.getProperty("declineTakeOverRequestPath"); 
	}
	
	private String getUserAgreementPath() {
		return getContextPath()  
				+ envProperties.getProperty("userAgreementPath"); 
	}

	private String getContextPath() {
		if (contextPath == null) {
			contextPath = "/" + envProperties.getProperty("contextName") + "/";
		}

		return contextPath;
	}
	
}