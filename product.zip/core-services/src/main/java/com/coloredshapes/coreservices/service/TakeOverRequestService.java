/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service;

import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;
import com.coloredshapes.coreservices.domain.enums.TakeOverAcceptanceResult;
import com.coloredshapes.coreservices.domain.enums.TakeOverDeclinationResult;

/**
 * service interface for sending takeOverRequest
 *
 */
public interface TakeOverRequestService {
	void sendTakeOverRequest(TakeOverRequest tor);

	TakeOverAcceptanceResult acceptTakeOverRequest(Long torId, Long userId);
	
	TakeOverDeclinationResult declineTakeOverRequest(Long torId, Long userId);

	void cancelTakeOverRequest(Long torId);
}
