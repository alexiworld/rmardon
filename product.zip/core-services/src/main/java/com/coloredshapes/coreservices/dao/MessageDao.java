/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import com.coloredshapes.coreservices.domain.entity.Message;

public interface MessageDao extends GenericDao<Message> {

	public void saveMessage(Message message);
	
	public List<Message> getMessages(Long userId);

	public List<Message> getMessagesBetween(Long user1Id, Long user2Id);

	public int deleteMessage(Long userId, List<Long> messageIds);

	public int deleteMessages(Long userId, List<Long> messageIds);

	public int deleteMessages(Long userId);

}
