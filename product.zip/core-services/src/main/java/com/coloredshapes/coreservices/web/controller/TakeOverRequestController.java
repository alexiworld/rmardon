/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.web.controller;

import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.coloredshapes.coreservices.domain.dto.TakeOverRequestStatusDto;
import com.coloredshapes.coreservices.domain.entity.TakeOverRequest;
import com.coloredshapes.coreservices.domain.enums.TakeOverAcceptanceResult;
import com.coloredshapes.coreservices.domain.enums.TakeOverDeclinationResult;
import com.coloredshapes.coreservices.service.TakeOverRequestService;
import com.coloredshapes.coreservices.utils.StandardUtils;

/**
 * <code>TakeOverRequestController</code> handles take over requests.
 */
@Controller
public class TakeOverRequestController extends BaseController {

	public static final Logger logger = LoggerFactory.getLogger(TakeOverRequestController.class);
	
	@Autowired
	private TakeOverRequestService takeOverRequestService;
	
	@Resource(name = "errProperties")
	private Properties errProperties;

	@RequestMapping(value = "/tor/{torId}", method = RequestMethod.GET)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.OK)
	public TakeOverRequest getTOR(@PathVariable("torId") String torIdCode) throws Exception {
		Long torId = StandardUtils.decodeLong(torIdCode);
		TakeOverRequest tor = new TakeOverRequest();
		tor.setId(torId); //TODO: invoke the service
		return tor;
	}

	@RequestMapping(value = "/tor", method = RequestMethod.POST)
	@ResponseBody
	public void postTOR(@RequestBody TakeOverRequest tor) throws Exception {
		takeOverRequestService.sendTakeOverRequest(tor);
	}
	
	@RequestMapping(value = "/tor", method = RequestMethod.PUT)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.OK)
	public void putTOR(@RequestBody TakeOverRequestStatusDto torStatus) throws Exception {
		Long torId = torStatus.getTorId();
		takeOverRequestService.cancelTakeOverRequest(torId);
	}
	
	@RequestMapping(value = "/acceptTOR", method = RequestMethod.GET)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.OK)
	public String acceptTOR(@RequestParam String refNum, @RequestParam("userId") String userIdCode) throws Exception {
		Long torId = StandardUtils.decodeLong(refNum);
		Long userId = StandardUtils.decodeLong(userIdCode);
		TakeOverAcceptanceResult result = takeOverRequestService.acceptTakeOverRequest(torId, userId);
		return errProperties.getProperty("tor." + result.value());
	}
	
	@RequestMapping(value = "/declineTOR", method = RequestMethod.GET)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.OK)
	public String declineTOR(@RequestParam String refNum, @RequestParam("userId") String userIdCode) throws Exception {
		Long torId = StandardUtils.decodeLong(refNum);
		Long userId = StandardUtils.decodeLong(userIdCode);
		TakeOverDeclinationResult result = takeOverRequestService.declineTakeOverRequest(torId, userId);
		return errProperties.getProperty("tor.decline." + result.value());
	}

}