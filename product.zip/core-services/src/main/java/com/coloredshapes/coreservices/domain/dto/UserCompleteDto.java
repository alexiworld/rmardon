/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.dto;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

public class UserCompleteDto extends UserProfileDto {

	private Integer agreementVersion;

	private Boolean mustAcceptAgreement;
	
	private Boolean containsAllAssignments;
	
	private List<AssignmentDto> assignments;

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Integer getAgreementVersion() {
		return agreementVersion;
	}

	public void setAgreementVersion(Integer agreementVersion) {
		this.agreementVersion = agreementVersion;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Boolean getMustAcceptAgreement() {
		return mustAcceptAgreement;
	}

	public void setMustAcceptAgreement(Boolean mustAcceptAgreement) {
		this.mustAcceptAgreement = mustAcceptAgreement;
	}

	
	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public Boolean getContainsAllAssignments() {
		return containsAllAssignments;
	}

	public void setContainsAllAssignments(Boolean containsAllAssignments) {
		this.containsAllAssignments = containsAllAssignments;
	}

	@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
	public List<AssignmentDto> getAssignments() {
		return assignments;
	}

	public void setAssignments(List<AssignmentDto> assignments) {
		this.assignments = assignments;
	}

	/** 
     * Returns a string representation of this object.
     * 
     * @return the string representation
     */
    @Override
    public String toString(){
        return new ToStringBuilder(this)
            .append("agreementVersion", agreementVersion)   
            .append("mustAcceptAgreement", mustAcceptAgreement)
            .append("containsAllAssignments", containsAllAssignments)
            .append("assignments", assignments)
            .toString();
    }	
    
}