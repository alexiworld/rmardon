/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import com.coloredshapes.coreservices.domain.entity.Image;

public interface ImageDao extends GenericDao<Image> {
	
	public Image getImage(String file);
	
}
