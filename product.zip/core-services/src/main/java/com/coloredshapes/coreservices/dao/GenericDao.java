/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;
import java.util.Map;

public interface GenericDao<T> {

	long countAll(Map<String, Object> params);

	T create(T t);

	void delete(Object id);

	T find(Object id);

	T findOneBy(String param, Object value);

	T findOneBy(Map<String, Object> params);

	List<T> findManyBy(String param, Object value);

	List<T> findManyBy(Map<String, Object> params);

	T update(T t);

}
