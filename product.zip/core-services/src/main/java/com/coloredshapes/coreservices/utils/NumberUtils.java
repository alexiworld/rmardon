/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.utils;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;

public class NumberUtils {
	
	public static List<Long> fromBigIntListToLongList(List<BigInteger> bigInts) {
		List<Long> longList = new LinkedList<Long>();
		for (BigInteger bignit : bigInts) {
			longList.add(bignit.longValue());
		}
		return longList;
	}

}
