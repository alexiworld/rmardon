/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.coloredshapes.coreservices.domain.enums.TakeOverStatus;
import com.coloredshapes.coreservices.domain.jsonhelper.IdDeserializer;
import com.coloredshapes.coreservices.domain.jsonhelper.IdSerializer;

/**
 * class for capturing the data for a take over request (TOR).
 */
@Entity
@Table(name = "take_over_request")
public class TakeOverRequest extends BaseEntity {

	/**
	 * group for which the TOR is from
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "group_id", insertable = false, updatable = false)
	private Group group;

	/**
	 * group for which the TOR is for
	 */
	@Column(name = "group_id")
	private Long groupId;

	/**
	 * note of the TOR
	 */
	@Column(name = "note")
	private String note;

	/**
	 * user who took over event
	 */
	@ManyToOne
	@JoinColumn(name = "taken_by_user")
	private User acceptedByUser;

	/**
	 * time of accepting TOR
	 */
	@Column(name = "accepted_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime acceptanceTime;

	/**
	 * status of the TOR
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private TakeOverStatus status;

	/**
	 * individual take over events included in the TOR 
	 */
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "take_over_request_id", referencedColumnName = "id")
	private List<TakeOverEvent> takeOverEvents;
	
	@JsonIgnore
	public Group getGroup() {
		return group;
	}

	@JsonIgnore
	public void setGroup(Group group) {
		this.group = group;
	}

	@JsonSerialize(using = IdSerializer.class, include=JsonSerialize.Inclusion.NON_NULL)
	public Long getGroupId() {
		return groupId;
	}

	@JsonDeserialize(using = IdDeserializer.class)
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@JsonIgnore
	public User getAcceptedByUser() {
		return acceptedByUser;
	}

	@JsonIgnore
	public void setAcceptedByUser(User takenByUser) {
		this.acceptedByUser = takenByUser;
	}

	@JsonIgnore
	public DateTime getAcceptanceTime() {
		return acceptanceTime;
	}

	@JsonIgnore
	public void setAcceptanceTime(DateTime acceptedTime) {
		this.acceptanceTime = acceptedTime;
	}

	public TakeOverStatus getStatus() {
		return status;
	}

	public void setStatus(TakeOverStatus status) {
		this.status = status;
	}

	public List<TakeOverEvent> getTakeOverEvents() {
		return takeOverEvents;
	}

	public void setTakeOverEvents(List<TakeOverEvent> sfrShift) {
		this.takeOverEvents = sfrShift;
	}

	/**
	 * Returns a textual representation of this object.
	 * 
	 * @return the textual representation
	 */
	@Override
	public String toString() {
        return new ToStringBuilder(this)
        	.append("acceptedByUser", acceptedByUser) 
        	.append("acceptanceTime", acceptanceTime)
            .append("groupId", groupId) 
            .append("note", note)
            .toString();
	}

}