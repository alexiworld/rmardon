/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.dao.impl.GroupDaoJpaImpl;
import com.coloredshapes.coreservices.dao.impl.UserDaoJpaImpl;
import com.coloredshapes.coreservices.domain.dto.UserBasicDto;
import com.coloredshapes.coreservices.domain.dto.UserCompleteDto;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.ContentLimit;
import com.coloredshapes.coreservices.domain.enums.ContentStatus;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.enums.UserStatus;
import com.coloredshapes.coreservices.exception.ExistingUserException;
import com.coloredshapes.coreservices.exception.InvalidUserException;

public class UserServiceImplTest {

	@Test
	public void testCreateNewUserProfileSuccessful()
	throws NoSuchAlgorithmException, ExistingUserException {
		// set up mock dependency
		UserDao userDao = mock(UserDaoJpaImpl.class);
		when(userDao.getUser(1L)).thenReturn(null);
		UserServiceImpl userService = new UserServiceImpl();

		ReflectionTestUtils.setField(userService, "userDao", userDao);
		UserCompleteDto user = new UserCompleteDto();
		user.setPassword("12345");
		user.setId(1L);
		userService.createUser(user);

		verify(userDao).getUser(1L);
		// TODO: Find means to verify data coming to the DAO
		//verify(userDao).createUser(user);
	}

	@Test(expected = ExistingUserException.class)
	public void testCreateNewUserDuplidateUserException()
	throws NoSuchAlgorithmException, ExistingUserException {
		// set up mock dependency
		UserDao memebrDao = mock(UserDaoJpaImpl.class);
		when(memebrDao.getUser(1L)).thenReturn(new User());
		UserServiceImpl userService = new UserServiceImpl();

		ReflectionTestUtils.setField(userService, "userDao", memebrDao);
		UserCompleteDto user = new UserCompleteDto();
		user.setPassword("12345");
		user.setId(1L);
		userService.createUser(user);

		verify(memebrDao).getUser(1L);

	}

	@Test
	public void testGetMemberByKey() 
	throws NoSuchAlgorithmException, ExistingUserException {
		// set up mock dependency
		UserDao memebrDao = mock(UserDaoJpaImpl.class);
		User mockUser = new User();
		mockUser.setId(1L);
		mockUser.setFirstName("testing");
		when(memebrDao.getUser(1L)).thenReturn(mockUser);
		UserServiceImpl userService = new UserServiceImpl();

		ReflectionTestUtils.setField(userService, "userDao", memebrDao);

		UserBasicDto user = userService.getUser(1L, ContentLimit.COMPLETE, ContentStatus.ACTIVE, null);

		verify(memebrDao).getUser(1L);
		Assert.assertEquals("testing", user.getFirstName());
	}
	
	@Test
	public void testUpdateUser() throws NoSuchAlgorithmException,
	InvalidUserException, IOException {
		// set up mock dependency
		UserDao memebrDao = mock(UserDaoJpaImpl.class);
		User mockUser = buildUser(1L);
		when(memebrDao.getUser(1L)).thenReturn(mockUser);
		when(memebrDao.update(mockUser)).thenReturn(mockUser);
		UserServiceImpl userService = new UserServiceImpl();

		ReflectionTestUtils.setField(userService, "userDao", memebrDao);
        
		UserCompleteDto updatedUser = new UserCompleteDto();
		updatedUser.setAddress("updatedadd");
		updatedUser.setCity("updatedCity");
		updatedUser.setEmail("updatedemail@gmai.com");
		updatedUser.setFirstName("updatedFirstName");
		updatedUser.setId(1L);
		updatedUser.setPhoneNumber("00000000");
		updatedUser.setPostalCode("V3R S2W");
		updatedUser.setRegion("ON");
		updatedUser.setLastName("updatedSurname");
		
		userService.updateUser(updatedUser);

		verify(memebrDao).getUser(1L);
		verify(memebrDao).update(mockUser);
		//Assert.assertEquals("updatedadd", updatedUser.getAddress());
		//Assert.assertEquals("updatedCity", updatedUser.getCity());
		//Assert.assertEquals("updatedemail@gmai.com", updatedUser.getEmail());
		//Assert.assertEquals("updatedFirstName", updatedUser.getFirstName());
		//Assert.assertEquals("peter", updatedUser.getId());
		//Assert.assertEquals("00000000", updatedUser.getPhoneNumber());
		//Assert.assertEquals("V3R S2W", updatedUser.getPostalCode());
		//Assert.assertEquals("ON", updatedUser.getRegion());
		//Assert.assertEquals("updatedSurname", updatedUser.getLastName());
	}
	
	@Test(expected = InvalidUserException.class)
	public void testUpdateMemberWithoutFindingOldMember() throws NoSuchAlgorithmException,
	InvalidUserException, IOException {
		// set up mock dependency
		UserDao userDao = mock(UserDaoJpaImpl.class);
		User oldUser = buildUser(1L);
		when(userDao.getUser(1L)).thenReturn(null);
		when(userDao.update(oldUser)).thenReturn(oldUser);
		UserServiceImpl userService = new UserServiceImpl();

		ReflectionTestUtils.setField(userService, "userDao", userDao);
        
		UserCompleteDto updatedUser = new UserCompleteDto();
		updatedUser.setAddress("updatedadd");
		updatedUser.setCity("updatedCity");
		updatedUser.setEmail("updatedemail@gmai.com");
		updatedUser.setFirstName("updatedFirstName");
		updatedUser.setId(1L);
		updatedUser.setPhoneNumber("00000000");
		updatedUser.setPostalCode("V3R S2W");
		updatedUser.setRegion("ON");
		updatedUser.setLastName("updatedSurname");
		
		userService.updateUser(updatedUser);

		//verify(userDao).getUser(1L);
		//verify(userDao, never()).update(oldUser);
		//Assert.assertEquals("updatedadd", updatedUser.getAddress());
		//Assert.assertEquals("updatedCity", updatedUser.getCity());
		//Assert.assertEquals("updatedemail@gmai.com", updatedUser.getEmail());
		//Assert.assertEquals("updatedFirstName", updatedUser.getFirstName());
		//Assert.assertEquals("peter", updatedUser.getId());
		//Assert.assertEquals("00000000", updatedUser.getPhoneNumber());
		//Assert.assertEquals("V3R S2W", updatedUser.getPostalCode());
		//Assert.assertEquals("ON", updatedUser.getRegion());
		//Assert.assertEquals("updatedSurname", updatedUser.getLastName());
	}

	/**
	 * Test retrieval of group's active users.
	 */
	@Test
	public void testGetActiveUserKeysForUnit() {
		// prepare the group
		Group group = buildGroup();
		
		// set up mock dependency
		GroupDao groupDao = mock(GroupDaoJpaImpl.class);
		when(groupDao.getGroup(group.getId())).thenReturn(group);
		
		UserServiceImpl userService = new UserServiceImpl();
		ReflectionTestUtils.setField(userService, "groupDao", groupDao);

		List<Long> activeUserIds = userService.getGroupUserIds(group.getId(), ContentStatus.ACTIVE);
		List<Long> expectedUserIds = Arrays.asList(new Long[] { 1L, 5L });
		
		verify(groupDao).getGroup(group.getId());
		Assert.assertEquals("Incorrect active users returned", expectedUserIds, activeUserIds);
	}

	/**
	 * Gets the test group.
	 * 
	 * @param isFirst	true if this is for the first test group, false for the second test group
	 * @return	the test group
	 */
	private static Group buildGroup() {
		Group testGroup = new Group();
		testGroup.setVersion(0);
		testGroup.setId(1L);
		testGroup.setName("Brown House");
		testGroup.setAddress("Group Address");
		testGroup.setCity("Vancouver");
		testGroup.setRegion("BC");
		testGroup.setPostalCode("A2B 4M2");
		testGroup.setEmail("info@testGroup.com");
		testGroup.setPhoneNumber("604-1234-567");
		
		List<Membership> memberships = new LinkedList<Membership>();
		memberships.add(buildEmployment(testGroup, 1L, MembershipStatus.ACTIVE));
		memberships.add(buildEmployment(testGroup, 2L, MembershipStatus.CLOSED));
		memberships.add(buildEmployment(testGroup, 3L, MembershipStatus.INACTIVE));
		memberships.add(buildEmployment(testGroup, 4L, MembershipStatus.PENDING));
		memberships.add(buildEmployment(testGroup, 5L, MembershipStatus.ACTIVE));

		testGroup.setMemberships(memberships);
		return testGroup;
	}
	
	/**
	 * Builds an membership relationship.
	 * 
	 * @param group				the group
	 * @param userId			the user id
	 * @param membershipStatus	the desired membership status
	 * @return	the membership relationship
	 */
	private static Membership buildEmployment(Group group, Long userId, MembershipStatus membershipStatus) {
		Membership membership = new Membership();
		membership.setGroup(group);
		membership.setUser(buildUser(userId));
		membership.setMembershipStatus(membershipStatus);
		return membership;
	}
	
	/**
	 * Gets the test user.
	 * 
	 * @param isFirst	true if this is for the first test user, false for the second test user
	 * @return	the test user 
	 */
	private static User buildUser(Long userId) {
		User testUser = new User();
		testUser.setVersion(0);
		testUser.setId(userId);
		testUser.setFirstName("Test");
		testUser.setLastName("The Great");
		testUser.setAddress("X Address");
		testUser.setCity("Vancouver");
		testUser.setRegion("BC");
		testUser.setPostalCode("A2B 4M2");
		testUser.setEmail("runner@thegreat.com");
		testUser.setPhoneNumber("778-1234-567");
		testUser.setPassword("password");
		testUser.setHashedPassword("password");
		testUser.setSalt("123ABCXYZ890");
		testUser.setStatus(UserStatus.ACTIVE);
		return testUser;
	}


}
