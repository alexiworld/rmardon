/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.service.QueueService;
import com.coloredshapes.coreservices.service.impl.QueueServiceImpl;

/**
 * <code>MessageServiceImplTest</code> class is used for group testing 
 * of <code>QueueServiceImpl</code>.
 * 
 * To run this junit with gradle use the following command:
 * cd $PROJ_PATH/core
 * gradle -Dtest.single=** /* /MessageServiceImplTest* test
 * There must be no spaces between * and / in the command
 */
@RunWith(MockitoJUnitRunner.class)
public class MessageServiceImplTest {
	
	@Mock private AmqpTemplate amqpTemplate;

	private final static Long TEST_GROUP_ID = 1L;

	/**
	 * Tests sendAssignmentsEmail service operation.
	 */
	@Test
	public void testSendAssignmentsEmail() {
		// Prepare the input
		final DateEventsPatchDto dateEventsPatch = new DateEventsPatchDto();
		dateEventsPatch.setGroupId(TEST_GROUP_ID);
		final String exchange   = "ColoredShapes.Exchange";
		final String routingKey = "Services";
		
		// Initialize the mocks & their behavior
		reset(amqpTemplate);
		doNothing().when(amqpTemplate).convertAndSend(eq(exchange), eq(routingKey), eq(dateEventsPatch));
		 
		// Prepare the service
		QueueService queueService = new QueueServiceImpl();
		ReflectionTestUtils.setField(queueService, "amqpTemplate", amqpTemplate);
		ReflectionTestUtils.setField(queueService, "exchange", exchange);
		ReflectionTestUtils.setField(queueService, "routingKey", routingKey);


		// Invoke the service operation
		queueService.enqueueDateEventsPatch(dateEventsPatch);
		
		// Verify the mock invoking sequence
		verify(amqpTemplate).convertAndSend(exchange, routingKey, dateEventsPatch);
	}

}