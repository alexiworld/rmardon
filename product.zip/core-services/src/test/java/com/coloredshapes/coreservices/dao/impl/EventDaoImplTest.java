/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao.impl;

import static com.coloredshapes.coreservices.utils.RandomUtils.getRandomNum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;

/**
 * <code>EventDaoImplTest</code> class is used for group testing 
 * of <code>TimeBlockDaoTest</code>.
 * 
 * To run this junit with gradle use the following command:
 * cd $PROJ_PATH/core
 * gradle -Dtest.single=** /* /EventDaoImplTest* test
 * There must be no spaces between * and / in the command
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:servlet-context.xml" })
@Transactional
public class EventDaoImplTest {
	
	@Autowired
	private EventDao eventDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private GroupDao groupDao;
	
	private final static Long TEST_USER_ID  = 1L;
	private final static Long TEST_GROUP_ID = 1L;
	private static User TEST_USER = null;
	private static Group TEST_GROUP = null;

	private final static SourceType[] USER_EVENTS_ONLY = new SourceType[] { SourceType.USER };
	private final static SourceType[] GROUP_EVENTS_ONLY = new SourceType[] { SourceType.GROUP };
	private final static SourceType[] ALL_EVENTS = new SourceType[] { SourceType.USER, SourceType.GROUP };
	
	private final static DateTime TEST_START_TIME = new DateTime(2010, 06, 15,  0,  0,  0);
	private final static DateTime TEST_END_TIME   = new DateTime(2010, 06, 15, 23, 59, 59);
	private final static DateTime TEST_USER_TIME_BLOCK_START_TIME = new DateTime(2010, 06, 15, 14, 0, 0);
	private final static DateTime TEST_USER_TIME_BLOCK_END_TIME   = new DateTime(2010, 06, 15, 16, 0, 0);
	private final static DateTime TEST_GROUP_TIME_BLOCK_START_TIME   = new DateTime(2010, 06, 15, 18, 0, 0);
	private final static DateTime TEST_GROUP_TIME_BLOCK_END_TIME     = new DateTime(2010, 06, 15, 20, 0, 0);

	/**
	 * Test the autowired TimeBlockDAO implementation
	 */
	@Test
	public void testDao() {
		// Test to ensure there are no left over from previous runs
		Assert.assertEquals(0, getEvents(USER_EVENTS_ONLY).size());
		Assert.assertEquals(0, getEvents(GROUP_EVENTS_ONLY).size());
		Assert.assertEquals(0, getEvents(ALL_EVENTS).size());
		Assert.assertEquals(0, getEvents().size());
		
		// Create user and group events
		createEvents();
		
		// Test to ensure events are properly created
		List<Event> userEvents  = getEvents(USER_EVENTS_ONLY);
		List<Event> groupEvents = getEvents(GROUP_EVENTS_ONLY);
		List<Event> allEvents   = getEvents(ALL_EVENTS);
		List<Event> allEventsQueriedByGroup = getEvents();

		Assert.assertEquals(1, userEvents.size());
		Assert.assertEquals(1, groupEvents.size());
		Assert.assertEquals(2, allEvents.size());
		Assert.assertEquals(2, allEventsQueriedByGroup.size());

		// Deletes the events
		Long userEventId = userEvents.get(0).getId();
		Long groupEventId = groupEvents.get(0).getId();
		
		Map<Outcome, List<Long>> outcomes = deleteEvents(userEventId, null);
		List<Long> timeBlocksDeleted    = outcomes.get(Outcome.SUCCESS);
		List<Long> timeBlocksNotDeleted = outcomes.get(Outcome.FAILURE);
		Assert.assertEquals(1, timeBlocksDeleted.size());
		Assert.assertEquals(0, timeBlocksNotDeleted.size());

		outcomes = deleteEvents(null, groupEventId);
		timeBlocksDeleted    = outcomes.get(Outcome.SUCCESS);
		timeBlocksNotDeleted = outcomes.get(Outcome.FAILURE);
		Assert.assertEquals(1, timeBlocksDeleted.size());
		Assert.assertEquals(0, timeBlocksNotDeleted.size());
		
		// Test to ensure all test events are properly deleted 
		Assert.assertEquals(0, getEvents(USER_EVENTS_ONLY).size());
		Assert.assertEquals(0, getEvents(GROUP_EVENTS_ONLY).size());
		Assert.assertEquals(0, getEvents(ALL_EVENTS).size());
		Assert.assertEquals(0, getEvents().size());
	}

	/**
	 * Test the autowired TimeBlockDAO implementation
	 */
	@Test
	public void testAddingOfConflictingEvents() {
		List<Event> eventsToBeCreated = buildEvents(true);
		Map<Outcome, List<Event>> outcomes = eventDao.createEvents(eventsToBeCreated);
		List<Event> eventsCreated    = outcomes.get(Outcome.SUCCESS);
		List<Event> eventsNotCreated = outcomes.get(Outcome.FAILURE);
		Assert.assertNotNull(eventsCreated);
		Assert.assertEquals(1, eventsCreated.size());
		Assert.assertNotNull(eventsNotCreated);
		Assert.assertEquals(1, eventsNotCreated.size());
		
		// Clean up the garbage
		for (Event event : eventsToBeCreated) {
			if (SourceType.USER.equals(event.getSourceType())) {
				deleteEvents(event.getId(), null);
			} else {
				deleteEvents(null, event.getId());
			}
		}
	}
	
	/**
	 * Gets events on behalf of the test user.
	 * 
	 * @param sourceTypes	the block types to be returned
	 * @return	the events
	 */
	public List<Event> getEvents(SourceType[] sourceTypes) {
		List<Event> events = eventDao.getEventsByUserId(
			TEST_START_TIME, TEST_END_TIME, TEST_USER_ID,  
			sourceTypes, new Long[] { TEST_GROUP_ID });
		return events;
	}

	/**
	 * Gets events on behalf of the test group manager.
	 * 
	 * @return	the events
	 */
	public List<Event> getEvents() {
		List<Event> events = eventDao.getEventsByUserIds(
			TEST_START_TIME, TEST_END_TIME,  
			new Long[] { TEST_USER_ID });
		return events;
	}
	
	/**
	 * Deletes a user or scheduled by an group event.
	 * 
	 * @param userTimeBlockKey	the key of user event
	 * @param groupTimeBlockKey		the key of group event
	 * @return	the event not being deleted properly
	 */
	public Map<Outcome, List<Long>> deleteEvents(Long userTimeBlockKey, Long groupTimeBlockKey) {
		if (userTimeBlockKey != null) {
			Map<Outcome, List<Long>> outcomes = eventDao.deleteEvents(
				TEST_USER_ID, null, 
				Arrays.asList(new Long[] {userTimeBlockKey}));
			return outcomes;
		}
		if (groupTimeBlockKey != null) {
			Map<Outcome, List<Long>> outcomes = eventDao.deleteEvents(
				null, TEST_GROUP_ID, 
				Arrays.asList(new Long[] {groupTimeBlockKey}));
			return outcomes;
		}
		return null;
	}

	/**
	 * Creates two events - one user, and one group for the purpose of this test.
	 */
	public void createEvents() {
		List<Event> eventsToBeCreated = buildEvents(false);
		Map<Outcome, List<Event>> outcomes = eventDao.createEvents(eventsToBeCreated);
		List<Event> eventsCreated    = outcomes.get(Outcome.SUCCESS);
		List<Event> eventsNotCreated = outcomes.get(Outcome.FAILURE);
		Assert.assertNotNull(eventsCreated);
		Assert.assertEquals(2, eventsCreated.size());
		Assert.assertNotNull(eventsNotCreated);
		Assert.assertEquals(0, eventsNotCreated.size());
	}

	/**
	 * Build two events - one user, and one group for the purpose of this test.
	 */
	public List<Event> buildEvents(boolean conflicting) {
		List<Event> events = new ArrayList<Event>(2);
		
		DateTime groupTimeBlockStartTime = conflicting ? TEST_USER_TIME_BLOCK_START_TIME : TEST_GROUP_TIME_BLOCK_START_TIME;
		DateTime groupTimeBlockEndTime   = conflicting ? TEST_USER_TIME_BLOCK_END_TIME   : TEST_GROUP_TIME_BLOCK_END_TIME;
	
		Event event = new Event();
		event.setId(getRandomNum());
		event.setStartTime(TEST_USER_TIME_BLOCK_START_TIME);
		event.setEndTime(TEST_USER_TIME_BLOCK_END_TIME);
		event.setNote("test user event");
		event.setSourceType(SourceType.USER);
		event.setUser(TEST_USER);
		event.setGroup(null);
		events.add(event);
		
		event = new Event();
		event.setId(getRandomNum());
		event.setStartTime(groupTimeBlockStartTime);
		event.setEndTime(groupTimeBlockEndTime);
		event.setNote("test group event");
		event.setSourceType(SourceType.GROUP);
		event.setUser(TEST_USER);
		event.setGroup(TEST_GROUP);
		events.add(event);

		return events;
	}

	/**
	 * Sets up data required for the execution of the test.
	 */
	@Before
	public void setUp() {
		try {
			TEST_USER = userDao.getUser(TEST_USER_ID);
		} catch (Exception e) {
		}

		if (TEST_USER == null) {
			TEST_USER = new User();
			TEST_USER.setVersion(0);
			TEST_USER.setId(TEST_USER_ID);
			TEST_USER.setFirstName("Test");
			TEST_USER.setLastName("The Great");
			TEST_USER.setAddress("X Address");
			TEST_USER.setCity("Vancouver");
			TEST_USER.setRegion("BC");
			TEST_USER.setPostalCode("A2B 4M2");
			TEST_USER.setEmail("runner@thegreat.com");
			TEST_USER.setPhoneNumber("778-1234-567");
			TEST_USER.setPassword("password");
			TEST_USER.setHashedPassword("password");
			TEST_USER.setSalt("123ABCXYZ890");
			TEST_USER.setDateTimeZone(DateTimeZone.forID("America/Los_Angeles"));
			userDao.createUser(TEST_USER);
		}

		try {
			TEST_GROUP = groupDao.getGroup(TEST_GROUP_ID);
		} catch (Exception e) {
		}
		
		if (TEST_GROUP == null) {
			TEST_GROUP = new Group();
			TEST_GROUP.setVersion(0);
			TEST_GROUP.setId(TEST_GROUP_ID);
			TEST_GROUP.setName("Test Group");
			TEST_GROUP.setAddress("Group Address");
			TEST_GROUP.setCity("Vancouver");
			TEST_GROUP.setRegion("BC");
			TEST_GROUP.setPostalCode("A2B 4M2");
			TEST_GROUP.setEmail("info@TEST_GROUP.com");
			TEST_GROUP.setPhoneNumber("604-1234-567");
			groupDao.createGroup(TEST_GROUP);
		}
	}

}