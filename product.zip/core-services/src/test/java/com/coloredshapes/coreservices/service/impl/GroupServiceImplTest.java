/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Mockito.mock;

import java.security.NoSuchAlgorithmException;

import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.impl.GroupDaoJpaImpl;
import com.coloredshapes.coreservices.domain.dto.GroupCompleteDto;
import com.coloredshapes.coreservices.exception.InvalidGroupException;
import com.coloredshapes.coreservices.service.GroupService;

public class GroupServiceImplTest {
	@Test
	public void testCreateGroup() throws InvalidGroupException, NoSuchAlgorithmException {
		// set up mock dependency
		GroupDao groupDao = mock(GroupDaoJpaImpl.class);
		GroupCompleteDto groupDto = new GroupCompleteDto();

		GroupService groupService = new GroupServiceImpl();

		ReflectionTestUtils.setField(groupService, "groupDao", groupDao);

		groupService.createGroup(groupDto);

		//verify(groupDao).createGroup(groupDto);
	}
}
