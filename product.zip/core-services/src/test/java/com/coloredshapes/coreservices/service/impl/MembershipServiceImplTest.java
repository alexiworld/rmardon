/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.dao.impl.UserDaoJpaImpl;
import com.coloredshapes.coreservices.domain.dto.MembershipDto;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.exception.InvalidUserException;

public class MembershipServiceImplTest {

	@Test
	public void testGetEmploymentForMemberSuccessful()
	throws InvalidUserException {
		MembershipServiceImpl employmentService = new MembershipServiceImpl();
		UserDao userDaoMock = mock(UserDaoJpaImpl.class);
		final Long userId = 1L;
		User user = new User();
		user.setId(userId);

		Membership emp1 = new Membership();
		emp1.setMembershipStatus(MembershipStatus.ACTIVE);
		Membership emp2 = new Membership();
		Membership emp3 = new Membership();

		List<Membership> EmploymentList = new LinkedList<Membership>();
		EmploymentList.add(emp1);
		EmploymentList.add(emp2);
		EmploymentList.add(emp3);
		user.setMemberships(EmploymentList);
		when(userDaoMock.getUser(userId)).thenReturn(user);

		ReflectionTestUtils.setField(employmentService, "userDao", userDaoMock);

		List<MembershipDto> memberships = employmentService.getUserMemberships(userId);
		verify(userDaoMock).getUser(userId);

		Assert.assertEquals(3, memberships.size());
		Assert.assertEquals(MembershipStatus.ACTIVE, memberships.get(0)
				.getMembershipStatus());
	}

	@Test
	public void testUpdateEmploymentForMemberSuccessful()
	throws InvalidUserException {
		MembershipServiceImpl membershipService = new MembershipServiceImpl();
		UserDao userDaoMock = mock(UserDaoJpaImpl.class);
		final Long userId = 1L;
		User user = new User();
		user.setId(userId);

		Membership membership1 = new Membership();
		membership1.setMembershipStatus(MembershipStatus.ACTIVE);
		Membership membership2 = new Membership();
		membership2.setMembershipStatus(MembershipStatus.ACTIVE);
		Membership membership3 = new Membership();

		List<Membership> EmploymentList = new LinkedList<Membership>();
		EmploymentList.add(membership1);
		EmploymentList.add(membership2);
		EmploymentList.add(membership3);
		user.setMemberships(EmploymentList);
		Map<Long, String> map = new LinkedHashMap<Long, String>();
		map.put(1L, "INACTIVE");
		map.put(2L, "SUSPENDED");
		when(userDaoMock.getUser(userId)).thenReturn(user);
		when(userDaoMock.update(user)).thenReturn(user);
		ReflectionTestUtils.setField(membershipService, "userDao", userDaoMock);

		membershipService.updateUserMemberships(userId, map);
		verify(userDaoMock).getUser(userId);
	}
}
