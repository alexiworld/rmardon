/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.security;

import java.security.NoSuchAlgorithmException;

import org.junit.Assert;

import org.junit.Test;

import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.security.SecurityUtil;

public class SecurityUtilTest {
	@Test
	public void testSethHashPasswordAndSaltSuccess() throws NoSuchAlgorithmException{
		User user=new User();
		user.setPassword("fsdfsfd");
		SecurityUtil.sethHashPasswordAndSalt(user);
		Assert.assertEquals(28, user.getHashedPassword().length());
		Assert.assertEquals(12, user.getSalt().length());
	}

}
