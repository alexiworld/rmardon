/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalTime;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.dao.RepeatableEventDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.dao.impl.RepeatableEventDaoImpl;
import com.coloredshapes.coreservices.domain.dto.RepeatableEventDto;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.exception.InvalidUserException;

public class RepeatableEventServiceImplTest {
	
	@Test
	public void testAddRepeatableEventsSuccessful()
	throws InvalidUserException {
		// set up mock dependency
		final Long userId = 1L;
		List<RepeatableEventDto> events = new ArrayList<RepeatableEventDto>();
		RepeatableEventDto b1 = new RepeatableEventDto();
		RepeatableEventDto b2 = new RepeatableEventDto();
		RepeatableEventDto b3 = new RepeatableEventDto();
		b1.setDayOfWeek(DayOfWeek.MON);
		b1.setStartTime(new LocalTime(2, 30, 0));
		b1.setEndTime(new LocalTime(3, 29, 0));

		b1.setNote("dfsdf");

		b2.setDayOfWeek(DayOfWeek.MON);
		b2.setStartTime(new LocalTime(3, 30, 0));
		b2.setEndTime(new LocalTime(9, 29, 0));

		b2.setNote("dfsdf");

		b3.setDayOfWeek(DayOfWeek.TUE);
		b3.setStartTime(new LocalTime(1, 30, 0));
		b3.setEndTime(new LocalTime(3, 29, 0));

		b3.setNote("dfsdf");
		events.add(b1);
		events.add(b2);
		events.add(b3);
		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.MON, b1.getStartTime(), b1.getEndTime(),
						userId)).thenReturn(null);
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.MON, b2.getStartTime(), b2.getEndTime(),
						userId)).thenReturn(null);
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.TUE, b3.getStartTime(), b3.getEndTime(),
						userId)).thenReturn(null);
		UserDao userDao = mock(UserDao.class);
		User user = new User();
		user.setPassword("12345");
		user.setId(1L);
		when(userDao.getUser(1L)).thenReturn(user);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils.setField(repeatableEventService, "userDao", userDao);
		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		Map<Outcome, List<RepeatableEventDto>> outcome = repeatableEventService
				.createRepeatableEvents(events, 1L);

		verify(userDao).getUser(1L);
		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.MON,
						b1.getStartTime(), b1.getEndTime(), userId);

		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, times(1)).create(b1);

		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.MON,
						b2.getStartTime(), b2.getEndTime(), userId);
		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, times(1)).create(b2);

		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.TUE,
						b3.getStartTime(), b3.getEndTime(), userId);
		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, times(1)).create(b3);

		Assert.assertEquals(0, outcome.get(Outcome.FAILURE).size());

	}

	@Test
	public void testAddRepeatableEventsSuccessfulWithOneConflict()
			throws InvalidUserException {
		// set up mock dependency
		final Long userId = 1L;
		List<RepeatableEventDto> events = new ArrayList<RepeatableEventDto>();
		RepeatableEventDto b1 = new RepeatableEventDto();
		RepeatableEventDto b2 = new RepeatableEventDto();
		RepeatableEventDto b3 = new RepeatableEventDto();
		b1.setDayOfWeek(DayOfWeek.MON);
		b1.setStartTime(new LocalTime(2, 30, 0));
		b1.setEndTime(new LocalTime(3, 29, 0));

		b1.setNote("dfsdf");

		b2.setDayOfWeek(DayOfWeek.MON);
		b2.setStartTime(new LocalTime(3, 30, 0));
		b2.setEndTime(new LocalTime(9, 29, 0));

		b2.setNote("dfsdf");

		b3.setDayOfWeek(DayOfWeek.TUE);
		b3.setStartTime(new LocalTime(1, 30, 0));
		b3.setEndTime(new LocalTime(3, 29, 0));

		b3.setNote("dfsdf");
		events.add(b1);
		events.add(b2);
		events.add(b3);
		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.MON, b1.getStartTime(), b1.getEndTime(),
						userId)).thenReturn(null);
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.MON, b2.getStartTime(), b2.getEndTime(),
						userId)).thenReturn(new RepeatableEvent());
		when(
				repeatableEventDao.getRepeatableEventStartOrEndBetween(
						DayOfWeek.TUE, b3.getStartTime(), b3.getEndTime(),
						userId)).thenReturn(null);
		UserDao userDao = mock(UserDao.class);
		User user = new User();
		user.setPassword("12345");
		user.setId(1L);
		when(userDao.getUser(1L)).thenReturn(user);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils.setField(repeatableEventService, "userDao", userDao);
		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		Map<Outcome, List<RepeatableEventDto>> outcome = repeatableEventService
				.createRepeatableEvents(events, 1L);

		verify(userDao).getUser(1L);
		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.MON,
						b1.getStartTime(), b1.getEndTime(), userId);

		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, times(1)).create(b1);

		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.MON,
						b2.getStartTime(), b2.getEndTime(), userId);
		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, never()).create(b2);

		verify(repeatableEventDao, times(1))
				.getRepeatableEventStartOrEndBetween(DayOfWeek.TUE,
						b3.getStartTime(), b3.getEndTime(), userId);
		// There is a problem with not knowing entities instantiated as objects by the service when using DTOs
		//verify(repeatableEventDao, times(1)).create(b3);

		Assert.assertEquals(1, outcome.get(Outcome.FAILURE).size());
	}

	@Test(expected = InvalidUserException.class)
	public void testAddRepeatableEventsUserNotExsitException()
			throws InvalidUserException {
		// set up mock dependency
		List<RepeatableEventDto> events = new ArrayList<RepeatableEventDto>();
		RepeatableEventDto e1 = new RepeatableEventDto();
		e1.setDayOfWeek(DayOfWeek.MON);
		e1.setStartTime(new LocalTime(2, 30, 0));
		e1.setEndTime(new LocalTime(3, 29, 0));

		e1.setNote("some note");

		events.add(e1);

		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);

		UserDao userDao = mock(UserDao.class);
		User user = new User();
		user.setPassword("12345");
		user.setId(1L);
		when(userDao.getUser(1L)).thenReturn(null);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils
				.setField(repeatableEventService, "userDao", userDao);
		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		@SuppressWarnings("unused")
		Map<Outcome, List<RepeatableEventDto>> outcome = repeatableEventService
				.createRepeatableEvents(events, 1L);

		verify(userDao).getUser(1L);
	}

	@Test()
	public void testDeleteRepeatableEvents() throws InvalidUserException {
		// set up mock dependency
		final Long userId = 1L;

		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);

		UserDao userDao = mock(UserDao.class);
		User user = new User();
		user.setPassword("12345");
		user.setId(userId);
		when(userDao.getUser(userId)).thenReturn(user);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils.setField(repeatableEventService, "userDao", userDao);
		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		List<Long> eventIds = new LinkedList<Long>();
		eventIds.add(1l);
		eventIds.add(2l);
		eventIds.add(3l);

		repeatableEventService.deleteRepeatableEvent(userId, eventIds);

		verify(userDao).getUser(userId);
		verify(repeatableEventDao, times(1)).deleteRepeatableEventsOfUser(
				userId, eventIds);

	}

	@Test(expected = InvalidUserException.class)
	public void testDeleteRepeatableEventsWithoutFindingUser()
			throws InvalidUserException {
		// set up mock dependency
		final Long userId = 1L;

		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);

		UserDao userDao = mock(UserDao.class);
		User user = new User();
		user.setPassword("12345");
		user.setId(userId);
		when(userDao.getUser(userId)).thenReturn(null);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils.setField(repeatableEventService, "userDao", userDao);
		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		List<Long> eventIds = new LinkedList<Long>();
		eventIds.add(1l);
		eventIds.add(2l);
		eventIds.add(3l);

		repeatableEventService.deleteRepeatableEvent(userId, eventIds);

		verify(userDao).getUser(userId);
		verify(repeatableEventDao, never()).deleteRepeatableEventsOfUser(
				userId, eventIds);

	}

	@Test
	public void testGetRepeatableEventsByUserId() {
		// set up mock dependency
		final Long userId = 1L;

		RepeatableEventDao repeatableEventDao = mock(RepeatableEventDaoImpl.class);
		List<RepeatableEvent> events = new ArrayList<RepeatableEvent>();
		RepeatableEvent b1 = new RepeatableEvent();
		RepeatableEvent b2 = new RepeatableEvent();
		RepeatableEvent b3 = new RepeatableEvent();
		b1.setDayOfWeek(DayOfWeek.MON);
		b1.setStartTime(new LocalTime(2, 30, 0));
		b1.setEndTime(new LocalTime(3, 29, 0));

		b1.setNote("dfsdf");

		b2.setDayOfWeek(DayOfWeek.MON);
		b2.setStartTime(new LocalTime(3, 30, 0));
		b2.setEndTime(new LocalTime(9, 29, 0));

		b2.setNote("dfsdf");

		b3.setDayOfWeek(DayOfWeek.TUE);
		b3.setStartTime(new LocalTime(1, 30, 0));
		b3.setEndTime(new LocalTime(3, 29, 0));

		b3.setNote("dfsdf");
		events.add(b1);
		events.add(b3);
		events.add(b2);

		when(repeatableEventDao.getRepeatableEventByUserId(userId))
				.thenReturn(events);
		RepeatableEventServiceImpl repeatableEventService = new RepeatableEventServiceImpl();

		ReflectionTestUtils.setField(repeatableEventService, "repeatableEventDao",
				repeatableEventDao);

		List<Long> eventIds = new LinkedList<Long>();
		eventIds.add(1l);
		eventIds.add(2l);
		eventIds.add(3l);

		Map<DayOfWeek, List<RepeatableEventDto>> eventsByDayOfWeek = repeatableEventService
				.getRepeatableEvents(userId);

		verify(repeatableEventDao, times(1))
				.getRepeatableEventByUserId(userId);

		Assert.assertEquals(2, eventsByDayOfWeek.size());
		Assert.assertEquals(DayOfWeek.MON, eventsByDayOfWeek.get(DayOfWeek.MON).get(0).getDayOfWeek());
		Assert.assertEquals(new LocalTime(2, 30, 0), eventsByDayOfWeek.get(DayOfWeek.MON).get(0).getStartTime());
		Assert.assertEquals(new LocalTime(3, 29, 0), eventsByDayOfWeek.get(DayOfWeek.MON).get(0).getEndTime());

		Assert.assertEquals(DayOfWeek.MON, eventsByDayOfWeek.get(DayOfWeek.MON).get(1).getDayOfWeek());
		Assert.assertEquals(new LocalTime(3, 30, 0), eventsByDayOfWeek.get(DayOfWeek.MON).get(1).getStartTime());
		Assert.assertEquals(new LocalTime(9, 29, 0), eventsByDayOfWeek.get(DayOfWeek.MON).get(1).getEndTime());

		Assert.assertEquals(DayOfWeek.TUE, eventsByDayOfWeek.get(DayOfWeek.TUE).get(2).getDayOfWeek());
		Assert.assertEquals(new LocalTime(1, 30, 0), eventsByDayOfWeek.get(DayOfWeek.TUE).get(2).getStartTime());
		Assert.assertEquals(new LocalTime(3, 29, 0), eventsByDayOfWeek.get(DayOfWeek.TUE).get(2).getEndTime());
	}
}
