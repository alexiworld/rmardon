/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static com.coloredshapes.coreservices.utils.EventUtils.toDateEvent;
import static com.coloredshapes.coreservices.utils.EventUtils.toEvent;
import static com.coloredshapes.coreservices.utils.RandomUtils.getRandomNum;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.dao.EventDao;
import com.coloredshapes.coreservices.dao.GroupDao;
import com.coloredshapes.coreservices.dao.RepeatableEventDao;
import com.coloredshapes.coreservices.dao.UserDao;
import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsPatchDto;
import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Event;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.Membership;
import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import com.coloredshapes.coreservices.domain.enums.Outcome;
import com.coloredshapes.coreservices.domain.enums.SourceType;
import com.coloredshapes.coreservices.service.EventService;
import com.coloredshapes.coreservices.service.MessageService;
import com.coloredshapes.coreservices.service.QueueService;
import com.coloredshapes.coreservices.utils.DateEventComparator;

/**
 * <code>EventServiceImplTest</code> class is used for group testing 
 * of <code>EventServiceImpl</code>.
 * 
 * To run this junit with gradle use the following command:
 * cd $PROJ_PATH/core
 * gradle -Dtest.single=** /* /EventServiceImplTest* test
 * There must be no spaces between * and / in the command
 */
@RunWith(MockitoJUnitRunner.class)
public class EventServiceImplTest {
	
	@Mock private EventDao eventDao;
	@Mock private RepeatableEventDao repeatableEventDao;
	@Mock private UserDao userDao;
	@Mock private GroupDao groupDao;
	@Mock private MessageService messageService;
	@Mock private QueueService queueService;

	private final static Long TEST_USER1_ID  = 1L;
	private final static Long TEST_USER2_ID  = 2L;
	private final static Long TEST_GROUP1_ID = 1L;
	private final static Long TEST_GROUP2_ID = 2L;

	//private static User TEST_USER1_ID = getUser(true);
	//private static User TEST_USER2_ID = getUser(false);
	//private static Group TEST_GROUP1   = getGroup(true);
	//private static Group TEST_GROUP2   = getGroup(false);

	private final static Long[] TEST_USER_IDS  = { TEST_USER1_ID,  TEST_USER2_ID  };
	private final static Long[] TEST_GROUP_IDS = { TEST_GROUP1_ID, TEST_GROUP1_ID };

	//private final static SourceType[] USER_EVENTS_ONLY  = { SourceType.USER };
	//private final static SourceType[] GROUP_EVENTS_ONLY = { SourceType.GROUP  };
	private final static SourceType[] ALL_EVENTS = { SourceType.USER, SourceType.GROUP };
	
	private final static Long TEST_USER1_EVENT_ID = getKey();
	private final static Long TEST_USER2_EVENT_ID = getKey();
	private final static Long TEST_GROUP1_EVENT_ID  = getKey();
	private final static Long TEST_GROUP2_EVENT_ID  = getKey();
	
	private final static int DAY_START_HOUR = 10;
	private final static int DAY_START_MIN  = 0;
	private final static int DAY_END_HOUR   = 18;
	private final static int DAY_END_MIN    = 0;
	
	private final static DateTime TEST_START_TIME = new DateTime(2010, 06, 14,  0,  0,  0);
	private final static DateTime TEST_END_TIME   = new DateTime(2010, 06, 18, 23, 59, 59);
	private final static DateTime TEST_FAR_IN_THE_FUTURE_START_TIME = DateTime.now().plusWeeks(51);
	private final static DateTime TEST_FAR_IN_THE_FUTURE_END_TIME   = TEST_FAR_IN_THE_FUTURE_START_TIME.plusHours(2);
	private final static DateTime TEST_EVENT1_START_TIME = new DateTime(2010, 06, 15, 10, 0, 0);
	private final static DateTime TEST_EVENT1_END_TIME   = new DateTime(2010, 06, 15, 12, 0, 0);
	private final static DateTime TEST_EVENT2_START_TIME = new DateTime(2010, 06, 16, 10, 0, 0);
	private final static DateTime TEST_EVENT2_END_TIME   = new DateTime(2010, 06, 16, 12, 0, 0);
	private final static DateTime TEST_EVENT3_START_TIME = new DateTime(2010, 06, 17, 10, 0, 0);
	private final static DateTime TEST_EVENT3_END_TIME   = new DateTime(2010, 06, 17, 12, 0, 0);
	private final static DateTime TEST_EVENT4_START_TIME = new DateTime(2010, 06, 15, 14, 0, 0);
	private final static DateTime TEST_EVENT4_END_TIME   = new DateTime(2010, 06, 15, 20, 0, 0);
	private final static DateTime TEST_EVENT5_START_TIME = new DateTime(2010, 06, 16, 14, 0, 0);
	private final static DateTime TEST_EVENT5_END_TIME   = new DateTime(2010, 06, 16, 20, 0, 0);
	private final static DateTime TEST_EVENT6_START_TIME = new DateTime(2010, 06, 17, 14, 0, 0);
	private final static DateTime TEST_EVENT6_END_TIME   = new DateTime(2010, 06, 17, 20, 0, 0);
	private final static DateTime TEST_DAY2DATE_EVENT1_START_TIME = new DateTime(2010, 06, 14, DAY_START_HOUR, DAY_START_MIN, 0);
	private final static DateTime TEST_DAY2DATE_EVENT1_END_TIME   = new DateTime(2010, 06, 14, DAY_END_HOUR, DAY_END_MIN, 0);
	private final static DateTime TEST_DAY2DATE_EVENT2_START_TIME = new DateTime(2010, 06, 18, DAY_START_HOUR, DAY_START_MIN, 0);
	private final static DateTime TEST_DAY2DATE_EVENT2_END_TIME   = new DateTime(2010, 06, 18, DAY_END_HOUR, DAY_END_MIN, 0);

	private final static DateTime[] TEST_EVENTS_START_TIME = {
		TEST_EVENT1_START_TIME, TEST_EVENT2_START_TIME, 
		TEST_EVENT3_START_TIME, TEST_EVENT4_START_TIME,
		TEST_EVENT5_START_TIME, TEST_EVENT6_START_TIME
	};
	private final static DateTime[] TEST_EVENTS_END_TIME = {
		TEST_EVENT1_END_TIME, TEST_EVENT2_END_TIME, 
		TEST_EVENT3_END_TIME, TEST_EVENT4_END_TIME,
		TEST_EVENT5_END_TIME, TEST_EVENT6_END_TIME
	};

	private final static DateTime[] TEST_DAY2DATE_EVENTS_START_TIME = {
		TEST_DAY2DATE_EVENT1_START_TIME, TEST_DAY2DATE_EVENT2_START_TIME
	};

	private final static DateTime[] TEST_DAY2DATE_EVENTS_END_TIME = {
		TEST_DAY2DATE_EVENT1_END_TIME, TEST_DAY2DATE_EVENT2_END_TIME
	};
	
	/**
	 * Tests getEventsByMemberKey service operation.
	 */
	@Test
	public void testGetEventsByUserKey() {
		// Initialise the mocks & their behaviour
		reset(eventDao);
		when(eventDao.getEventsByUserId(
			eq(TEST_START_TIME), eq(TEST_END_TIME), 
			eq(TEST_USER1_ID), eq(ALL_EVENTS), eq(TEST_GROUP_IDS)))
			.thenReturn(buildEvents(true, true, false, false, false, false));
		 
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "eventDao", eventDao);

		// Invoke the service operation
		TimePeriodDto timePeriod = new TimePeriodDto(TEST_START_TIME, TEST_END_TIME);
		final Map<String, DateEventsDto> actualEvents = 
			eventService.getEvents(TEST_USER1_ID, timePeriod, ALL_EVENTS, TEST_GROUP_IDS);
		
		// Verify the mock invoking sequence
		verify(eventDao).getEventsByUserId(
			TEST_START_TIME, TEST_END_TIME, TEST_USER1_ID, ALL_EVENTS, TEST_GROUP_IDS);

		// Prepare the expected result
		final Map<String, DateEventsDto> expectedEvents = new LinkedHashMap<String, DateEventsDto>();
		
		DateEventsDto user1DateEvents = new DateEventsDto();
		user1DateEvents.setDateEvents(buildDateEvents(true, false, false, false, false, false));
		expectedEvents.put(SourceType.USER.toString(), user1DateEvents);
		DateEventsDto group1DateEvents = new DateEventsDto();
		group1DateEvents.setDateEvents(buildDateEvents(false, true, false, false, false, false));
		expectedEvents.put(SourceType.GROUP.toString(), group1DateEvents);
		
		// Asserts the results
		Assert.assertEquals("Incorrect date events returned", expectedEvents, actualEvents);
	}

	/**
	 * Tests getEventsByUserKeys service operation.
	 */
	@Test
	public void testGetEventsByUserKeys() {
		final Long TEST_USER3_ID = 3L;
		final Long[] TEST_USER_IDS = { TEST_USER1_ID, TEST_USER2_ID, TEST_USER3_ID };

		User notActiveUser = getNotActiveUser(TEST_USER3_ID, true);
		
		// Initialize the mocks & their behavior
		reset(groupDao);
		reset(eventDao);
		reset(repeatableEventDao);
		reset(userDao);
		when(groupDao.getGroup(eq(TEST_GROUP1_ID)))
			.thenReturn(getGroup(true));
		when(eventDao.getEventsByUserIds(
			eq(TEST_START_TIME), eq(TEST_END_TIME), eq(TEST_USER_IDS)))
			.thenReturn(buildEvents(true, true, false, true, false, true));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER1_ID)))
			.thenReturn(buildRepeatableEvents(true));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER2_ID)))
			.thenReturn(buildRepeatableEvents(false));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER3_ID)))
			.thenReturn(null);
		when(userDao.getUser(eq(TEST_USER1_ID)))
			.thenReturn(getUser(true));
		when(userDao.getUser(eq(TEST_USER2_ID)))
			.thenReturn(getUser(false));
		when(userDao.getUser(eq(TEST_USER3_ID)))
			.thenReturn(notActiveUser);
		
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "groupDao", groupDao);
		ReflectionTestUtils.setField(eventService, "eventDao", eventDao);
		ReflectionTestUtils.setField(eventService, "repeatableEventDao", repeatableEventDao);
		ReflectionTestUtils.setField(eventService, "userDao", userDao);

		// Invoke the service operation
		TimePeriodDto timePeriod = new TimePeriodDto(TEST_START_TIME, TEST_END_TIME);
		final List<DateEventsDto> actualEvents = 
				eventService.getEvents(TEST_GROUP1_ID, timePeriod, TEST_USER_IDS);

		// Reset the ids of date events result from day time to date time conversion
		for (DateEventsDto dateEvents : actualEvents) {
			for (DateEventDto event : dateEvents.getDateEvents()) {
				if (StringUtils.isNotEmpty(event.getNote()) &&
					event.getNote().startsWith("DAY-")) {
					event.setId(null);
				}
			}
		}
		
		// Verify the mock invoking sequence
		verify(eventDao).getEventsByUserIds(TEST_START_TIME, TEST_END_TIME, TEST_USER_IDS);
		verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER1_ID);
		verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER2_ID);
		verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER3_ID);
		verify(userDao).getUser(TEST_USER1_ID);
		verify(userDao).getUser(TEST_USER2_ID);
		verify(userDao).getUser(TEST_USER3_ID);
		
		// Prepare the expected result
		final List<DateEventsDto> expectedEvents = new LinkedList<DateEventsDto>();
		
		DateEventsDto user1DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER1_ID);
		user1DateEvents.setDateEvents(buildDateEvents(true, true, false, false, false, false));
		user1DateEvents.getDateEvents().add(buildDay2DateEvent(true, TEST_USER1_ID));
		for (DateEventDto dateEvent : user1DateEvents.getDateEvents()) {
			if (!TEST_GROUP1_ID.equals(dateEvent.getGroupId())) {
				dateEvent.setGroupId(null);
				dateEvent.setNote(null);
				dateEvent.setId(null);
			}
		}
		Collections.sort(user1DateEvents.getDateEvents(), new DateEventComparator());
		expectedEvents.add(user1DateEvents);
		
		DateEventsDto user2DateEvents = new DateEventsDto();
		user2DateEvents.setUserId(TEST_USER2_ID);
		user2DateEvents.setDateEvents(buildDateEvents(false, false, false, true, false, true));
		// The event created by group2 must look like user event
		DateEventDto group2DateEvent = user2DateEvents.getDateEvents().get(1);
		group2DateEvent.setGroupId(null); group2DateEvent.setNote("");
		user2DateEvents.getDateEvents().add(buildDay2DateEvent(false, TEST_USER2_ID));
		for (DateEventDto dateEvent : user2DateEvents.getDateEvents()) {
			if (!TEST_GROUP1_ID.equals(dateEvent.getGroupId())) {
				dateEvent.setGroupId(null);
				dateEvent.setNote(null);
				dateEvent.setId(null);
			}
		}
		Collections.sort(user2DateEvents.getDateEvents(), new DateEventComparator());
		expectedEvents.add(user2DateEvents);
		
		DateEventsDto notActiveUserDateEvents = new DateEventsDto();
		notActiveUserDateEvents.setUserId(TEST_USER3_ID);
		notActiveUserDateEvents.setDateEvents(new ArrayList<DateEventDto>());
		DateEventDto notActiveUserDateEvent = new DateEventDto();
		notActiveUserDateEvent.setUserId(TEST_USER3_ID);
		notActiveUserDateEvent.setStartTime(timePeriod.getStartTime());
		notActiveUserDateEvent.setEndTime(timePeriod.getEndTime());
		notActiveUserDateEvents.getDateEvents().add(notActiveUserDateEvent);
		Collections.sort(notActiveUserDateEvents.getDateEvents(), new DateEventComparator());
		expectedEvents.add(notActiveUserDateEvents);


		// Asserts the results
		Assert.assertEquals("Incorrect date events returned", expectedEvents, actualEvents);
	}

	/**
	 * Tests deleteEvents service operation.
	 */
	@Test
	public void testCreateEventsByTheUser() {
		// Prepare the events for service, mocking arguments and results
		List<Event> user1EventsToBeCreated = buildEvents(true, false, false, true, false, false);
		//The latest decision is to allow the user to overlap his/her events and hence the day2date event
		//will be passed to the event service to be created (or in other words persisted). This is the reason for
		// creating a date event and have the mock check it for a match against what the service impl provides. 
		user1EventsToBeCreated.add(toEvent(buildDay2DateEvent(true, TEST_USER1_ID), getUser(true), null, null));
		switchUserAlsoGroupInEvents(user1EventsToBeCreated, true, true, true);

		List<Event> user1EventsNotCreated = buildEvents(true, false, false, false, false, false);
		List<Event> user1EventsCreated    = new LinkedList<Event>(user1EventsToBeCreated);
		user1EventsCreated.remove(0);
		final Map<Outcome, List<Event>> outcomesFromDao = new HashMap<Outcome, List<Event>>();
		outcomesFromDao.put(Outcome.SUCCESS, user1EventsCreated);
		outcomesFromDao.put(Outcome.FAILURE, user1EventsNotCreated);
		
		DateEventsDto user1DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER1_ID);
		user1DateEvents.setDateEvents(buildDateEvents(true, false, false, true, false, false));
		user1DateEvents.getDateEvents().add(buildDay2DateEvent(true, TEST_USER1_ID));
		switchUserAlsoGroupInDateEvents(user1DateEvents.getDateEvents(), true, true, true);
		//Date events in the far future should be rejected
		DateEventDto buildFarInTheFutureDateEvent = buildFarInTheFutureDateEvent(true, true, true);
		user1DateEvents.getDateEvents().add(buildFarInTheFutureDateEvent);
		
		// Initialize the mocks & their behavior
		reset(userDao);
		reset(repeatableEventDao);
		reset(eventDao);
		
		when(userDao.getUser(eq(TEST_USER1_ID)))
			.thenReturn(getUser(true));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER1_ID)))
			.thenReturn(buildRepeatableEvents(true));
		when(eventDao.createEvents(eq(user1EventsToBeCreated)))
			.thenReturn(outcomesFromDao);
		
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "eventDao", eventDao);
		ReflectionTestUtils.setField(eventService, "repeatableEventDao", repeatableEventDao);
		ReflectionTestUtils.setField(eventService, "userDao", userDao);

		// Invoke the service operation
		Map<Outcome, DateEventsDto> actualOutcomes = eventService.createEvents(user1DateEvents);
		DateEventsDto actualUser1DateEventsCreated    = actualOutcomes.get(Outcome.SUCCESS);
		DateEventsDto actualUser1DateEventsNotCreated = actualOutcomes.get(Outcome.FAILURE); 
		
		// Verify the mock invoking sequence
		InOrder inOrder = inOrder(groupDao, userDao, repeatableEventDao, eventDao);

		inOrder.verify(userDao).getUser(TEST_USER1_ID);
		inOrder.verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER1_ID);
		inOrder.verify(eventDao).createEvents(user1EventsToBeCreated);

		// Asserts the results
		DateEventsDto expectedUser1DateEventsNotCreated = new DateEventsDto();
		expectedUser1DateEventsNotCreated.setUserId(TEST_USER1_ID);
		expectedUser1DateEventsNotCreated.setDateEvents(new LinkedList<DateEventDto>());
		//Date events in the far future should be rejected
		expectedUser1DateEventsNotCreated.getDateEvents().add(buildFarInTheFutureDateEvent);
		//The latest decision is to allow the user to overlap his/her events and hence the day2date event
		//will not failed and therefore will not be returned as it was previously. This is the reason for commenting: 
		//expectedUser1DateEventsNotCreated.getEvents().add(buildDay2DateTimeBlock(true, TEST_USER1_ID));
		expectedUser1DateEventsNotCreated.getDateEvents().addAll(buildDateEvents(true, false, false, false, false, false));

		Assert.assertEquals("Incorrect user id returned",
			TEST_USER1_ID, actualUser1DateEventsCreated.getUserId());
		Assert.assertEquals("Incorrect added events size returned",
			2, actualUser1DateEventsCreated.getDateEvents().size());
		Assert.assertEquals("Incorrect added 1st event returned",
			"test 1st user event", actualUser1DateEventsCreated.getDateEvents().get(0).getNote());
		Assert.assertEquals("Incorrect added 2nd event returned",
			"DAY-MON", actualUser1DateEventsCreated.getDateEvents().get(1).getNote());
		
		Assert.assertEquals("Incorrect not-created events returned", 
			expectedUser1DateEventsNotCreated, actualUser1DateEventsNotCreated);
	}

	/**
	 * Tests deleteEvents service operation.
	 */
	@Test
	public void testCreateEventsByTheGroup() {
		// Prepare the mocking arguments
		List<Event> user1Events = buildEvents(false, true, false, false, false, false);
		List<Event> user2Events = buildEvents(false, false, false, false, false, true);
		switchUserAlsoGroupInEvents(user2Events, false, false, true);

		// Prepare the mocking results
		final Map<Outcome, List<Event>> user1OutcomesFromDao = new HashMap<Outcome, List<Event>>();
		user1OutcomesFromDao.put(Outcome.SUCCESS, Collections.<Event>emptyList());
		user1OutcomesFromDao.put(Outcome.FAILURE, user1Events);
		
		final Map<Outcome, List<Event>> user2OutcomesFromDao = new HashMap<Outcome, List<Event>>();
		user2OutcomesFromDao.put(Outcome.SUCCESS, user2Events);
		user2OutcomesFromDao.put(Outcome.FAILURE, Collections.<Event>emptyList());
		
		// Prepare the events for service
		final List<DateEventsDto> dateEventsToBeCreated = new ArrayList<DateEventsDto>(2);

		DateEventsDto user1DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER1_ID);
		user1DateEvents.setDateEvents(buildDateEvents(false, true, false, false, false, false));
		user1DateEvents.getDateEvents().add(buildDay2DateEvent(true, TEST_USER1_ID));
		switchUserAlsoGroupInDateEvents(user1DateEvents.getDateEvents(), false, true, true);
		dateEventsToBeCreated.add(user1DateEvents);

		//Date events in the far future should be rejected
		DateEventDto buildFarInTheFutureDateEvent = buildFarInTheFutureDateEvent(true, true, true);
		user1DateEvents.getDateEvents().add(buildFarInTheFutureDateEvent);

		DateEventsDto user2DateEvents = new DateEventsDto();
		user2DateEvents.setUserId(TEST_USER2_ID);
		user2DateEvents.setDateEvents(buildDateEvents(false, false, false, false, false, true));
		user2DateEvents.getDateEvents().add(buildDay2DateEvent(false, TEST_USER2_ID));
		switchUserAlsoGroupInDateEvents(user2DateEvents.getDateEvents(), false, false, true);
		dateEventsToBeCreated.add(user2DateEvents);

		// Initialize the mocks & their behavior
		reset(groupDao);
		reset(userDao);
		reset(repeatableEventDao);
		reset(eventDao);
		
		when(groupDao.getGroup(eq(TEST_GROUP1_ID)))
			.thenReturn(getGroup(true));
		when(userDao.getUser(eq(TEST_USER1_ID)))
			.thenReturn(getUser(true));
		when(userDao.getUser(eq(TEST_USER2_ID)))
			.thenReturn(getUser(false));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER1_ID)))
			.thenReturn(buildRepeatableEvents(true));
		when(repeatableEventDao.getRepeatableEventByUserId(eq(TEST_USER2_ID)))
			.thenReturn(buildRepeatableEvents(false));
		// Simulate that the first user event is persisted, but for some
		// reason the second user event is not. It covers both scenarios.
		when(eventDao.createEvents(eq(user1Events)))
			.thenReturn(user1OutcomesFromDao);
		when(eventDao.createEvents(eq(user2Events)))
			.thenReturn(user2OutcomesFromDao);
		 
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "eventDao", eventDao);
		ReflectionTestUtils.setField(eventService, "repeatableEventDao", repeatableEventDao);
		ReflectionTestUtils.setField(eventService, "userDao", userDao);
		ReflectionTestUtils.setField(eventService, "groupDao", groupDao);

		// Invoke the service operation
		Map<Outcome, List<DateEventsDto>> actualOutcomes = 
			eventService.createEvents(TEST_GROUP1_ID, dateEventsToBeCreated);
		final List<DateEventsDto> actualDateEventsCreated    = actualOutcomes.get(Outcome.SUCCESS);
		final List<DateEventsDto> actualDateEventsNotCreated = actualOutcomes.get(Outcome.FAILURE); 
		
		// Verify the mock invoking sequence
		InOrder inOrder = inOrder(groupDao, userDao, repeatableEventDao, eventDao);

		inOrder.verify(groupDao).getGroup(TEST_GROUP1_ID);
		
		inOrder.verify(userDao).getUser(TEST_USER1_ID);
		inOrder.verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER1_ID);
		inOrder.verify(eventDao, times(1)).createEvents(user1Events);
		
		inOrder.verify(userDao).getUser(TEST_USER2_ID);
		inOrder.verify(repeatableEventDao).getRepeatableEventByUserId(TEST_USER2_ID);
		inOrder.verify(eventDao, times(1)).createEvents(user2Events);

		// Asserts the results
		final List<DateEventsDto> expectedDateEventsNotCreated = new ArrayList<DateEventsDto>(2);

		user1DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER1_ID);
		user1DateEvents.setDateEvents(new LinkedList<DateEventDto>());
		user1DateEvents.getDateEvents().add(buildDay2DateEvent(true, TEST_USER1_ID));
		
		//Date events in the far future should be rejected. This event appears after the day 2 date time
		//block as this is the order of the events passed to eventService.createEvents() 
		user1DateEvents.getDateEvents().add(buildFarInTheFutureDateEvent);

		user1DateEvents.getDateEvents().addAll(buildDateEvents(false, true, false, false, false, false));
		switchUserAlsoGroupInDateEvents(user1DateEvents.getDateEvents(), false, true, true);
		expectedDateEventsNotCreated.add(user1DateEvents);
		
		user2DateEvents = new DateEventsDto();
		user2DateEvents.setUserId(TEST_USER2_ID);
		user2DateEvents.setDateEvents(buildDateEvents(false, false, false, false, false, false));
		user2DateEvents.getDateEvents().add(buildDay2DateEvent(false, TEST_USER2_ID));
		switchUserAlsoGroupInDateEvents(user2DateEvents.getDateEvents(), false, false, true);
		expectedDateEventsNotCreated.add(user2DateEvents);

		Assert.assertEquals("Incorrect added events size returned",
			1, actualDateEventsCreated.size());
		Assert.assertEquals("Incorrect user id returned",
			TEST_USER2_ID, actualDateEventsCreated.get(0).getUserId());
		Assert.assertEquals("Incorrect added event returned",
			"test 2nd user 1st group event", 
			actualDateEventsCreated.get(0).getDateEvents().get(0).getNote());

		Assert.assertEquals("Incorrect not-created events returned", 
			expectedDateEventsNotCreated, actualDateEventsNotCreated);
	}

	/**
	 * Tests deleteEvents service operation.
	 */
	@Test
	public void testDeleteEvents() {
		// Prepare the events for deletion & the ones that will not be deleted successfully
		Long eventKey1 = getKey();
		Long eventKey2 = getKey();
		Long eventKey3 = getKey();
		
		List<Long> eventKeysToBeDeleted = Arrays.asList(new Long[] { eventKey1, eventKey2, eventKey3 });
		
		Map<Outcome, List<Long>> expectedOutcomes = new HashMap<Outcome, List<Long>>();
		List<Long> expectedTimeBlockKeysDeleted    = Arrays.asList(new Long[] { eventKey2 });
		List<Long> expectedTimeBlockKeysNotDeleted = Arrays.asList(new Long[] { eventKey1, eventKey3 });
		expectedOutcomes.put(Outcome.SUCCESS, expectedTimeBlockKeysDeleted);
		expectedOutcomes.put(Outcome.FAILURE, expectedTimeBlockKeysNotDeleted);

		// Initialize the mocks & their behavior
		reset(eventDao);
		when(eventDao.deleteEvents(
			eq(TEST_USER1_ID), eq(TEST_GROUP1_ID), eq(eventKeysToBeDeleted)))
			.thenReturn(expectedOutcomes);
		 
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "eventDao", eventDao);

		// Invoke the service operation
		final Map<Outcome, List<Long>> actualOutcomes = 
			eventService.deleteEvents(TEST_USER1_ID, TEST_GROUP1_ID, eventKeysToBeDeleted);
		final List<Long> actualTimeBlockKeysDeleted    = actualOutcomes.get(Outcome.SUCCESS);
		final List<Long> actualTimeBlockKeysNotDeleted = actualOutcomes.get(Outcome.FAILURE);  
				
		// Verify the mock invoking sequence
		verify(eventDao).deleteEvents(
			TEST_USER1_ID, TEST_GROUP1_ID, eventKeysToBeDeleted);

		// Asserts the results
		Assert.assertEquals("Incorrect deleted events ids returned", 
			expectedTimeBlockKeysDeleted, actualTimeBlockKeysDeleted);
		Assert.assertEquals("Incorrect not deleted events ids returned", 
			expectedTimeBlockKeysNotDeleted, actualTimeBlockKeysNotDeleted);
	}

	/**
	 * Tests assignShifts service operation.
	 */
	@Test
	public void testAssignShifts() {
		// Prepare arguments and results
		final DateEventsPatchDto dateEventsPatch = new DateEventsPatchDto();
		dateEventsPatch.setGroupId(TEST_GROUP1_ID);

		dateEventsPatch.setDeletedEvents(new Long[] { getKey(), getKey() });
		final List<Long> eventsDeleted    = Collections.<Long>emptyList();
		final List<Long> eventsNotDeleted = Arrays.asList(dateEventsPatch.getDeletedEvents());

		final List<DateEventsDto> eventsToBeAdded = new ArrayList<DateEventsDto>(2);

		DateEventsDto user1DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER1_ID);
		user1DateEvents.setDateEvents(buildDateEvents(true, false, false, false, false, false));
		eventsToBeAdded.add(user1DateEvents);

		DateEventsDto user2DateEvents = new DateEventsDto();
		user1DateEvents.setUserId(TEST_USER2_ID);
		user1DateEvents.setDateEvents(buildDateEvents(false, false, false, true, false, false));
		eventsToBeAdded.add(user2DateEvents);
		
		dateEventsPatch.setAddedEvents(eventsToBeAdded);
		final List<DateEventsDto> eventsAdded    = Collections.<DateEventsDto>emptyList();
		final List<DateEventsDto> eventsNotAdded = dateEventsPatch.getAddedEvents();
		
		// Prepare the service and mocking spy
		EventServiceImpl eventService = new EventServiceImpl() {
			@Override
			public Map<Outcome, List<Long>> deleteEvents(Long userId, Long groupId, List<Long> eventIds) {
				if (userId != null) {
					throw new IllegalArgumentException("The user id was present.");
				}
				
				if (groupId == null || !groupId.equals(dateEventsPatch.getGroupId())) {
					throw new IllegalArgumentException("Incorrect group id was used.");
				}
					
				if (!Arrays.asList(dateEventsPatch.getDeletedEvents()).equals(eventIds)) {
					throw new IllegalArgumentException("Incorrect event ids passed to delete method.");
				}
				
				Map<Outcome, List<Long>> outcomes = new HashMap<Outcome, List<Long>>(); 
				outcomes.put(Outcome.SUCCESS, eventsDeleted);
				outcomes.put(Outcome.FAILURE, eventsNotDeleted);
				
				return outcomes;
			}
			
			@Override
			public Map<Outcome, List<DateEventsDto>> createEvents(Long groupId,
					List<DateEventsDto> listOfDateEvents) {
				if (groupId == null || !groupId.equals(dateEventsPatch.getGroupId())) {
					throw new IllegalArgumentException("Incorrect group id was used.");
				}
					
				if (!dateEventsPatch.getAddedEvents().equals(listOfDateEvents)) {
					throw new IllegalArgumentException("Incorrect event ids passed to delete method.");
				}

				Map<Outcome, List<DateEventsDto>> outcomes = new HashMap<Outcome, List<DateEventsDto>>(); 
				outcomes.put(Outcome.SUCCESS, eventsAdded);
				outcomes.put(Outcome.FAILURE, eventsNotAdded);

				return outcomes;
			}
		};
		ReflectionTestUtils.setField(eventService, "queueService", queueService);

		// Initialize the mocks & their behavior
		reset(queueService);
		doNothing().when(queueService).enqueueDateEventsPatch(eq(dateEventsPatch));

		//TODO: spy/stubs do not behave as expected, need to find why. until then the solution is to use a subclass of service implementation.
		//EventService spy = spy(eventService);
		//doReturn(eventsToBeDeleted).when(spy).deleteEvents(anyString(), eq(shiftAssignment.getGroupKey()), eq(eventsToBeDeleted));
		//when(spy.deleteEvents(anyString(), eq(shiftAssignment.getGroupKey()), eq(eventsToBeDeleted))).thenReturn(eventsToBeDeleted);
		//stub(eventService.deleteEvents(anyString(), eq(shiftAssignment.getGroupKey()), eq(eventsToBeDeleted))).toReturn(eventsToBeDeleted);
		//when(spy.createEvents(eq(shiftAssignment.getGroupKey()), eq(eventsToBeAdded))).thenReturn(eventsToBeAdded);

		// Invoke the service operation
		eventService.synchDateEventsPatch(dateEventsPatch);
	}

	/**
	 * Tests notifyAssignments service operation.
	 */
	/*
	@Test
	public void testSendGroupNote() {
		// Prepare arguments and results
		final CollectiveMessageDto collectiveNote = new CollectiveMessageDto();
		collectiveNote.setGroupId(TEST_GROUP1_ID);
		collectiveNote.setUserIds(TEST_USER_IDS);
		collectiveNote.setStartTime(TEST_START_TIME);
		collectiveNote.setEndTime(TEST_END_TIME);
		
		Group group = getGroup(true);
		User user1 = getUser(true);
		User user2 = getUser(false);
		List<User> users = new ArrayList<User>(2);
		users.add(user1);
		users.add(user2);
		TimePeriodDto timePeriod = new TimePeriodDto(TEST_START_TIME, TEST_END_TIME);

		// Initialize the mocks & their behavior
		reset(groupDao);
		reset(userDao);
		reset(messageService);
		
		when(groupDao.getGroup(eq(TEST_GROUP1_ID)))
			.thenReturn(group);
		when(userDao.getUser(eq(TEST_USER1_ID)))
			.thenReturn(user1);
		when(userDao.getUser(eq(TEST_USER2_ID)))
			.thenReturn(user2);
		doNothing().when(messageService).sendCollectiveMessage(eq(group), eq(users), eq(timePeriod));
		 
		// Prepare the service
		EventService eventService = new EventServiceImpl();
		ReflectionTestUtils.setField(eventService, "groupDao", groupDao);
		ReflectionTestUtils.setField(eventService, "userDao", userDao);
		ReflectionTestUtils.setField(eventService, "messageService", messageService);
		
		// Invoke the service operation
		eventService.sendCollectiveMessage(collectiveNote);
	}
	*/

	//
	// Helper/Utility methods for the tests
	//

	/**
	 * Builds a list of day events for user 1 or 2.
	 * 
	 * @param isFirst	true if this is for the first user, false for the second one.
	 * @return	a list of day events
	 */
	private static List<RepeatableEvent> buildRepeatableEvents(boolean isFirst) {
		List<RepeatableEvent> repeatableEvents = new LinkedList<RepeatableEvent>();
		repeatableEvents.add(buildRepeatableEvent(isFirst));
		return repeatableEvents;
	}
	
	/**
	 * Builds day event.
	 * 
	 * @param isFirst	true if this is MON, false if this is FRI day event
	 * @return	the day event
	 */
	private static RepeatableEvent buildRepeatableEvent(boolean isFirst) {
		RepeatableEvent repeatableEvent = new RepeatableEvent();
		repeatableEvent.setDayOfWeek(isFirst ? DayOfWeek.MON : DayOfWeek.FRI);
		repeatableEvent.setStartTime(new LocalTime(DAY_START_HOUR, DAY_START_MIN));
		repeatableEvent.setEndTime(new LocalTime(DAY_END_HOUR, DAY_END_MIN));
		repeatableEvent.setUser(getUser(isFirst));
		repeatableEvent.setNote("DAY-" + repeatableEvent.getDayOfWeek().name());
		return repeatableEvent;
	}
	
	/**
	 * Builds day converted to date event.
	 * 
	 * @param isFirst		true if this is MON, false if this is FRI day event
	 * @param userId		the user id for which the date event to be built
	 * @return	the built date event
	 */
	private static DateEventDto buildDay2DateEvent(boolean isFirst, Long userId) {
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setId(null);
		dateEvent.setStartTime(isFirst ? TEST_DAY2DATE_EVENTS_START_TIME[0] : TEST_DAY2DATE_EVENTS_START_TIME[1]);
		dateEvent.setEndTime(isFirst ? TEST_DAY2DATE_EVENTS_END_TIME[0] : TEST_DAY2DATE_EVENTS_END_TIME[1]);
		dateEvent.setNote(isFirst ? "DAY-MON" : "DAY-FRI");
		dateEvent.setUserId(userId);
		dateEvent.setGroupId(null);
		return dateEvent;
	}

	/**
	 * Changes the user also group in list of date events.
	 * 
	 * @param events 	a list of date events to be updated
	 * @param isUser 		true if all date events should become user events, false to become group events
	 * @param isFirstUser true if all date events should be for test user 1, false for test user 2
	 * @param isFirstGroup 	true if all date events should be owned by test group 1, false for test group 2
	 * @return	the updated list of date events
	 */
	private static List<DateEventDto> switchUserAlsoGroupInDateEvents(
		List<DateEventDto> dateEvents, boolean isUser, 
		boolean isFirstUser, boolean isFirstGroup) {
		for (DateEventDto dateEvent : dateEvents) {
			dateEvent.setUserId(getUserId(isFirstUser));
			
			boolean updateTheNote = false;
			String note = dateEvent.getNote();
			if (StringUtils.isNotEmpty(note) && !note.startsWith("DAY-")) {
				updateTheNote = true;
			}
			
			if (isUser) {
				dateEvent.setGroupId(null);
				if (updateTheNote) {
					dateEvent.setNote(getNote(isUser, isFirstUser, isFirstGroup));
				}	
			} else {
				dateEvent.setGroupId(getGroupId(isFirstGroup));
				if (updateTheNote) {
					dateEvent.setNote(getNote(isUser, isFirstUser, isFirstGroup));
				}
			}
		}
		return dateEvents;
	}

	/**
	 * Builds a list of date events containing combination of user 1 and 2 and group 1 and 2 date events.
	 * @return	a list of date events
	 */
	private static List<DateEventDto> buildDateEvents(
		boolean includeUser1NoGroupTimeBlock, boolean includeUser1Group1TimeBlock, boolean includeUser1Group2TimeBlock,
		boolean includeUser2NoGroupTimeBlock, boolean includeUser2Group1TimeBlock, boolean includeUser2Group2TimeBlock) {
		List<DateEventDto> dateEvents = new LinkedList<DateEventDto>();
		if (includeUser1NoGroupTimeBlock) { dateEvents.add(toDateEvent(buildEvent(true,  true,  false))); }
		if (includeUser1Group1TimeBlock)  { dateEvents.add(toDateEvent(buildEvent(false, true,  true ))); }
		if (includeUser1Group2TimeBlock)  { dateEvents.add(toDateEvent(buildEvent(false, true,  false))); }
		if (includeUser2NoGroupTimeBlock) { dateEvents.add(toDateEvent(buildEvent(true,  false, false))); }
		if (includeUser2Group1TimeBlock)  { dateEvents.add(toDateEvent(buildEvent(false, false, true ))); }
		if (includeUser2Group2TimeBlock)  { dateEvents.add(toDateEvent(buildEvent(false, false, false))); }
		return dateEvents;
	}
	
	private static DateEventDto buildFarInTheFutureDateEvent(boolean isUser, boolean isFirstUser, boolean isFirstGroup) {
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setId(getRandomNum());
		dateEvent.setStartTime(TEST_FAR_IN_THE_FUTURE_START_TIME);
		dateEvent.setEndTime(TEST_FAR_IN_THE_FUTURE_END_TIME);
		dateEvent.setNote("Far in the future");
		dateEvent.setUserId(getUserId(isFirstUser));
		if (!isUser) {
			dateEvent.setGroupId(getGroupId(isFirstGroup));
		}
		return dateEvent;
	}

	/**
	 * Changes the user also group in list of events.
	 * 
	 * @param events 	a list of events to be updated
	 * @param isUser 		true if all date events should become user events, false to become group events
	 * @param isFirstUser true if all date events should be for test user 1, false for test user 2
	 * @param isFirstGroup 	true if all date events should be owned by test group 1, false for test group 2
	 * @return	the updated list of events
	 */
	private static List<Event> switchUserAlsoGroupInEvents(
		List<Event> events, boolean isUser, 
		boolean isFirstUser, boolean isFirstGroup) {
		for (Event event : events) {
			event.setUser(getUser(isFirstUser));
			
			boolean updateTheNote = false;
			String note = event.getNote();
			if (StringUtils.isNotEmpty(note) && !note.startsWith("DAY-")) {
				updateTheNote = true;
			}
			
			if (isUser) {
				event.setSourceType(SourceType.USER);
				event.setGroup(null);
				if (updateTheNote) {
					event.setNote(getNote(isUser, isFirstUser, isFirstGroup));
				}
			} else {
				event.setSourceType(SourceType.GROUP);
				event.setGroup(getGroup(isFirstGroup));
				if (updateTheNote) {
					event.setNote(getNote(isUser, isFirstUser, isFirstGroup));
				}
			}
		}
		return events;
	}

	/**
	 * Builds a list of events containing combination of user 1 and 2 and group 1 and 2 events.
	 * @return	a list of events
	 */
	private static List<Event> buildEvents(
		boolean includeUser1NoGroupTimeBlock, boolean includeUser1Group1TimeBlock, boolean includeUser1Group2TimeBlock,
		boolean includeUser2NoGroupTimeBlock, boolean includeUser2Group1TimeBlock, boolean includeUser2Group2TimeBlock) {
		List<Event> events = new LinkedList<Event>();
		if (includeUser1NoGroupTimeBlock) { events.add(buildEvent(true,  true, false)); }
		if (includeUser1Group1TimeBlock)  { events.add(buildEvent(false, true, true )); }
		if (includeUser1Group2TimeBlock)  { events.add(buildEvent(false, true, false)); }
		if (includeUser2NoGroupTimeBlock) { events.add(buildEvent(true,  false, false)); }
		if (includeUser2Group1TimeBlock)  { events.add(buildEvent(false, false, true )); }
		if (includeUser2Group2TimeBlock)  { events.add(buildEvent(false, false, false)); }
		return events;
	}

	/**
	 * Builds a event.
	 * 
	 * @param isUser	true for a user created event, false for an group created event
	 * @param isFirstUser	true if the event will be for the first user, false otherwise
	 * @param isFirstGroup	true if the event is assigned by the first group, false otherwise
	 * @return	the event
	 */
	private static Event buildEvent(boolean isUser, boolean isFirstUser, boolean isFirstGroup) {
		Event event = new Event();
		event.setId(getEventId(isUser, isFirstUser, isFirstGroup));
		event.setStartTime(getDateTime(true, isUser, isFirstUser, isFirstGroup));
		event.setEndTime(getDateTime(false, isUser, isFirstUser, isFirstGroup));
		event.setNote(getNote(isUser, isFirstUser, isFirstGroup));
		event.setSourceType(isUser ? SourceType.USER : SourceType.GROUP);
		event.setUser(getUser(isFirstUser));
		event.setGroup(isUser ? null : getGroup(isFirstGroup));
		return event;
	}

	/**
	 * Gets the event id for specific user/group.
	 * 
	 * @param isUser	true if this is for the user, false for the group
	 * @param isFirstUser	true if this is for the first user in line, false otherwise
	 * @param isFirstGroup	true if this is for the first group in line, false otherwise
	 * @return	the event id
	 */
	private static Long getEventId(boolean isUser, boolean isFirstUser, boolean isFirstGroup) {
		if (isUser) {
			if (isFirstUser) {
				return TEST_USER1_EVENT_ID;
			} else {
				return TEST_USER2_EVENT_ID;
			}
		} else {
			if (isFirstGroup) {
				return TEST_GROUP1_EVENT_ID;
			} else {
				return TEST_GROUP2_EVENT_ID;
			}
		}
	}
	
	/**
	 * Generates a unique id.
	 * 
	 * @return the unique id
	 */
	private static Long getKey() {
		return getRandomNum();
	}

	/**
	 * Gets the start/end time for specific user/group.
	 * 
	 * @param isStart	true if this is for the start time, false for the end time
	 * @param isUser	true if this is for the user, false for the group
	 * @param isFirstUser	true if this is for the first user in line, false otherwise
	 * @param isFirstGroup	true if this is for the first group in line, false otherwise
	 * @return	the date time
	 */
	private static DateTime getDateTime(boolean isStart, boolean isUser, boolean isFirstUser, boolean isFirstGroup) {
		if (isStart) {
			if (isFirstUser) {
				if (isUser) {
					return TEST_EVENTS_START_TIME[0];
				} else {
					return isFirstGroup ? TEST_EVENTS_START_TIME[1] : TEST_EVENTS_START_TIME[2];
				}
			} else {
				if (isUser) {
					return TEST_EVENTS_START_TIME[3];
				} else {
					return isFirstGroup ? TEST_EVENTS_START_TIME[4] : TEST_EVENTS_START_TIME[5];
				}
			}
		} else {
			if (isFirstUser) {
				if (isUser) {
					return TEST_EVENTS_END_TIME[0];
				} else {
					return isFirstGroup ? TEST_EVENTS_END_TIME[1] : TEST_EVENTS_END_TIME[2];
				}
			} else {
				if (isUser) {
					return TEST_EVENTS_END_TIME[3];
				} else {
					return isFirstGroup ? TEST_EVENTS_END_TIME[4] : TEST_EVENTS_END_TIME[5];
				}
			}
		}
	}
	
	/**
	 * Gets the note for specific user/group.
	 * 
	 * @param isUser	true if this note is for a user, false for an group
	 * @param isFirstUser	true for the first user, false otherwise
	 * @param isFirstGroup	true for the first group, false otherwise
	 * @return	the note
	 */
	private static String getNote(boolean isUser, boolean isFirstUser, boolean isFirstGroup) {
		StringBuilder sb = new StringBuilder("test ");
		if (isFirstUser) {
			if (isUser) {
				sb.append("1st user");
			} else {
				if (isFirstGroup) {
					sb.append("1st user 1st group");
				} else {
					sb.append("1st user 2nd group");
				}
			}
		} else {
			if (isUser) {
				sb.append("2nd user");
			} else {
				if (isFirstGroup) {
					sb.append("2nd user 1st group");
				} else {
					sb.append("2nd user 2nd group");
				}
			}
		}

		sb.append(" event");
		return sb.toString();
	}
	
	/**
	 * Gets the user id.
	 * 
	 * @param isFirst	true if this is for the first test user, false for the second test user
	 * @return	the user id
	 */
	private static Long getUserId(boolean isFirst) {
		if (isFirst) {
			return TEST_USER1_ID;
		} else {
			return TEST_USER2_ID;
		}
	}
	
	/**
	 * Gets the group id.
	 * 
	 * @param isFirst	true if this is for the first test group, false for the second test group
	 * @return	the group id
	 */
	private static Long getGroupId(boolean isFirst) {
		if (isFirst) {
			return TEST_GROUP1_ID;
		} else {
			return TEST_GROUP2_ID;
		}
	}
	
	/**
	 * Gets a test user with not active membership status.
	 * 
	 * @return	the test user with not active membership status.
	 */
	private static User getNotActiveUser(Long userId, boolean isFirstGroup) {
		User testUser = getUser(true);
		testUser.setId(userId);
		testUser.setFirstName("Test " + testUser.getId());
		List<Membership> memberships = testUser.getMemberships();
		Membership membership = memberships.get(isFirstGroup ? 0 : 1);
		membership.setMembershipStatus(MembershipStatus.INACTIVE);
		return testUser;
	}
		
	/**
	 * Gets a test user.
	 * 
	 * @param isFirst	true if this is for the first test user, false for the second test user
	 * @return	the test user 
	 */
	private static User getUser(boolean isFirst) {
		User testUser = new User();
		testUser.setVersion(0);
		testUser.setId(getUserId(isFirst));
		testUser.setFirstName("Test");
		testUser.setLastName("The Great");
		testUser.setAddress("X Address");
		testUser.setCity("Vancouver");
		testUser.setRegion("BC");
		testUser.setPostalCode("A2B 4M2");
		testUser.setEmail("runner@thegreat.com");
		testUser.setPhoneNumber("778-1234-567");
		testUser.setPassword("password");
		testUser.setHashedPassword("password");
		testUser.setSalt("123ABCXYZ890");
		testUser.setDateTimeZone(DateTimeZone.forID("America/Los_Angeles"));
		
		List<Membership> memberships = new LinkedList<Membership>();
		testUser.setMemberships(memberships);
		
		Membership membership = new Membership();
		membership.setMembershipStatus(MembershipStatus.ACTIVE);
		membership.setGroup(getGroup(true));
		membership.setUser(testUser);
		memberships.add(membership);
		
		membership = new Membership();
		membership.setMembershipStatus(MembershipStatus.ACTIVE);
		membership.setGroup(getGroup(false));
		membership.setUser(testUser);
		memberships.add(membership);
		
		return testUser;
	}
	
	/**
	 * Gets a test group.
	 * 
	 * @param isFirst	true if this is for the first test group, false for the second test group
	 * @return	the test group
	 */
	private static Group getGroup(boolean isFirst) {
		Group testGroup = new Group();
		testGroup.setVersion(0);
		testGroup.setId(getGroupId(isFirst));
		testGroup.setName("Test Group " + testGroup.getId());
		testGroup.setAddress("Group Address");
		testGroup.setCity("Vancouver");
		testGroup.setRegion("BC");
		testGroup.setPostalCode("A2B 4M2");
		testGroup.setEmail("info@testGroup.com");
		testGroup.setPhoneNumber("604-1234-567");
		return testGroup;
	}

}