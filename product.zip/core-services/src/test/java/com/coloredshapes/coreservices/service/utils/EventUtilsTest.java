/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.utils;

import java.util.LinkedList;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.coloredshapes.coreservices.domain.dto.DateEventDto;
import com.coloredshapes.coreservices.domain.dto.DateEventsDto;
import com.coloredshapes.coreservices.utils.EventUtils;

/**
 * <code>EventUtilsTest</code> class is used for group testing 
 * of <code>EventUtils</code>.
 * 
 * To run this junit with gradle use the following command:
 * cd $PROJ_PATH/core
 * gradle -Dtest.single=** /* /EventUtilsTest* test
 * There must be no spaces between * and / in the command
 */
@RunWith(MockitoJUnitRunner.class)
public class EventUtilsTest {
	
	private final static Long TEST_USER_ID = 1L;
	private final static String TEST_NOTE = "some note";

	/**
	 * Tests compactDateTimeBlocks utility function.
	 */
	@Test
	public void testCompactDateTimeBlocks() {
		DateEventsDto dateEvents = new DateEventsDto();
		dateEvents.setUserId(TEST_USER_ID);
		dateEvents.setDateEvents(new LinkedList<DateEventDto>());
		dateEvents.getDateEvents().add(buildDateEvent(10, 00, 12, 00));
		dateEvents.getDateEvents().add(buildDateEvent(10, 00, 10, 30));
		dateEvents.getDateEvents().add(buildDateEvent(10, 00, 12, 00));
		dateEvents.getDateEvents().add(buildDateEvent(10, 00, 12, 30));
		dateEvents.getDateEvents().add(buildDateEvent(10, 20, 10, 40));
		dateEvents.getDateEvents().add(buildDateEvent(10, 20, 12, 45));
		dateEvents.getDateEvents().add(buildDateEvent(13, 20, 14, 00));
		dateEvents.getDateEvents().add(buildDateEvent(13, 00, 13, 40));
		dateEvents.getDateEvents().add(buildDateEvent(14, 20, 14, 40));
		EventUtils.compactDateEvents(dateEvents);
		
		Assert.assertEquals("Wrong number of compacted date events", 3, dateEvents.getDateEvents().size());
		Assert.assertEquals("Wrong start date for the 1st compacted date event", 
				new DateTime(2010, 06, 15, 10, 0, 0), dateEvents.getDateEvents().get(0).getStartTime());
		Assert.assertEquals("Wrong end date for the 1st compacted date event", 
				new DateTime(2010, 06, 15, 12, 45, 0), dateEvents.getDateEvents().get(0).getEndTime());
		Assert.assertEquals("Wrong start date for the 2nd compacted date event", 
				new DateTime(2010, 06, 15, 13, 0, 0), dateEvents.getDateEvents().get(1).getStartTime());
		Assert.assertEquals("Wrong end date for the 2nd compacted date event", 
				new DateTime(2010, 06, 15, 14, 0, 0), dateEvents.getDateEvents().get(1).getEndTime());
		Assert.assertEquals("Wrong start date for the 3rd compacted date event", 
				new DateTime(2010, 06, 15, 14, 20, 0), dateEvents.getDateEvents().get(2).getStartTime());
		Assert.assertEquals("Wrong end date for the 3rd compacted date event", 
				new DateTime(2010, 06, 15, 14, 40, 0), dateEvents.getDateEvents().get(2).getEndTime());
	}

	/**
	 * Build date event with start and end times.
	 * 
	 * @param startHours	 start hours
	 * @param startMins      start mins
	 * @param endHours       end hours
	 * @param endMins        end mins
	 * @return	the date event
	 */
	private DateEventDto buildDateEvent(int startHours, int startMins, int endHours, int endMins) {
		DateEventDto dateEvent = new DateEventDto();
		dateEvent.setStartTime(new DateTime(2010, 06, 15, startHours, startMins, 0));
		dateEvent.setEndTime(new DateTime(2010, 06, 15, endHours, endMins, 0));
		dateEvent.setNote(TEST_NOTE);
		dateEvent.setUserId(TEST_USER_ID);
		return dateEvent;
	} 

}