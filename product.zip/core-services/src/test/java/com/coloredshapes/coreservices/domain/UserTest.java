/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain;

import org.junit.After;
import org.junit.Before;

public class UserTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }
}
