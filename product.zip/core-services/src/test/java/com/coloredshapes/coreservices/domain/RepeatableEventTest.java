/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.joda.time.LocalTime;
import org.junit.Test;

import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;

public class RepeatableEventTest {
    
	@Test(expected = com.coloredshapes.coreservices.exception.InvalidEventException.class)
    public void testConstructorValidationFailure(){
        LocalTime lt1 = LocalTime.parse("15:00");
        LocalTime lt2 = LocalTime.parse("9:00");
        RepeatableEvent underTest = new RepeatableEvent(DayOfWeek.MON,lt1,lt2);
        underTest.toString(); //should never get here

    }

    @Test
    public void testEqualsAndHashCode(){
        //Create a block with for Monday between 8:00 and 12:00
    	RepeatableEvent firstEvent;
        //Create a block for Monday between 8:00 and 12:00
        firstEvent = new RepeatableEvent(DayOfWeek.MON,new LocalTime(8,00),new LocalTime(12,00));
        //check the equals and hashCode()
        assertEquals(new RepeatableEvent(DayOfWeek.MON,new LocalTime(8,00),new LocalTime(12,00)),firstEvent);
        assertEquals(new RepeatableEvent(DayOfWeek.MON,new LocalTime(8,00),new LocalTime(12,00)).hashCode(),firstEvent.hashCode());
    }

    @Test
    public void testFieldGetters(){
    	RepeatableEvent secondEvent = new RepeatableEvent(DayOfWeek.SUN,LocalTime.parse("11:00"),LocalTime.parse("14:00"));
        DayOfWeek dow = secondEvent.getDayOfWeek();
        LocalTime startTime = secondEvent.getStartTime();
        LocalTime endTime = secondEvent.getEndTime();
        assertEquals(DayOfWeek.SUN,dow);
        assertEquals(11,startTime.getHourOfDay());
        assertEquals(00,startTime.getMinuteOfHour());
        assertEquals(14,endTime.getHourOfDay());
        assertEquals(00,endTime.getMinuteOfHour());

    }

    @Test
    public void testConflictsWith(){
        RepeatableEvent time1 = new RepeatableEvent(DayOfWeek.MON,LocalTime.parse("10:00"),LocalTime.parse("16:00"));
        RepeatableEvent time2 = new RepeatableEvent(DayOfWeek.MON,LocalTime.parse("8:00"),LocalTime.parse("12:00"));
        assertTrue(time1.conflictsWith(time2));
        RepeatableEvent time3 = new RepeatableEvent(DayOfWeek.WED,LocalTime.parse("12:00"),LocalTime.parse("16:00"));
        RepeatableEvent time4 = new RepeatableEvent(DayOfWeek.WED,LocalTime.parse("14:00"),LocalTime.parse("22:00"));
        assertTrue(time3.conflictsWith(time4));
    }
}
