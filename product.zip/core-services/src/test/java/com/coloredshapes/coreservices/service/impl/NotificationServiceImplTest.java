/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.service.impl;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.test.util.ReflectionTestUtils;

import com.coloredshapes.coreservices.domain.dto.TimePeriodDto;
import com.coloredshapes.coreservices.domain.entity.Group;
import com.coloredshapes.coreservices.domain.entity.User;
import com.coloredshapes.coreservices.service.MessageService;

/**
 * <code>NotificationServiceImplTest</code> class is used for group testing 
 * of <code>MessageServiceImpl</code>.
 * 
 * To run this junit with gradle use the following command:
 * cd $PROJ_PATH/core
 * gradle -Dtest.single=** /* /NotificationServiceImplTest* test
 * There must be no spaces between * and / in the command
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationServiceImplTest {
	
	@Mock private MailSender mailSender;

    private static final String NEW_LINE = System.getProperty("line.separator"); 

    @SuppressWarnings("unused") private final static Long TEST_USER1_ID = 1L;
    @SuppressWarnings("unused") private final static Long TEST_USER2_ID = 2L;
    @SuppressWarnings("unused") private final static Long TEST_GROUP_ID = 1L;

	private static User TEST_USER1 = getUser(true);
	private static User TEST_USER2 = getUser(false);
	private static Group TEST_UNIT = getGroup(true);

	private final static DateTime TEST_START_TIME = new DateTime(2010, 06, 15, 10, 0, 0);
	private final static DateTime TEST_END_TIME   = new DateTime(2010, 06, 15, 18, 0, 0);

	
	/**
	 * Tests sendAssignmentsEmail service operation.
	 */
	@Test
	public void testSendAssignmentsEmail() {
		// Prepare the input
		List<User> users = new ArrayList<User>(2);
		users.add(TEST_USER1);
		users.add(TEST_USER2);
		TimePeriodDto timePeriod = new TimePeriodDto(TEST_START_TIME, TEST_END_TIME);

		SimpleMailMessage simpleMessage = new SimpleMailMessage();
		simpleMessage.setFrom("remotesources@gmail.com");
		simpleMessage.setSubject("Shift assignments");

		SimpleMailMessage simpleMessage1 = new SimpleMailMessage();
		simpleMessage1.setTo("runner@thegreat.com");
		simpleMessage1.setFrom("remotesources@gmail.com");
		simpleMessage1.setSubject("Shift assignments");
		simpleMessage1.setText("Dear TestUser1 The Great,"+NEW_LINE+"TestGroup has assigned you shift(s) for the period from 15.06.2010 10:00 to 15.06.2010 18:00."+NEW_LINE);
		
		SimpleMailMessage simpleMessage2 = new SimpleMailMessage();
		simpleMessage2.setTo("runner@thegreat.com");
		simpleMessage2.setFrom("remotesources@gmail.com");
		simpleMessage2.setSubject("Shift assignments");
		simpleMessage2.setText("Dear TestUser2 The Great,"+NEW_LINE+"TestGroup has assigned you shift(s) for the period from 15.06.2010 10:00 to 15.06.2010 18:00."+NEW_LINE);
		
		// Initialize the mocks & their behavior
		reset(mailSender);
		doNothing().when(mailSender).send(eq(simpleMessage1));
		doNothing().when(mailSender).send(eq(simpleMessage2));
		 
		// Prepare the service
		MessageService messageService = new MessageServiceImpl();
		ReflectionTestUtils.setField(messageService, "mailSender", mailSender);
		ReflectionTestUtils.setField(messageService, "templateMessage", simpleMessage);
		
		// Invoke the service operation
		messageService.sendCollectiveMessage(TEST_UNIT, users, timePeriod);
		
		// Verify the mock invoking sequence
		verify(mailSender).send(simpleMessage1);
		verify(mailSender).send(simpleMessage2);
	}

	
	/**
	 * Gets the user key.
	 * 
	 * @param isFirst	true if this is for the first test user, false for the second test user
	 * @return	the user key
	 */
	private static Long getUserId(boolean isFirst) {
		if (isFirst) {
			return 1L;
		} else {
			return 2L;
		}
	}
	
	/**
	 * Gets the group key.
	 * 
	 * @return	the group key
	 */
	private static Long getGroupId() {
		return 1L;
	}

	/**
	 * Gets the test user.
	 * 
	 * @param isFirst	true if this is for the first test user, false for the second test user
	 * @return	the test user 
	 */
	private static User getUser(boolean isFirst) {
		User testUser = new User();
		testUser.setVersion(0);
		testUser.setId(getUserId(isFirst));
		testUser.setFirstName("Test");
		testUser.setLastName("The Great");
		testUser.setAddress("X Address");
		testUser.setCity("Vancouver");
		testUser.setRegion("BC");
		testUser.setPostalCode("A2B 4M2");
		testUser.setEmail("runner@thegreat.com");
		testUser.setPhoneNumber("778-1234-567");
		testUser.setPassword("password");
		testUser.setHashedPassword("password");
		testUser.setSalt("123ABCXYZ890");
		return testUser;
	}
	
	/**
	 * Gets the test group.
	 * 
	 * @param isFirst	true if this is for the first test group, false for the second test group
	 * @return	the test group
	 */
	private static Group getGroup(boolean isFirst) {
		Group testGroup = new Group();
		testGroup.setVersion(0);
		testGroup.setId(getGroupId());
		testGroup.setName("Test Group# " + testGroup.getId());
		testGroup.setAddress("Group Address");
		testGroup.setCity("Vancouver");
		testGroup.setRegion("BC");
		testGroup.setPostalCode("A2B 4M2");
		testGroup.setEmail("info@testGroup.com");
		testGroup.setPhoneNumber("604-1234-567");
		return testGroup;
	}

}