/*
 * Copyright Richard Mardon  2010+
 */
package com.coloredshapes.coreservices.dao;

import java.util.List;

import org.joda.time.LocalTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.coloredshapes.coreservices.domain.entity.RepeatableEvent;
import com.coloredshapes.coreservices.domain.enums.DayOfWeek;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:servlet-context.xml" })
public class RepeatableEventDaoImplTest {
	
	@Autowired
	private RepeatableEventDao repeatableEventDaoImpl;
	
	@Autowired
	private UserDao userDao;
	
	@Test
	public void testGetRepeatableEventStartOrEndBetween(){
		Long userId = 1L;
		DayOfWeek day = DayOfWeek.MON;
		LocalTime start = new LocalTime().minusHours(3);
		LocalTime end = new LocalTime().plusHours(5);
		@SuppressWarnings("unused")
		RepeatableEvent event = repeatableEventDaoImpl
				.getRepeatableEventStartOrEndBetween(day, start, end, userId);
	}
	
	@Test
	public void testGetRepeatableEventByUserId(){
		Long userId = 1L;
		@SuppressWarnings("unused")
		List<RepeatableEvent> events = repeatableEventDaoImpl
				.getRepeatableEventByUserId(userId);
	}
	
	@Test
	public void testCreateRepeatableEvent(){
		RepeatableEvent event = new RepeatableEvent();
		event.setUser(userDao.getUser(1L));
		LocalTime start = new LocalTime();
		LocalTime end = start.plusHours(2);
		event.setStartTime(start);
		event.setEndTime(end);
		event.setNote("dinner with ken");
		DayOfWeek day = DayOfWeek.THU;
		event.setDayOfWeek(day);
		repeatableEventDaoImpl.createRepeatableEvent(event);
	}
	
	@Test
	public void testCreateRepeatableEventBean(){
		RepeatableEvent event = new RepeatableEvent();
		event.setUser(userDao.getUser(1L));
		LocalTime start = new LocalTime();
		LocalTime end = start.plusHours(2);
		event.setStartTime(start);
		event.setEndTime(end);
		event.setNote("shopping");
		DayOfWeek day = DayOfWeek.SUN;
		event.setDayOfWeek(day);
		repeatableEventDaoImpl.create(event);
	}

}