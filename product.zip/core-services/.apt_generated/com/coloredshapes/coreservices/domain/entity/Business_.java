package com.coloredshapes.coreservices.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Business.class)
public abstract class Business_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Business, String> businessName;
	public static volatile SingularAttribute<Business, String> taxNumber;
	public static volatile SingularAttribute<Business, String> businessNumber;
	public static volatile SingularAttribute<Business, String> industry;
	public static volatile SingularAttribute<Business, Group> group;
	public static volatile SingularAttribute<Business, String> incorporatedName;

}

