package com.coloredshapes.coreservices.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(UserConfirmation.class)
public abstract class UserConfirmation_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<UserConfirmation, DateTime> registrationTime;
	public static volatile SingularAttribute<UserConfirmation, String> refNum;
	public static volatile SingularAttribute<UserConfirmation, DateTime> confirmationTime;
	public static volatile SingularAttribute<UserConfirmation, Long> userId;

}

