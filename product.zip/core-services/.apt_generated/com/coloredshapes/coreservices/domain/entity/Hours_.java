package com.coloredshapes.coreservices.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Hours.class)
public abstract class Hours_ {

	public static volatile SingularAttribute<Hours, Double> perMonth;
	public static volatile SingularAttribute<Hours, Double> perWeek;
	public static volatile SingularAttribute<Hours, Double> perYear;
	public static volatile SingularAttribute<Hours, Double> perDay;

}

