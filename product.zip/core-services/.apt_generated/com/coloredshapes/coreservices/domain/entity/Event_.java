package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.SourceType;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Event.class)
public abstract class Event_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Event, String> note;
	public static volatile SingularAttribute<Event, SourceType> sourceType;
	public static volatile SingularAttribute<Event, Assignment> assignment;
	public static volatile SingularAttribute<Event, DateTime> startTime;
	public static volatile SingularAttribute<Event, DateTime> endTime;
	public static volatile SingularAttribute<Event, User> user;
	public static volatile SingularAttribute<Event, Group> group;

}

