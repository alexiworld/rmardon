package com.coloredshapes.coreservices.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Message.class)
public abstract class Message_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Message, Boolean> visibleToSender;
	public static volatile SingularAttribute<Message, User> sender;
	public static volatile SingularAttribute<Message, Boolean> visibleToRecipient;
	public static volatile SingularAttribute<Message, User> recipient;
	public static volatile SingularAttribute<Message, Boolean> opened;
	public static volatile SingularAttribute<Message, MessageContent> content;

}

