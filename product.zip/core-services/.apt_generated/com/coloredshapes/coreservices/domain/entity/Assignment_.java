package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.AssignmentStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Assignment.class)
public abstract class Assignment_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Assignment, Hours> hours;
	public static volatile SingularAttribute<Assignment, Role> role;
	public static volatile SingularAttribute<Assignment, Double> rate;
	public static volatile SingularAttribute<Assignment, User> user;
	public static volatile SingularAttribute<Assignment, Group> group;
	public static volatile SingularAttribute<Assignment, AssignmentStatus> status;

}

