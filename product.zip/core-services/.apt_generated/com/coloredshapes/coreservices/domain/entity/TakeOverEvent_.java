package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.TakeOverStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(TakeOverEvent.class)
public abstract class TakeOverEvent_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<TakeOverEvent, String> note;
	public static volatile SingularAttribute<TakeOverEvent, DateTime> startTime;
	public static volatile SingularAttribute<TakeOverEvent, DateTime> endTime;
	public static volatile SingularAttribute<TakeOverEvent, User> user;
	public static volatile SingularAttribute<TakeOverEvent, TakeOverRequest> takeOverRequest;
	public static volatile SingularAttribute<TakeOverEvent, TakeOverStatus> status;

}

