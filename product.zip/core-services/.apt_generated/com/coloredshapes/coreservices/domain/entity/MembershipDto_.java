package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.dto.MembershipDto;
import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MembershipDto.class)
public abstract class MembershipDto_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<MembershipDto, MembershipStatus> membershipStatus;
	public static volatile SingularAttribute<MembershipDto, Group> group;
	public static volatile SingularAttribute<MembershipDto, User> user;

}

