package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.MembershipRequestStatus;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MembershipRequest.class)
public abstract class MembershipRequest_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<MembershipRequest, Date> confirmationDate;
	public static volatile SingularAttribute<MembershipRequest, Long> groupId;
	public static volatile SingularAttribute<MembershipRequest, String> userEmail;
	public static volatile SingularAttribute<MembershipRequest, Long> userId;
	public static volatile SingularAttribute<MembershipRequest, String> referenceId;
	public static volatile SingularAttribute<MembershipRequest, Date> createDate;
	public static volatile SingularAttribute<MembershipRequest, MembershipRequestStatus> status;

}

