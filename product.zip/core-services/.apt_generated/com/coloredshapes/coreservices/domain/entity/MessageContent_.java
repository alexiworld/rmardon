package com.coloredshapes.coreservices.domain.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MessageContent.class)
public abstract class MessageContent_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<MessageContent, String> subject;
	public static volatile SingularAttribute<MessageContent, String> channel;
	public static volatile SingularAttribute<MessageContent, DateTime> time;
	public static volatile SingularAttribute<MessageContent, String> body;

}

