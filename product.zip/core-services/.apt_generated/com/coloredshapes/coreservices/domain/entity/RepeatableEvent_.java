package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.DayOfWeek;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.LocalTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(RepeatableEvent.class)
public abstract class RepeatableEvent_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<RepeatableEvent, String> note;
	public static volatile SingularAttribute<RepeatableEvent, DayOfWeek> dayOfWeek;
	public static volatile SingularAttribute<RepeatableEvent, LocalTime> startTime;
	public static volatile SingularAttribute<RepeatableEvent, LocalTime> endTime;
	public static volatile SingularAttribute<RepeatableEvent, User> user;

}

