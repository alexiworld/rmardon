package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.MembershipStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Membership.class)
public abstract class Membership_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Membership, MembershipStatus> membershipStatus;
	public static volatile SingularAttribute<Membership, User> user;
	public static volatile SingularAttribute<Membership, Group> group;

}

