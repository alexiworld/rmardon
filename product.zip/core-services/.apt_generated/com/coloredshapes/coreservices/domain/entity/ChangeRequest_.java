package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.entity.ChangeRequest.ChangeRequestStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ChangeRequest.class)
public abstract class ChangeRequest_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<ChangeRequest, Event> event;
	public static volatile SingularAttribute<ChangeRequest, ChangeRequestStatus> status;

}

