package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.UserStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTimeZone;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(User.class)
public abstract class User_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<User, String> lastName;
	public static volatile SingularAttribute<User, String> country;
	public static volatile SingularAttribute<User, Integer> agreementVersion;
	public static volatile SingularAttribute<User, String> address;
	public static volatile SingularAttribute<User, String> salt;
	public static volatile ListAttribute<User, Assignment> assignments;
	public static volatile SingularAttribute<User, String> city;
	public static volatile SingularAttribute<User, String> mobileNumber;
	public static volatile SingularAttribute<User, String> hashedPassword;
	public static volatile SingularAttribute<User, String> postalCode;
	public static volatile ListAttribute<User, Group> groups;
	public static volatile SingularAttribute<User, Boolean> isTempPassword;
	public static volatile ListAttribute<User, Membership> memberships;
	public static volatile SingularAttribute<User, String> firstName;
	public static volatile SingularAttribute<User, String> qualification;
	public static volatile SingularAttribute<User, String> phoneNumber;
	public static volatile SingularAttribute<User, DateTimeZone> dateTimeZone;
	public static volatile ListAttribute<User, RepeatableEvent> repeatableEvents;
	public static volatile SingularAttribute<User, String> shortName;
	public static volatile SingularAttribute<User, String> region;
	public static volatile SingularAttribute<User, String> email;
	public static volatile SingularAttribute<User, UserStatus> status;

}

