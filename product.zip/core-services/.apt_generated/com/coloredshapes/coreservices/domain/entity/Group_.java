package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.GroupStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Group.class)
public abstract class Group_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Group, String> country;
	public static volatile ListAttribute<Group, Assignment> assignments;
	public static volatile SingularAttribute<Group, String> address;
	public static volatile SingularAttribute<Group, String> city;
	public static volatile SingularAttribute<Group, String> mobileNumber;
	public static volatile ListAttribute<Group, Role> roles;
	public static volatile SingularAttribute<Group, DateTime> deactivatedDate;
	public static volatile SingularAttribute<Group, String> postalCode;
	public static volatile SingularAttribute<Group, String> description;
	public static volatile SingularAttribute<Group, Long> parentId;
	public static volatile ListAttribute<Group, Membership> memberships;
	public static volatile ListAttribute<Group, User> users;
	public static volatile SingularAttribute<Group, DateTime> onBoardDate;
	public static volatile SingularAttribute<Group, Group> topGroup;
	public static volatile SingularAttribute<Group, String> phoneNumber;
	public static volatile SingularAttribute<Group, String> name;
	public static volatile ListAttribute<Group, Group> subGroups;
	public static volatile SingularAttribute<Group, String> shortName;
	public static volatile SingularAttribute<Group, String> region;
	public static volatile SingularAttribute<Group, String> email;
	public static volatile SingularAttribute<Group, GroupStatus> status;

}

