package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.TakeOverStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.joda.time.DateTime;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(TakeOverRequest.class)
public abstract class TakeOverRequest_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<TakeOverRequest, String> note;
	public static volatile SingularAttribute<TakeOverRequest, User> acceptedByUser;
	public static volatile SingularAttribute<TakeOverRequest, Long> groupId;
	public static volatile SingularAttribute<TakeOverRequest, DateTime> acceptanceTime;
	public static volatile ListAttribute<TakeOverRequest, TakeOverEvent> takeOverEvents;
	public static volatile SingularAttribute<TakeOverRequest, Group> group;
	public static volatile SingularAttribute<TakeOverRequest, TakeOverStatus> status;

}

