package com.coloredshapes.coreservices.domain.entity;

import com.coloredshapes.coreservices.domain.enums.RoleStatus;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Role.class)
public abstract class Role_ extends com.coloredshapes.coreservices.domain.entity.BaseEntity_ {

	public static volatile SingularAttribute<Role, String> qualification;
	public static volatile SingularAttribute<Role, String> note;
	public static volatile SingularAttribute<Role, Hours> hours;
	public static volatile SingularAttribute<Role, String> color;
	public static volatile SingularAttribute<Role, Double> rate;
	public static volatile SingularAttribute<Role, String> name;
	public static volatile SingularAttribute<Role, String> description;
	public static volatile SingularAttribute<Role, String> shortName;
	public static volatile SingularAttribute<Role, Group> group;
	public static volatile SingularAttribute<Role, RoleStatus> status;

}

